import csv,json,pathlib,hashlib,zipfile
p=pathlib.Path(__file__).parent
targets={'list':0x1c00e54c,'matrix':0x1c00d754,'state':0x1c00d340}
summary=[]
cold=json.loads((p/'results.json').read_text())['rows']
for name,target in targets.items():
    a=list(csv.DictReader((p/('warm_'+name+'.csv')).open()))
    assert len(a)==1024
    for i,r in enumerate(a):
        assert int(r['sample'])==i
        assert all(int(r[k]) in (0,1) for k in ['valid0','valid1','flush','exception','ib_empty','ic_wait','rob_empty','head_wait'])
        if i: assert int(r['cycle'])==int(a[i-1]['cycle'])+1
    r=a[256]
    assert any(int(r['valid'+str(j)]) and int(r['pc'+str(j)],16)==target for j in [0,1])
    counts=[sum(int(r['valid0'])+int(r['valid1'])==n for r in a) for n in range(3)]
    retired=counts[1]+2*counts[2]
    assert sum(counts)==1024
    z=[r for r in a if not (int(r['valid0']) or int(r['valid1']))]
    x=dict(algorithm=name,trigger_pc=f'{target:08X}',start_cycle=int(a[0]['cycle']),trigger_cycle=int(a[256]['cycle']),end_cycle=int(a[-1]['cycle']),samples=1024,trigger_index=256,zero=counts[0],single=counts[1],dual=counts[2],retired=retired,ipc=retired/1024,dual_percent=counts[2]/1024*100,flush=sum(int(r['flush']) for r in a),exception=sum(int(r['exception']) for r in a),zero_and_ic_wait=sum(int(r['ic_wait']) for r in z),zero_and_empty_ib_rob_ic_wait=sum(all(int(r[k]) for k in ['ic_wait','ib_empty','rob_empty']) for r in z))
    x['cold_ipc']=next(y['ipc'] for y in cold if y['algorithm']==name)
    summary.append(x)
with (p/'warm_summary.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
now=list(csv.DictReader((p/'warm_kernel_profile.csv').open()))
old=list(csv.DictReader((p/'kernel_profile.csv').open()))
assert now==old,'Whole-kernel counts changed'
kernel=[]
for r in now:
    r={k:int(v) for k,v in r.items()}
    assert r['cycles']==r['zero']+r['single']+r['dual']
    assert r['retired']==r['single']+2*r['dual']
    r['ipc']=r['retired']/r['cycles']
    kernel.append(r)
assert [r['iterations'] for r in kernel]==[10,100]
d=dict(source_commit='dfb849e6a6df77eb90d1a066c1b8bc3c493f1a08',cpu_hz=125000000,sys_hz=49500000,warmup_iterations=10,sampling_rule='First valid commit at each declared entry in the subsequent 100-iteration kernel call; no post-selection; 1024 consecutive CPU edges, trigger index256, All Data',scope='RTL simulation; local windows retain call context; not board ILA or full >=10-second scoring',windows=summary,kernel=kernel,whole_kernel_counts_reproduced=True)
(p/'warm_results.json').write_text(json.dumps(d,indent=2),encoding='utf8')
print(json.dumps(d,indent=2))

