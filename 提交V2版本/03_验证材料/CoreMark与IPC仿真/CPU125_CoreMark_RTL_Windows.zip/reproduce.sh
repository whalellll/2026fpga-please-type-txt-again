#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
ulimit -c 0
verilator --version > simulator-version.txt
timeout 1200 verilator --binary --timing -Wno-fatal -Wno-BLKANDNBLK --top-module tb_cpu_integration -j 2 -CFLAGS -Os --Mdir obj_dir rtl/cpu/CoreTop.sv rtl/clint.v rtl/cpu_top.v rtl/soc/axi_1x2.v rtl/soc/axi_boot_periph.v rtl/soc/axi_cpu_sys_cdc.v rtl/soc/uart_tx_fifo.v sim/tb_cpu_integration.sv > build.log 2>&1
timeout 600 stdbuf -oL obj_dir/Vtb_cpu_integration +production_coremark +coremark_mode=performance +cpu_hz=125000000 +max_cycles=12000000 > simulation.log 2>&1
python3 analyze.py

