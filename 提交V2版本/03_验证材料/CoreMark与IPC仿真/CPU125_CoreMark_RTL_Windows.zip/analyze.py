import csv, json, hashlib, pathlib, subprocess
root=pathlib.Path(__file__).parent
targets={'list':0x1c00e54c,'matrix':0x1c00d754,'state':0x1c00d340}
rows=[]
for name,target in targets.items():
    with (root/(name+'.csv')).open() as f: data=list(csv.DictReader(f))
    assert len(data)==1024,(name,len(data))
    for i,r in enumerate(data):
        assert int(r['sample'])==i
        if i: assert int(r['cycle'])==int(data[i-1]['cycle'])+1
        assert all(int(r[k]) in (0,1) for k in ['valid0','valid1','flush','exception'])
    trig=data[256]
    assert any(int(trig['valid'+str(j)]) and int(trig['pc'+str(j)],16)==target for j in [0,1]),(name,trig)
    counts=[sum(int(r['valid0'])+int(r['valid1'])==n for r in data) for n in range(3)]
    retired=counts[1]+2*counts[2]
    assert sum(counts)==1024
    rows.append(dict(algorithm=name,trigger_pc=f'{target:08X}',samples=1024,trigger_index=256,
        start_cycle=int(data[0]['cycle']),trigger_cycle=int(trig['cycle']),end_cycle=int(data[-1]['cycle']),
        zero=counts[0],single=counts[1],dual=counts[2],retired=retired,ipc=retired/1024,
        dual_percent=counts[2]/1024*100,flush=sum(int(r['flush']) for r in data),
        exception=sum(int(r['exception']) for r in data)))
inputs=['rtl/cpu/CoreTop.sv','rtl/clint.v','rtl/cpu_top.v','rtl/soc/axi_1x2.v','rtl/soc/axi_boot_periph.v','rtl/soc/axi_cpu_sys_cdc.v','rtl/soc/uart_tx_fifo.v','sim/tb_cpu_integration.sv','artifacts/bootrom.hex','artifacts/bootloader.elf']
hashes={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in inputs}
assert hashes['rtl/cpu/CoreTop.sv']=='97abbc7927c1736f0d0241525b6ecafc2654f21e89f73019846d0da156ccef31'
assert hashes['artifacts/bootloader.elf']=='404b6278419ab8686a9b0cc72144ce04c6e477a82fa4553c7b95fc435062205c'
report=dict(scope='RTL simulation; first committed entry at each declared trigger; not board ILA',commit='dfb849e6a6df77eb90d1a066c1b8bc3c493f1a08',cpu_hz=125000000,sys_hz=49500000,firmware='unmodified released automatic-calibration ROM',sampling='posedge cpu_clk, pre-NBA, 64-bit, All Data',rows=rows,sha256=hashes)
(root/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
with (root/'summary.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(json.dumps(report,ensure_ascii=False,indent=2))

