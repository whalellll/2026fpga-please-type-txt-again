# CPU125 CoreMark 首轮连续窗口 RTL 仿真结果

版本：performance_soc 固定提交 dfb849e6a6df77eb90d1a066c1b8bc3c493f1a08；CPU125MHz、SYS49.5MHz；performance 模式。

使用未经改动的发布 CPU RTL 和发布自动校准 ROM。触发选择为启动 CoreMark 后各指定 PC 的首次有效提交，处于首轮自动校准调用；窗口包含冷启动/缓存状态和调用上下文，不是完整函数或完整 CoreMark 的平均 IPC。

每组1024个连续CPU周期；触发样点序号256，从0计数；CPU上升沿读取边沿前提交信号；All Data，包含零提交周期。PC按PC[31:2]恢复低两位0，并仅在对应valid为1时计提交。

| 窗口 | 触发PC | 零提交 | 单提交 | 双提交 | 提交数 | IPC | flush高样点 | 提交异常 |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| 链表 | 1C00E54C | 859 | 105 | 60 | 225 | 0.219727 | 8 | 0 |
| 矩阵 | 1C00D754 | 556 | 134 | 334 | 802 | 0.783203 | 10 | 0 |
| 状态转换 | 1C00D340 | 959 | 44 | 21 | 86 | 0.083984 | 7 | 0 |

双提交周期占比：链表5.86%、矩阵32.62%、状态转换2.05%。该矩阵窗口IPC未超过1。零提交只说明该周期没有有效提交，不能据此直接归因为某种阻塞。

## 触发语义

- 链表：core_bench_list 入口 1C00E54C。
- 矩阵：LTO内联后的 calc_func flag=1 分支首条指令 1C00D754；core_list_join.c 的 case 1 调用 core_bench_matrix，对应 calc.dis 中 1C00D750 分支后路径。
- 状态转换：core_state_transition 入口 1C00D340。
- 本轮触发点已按当前ELF确认；旧表的矩阵/状态机PC落在新版printf内部，旧表与本表不是相同代码地址或相同缓存状态的A/B对比。

## 实际执行与验证

- Verilator 5.020，WSL Ubuntu；实际命令见 reproduce.sh。CPU代码SHA256和ELF SHA256均与冻结版本一致，ROM SHA256也与发布位流固件清单一致。
- 已实际编译并运行，simulation.log 含三次 CAPTURE_DONE 和 CPU125_THREE_CONTINUOUS_WINDOWS_COMPLETE，正常 $finish。
- analyze.py 核验每组1024行、样点序号、CPU周期连续、触发位于256且valid/PC匹配、零/单/双计数和为1024，提交数=单+2×双。
- 启动诊断发现本机旧仿真器将 procedural force 的右侧值只在语句执行时取值，使原测试台启动加速计时停住。仅在测试台、原release之前按SYS下降沿刷新同一force；release前先关闭刷新。原CPU/CLINT RTL不变。release后原测试台仍逐SYS周期断言mtime递增1，所有采样均发生在release之后。
- 失败启动记录保留为 simulation_attempt1.log、diagnostic.log；这些超时记录没有纳入统计。

## 适用范围

这些是 RTL 仿真结果，不是 Fabric Inserter/ILA 实板捕获。不验证插核后物理时序、实际FPGA/DDR/外设等待；本轮在三组捕获完成后结束，未完成正式CoreMark全程评分或新的全程CRC验收。

## 原始数据与来源

list.csv、matrix.csv、state.csv 为原始连续采样；results.json 为带源码哈希的结果；evidence-manifest.json 绑定所有复现输入和输出；reproduce.sh 可从本目录重建复现。

https://github.com/whalellll/performance_soc/tree/dfb849e6a6df77eb90d1a066c1b8bc3c493f1a08
