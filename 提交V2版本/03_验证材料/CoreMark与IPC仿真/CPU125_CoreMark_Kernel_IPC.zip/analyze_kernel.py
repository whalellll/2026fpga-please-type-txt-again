import csv,json,pathlib,hashlib,zipfile
p=pathlib.Path(__file__).parent
windows=[]
for name in ['list','matrix','state']:
    a=list(csv.DictReader((p/('profile_'+name+'.csv')).open()))
    b=list(csv.DictReader((p/(name+'.csv')).open()))
    assert len(a)==len(b)==1024
    assert all(all(x[k]==y[k] for k in y) for x,y in zip(a,b)),name
    zero=[r for r in a if int(r['valid0'])+int(r['valid1'])==0]
    zlen=max(map(len,''.join('0' if int(r['valid0'])+int(r['valid1'])==0 else '1' for r in a).split('1')))
    obj=dict(algorithm=name,zero=len(zero),longest_zero_run=zlen)
    for k in ['ib_empty','ic_wait','rob_empty','head_wait']:
        obj['zero_and_'+k]=sum(int(r[k]) for r in zero)
    obj['zero_frontend_refill_and_empty_rob']=sum(all(int(r[k]) for k in ['ic_wait','ib_empty','rob_empty']) for r in zero)
    windows.append(obj)
kernel=[]
for r in csv.DictReader((p/'kernel_profile.csv').open()):
    x={k:int(v) for k,v in r.items()}
    assert x['cycles']==x['zero']+x['single']+x['dual']
    assert x['retired']==x['single']+2*x['dual']
    assert x['list_calls']==2*x['iterations']
    x['ipc']=x['retired']/x['cycles']
    x['duration_seconds']=x['cycles']/125000000
    kernel.append(x)
assert [x['iterations'] for x in kernel]==[10,100],kernel
d=dict(source_commit='dfb849e6a6df77eb90d1a066c1b8bc3c493f1a08',scope='RTL simulation; complete iterate kernel calls during unchanged production ROM auto-calibration; not full >=10-second scoring run',cpu_hz=125000000,sys_hz=49500000,kernel=kernel,windows=windows)
(p/'kernel_results.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(d,indent=2))

