/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2026 The Stockfish developers (see AUTHORS file)

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef HISTORY_H_INCLUDED
#define HISTORY_H_INCLUDED

#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <limits>
#include <type_traits>  // IWYU pragma: keep

#include "memory.h"
#include "misc.h"
#include "position.h"

namespace Stockfish {

constexpr int PAWN_HISTORY_BASE_SIZE   = 8192;  // has to be a power of 2
constexpr int UINT_16_HISTORY_SIZE     = std::numeric_limits<u16>::max() + 1;
constexpr int CORRHIST_BASE_SIZE       = UINT_16_HISTORY_SIZE;
constexpr int CORRECTION_HISTORY_LIMIT = 1024;
constexpr int LOW_PLY_HISTORY_SIZE     = 5;

static_assert((PAWN_HISTORY_BASE_SIZE & (PAWN_HISTORY_BASE_SIZE - 1)) == 0,
              "PAWN_HISTORY_BASE_SIZE has to be a power of 2");

static_assert((CORRHIST_BASE_SIZE & (CORRHIST_BASE_SIZE - 1)) == 0,
              "CORRHIST_BASE_SIZE has to be a power of 2");

// StatsEntry is the container of various numerical statistics. We use a class
// instead of a naked value to directly call history update operator<<() on
// the entry. The first template parameter T is the base type of the array,
// and the second template parameter D limits the range of updates in [-D, D]
// when we update values with the << operator
template<typename T, int D, bool Shared = false, int InitialValue = 0>
struct StatsEntry {
    static_assert(std::is_integral_v<T> && std::is_signed_v<T>, "Not a signed integer type");
    static_assert(D > 0 && D <= std::numeric_limits<T>::max()
                    && D <= std::numeric_limits<int>::max() / D,
                  "D can lead to overflows");

   private:
#if defined(PIKAFISH_EMBEDDED_SINGLE_THREAD)
    // Embedded history tables are touched only by the sole search worker.
    // Other cross-thread state keeps using RelaxedAtomic normally.
    using EntryStorage = T;
#else
    using EntryStorage = std::conditional_t<Shared, RelaxedAtomic<T>, T>;
#endif
    EntryStorage entry;

   public:
    void operator=(const T& v) {
        const int encoded = int(v) - InitialValue;
        assert(encoded >= std::numeric_limits<T>::min()
               && encoded <= std::numeric_limits<T>::max());
        entry = T(encoded);
    }

    operator T() const { return T(int(T(entry)) + InitialValue); }

    void operator<<(int bonus) {
        // Make sure that bonus is in range [-D, D]
        int clampedBonus = std::clamp(bonus, -D, D);
        T   val          = *this;
        *this            = val + clampedBonus - val * std::abs(clampedBonus) / D;

        assert(std::abs(T(*this)) <= D);
    }
};

enum StatsType {
    NoCaptures,
    Captures
};

template<typename T, int D, usize... Sizes>
using Stats = MultiArray<StatsEntry<T, D>, Sizes...>;

template<typename T, int D, usize... Sizes>
using AtomicStats = MultiArray<StatsEntry<T, D, true>, Sizes...>;

template<typename T, int D, int InitialValue, usize... Sizes>
using OffsetStats = MultiArray<StatsEntry<T, D, false, InitialValue>, Sizes...>;

template<typename T, int D, int InitialValue, usize... Sizes>
using OffsetAtomicStats = MultiArray<StatsEntry<T, D, true, InitialValue>, Sizes...>;

// DynStats is a dynamically sized array of Stats, used for thread-shared histories
// which should scale with the total number of threads. The SizeMultiplier gives
// the per-thread allocation count of T.
template<typename T, int SizeMultiplier, int InitialValue = 0>
struct DynStats {
    explicit DynStats(usize s) {
        size = s * SizeMultiplier;
#if defined(PIKAFISH_EMBEDDED_SINGLE_THREAD)
        data = make_unique_large_page_fresh_zero<T[]>(size);
#else
        data = make_unique_large_page<T[]>(size);
#endif
    }
    // Sets all values in the range to 0
    void clear_range(int value, usize threadIdx, usize numaTotal) {
        usize start = u64(threadIdx) * size / numaTotal;
        assert(start < size);
        usize end = threadIdx + 1 == numaTotal ? size : u64(threadIdx + 1) * size / numaTotal;

#if defined(PIKAFISH_EMBEDDED_SINGLE_THREAD)
        if (value == InitialValue)
        {
            static_assert(std::is_trivially_copyable_v<T>);
            std::memset(data.get() + start, 0, (end - start) * sizeof(T));
            return;
        }
#endif
        while (start < end)
            data[start++].fill(value);
    }
    usize get_size() const { return size; }
    T&    operator[](usize index) {
        assert(index < size);
        return data.get()[index];
    }
    const T& operator[](usize index) const {
        assert(index < size);
        return data.get()[index];
    }

   private:
    usize             size;
    LargePagePtr<T[]> data;
};

// ButterflyHistory records how often quiet moves have been successful or unsuccessful
// during the current search, and is used for reduction and move ordering decisions.
// It uses 2 tables (one for each color) indexed by the move's from and to squares,
// see https://www.chessprogramming.org/Butterfly_Boards
#if defined(PIKAFISH_EMBEDDED_SINGLE_THREAD)
using ButterflyHistory = OffsetStats<i16, 7183, -5, COLOR_NB, UINT_16_HISTORY_SIZE>;
#else
using ButterflyHistory = Stats<i16, 7183, COLOR_NB, UINT_16_HISTORY_SIZE>;
#endif

// LowPlyHistory is addressed by ply and move's from and to squares, used
// to improve move ordering near the root
using LowPlyHistory = Stats<i16, 7183, LOW_PLY_HISTORY_SIZE, UINT_16_HISTORY_SIZE>;

// CapturePieceToHistory is addressed by a move's [piece][to][captured piece type]
#if defined(PIKAFISH_EMBEDDED_SINGLE_THREAD)
using CapturePieceToHistory =
  OffsetStats<i16, 10692, -607, PIECE_NB, SQUARE_NB, PIECE_TYPE_NB>;
#else
using CapturePieceToHistory = Stats<i16, 10692, PIECE_NB, SQUARE_NB, PIECE_TYPE_NB>;
#endif

// PieceToHistory is like ButterflyHistory but is addressed by a move's [piece][to]
#if defined(PIKAFISH_EMBEDDED_SINGLE_THREAD)
using PieceToHistory = OffsetAtomicStats<i16, 30000, -436, PIECE_NB, SQUARE_NB>;
#else
using PieceToHistory = AtomicStats<i16, 30000, PIECE_NB, SQUARE_NB>;
#endif

// ContinuationHistory is the combined history of a given pair of moves, usually
// the current one given a previous one. The nested history table is based on
// PieceToHistory instead of ButterflyBoards.
using ContinuationHistory = MultiArray<PieceToHistory, PIECE_NB, SQUARE_NB>;

// PawnHistory is addressed by the pawn structure and a move's [piece][to]
#if defined(PIKAFISH_EMBEDDED_SINGLE_THREAD)
using PawnHistory =
  DynStats<OffsetAtomicStats<i16, 8192, -1247, PIECE_NB, SQUARE_NB>,
           PAWN_HISTORY_BASE_SIZE, -1247>;
#else
using PawnHistory = DynStats<AtomicStats<i16, 8192, PIECE_NB, SQUARE_NB>, PAWN_HISTORY_BASE_SIZE>;
#endif

// Correction histories record differences between the static evaluation of
// positions and their search score. It is used to improve the static evaluation
// used by some search heuristics.
// see https://www.chessprogramming.org/Static_Evaluation_Correction_History
enum CorrHistType {
    PieceTo,       // By [piece][to] move
    Continuation,  // Combined history of move pairs
};

template<typename T, int D, int InitialValue = 0>
struct CorrectionBundle {
    StatsEntry<T, D, true, InitialValue> pawn;
    StatsEntry<T, D, true, InitialValue> minor;
    StatsEntry<T, D, true, InitialValue> nonPawnWhite;
    StatsEntry<T, D, true, InitialValue> nonPawnBlack;

    void operator=(T val) {
        pawn         = val;
        minor        = val;
        nonPawnWhite = val;
        nonPawnBlack = val;
    }
};

namespace Detail {

template<CorrHistType>
struct CorrHistTypedef;

template<>
struct CorrHistTypedef<PieceTo> {
#if defined(PIKAFISH_EMBEDDED_SINGLE_THREAD)
    using type = OffsetStats<i16, CORRECTION_HISTORY_LIMIT, 7, PIECE_NB, SQUARE_NB>;
#else
    using type = Stats<i16, CORRECTION_HISTORY_LIMIT, PIECE_NB, SQUARE_NB>;
#endif
};

template<>
struct CorrHistTypedef<Continuation> {
    using type = MultiArray<CorrHistTypedef<PieceTo>::type, PIECE_NB, SQUARE_NB>;
};

}

#if defined(PIKAFISH_EMBEDDED_SINGLE_THREAD)
using UnifiedCorrectionHistory =
  DynStats<MultiArray<CorrectionBundle<i16, CORRECTION_HISTORY_LIMIT, -6>, COLOR_NB>,
           CORRHIST_BASE_SIZE, -6>;
#else
using UnifiedCorrectionHistory =
  DynStats<MultiArray<CorrectionBundle<i16, CORRECTION_HISTORY_LIMIT>, COLOR_NB>,
           CORRHIST_BASE_SIZE>;
#endif

template<CorrHistType T>
using CorrectionHistory = typename Detail::CorrHistTypedef<T>::type;

using TTMoveHistory = StatsEntry<i16, 8192>;

struct ContinuationHistoryBlock {
    ContinuationHistory table[2][2];
};

// Set of histories shared between groups of threads. To avoid excessive
// cross-node data transfer, histories are shared only between threads
// on a given NUMA node. The passed size must be a power of two to make
// the indexing more efficient.
struct SharedHistories {
    SharedHistories(usize threadCount) :
        correctionHistory(threadCount),
#if defined(PIKAFISH_EMBEDDED_SINGLE_THREAD)
        continuationHistoryBlock(
          make_unique_large_page_fresh_zero<ContinuationHistoryBlock>()),
#else
        continuationHistoryBlock(make_unique_large_page<ContinuationHistoryBlock>()),
#endif
        pawnHistory(threadCount) {
        assert((threadCount & (threadCount - 1)) == 0 && threadCount != 0);
        sizeMinus1         = correctionHistory.get_size() - 1;
        pawnHistSizeMinus1 = pawnHistory.get_size() - 1;
    }

    auto& continuationHistory() { return continuationHistoryBlock->table; }

    usize get_size() const { return sizeMinus1 + 1; }

    auto& pawn_entry(const Position& pos) {
        return pawnHistory[pos.pawn_key() & pawnHistSizeMinus1];
    }
    const auto& pawn_entry(const Position& pos) const {
        return pawnHistory[pos.pawn_key() & pawnHistSizeMinus1];
    }

    auto& pawn_correction_entry(const Position& pos) {
        return correctionHistory[pos.pawn_key() & sizeMinus1];
    }
    const auto& pawn_correction_entry(const Position& pos) const {
        return correctionHistory[pos.pawn_key() & sizeMinus1];
    }

    auto& minor_piece_correction_entry(const Position& pos) {
        return correctionHistory[pos.minor_piece_key() & sizeMinus1];
    }
    const auto& minor_piece_correction_entry(const Position& pos) const {
        return correctionHistory[pos.minor_piece_key() & sizeMinus1];
    }

    template<Color c>
    auto& nonpawn_correction_entry(const Position& pos) {
        return correctionHistory[pos.non_pawn_key(c) & sizeMinus1];
    }
    template<Color c>
    const auto& nonpawn_correction_entry(const Position& pos) const {
        return correctionHistory[pos.non_pawn_key(c) & sizeMinus1];
    }

    UnifiedCorrectionHistory               correctionHistory;
    LargePagePtr<ContinuationHistoryBlock> continuationHistoryBlock;
    PawnHistory                            pawnHistory;


   private:
    usize sizeMinus1, pawnHistSizeMinus1;
};

}  // namespace Stockfish

#endif  // #ifndef HISTORY_H_INCLUDED
