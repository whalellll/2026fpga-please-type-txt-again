module way_512x32(
  input  [8:0]  R0_addr,
  input         R0_en,
                R0_clk,
  output [31:0] R0_data,
  input  [8:0]  W0_addr,
  input         W0_en,
                W0_clk,
  input  [31:0] W0_data
);

  reg [31:0] Memory[0:511] /* synthesis syn_ramstyle = "block_ram" */;
  reg        _R0_en_d0;
  reg [8:0]  _R0_addr_d0;
  always @(posedge R0_clk) begin
    _R0_en_d0 <= R0_en;
    _R0_addr_d0 <= R0_addr;
  end
  always @(posedge W0_clk) begin
    if (W0_en & 1'h1)
      Memory[W0_addr] <= W0_data;
  end
  assign R0_data = _R0_en_d0 ? Memory[_R0_addr_d0] : 32'bx;
endmodule

module way_512x20(
  input  [8:0]  R0_addr,
  input         R0_en,
                R0_clk,
  output [19:0] R0_data,
  input  [8:0]  W0_addr,
  input         W0_en,
                W0_clk,
  input  [19:0] W0_data
);

  reg [19:0] Memory[0:511] /* synthesis syn_ramstyle = "block_ram" */;
  reg        _R0_en_d0;
  reg [8:0]  _R0_addr_d0;
  always @(posedge R0_clk) begin
    _R0_en_d0 <= R0_en;
    _R0_addr_d0 <= R0_addr;
  end
  always @(posedge W0_clk) begin
    if (W0_en & 1'h1)
      Memory[W0_addr] <= W0_data;
  end
  assign R0_data = _R0_en_d0 ? Memory[_R0_addr_d0] : 20'bx;
endmodule

module replacement_512x1(
  input  [8:0] R0_addr,
  input        R0_en,
               R0_clk,
  output       R0_data,
  input  [8:0] W0_addr,
  input        W0_en,
               W0_clk,
               W0_data
);

  reg Memory[0:511] /* synthesis syn_ramstyle = "block_ram" */;
  always @(posedge W0_clk) begin
    if (W0_en & 1'h1)
      Memory[W0_addr] <= W0_data;
  end
  assign R0_data = R0_en ? Memory[R0_addr] : 1'bx;
endmodule

module bht_256x3(
  input  [7:0] R0_addr,
  input        R0_en,
               R0_clk,
  output [2:0] R0_data,
  input  [7:0] R1_addr,
  input        R1_en,
               R1_clk,
  output [2:0] R1_data,
  input  [7:0] R2_addr,
  input        R2_en,
               R2_clk,
  output [2:0] R2_data,
  input  [7:0] R3_addr,
  input        R3_en,
               R3_clk,
  output [2:0] R3_data,
  input  [7:0] R4_addr,
  input        R4_en,
               R4_clk,
  output [2:0] R4_data,
  input  [7:0] W0_addr,
  input        W0_en,
               W0_clk,
  input  [2:0] W0_data
);

  reg [2:0] Memory[0:255];
  always @(posedge W0_clk) begin
    if (W0_en & 1'h1)
      Memory[W0_addr] <= W0_data;
  end
  assign R0_data = R0_en ? Memory[R0_addr] : 3'bx;
  assign R1_data = R1_en ? Memory[R1_addr] : 3'bx;
  assign R2_data = R2_en ? Memory[R2_addr] : 3'bx;
  assign R3_data = R3_en ? Memory[R3_addr] : 3'bx;
  assign R4_data = R4_en ? Memory[R4_addr] : 3'bx;
endmodule

module btb_64x57(
  input  [5:0]  R0_addr,
  input         R0_en,
                R0_clk,
  output [56:0] R0_data,
  input  [5:0]  R1_addr,
  input         R1_en,
                R1_clk,
  output [56:0] R1_data,
  input  [5:0]  R2_addr,
  input         R2_en,
                R2_clk,
  output [56:0] R2_data,
  input  [5:0]  W0_addr,
  input         W0_en,
                W0_clk,
  input  [56:0] W0_data
);

  reg [56:0] Memory[0:63];
  always @(posedge W0_clk) begin
    if (W0_en & 1'h1)
      Memory[W0_addr] <= W0_data;
  end
  assign R0_data = R0_en ? Memory[R0_addr] : 57'bx;
  assign R1_data = R1_en ? Memory[R1_addr] : 57'bx;
  assign R2_data = R2_en ? Memory[R2_addr] : 57'bx;
endmodule

module ras_4x32(
  input  [1:0]  R0_addr,
  input         R0_en,
                R0_clk,
  output [31:0] R0_data,
  input  [1:0]  W0_addr,
  input         W0_en,
                W0_clk,
  input  [31:0] W0_data
);

  reg [31:0] Memory[0:3];
  always @(posedge W0_clk) begin
    if (W0_en & 1'h1)
      Memory[W0_addr] <= W0_data;
  end
  assign R0_data = R0_en ? Memory[R0_addr] : 32'bx;
endmodule

module fetch2_frontend_soc(
  input         clk,
                rst,
                stall_i,
                invalidate_req_i,
  output        invalidate_req_ready_o,
                invalidate_done_o,
  input         redirect_valid_i,
  input  [31:0] redirect_pc_i,
  input         resolve_valid_i,
                resolve_is_branch_i,
  input  [31:0] resolve_pc_i,
  input         resolve_taken_i,
  input  [31:0] resolve_target_i,
  input         bht_extra_valid_i,
  input  [31:0] bht_extra_pc_i,
  input         bht_extra_taken_i,
                ras_update0_valid_i,
                ras_update0_pop_i,
                ras_update0_push_i,
  input  [31:0] ras_update0_addr_i,
  input         ras_update1_valid_i,
                ras_update1_pop_i,
                ras_update1_push_i,
  input  [31:0] ras_update1_addr_i,
  output        slot0_valid_o,
  output [31:0] slot0_pc_o,
                slot0_inst_o,
  output        slot0_pred_taken_o,
  output [31:0] slot0_pred_target_o,
  output        slot1_valid_o,
  output [31:0] slot1_pc_o,
                slot1_inst_o,
  output        slot1_pred_taken_o,
  output [31:0] slot1_pred_target_o,
  output        slot0_access_fault_o,
                imem_cmd_valid_o,
  input         imem_cmd_ready_i,
  output [31:0] imem_cmd_addr_o,
  input         imem_rsp_valid_i,
  output        imem_rsp_ready_o,
  input  [31:0] imem_rsp_data_i,
  input         imem_rsp_last_i,
                imem_rsp_error_i
);

  wire [31:0]      _ras_odd_stack_ext_R0_data;
  wire [31:0]      _ras_even_stack_ext_R0_data;
  wire [56:0]      _btb_ext_R0_data;
  wire [56:0]      _btb_ext_R1_data;
  wire [56:0]      _btb_ext_R2_data;
  wire [2:0]       _bht_ext_R0_data;
  wire [2:0]       _bht_ext_R1_data;
  wire [2:0]       _bht_ext_R2_data;
  wire [2:0]       _bht_ext_R3_data;
  wire [2:0]       _bht_ext_R4_data;
  wire             _replacement_ext_R0_data;
  wire [19:0]      _way1_tag_next_ext_R0_data;
  wire [19:0]      _way1_tag_ext_R0_data;
  wire [31:0]      _way1_data3_next_ext_R0_data;
  wire [31:0]      _way1_data3_ext_R0_data;
  wire [31:0]      _way1_data2_next_ext_R0_data;
  wire [31:0]      _way1_data2_ext_R0_data;
  wire [31:0]      _way1_data1_next_ext_R0_data;
  wire [31:0]      _way1_data1_ext_R0_data;
  wire [31:0]      _way1_data0_next_ext_R0_data;
  wire [31:0]      _way1_data0_ext_R0_data;
  wire [19:0]      _way0_tag_next_ext_R0_data;
  wire [19:0]      _way0_tag_ext_R0_data;
  wire [31:0]      _way0_data3_next_ext_R0_data;
  wire [31:0]      _way0_data3_ext_R0_data;
  wire [31:0]      _way0_data2_next_ext_R0_data;
  wire [31:0]      _way0_data2_ext_R0_data;
  wire [31:0]      _way0_data1_next_ext_R0_data;
  wire [31:0]      _way0_data1_ext_R0_data;
  wire [31:0]      _way0_data0_next_ext_R0_data;
  wire [31:0]      _way0_data0_ext_R0_data;
  reg              invalidate_done_o_out_reg;
  reg  [31:0]      lookup_pc_q;
  reg              lookup_valid_q;
  reg  [31:0]      auxiliary_line_addr_q;
  reg  [31:0]      pending_pc;
  reg              scrub_active;
  reg  [8:0]       scrub_index;
  reg              invalidate_inflight_q;
  reg              invalidate_wait_refill_q;
  reg              refill_active;
  reg  [31:0]      refill_base;
  reg  [8:0]       refill_index;
  reg  [18:0]      refill_tag;
  reg              refill_way;
  reg  [1:0]       refill_word;
  reg              refill_cmd_sent_q;
  reg              refill_killed_q;
  reg              refill_error_q;
  reg              fault_pending_q;
  reg  [31:0]      fault_pc_q;
  wire             lookup_executable =
    {1'h0, lookup_pc_q} > 33'h1BFFFFFF & {1'h0, lookup_pc_q} + 33'h3 < 33'h1C020000;
  wire             way0_hit =
    lookup_valid_q & _way0_tag_ext_R0_data[19]
    & _way0_tag_ext_R0_data[18:0] == lookup_pc_q[31:13];
  wire             hit_way =
    lookup_valid_q & _way1_tag_ext_R0_data[19]
    & _way1_tag_ext_R0_data[18:0] == lookup_pc_q[31:13];
  wire             cache_hit = way0_hit | hit_way;
  wire             auxiliary_hit_way =
    lookup_valid_q & _way1_tag_next_ext_R0_data[19]
    & _way1_tag_next_ext_R0_data[18:0] == auxiliary_line_addr_q[31:13];
  wire             auxiliary_line_hit =
    lookup_valid_q & _way0_tag_next_ext_R0_data[19]
    & _way0_tag_next_ext_R0_data[18:0] == auxiliary_line_addr_q[31:13]
    | auxiliary_hit_way;
  wire             selected_refill_way =
    _way0_tag_ext_R0_data[19] & (~(_way1_tag_ext_R0_data[19]) | _replacement_ext_R0_data);
  wire             _imem_cmd_valid_o_output =
    refill_active & ~refill_cmd_sent_q & ~refill_killed_q;
  wire             _imem_rsp_ready_o_output =
    refill_active & refill_cmd_sent_q & ~redirect_valid_i;
  wire             refill_take = imem_rsp_valid_i & _imem_rsp_ready_o_output;
  wire             refill_finish = refill_take & (imem_rsp_last_i | (&refill_word));
  wire             refill_failed_now =
    refill_error_q | imem_rsp_error_i | imem_rsp_last_i & refill_word != 2'h3
    | ~imem_rsp_last_i & (&refill_word);
  wire [3:0][31:0] _GEN =
    hit_way
      ? {{_way1_data3_ext_R0_data},
         {_way1_data2_ext_R0_data},
         {_way1_data1_ext_R0_data},
         {_way1_data0_ext_R0_data}}
      : {{_way0_data3_ext_R0_data},
         {_way0_data2_ext_R0_data},
         {_way0_data1_ext_R0_data},
         {_way0_data0_ext_R0_data}};
  wire [31:0]      fetch_inst0 = _GEN[lookup_pc_q[3:2]];
  wire [3:0][31:0] _GEN_0 =
    {{auxiliary_hit_way ? _way1_data0_next_ext_R0_data : _way0_data0_next_ext_R0_data},
     {hit_way ? _way1_data3_ext_R0_data : _way0_data3_ext_R0_data},
     {hit_way ? _way1_data2_ext_R0_data : _way0_data2_ext_R0_data},
     {hit_way ? _way1_data1_ext_R0_data : _way0_data1_ext_R0_data}};
  wire [31:0]      fetch_inst1 = _GEN_0[lookup_pc_q[3:2]];
  wire             _pred0_taken_T_5 = fetch_inst0[6:0] == 7'h63;
  wire             _pred0_taken_T = fetch_inst0[6:0] == 7'h6F;
  wire             _pred0_target_T = fetch_inst0[6:0] == 7'h67;
  wire             _writes0_T_3 = fetch_inst0[6:0] == 7'h3;
  wire             _known0_T_5 = fetch_inst0[6:0] == 7'h23;
  wire             _writes0_T = fetch_inst0[6:0] == 7'h33;
  wire             mdu0 = _writes0_T & fetch_inst0[31:25] == 7'h1;
  wire             fast_mul0 = mdu0 & fetch_inst0[14:12] == 3'h0;
  wire             _writes0_T_13 = fetch_inst0[6:0] == 7'h73;
  wire             _known0_T_19 = fetch_inst0[6:0] == 7'hF;
  wire             _writes0_T_1 = fetch_inst0[6:0] == 7'h13;
  wire             _writes0_T_9 = fetch_inst0[6:0] == 7'h37;
  wire             _writes0_T_11 = fetch_inst0[6:0] == 7'h17;
  wire             serial0 =
    _writes0_T_13 | _known0_T_19 | mdu0 & ~fast_mul0
    | ~(_writes0_T | _writes0_T_1 | _writes0_T_3 | _known0_T_5 | _pred0_taken_T_5
        | _pred0_taken_T | _pred0_target_T | _writes0_T_9 | _writes0_T_11 | _writes0_T_13
        | _known0_T_19);
  wire             writes0 =
    (_writes0_T | _writes0_T_1 | _writes0_T_3 | _pred0_taken_T | _pred0_target_T
     | _writes0_T_9 | _writes0_T_11 | _writes0_T_13) & (|(fetch_inst0[11:7]));
  wire             forwardable0 = writes0 & fetch_inst0[6:0] != 7'h3 & ~serial0;
  reg              bht_init_active_q;
  reg  [7:0]       bht_init_index_q;
  reg              bht_pending_valid_q;
  reg  [7:0]       bht_pending_index_q;
  reg  [2:0]       bht_pending_data_q;
  reg              train_valid_q;
  reg              train_is_branch_q;
  reg  [31:0]      train_pc_q;
  reg              train_taken_q;
  reg  [31:0]      train_target_q;
  reg              train_extra_valid_q;
  reg  [31:0]      train_extra_pc_q;
  reg              train_extra_taken_q;
  wire [31:0]      lookup_pc_plus4 = lookup_pc_q + 32'h4;
  wire [2:0]       resolve_bht_entry =
    bht_pending_valid_q & bht_pending_index_q == train_pc_q[9:2]
      ? bht_pending_data_q
      : _bht_ext_R1_data;
  wire [2:0]       bht_extra_entry =
    bht_pending_valid_q & bht_pending_index_q == train_extra_pc_q[9:2]
      ? bht_pending_data_q
      : _bht_ext_R4_data;
  wire             resolve_bht_update = train_valid_q & train_is_branch_q;
  wire             _bht_distinct_dual_update_T = train_extra_valid_q & resolve_bht_update;
  wire             bht_updates_same_index =
    _bht_distinct_dual_update_T & train_extra_pc_q[9:2] == train_pc_q[9:2];
  wire [3:0][1:0]  _GEN_1 =
    {{{1'h1, train_taken_q}},
     {{train_taken_q, 1'h1}},
     {{train_taken_q, 1'h0}},
     {{1'h0, train_taken_q}}};
  wire [1:0]       resolve_bht_next =
    _GEN_1[resolve_bht_entry[2] ? resolve_bht_entry[1:0] : 2'h1];
  wire [3:0][1:0]  _GEN_2 =
    {{{1'h1, train_extra_taken_q}},
     {{train_extra_taken_q, 1'h1}},
     {{train_extra_taken_q, 1'h0}},
     {{1'h0, train_extra_taken_q}}};
  wire [1:0]       bht_extra_next =
    _GEN_2[bht_extra_entry[2] ? bht_extra_entry[1:0] : 2'h1];
  wire [3:0][1:0]  _GEN_3 =
    {{{1'h1, train_taken_q}},
     {{train_taken_q, 1'h1}},
     {{train_taken_q, 1'h0}},
     {{1'h0, train_taken_q}}};
  wire             _GEN_4 = ~rst & bht_init_active_q;
  wire             _GEN_5 = ~rst & bht_pending_valid_q;
  wire             _GEN_6 = ~rst & train_extra_valid_q;
  wire             _GEN_7 = ~rst & resolve_bht_update;
  wire             _GEN_8 = _GEN_4 & bht_init_index_q[7:6] == 2'h0;
  wire             _GEN_9 = ~rst & train_valid_q & train_taken_q;
  wire [57:0]      btb_write_data =
    _GEN_8 | ~_GEN_9
      ? 58'h0
      : {1'h1, train_is_branch_q, train_pc_q[31:8], train_target_q};
  reg              lookup_btb_hit0_q;
  reg              lookup_btb_hit1_q;
  reg  [31:0]      lookup_btb_target0_q;
  reg  [31:0]      lookup_btb_target1_q;
  reg              lookup_bht_valid0_q;
  reg              lookup_bht_valid1_q;
  reg              lookup_bht_taken0_q;
  reg              lookup_bht_taken1_q;
  reg  [2:0]       ras_sp_q;
  reg  [3:0]       ras_count_q;
  wire [2:0]       ras_top_index = ras_sp_q - 3'h1;
  wire [31:0]      ras_top =
    ras_top_index[0] ? _ras_odd_stack_ext_R0_data : _ras_even_stack_ext_R0_data;
  wire             ras0_do_pop = ras_update0_valid_i & ras_update0_pop_i & (|ras_count_q);
  wire [2:0]       ras_sp0_popped = ras_sp_q - {2'h0, ras0_do_pop};
  wire [3:0]       ras_count0_popped = ras_count_q - {3'h0, ras0_do_pop};
  wire             ras0_do_push = ras_update0_valid_i & ras_update0_push_i;
  wire [3:0]       ras_count_after0 =
    ras0_do_push
      ? (ras_count0_popped[3] ? 4'h8 : ras_count0_popped + 4'h1)
      : ras_count0_popped;
  wire             ras1_do_pop =
    ras_update1_valid_i & ras_update1_pop_i & (|ras_count_after0);
  wire [2:0]       ras_sp1_popped =
    ras_sp0_popped + {2'h0, ras0_do_push} - {2'h0, ras1_do_pop};
  wire             ras1_do_push = ras_update1_valid_i & ras_update1_push_i;
  wire             ras0_hint_pop = ras_update0_pop_i & (|ras_count_q);
  wire [2:0]       _ras_sp0_popped_hint_T = ras_sp_q - {2'h0, ras0_hint_pop};
  wire [3:0]       _ras_count0_popped_hint_T = ras_count_q - {3'h0, ras0_hint_pop};
  wire [2:0]       _ras_write1_index_hint_T =
    _ras_sp0_popped_hint_T + {2'h0, ras_update0_push_i}
    - {2'h0,
       ras_update1_pop_i
         & (|(ras_update0_push_i
                ? (_ras_count0_popped_hint_T[3] ? 4'h8 : _ras_count0_popped_hint_T + 4'h1)
                : _ras_count0_popped_hint_T))};
  wire             ras_even_write1 = ras1_do_push & ~(_ras_write1_index_hint_T[0]);
  wire             ras_odd_write1 = ras1_do_push & _ras_write1_index_hint_T[0];
  wire             ras_pred0 =
    _pred0_target_T & (fetch_inst0[19:15] == 5'h1 | fetch_inst0[19:15] == 5'h5)
    & (~(fetch_inst0[11:7] == 5'h1 | fetch_inst0[11:7] == 5'h5)
       | fetch_inst0[11:7] != fetch_inst0[19:15]) & (|ras_count_q);
  wire             pred0_taken =
    _pred0_taken_T | _pred0_target_T & (ras_pred0 | lookup_btb_hit0_q) | _pred0_taken_T_5
    & lookup_bht_valid0_q & lookup_bht_taken0_q;
  wire [31:0]      _pred0_target_T_2 =
    lookup_pc_q
    + (_pred0_taken_T_5
         ? {{20{fetch_inst0[31]}},
            fetch_inst0[7],
            fetch_inst0[30:25],
            fetch_inst0[11:8],
            1'h0}
         : _pred0_taken_T
             ? {{12{fetch_inst0[31]}},
                fetch_inst0[19:12],
                fetch_inst0[20],
                fetch_inst0[30:21],
                1'h0}
             : {{20{fetch_inst0[31]}}, fetch_inst0[31:20]});
  wire [31:0]      pred0_target =
    _pred0_target_T ? (ras_pred0 ? ras_top : lookup_btb_target0_q) : _pred0_target_T_2;
  wire             target_same_line = pred0_target[31:4] == lookup_pc_q[31:4];
  wire [3:0][31:0] _GEN_10 =
    auxiliary_hit_way
      ? {{_way1_data3_next_ext_R0_data},
         {_way1_data2_next_ext_R0_data},
         {_way1_data1_next_ext_R0_data},
         {_way1_data0_next_ext_R0_data}}
      : {{_way0_data3_next_ext_R0_data},
         {_way0_data2_next_ext_R0_data},
         {_way0_data1_next_ext_R0_data},
         {_way0_data0_next_ext_R0_data}};
  wire [31:0]      second_inst =
    pred0_taken
      ? (target_same_line ? _GEN[pred0_target[3:2]] : _GEN_10[pred0_target[3:2]])
      : fetch_inst1;
  wire [31:0]      second_pc = pred0_taken ? pred0_target : lookup_pc_plus4;
  wire             _second_pred_taken_T_5 = second_inst[6:0] == 7'h63;
  wire             _second_pred_taken_T = second_inst[6:0] == 7'h6F;
  wire             _second_pred_target_T = second_inst[6:0] == 7'h67;
  wire             _second_reads_rs1_T_3 = second_inst[6:0] == 7'h3;
  wire             _second_reads_rs2_T_1 = second_inst[6:0] == 7'h23;
  wire             second_mem = _second_reads_rs1_T_3 | _second_reads_rs2_T_1;
  wire             _second_reads_rs2_T = second_inst[6:0] == 7'h33;
  wire             second_mdu = _second_reads_rs2_T & second_inst[31:25] == 7'h1;
  wire             _second_reads_rs1_T_11 = second_inst[6:0] == 7'h73;
  wire             _second_known_T_19 = second_inst[6:0] == 7'hF;
  wire             _second_reads_rs1_T_1 = second_inst[6:0] == 7'h13;
  wire             second_serial =
    _second_reads_rs1_T_11 | _second_known_T_19 | second_mdu
    & ~(second_mdu & second_inst[14:12] == 3'h0)
    | ~(_second_reads_rs2_T | _second_reads_rs1_T_1 | _second_reads_rs1_T_3
        | _second_reads_rs2_T_1 | _second_pred_taken_T_5 | _second_pred_taken_T
        | _second_pred_target_T | second_inst[6:0] == 7'h37 | second_inst[6:0] == 7'h17
        | _second_reads_rs1_T_11 | _second_known_T_19);
  wire             second_raw01 =
    writes0
    & ((_second_reads_rs2_T | _second_reads_rs1_T_1 | _second_reads_rs1_T_3
        | _second_reads_rs2_T_1 | _second_pred_taken_T_5 | _second_pred_target_T
        | _second_reads_rs1_T_11 & ~(second_inst[14]))
       & second_inst[19:15] == fetch_inst0[11:7]
       | (_second_reads_rs2_T | _second_reads_rs2_T_1 | _second_pred_taken_T_5)
       & second_inst[24:20] == fetch_inst0[11:7]);
  wire             second_jalr_base_raw01 =
    writes0 & _second_pred_target_T & second_inst[19:15] == fetch_inst0[11:7];
  wire [1:0]       target_bht_entry =
    bht_pending_valid_q & bht_pending_index_q == pred0_target[9:2]
      ? bht_pending_data_q[2:1]
      : _bht_ext_R0_data[2:1];
  wire             second_ras_pred =
    _second_pred_target_T & (second_inst[19:15] == 5'h1 | second_inst[19:15] == 5'h5)
    & (~(second_inst[11:7] == 5'h1 | second_inst[11:7] == 5'h5)
       | second_inst[11:7] != second_inst[19:15]) & (|ras_count_q);
  wire             second_pred_taken =
    _second_pred_taken_T | _second_pred_target_T
    & (second_ras_pred
       | (pred0_taken
            ? _btb_ext_R0_data[56] & _btb_ext_R0_data[55:32] == pred0_target[31:8]
            : lookup_btb_hit1_q)) | _second_pred_taken_T_5
    & (pred0_taken ? target_bht_entry[1] : lookup_bht_valid1_q)
    & (pred0_taken ? target_bht_entry[0] : lookup_bht_taken1_q);
  wire [31:0]      _second_pred_target_T_2 =
    second_pc
    + (_second_pred_taken_T_5
         ? {{20{second_inst[31]}},
            second_inst[7],
            second_inst[30:25],
            second_inst[11:8],
            1'h0}
         : _second_pred_taken_T
             ? {{12{second_inst[31]}},
                second_inst[19:12],
                second_inst[20],
                second_inst[30:21],
                1'h0}
             : {{20{second_inst[31]}}, second_inst[31:20]});
  wire [31:0]      second_pred_target =
    _second_pred_target_T
      ? (second_ras_pred
           ? ras_top
           : pred0_taken ? _btb_ext_R0_data[31:0] : lookup_btb_target1_q)
      : _second_pred_target_T_2;
  wire             pair_allowed =
    (pred0_taken
       ? (target_same_line & cache_hit | pred0_target[31:4] == auxiliary_line_addr_q[31:4]
          & auxiliary_line_hit) & pred0_target[1:0] == 2'h0 & pred0_target != lookup_pc_q
       : lookup_pc_q[3:2] != 2'h3 | auxiliary_line_hit
         & auxiliary_line_addr_q == {lookup_pc_q[31:4], 4'h0} + 32'h10) & ~serial0
    & ~second_serial
    & ~((_writes0_T_3 | _known0_T_5 | mdu0 | serial0)
        & (second_mem | second_mdu | second_serial)) & ~(second_mdu & second_raw01)
    & ~(fast_mul0 & second_raw01)
    & ~(writes0 & second_mem & second_inst[19:15] == fetch_inst0[11:7])
    & ~second_jalr_base_raw01 & ~(second_raw01 & ~forwardable0);
  wire             sequential_pair_allowed = pair_allowed & ~pred0_taken;
  wire             target_pair_allowed = pair_allowed & pred0_taken;
  wire             _invalidate_req_ready_o_output =
    ~rst & ~scrub_active & ~invalidate_inflight_q;
  wire             deliver =
    lookup_executable & cache_hit & ~refill_active & ~fault_pending_q
    & ~invalidate_inflight_q & ~invalidate_req_i;
  wire             _slot1_valid_o_output = deliver & pair_allowed;
  wire [31:0]      _predicted_next_pc_T = second_pc + 32'h4;
  wire [31:0]      _predicted_next_pc_T_3 = lookup_pc_q + 32'h4;
  wire             read_request =
    ~scrub_active & ~fault_pending_q & ~invalidate_inflight_q & ~invalidate_req_i
    & (redirect_valid_i | ~refill_active & (~lookup_valid_q | cache_hit & ~stall_i));
  wire [31:0]      predictor_read_pc =
    lookup_valid_q
      ? (cache_hit
           ? (pair_allowed
                ? (second_pred_taken ? second_pred_target : _predicted_next_pc_T)
                : pred0_taken ? pred0_target : _predicted_next_pc_T_3)
           : lookup_pc_plus4)
      : pending_pc;
  wire [8:0]       read_pc =
    redirect_valid_i ? redirect_pc_i[12:4] : predictor_read_pc[12:4];
  wire [31:0]      read_next_line_addr = {predictor_read_pc[31:4], 4'h0} + 32'h10;
  wire [31:0]      read_pc_plus4 = predictor_read_pc + 32'h4;
  wire             read_btb_prefetch_match =
    _btb_ext_R2_data[56] & _btb_ext_R2_data[39:32] == predictor_read_pc[15:8];
  wire [8:0]       read_auxiliary_line_addr =
    read_btb_prefetch_match ? _btb_ext_R2_data[12:4] : read_next_line_addr[12:4];
  wire             _GEN_11 =
    refill_take & ~redirect_valid_i & ~refill_killed_q & ~invalidate_inflight_q
    & ~invalidate_req_i;
  wire             _GEN_12 = refill_word == 2'h0;
  wire             _GEN_13 = _GEN_11 & ~refill_way;
  wire             _GEN_14 = _GEN_13 & _GEN_12;
  wire             _GEN_15 = refill_word == 2'h1;
  wire             _GEN_16 = _GEN_13 & ~_GEN_12 & _GEN_15;
  wire             _GEN_17 = refill_word == 2'h2;
  wire             _GEN_18 = _GEN_12 | _GEN_15;
  wire             _GEN_19 = _GEN_13 & ~_GEN_18 & _GEN_17;
  wire             _GEN_20 = _GEN_13 & ~_GEN_18 & ~_GEN_17;
  wire             _GEN_21 = _GEN_11 & refill_way & _GEN_12;
  wire             _GEN_22 = _GEN_11 & ~(~refill_way | _GEN_12) & _GEN_15;
  wire             _GEN_23 = ~refill_way | _GEN_18;
  wire             _GEN_24 = _GEN_11 & ~_GEN_23 & _GEN_17;
  wire             _GEN_25 = _GEN_11 & ~_GEN_23 & ~_GEN_17;
  wire             _GEN_26 = lookup_valid_q & ~cache_hit;
  wire             _GEN_27 = _GEN_26 & ~refill_active & ~redirect_valid_i;
  wire             _GEN_28 =
    refill_finish & ~refill_failed_now & ~refill_killed_q & ~redirect_valid_i;
  wire             way0_tag_write_enable =
    ~rst & (scrub_active | (_GEN_27 ? ~selected_refill_way : _GEN_28 & ~refill_way));
  wire             _GEN_29 = _GEN_28 & ~refill_way;
  wire [8:0]       way0_tag_write_index =
    rst
      ? 9'h0
      : scrub_active
          ? scrub_index
          : _GEN_27
              ? (selected_refill_way ? 9'h0 : lookup_pc_q[12:4])
              : _GEN_29 ? refill_index : 9'h0;
  wire             _GEN_30 = scrub_active | _GEN_27;
  wire [19:0]      way0_tag_write_data =
    rst | _GEN_30 | ~_GEN_29 ? 20'h0 : {1'h1, refill_tag};
  wire             _GEN_31 = _GEN_28 & refill_way;
  wire             way1_tag_write_enable =
    ~rst & (scrub_active | (_GEN_27 ? selected_refill_way : _GEN_31));
  wire [8:0]       way1_tag_write_index =
    rst
      ? 9'h0
      : scrub_active
          ? scrub_index
          : _GEN_27
              ? (selected_refill_way ? lookup_pc_q[12:4] : 9'h0)
              : _GEN_31 ? refill_index : 9'h0;
  wire [19:0]      way1_tag_write_data =
    rst | _GEN_30 | ~_GEN_31 ? 20'h0 : {1'h1, refill_tag};
  wire             _GEN_32 = cache_hit & ~stall_i;
  wire             replacement_write_enable =
    ~rst & (scrub_active | ~_GEN_27 & (_GEN_28 | _GEN_32));
  reg  [8:0]       primary_read_index_q;
  reg  [8:0]       auxiliary_read_index_q;
  wire [8:0]       physical_primary_read_index =
    read_request ? read_pc : primary_read_index_q;
  wire [8:0]       physical_auxiliary_read_index =
    read_request ? read_auxiliary_line_addr : auxiliary_read_index_q;
  wire             _GEN_35 = refill_take & refill_finish & invalidate_wait_refill_q;
  wire             bht_distinct_dual_update =
    _bht_distinct_dual_update_T & ~bht_updates_same_index;
  wire [3:0]       ras_count1_popped = ras_count_after0 - {3'h0, ras1_do_pop};
  wire             imem_cmd_accept = _imem_cmd_valid_o_output & imem_cmd_ready_i;
  wire             invalidate_accept = invalidate_req_i & _invalidate_req_ready_o_output;
  wire [1:0]       read_bht_entry0 =
    bht_pending_valid_q & bht_pending_index_q == predictor_read_pc[9:2]
      ? bht_pending_data_q[2:1]
      : _bht_ext_R3_data[2:1];
  wire [1:0]       read_bht_entry1 =
    bht_pending_valid_q & bht_pending_index_q == read_pc_plus4[9:2]
      ? bht_pending_data_q[2:1]
      : _bht_ext_R2_data[2:1];
  wire             _GEN_36 = rst | read_request & redirect_valid_i;
  wire             _GEN_37 = refill_active & (refill_cmd_sent_q | imem_cmd_accept);
  wire             _GEN_38 = refill_take & refill_finish;
  wire             _GEN_39 = ~refill_cmd_sent_q | ~_GEN_38;
  wire             _GEN_40 = refill_cmd_sent_q & refill_take;
  wire             _GEN_41 = lookup_valid_q & ~lookup_executable;
  wire             _GEN_42 = invalidate_accept | redirect_valid_i;
  wire             _GEN_43 = rst | scrub_active;
  wire             _GEN_44 = _GEN_41 | _GEN_26;
  wire             _GEN_45 = fault_pending_q | ~_GEN_44;
  wire             _GEN_46 = ~lookup_valid_q | _GEN_32;
  always @(posedge clk) begin
    if (rst) begin
      invalidate_done_o_out_reg <= 1'h0;
      lookup_pc_q <= 32'h1C000000;
      auxiliary_line_addr_q <= 32'h0;
      pending_pc <= 32'h1C000000;
      scrub_active <= 1'h1;
      scrub_index <= 9'h0;
      invalidate_inflight_q <= 1'h0;
      invalidate_wait_refill_q <= 1'h0;
      refill_base <= 32'h0;
      refill_index <= 9'h0;
      refill_tag <= 19'h0;
      refill_way <= 1'h0;
      fault_pending_q <= 1'h0;
      fault_pc_q <= 32'h0;
      bht_init_active_q <= 1'h1;
      bht_init_index_q <= 8'h0;
      bht_pending_valid_q <= 1'h0;
      bht_pending_index_q <= 8'h0;
      bht_pending_data_q <= 3'h0;
      train_valid_q <= 1'h0;
      train_extra_valid_q <= 1'h0;
      ras_sp_q <= 3'h0;
      ras_count_q <= 4'h0;
      primary_read_index_q <= 9'h0;
      auxiliary_read_index_q <= 9'h0;
    end
    else begin
      invalidate_done_o_out_reg <= scrub_active & (&scrub_index) & invalidate_inflight_q;
      if (~(scrub_active | invalidate_accept)) begin
        if (redirect_valid_i) begin
          lookup_pc_q <= redirect_pc_i;
          pending_pc <= redirect_pc_i;
        end
        else begin
          if (refill_active | fault_pending_q | _GEN_44 | ~_GEN_46) begin
          end
          else if (redirect_valid_i)
            lookup_pc_q <= redirect_pc_i;
          else if (lookup_valid_q) begin
            if (cache_hit) begin
              if (pair_allowed) begin
                if (second_pred_taken) begin
                  if (_second_pred_target_T) begin
                    if (second_ras_pred)
                      lookup_pc_q <= ras_top;
                    else if (pred0_taken)
                      lookup_pc_q <= _btb_ext_R0_data[31:0];
                    else
                      lookup_pc_q <= lookup_btb_target1_q;
                  end
                  else
                    lookup_pc_q <= _second_pred_target_T_2;
                end
                else
                  lookup_pc_q <= _predicted_next_pc_T;
              end
              else if (pred0_taken) begin
                if (_pred0_target_T) begin
                  if (ras_pred0)
                    lookup_pc_q <= ras_top;
                  else
                    lookup_pc_q <= lookup_btb_target0_q;
                end
                else
                  lookup_pc_q <= _pred0_target_T_2;
              end
              else
                lookup_pc_q <= _predicted_next_pc_T_3;
            end
            else
              lookup_pc_q <= lookup_pc_plus4;
          end
          else
            lookup_pc_q <= pending_pc;
          if (refill_active) begin
          end
          else if (fault_pending_q) begin
            if (stall_i) begin
            end
            else
              pending_pc <= fault_pc_q + 32'h4;
          end
          else if (_GEN_44)
            pending_pc <= lookup_pc_q;
          else if (_GEN_46) begin
            if (redirect_valid_i)
              pending_pc <= redirect_pc_i;
            else if (lookup_valid_q) begin
              if (cache_hit) begin
                if (pair_allowed) begin
                  if (second_pred_taken) begin
                    if (_second_pred_target_T) begin
                      if (second_ras_pred)
                        pending_pc <= ras_top;
                      else if (pred0_taken)
                        pending_pc <= _btb_ext_R0_data[31:0];
                      else
                        pending_pc <= lookup_btb_target1_q;
                    end
                    else
                      pending_pc <= _second_pred_target_T_2;
                  end
                  else
                    pending_pc <= _predicted_next_pc_T;
                end
                else if (pred0_taken) begin
                  if (_pred0_target_T) begin
                    if (ras_pred0)
                      pending_pc <= ras_top;
                    else
                      pending_pc <= lookup_btb_target0_q;
                  end
                  else
                    pending_pc <= _pred0_target_T_2;
                end
                else
                  pending_pc <= _predicted_next_pc_T_3;
              end
              else
                pending_pc <= lookup_pc_plus4;
            end
          end
        end
      end
      if (read_request) begin
        if (read_btb_prefetch_match)
          auxiliary_line_addr_q <= {_btb_ext_R2_data[31:4], 4'h0};
        else
          auxiliary_line_addr_q <= read_next_line_addr;
        primary_read_index_q <= read_pc;
        auxiliary_read_index_q <= read_auxiliary_line_addr;
      end
      if (scrub_active) begin
        scrub_active <= ~(&scrub_index) & scrub_active;
        if (&scrub_index)
          scrub_index <= 9'h0;
        else
          scrub_index <= scrub_index + 9'h1;
        invalidate_inflight_q <=
          ~((&scrub_index) & invalidate_inflight_q) & invalidate_inflight_q;
      end
      else begin
        if (invalidate_accept)
          scrub_active <= ~_GEN_37 | scrub_active;
        else
          scrub_active <=
            ~redirect_valid_i & refill_active & refill_cmd_sent_q & _GEN_35
            | scrub_active;
        if (invalidate_accept
              ? _GEN_37
              : redirect_valid_i | ~(refill_active & refill_cmd_sent_q & _GEN_35)) begin
        end
        else
          scrub_index <= 9'h0;
        invalidate_inflight_q <= invalidate_accept | invalidate_inflight_q;
        if (invalidate_accept)
          invalidate_wait_refill_q <= _GEN_37;
        else
          invalidate_wait_refill_q <=
            (redirect_valid_i | ~refill_active | ~refill_cmd_sent_q | ~_GEN_35)
            & invalidate_wait_refill_q;
        fault_pending_q <=
          ~(invalidate_accept | redirect_valid_i)
          & (refill_active
               ? refill_cmd_sent_q & refill_take & refill_finish & refill_failed_now
                 & ~refill_killed_q | fault_pending_q
               : fault_pending_q ? stall_i & fault_pending_q : _GEN_41 | fault_pending_q);
      end
      if (scrub_active | invalidate_accept | redirect_valid_i | refill_active
          | fault_pending_q | _GEN_41 | ~_GEN_26) begin
      end
      else begin
        refill_base <= {lookup_pc_q[31:4], 4'h0};
        refill_index <= lookup_pc_q[12:4];
        refill_tag <= lookup_pc_q[31:13];
        refill_way <= selected_refill_way;
      end
      if (refill_active & refill_cmd_sent_q & ~refill_killed_q & imem_rsp_valid_i
          & (imem_rsp_last_i | (&refill_word)) & refill_failed_now)
        fault_pc_q <= pending_pc;
      else if (~refill_active & ~fault_pending_q & lookup_valid_q & ~lookup_executable)
        fault_pc_q <= lookup_pc_q;
      bht_init_active_q <=
        rst | ~(bht_init_active_q & (&bht_init_index_q)) & bht_init_active_q;
      if (rst)
        bht_init_index_q <= 8'h0;
      else if (bht_init_active_q) begin
        if (&bht_init_index_q)
          bht_init_index_q <= 8'h0;
        else
          bht_init_index_q <= bht_init_index_q + 8'h1;
      end
      bht_pending_valid_q <=
        ~(rst | bht_init_active_q)
        & (bht_pending_valid_q
             ? resolve_bht_update | train_extra_valid_q
             : bht_distinct_dual_update);
      if (bht_init_active_q) begin
      end
      else if (bht_pending_valid_q) begin
        if (resolve_bht_update) begin
          bht_pending_index_q <= train_pc_q[9:2];
          bht_pending_data_q <=
            {1'h1, bht_updates_same_index ? _GEN_3[bht_extra_next] : resolve_bht_next};
        end
        else if (train_extra_valid_q) begin
          bht_pending_index_q <= train_extra_pc_q[9:2];
          bht_pending_data_q <= {1'h1, bht_extra_next};
        end
      end
      else if (bht_distinct_dual_update) begin
        bht_pending_index_q <= train_pc_q[9:2];
        bht_pending_data_q <= {1'h1, resolve_bht_next};
      end
      train_valid_q <= resolve_valid_i;
      train_extra_valid_q <= bht_extra_valid_i;
      ras_sp_q <= ras_sp1_popped + {2'h0, ras1_do_push};
      if (ras1_do_push) begin
        if (ras_count1_popped[3])
          ras_count_q <= 4'h8;
        else
          ras_count_q <= ras_count1_popped + 4'h1;
      end
      else
        ras_count_q <= ras_count1_popped;
    end
    lookup_valid_q <=
      ~(_GEN_43 | invalidate_accept)
      & (redirect_valid_i
           ? ~_GEN_37
           : ~(refill_active | fault_pending_q | _GEN_41 | _GEN_26)
             & (_GEN_46 | lookup_valid_q));
    refill_active <=
      ~_GEN_43
      & (_GEN_42
           ? _GEN_37 & refill_active
           : refill_active
               ? _GEN_39 & refill_active
               : fault_pending_q ? refill_active : ~_GEN_41 & (_GEN_26 | refill_active));
    if (_GEN_43)
      refill_word <= 2'h0;
    else if (_GEN_42) begin
      if (~_GEN_37)
        refill_word <= 2'h0;
    end
    else if (refill_active) begin
      if (_GEN_40) begin
        if (refill_finish)
          refill_word <= 2'h0;
        else
          refill_word <= refill_word + 2'h1;
      end
    end
    else if (_GEN_45) begin
    end
    else
      refill_word <= 2'h0;
    refill_cmd_sent_q <=
      ~_GEN_43
      & (_GEN_42
           ? _GEN_37
           : refill_active
               ? (refill_cmd_sent_q
                    ? ~_GEN_38 & refill_cmd_sent_q
                    : imem_cmd_accept | refill_cmd_sent_q)
               : _GEN_45 & refill_cmd_sent_q);
    refill_killed_q <=
      ~_GEN_43
      & (_GEN_42
           ? _GEN_37
           : refill_active ? _GEN_39 & refill_killed_q : _GEN_45 & refill_killed_q);
    refill_error_q <=
      ~_GEN_43
      & (_GEN_42
           ? _GEN_37 & refill_error_q
           : refill_active
               ? (_GEN_40 ? ~refill_finish & refill_failed_now : refill_error_q)
               : _GEN_45 & refill_error_q);
    if (rst) begin
    end
    else begin
      train_is_branch_q <= resolve_is_branch_i;
      train_pc_q <= resolve_pc_i;
      train_taken_q <= resolve_taken_i;
      train_target_q <= resolve_target_i;
      train_extra_pc_q <= bht_extra_pc_i;
      train_extra_taken_q <= bht_extra_taken_i;
    end
    lookup_btb_hit0_q <=
      ~_GEN_36
      & (read_request
           ? _btb_ext_R2_data[56] & _btb_ext_R2_data[55:32] == predictor_read_pc[31:8]
           : lookup_btb_hit0_q);
    lookup_btb_hit1_q <=
      ~_GEN_36
      & (read_request
           ? _btb_ext_R1_data[56] & _btb_ext_R1_data[55:32] == read_pc_plus4[31:8]
           : lookup_btb_hit1_q);
    if (_GEN_36) begin
      lookup_btb_target0_q <= 32'h0;
      lookup_btb_target1_q <= 32'h0;
    end
    else if (read_request) begin
      lookup_btb_target0_q <= _btb_ext_R2_data[31:0];
      lookup_btb_target1_q <= _btb_ext_R1_data[31:0];
    end
    lookup_bht_valid0_q <=
      ~_GEN_36 & (read_request ? read_bht_entry0[1] : lookup_bht_valid0_q);
    lookup_bht_valid1_q <=
      ~_GEN_36 & (read_request ? read_bht_entry1[1] : lookup_bht_valid1_q);
    lookup_bht_taken0_q <=
      ~_GEN_36 & (read_request ? read_bht_entry0[0] : lookup_bht_taken0_q);
    lookup_bht_taken1_q <=
      ~_GEN_36 & (read_request ? read_bht_entry1[0] : lookup_bht_taken1_q);
  end
  way_512x32 way0_data0_ext (
    .R0_addr (physical_primary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way0_data0_ext_R0_data),
    .W0_addr (refill_index),
    .W0_en   (_GEN_14),
    .W0_clk  (clk),
    .W0_data (imem_rsp_data_i)
  );
  way_512x32 way0_data0_next_ext (
    .R0_addr (physical_auxiliary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way0_data0_next_ext_R0_data),
    .W0_addr (refill_index),
    .W0_en   (_GEN_14),
    .W0_clk  (clk),
    .W0_data (imem_rsp_data_i)
  );
  way_512x32 way0_data1_ext (
    .R0_addr (physical_primary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way0_data1_ext_R0_data),
    .W0_addr (refill_index),
    .W0_en   (_GEN_16),
    .W0_clk  (clk),
    .W0_data (imem_rsp_data_i)
  );
  way_512x32 way0_data1_next_ext (
    .R0_addr (physical_auxiliary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way0_data1_next_ext_R0_data),
    .W0_addr (refill_index),
    .W0_en   (_GEN_16),
    .W0_clk  (clk),
    .W0_data (imem_rsp_data_i)
  );
  way_512x32 way0_data2_ext (
    .R0_addr (physical_primary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way0_data2_ext_R0_data),
    .W0_addr (refill_index),
    .W0_en   (_GEN_19),
    .W0_clk  (clk),
    .W0_data (imem_rsp_data_i)
  );
  way_512x32 way0_data2_next_ext (
    .R0_addr (physical_auxiliary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way0_data2_next_ext_R0_data),
    .W0_addr (refill_index),
    .W0_en   (_GEN_19),
    .W0_clk  (clk),
    .W0_data (imem_rsp_data_i)
  );
  way_512x32 way0_data3_ext (
    .R0_addr (physical_primary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way0_data3_ext_R0_data),
    .W0_addr (refill_index),
    .W0_en   (_GEN_20),
    .W0_clk  (clk),
    .W0_data (imem_rsp_data_i)
  );
  way_512x32 way0_data3_next_ext (
    .R0_addr (physical_auxiliary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way0_data3_next_ext_R0_data),
    .W0_addr (refill_index),
    .W0_en   (_GEN_20),
    .W0_clk  (clk),
    .W0_data (imem_rsp_data_i)
  );
  way_512x20 way0_tag_ext (
    .R0_addr (physical_primary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way0_tag_ext_R0_data),
    .W0_addr (way0_tag_write_index),
    .W0_en   (way0_tag_write_enable),
    .W0_clk  (clk),
    .W0_data (way0_tag_write_data)
  );
  way_512x20 way0_tag_next_ext (
    .R0_addr (physical_auxiliary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way0_tag_next_ext_R0_data),
    .W0_addr (way0_tag_write_index),
    .W0_en   (way0_tag_write_enable),
    .W0_clk  (clk),
    .W0_data (way0_tag_write_data)
  );
  way_512x32 way1_data0_ext (
    .R0_addr (physical_primary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way1_data0_ext_R0_data),
    .W0_addr (refill_index),
    .W0_en   (_GEN_21),
    .W0_clk  (clk),
    .W0_data (imem_rsp_data_i)
  );
  way_512x32 way1_data0_next_ext (
    .R0_addr (physical_auxiliary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way1_data0_next_ext_R0_data),
    .W0_addr (refill_index),
    .W0_en   (_GEN_21),
    .W0_clk  (clk),
    .W0_data (imem_rsp_data_i)
  );
  way_512x32 way1_data1_ext (
    .R0_addr (physical_primary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way1_data1_ext_R0_data),
    .W0_addr (refill_index),
    .W0_en   (_GEN_22),
    .W0_clk  (clk),
    .W0_data (imem_rsp_data_i)
  );
  way_512x32 way1_data1_next_ext (
    .R0_addr (physical_auxiliary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way1_data1_next_ext_R0_data),
    .W0_addr (refill_index),
    .W0_en   (_GEN_22),
    .W0_clk  (clk),
    .W0_data (imem_rsp_data_i)
  );
  way_512x32 way1_data2_ext (
    .R0_addr (physical_primary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way1_data2_ext_R0_data),
    .W0_addr (refill_index),
    .W0_en   (_GEN_24),
    .W0_clk  (clk),
    .W0_data (imem_rsp_data_i)
  );
  way_512x32 way1_data2_next_ext (
    .R0_addr (physical_auxiliary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way1_data2_next_ext_R0_data),
    .W0_addr (refill_index),
    .W0_en   (_GEN_24),
    .W0_clk  (clk),
    .W0_data (imem_rsp_data_i)
  );
  way_512x32 way1_data3_ext (
    .R0_addr (physical_primary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way1_data3_ext_R0_data),
    .W0_addr (refill_index),
    .W0_en   (_GEN_25),
    .W0_clk  (clk),
    .W0_data (imem_rsp_data_i)
  );
  way_512x32 way1_data3_next_ext (
    .R0_addr (physical_auxiliary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way1_data3_next_ext_R0_data),
    .W0_addr (refill_index),
    .W0_en   (_GEN_25),
    .W0_clk  (clk),
    .W0_data (imem_rsp_data_i)
  );
  way_512x20 way1_tag_ext (
    .R0_addr (physical_primary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way1_tag_ext_R0_data),
    .W0_addr (way1_tag_write_index),
    .W0_en   (way1_tag_write_enable),
    .W0_clk  (clk),
    .W0_data (way1_tag_write_data)
  );
  way_512x20 way1_tag_next_ext (
    .R0_addr (physical_auxiliary_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way1_tag_next_ext_R0_data),
    .W0_addr (way1_tag_write_index),
    .W0_en   (way1_tag_write_enable),
    .W0_clk  (clk),
    .W0_data (way1_tag_write_data)
  );
  replacement_512x1 replacement_ext (
    .R0_addr (lookup_pc_q[12:4]),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_replacement_ext_R0_data),
    .W0_addr
      (rst
         ? 9'h0
         : scrub_active
             ? scrub_index
             : _GEN_27
                 ? 9'h0
                 : _GEN_28 ? refill_index : _GEN_32 ? lookup_pc_q[12:4] : 9'h0),
    .W0_en   (replacement_write_enable),
    .W0_clk  (clk),
    .W0_data (~rst & ~_GEN_30 & (_GEN_28 ? ~refill_way : _GEN_32 & ~hit_way))
  );
  bht_256x3 bht_ext (
    .R0_addr (pred0_target[9:2]),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_bht_ext_R0_data),
    .R1_addr (train_pc_q[9:2]),
    .R1_en   (1'h1),
    .R1_clk  (clk),
    .R1_data (_bht_ext_R1_data),
    .R2_addr (read_pc_plus4[9:2]),
    .R2_en   (1'h1),
    .R2_clk  (clk),
    .R2_data (_bht_ext_R2_data),
    .R3_addr (predictor_read_pc[9:2]),
    .R3_en   (1'h1),
    .R3_clk  (clk),
    .R3_data (_bht_ext_R3_data),
    .R4_addr (train_extra_pc_q[9:2]),
    .R4_en   (1'h1),
    .R4_clk  (clk),
    .R4_data (_bht_ext_R4_data),
    .W0_addr
      (_GEN_4
         ? bht_init_index_q
         : _GEN_5
             ? bht_pending_index_q
             : _GEN_6 ? train_extra_pc_q[9:2] : _GEN_7 ? train_pc_q[9:2] : 8'h0),
    .W0_en   (_GEN_4 | _GEN_5 | _GEN_6 | _GEN_7),
    .W0_clk  (clk),
    .W0_data
      (_GEN_4
         ? 3'h0
         : _GEN_5
             ? bht_pending_data_q
             : _GEN_6
                 ? {1'h1,
                    bht_updates_same_index ? _GEN_3[bht_extra_next] : bht_extra_next}
                 : _GEN_7 ? {1'h1, resolve_bht_next} : 3'h0)
  );
  btb_64x57 btb_ext (
    .R0_addr (pred0_target[7:2]),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_btb_ext_R0_data),
    .R1_addr (read_pc_plus4[7:2]),
    .R1_en   (1'h1),
    .R1_clk  (clk),
    .R1_data (_btb_ext_R1_data),
    .R2_addr (predictor_read_pc[7:2]),
    .R2_en   (1'h1),
    .R2_clk  (clk),
    .R2_data (_btb_ext_R2_data),
    .W0_addr (_GEN_8 ? bht_init_index_q[5:0] : _GEN_9 ? train_pc_q[7:2] : 6'h0),
    .W0_en   (_GEN_8 | _GEN_9),
    .W0_clk  (clk),
    .W0_data ({btb_write_data[57], btb_write_data[55:0]})
  );
  ras_4x32 ras_even_stack_ext (
    .R0_addr (ras_top_index[2:1]),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_ras_even_stack_ext_R0_data),
    .W0_addr
      (ras_update1_push_i & ~(_ras_write1_index_hint_T[0])
         ? _ras_write1_index_hint_T[2:1]
         : _ras_sp0_popped_hint_T[2:1]),
    .W0_en   (~rst & (ras0_do_push & ~(_ras_sp0_popped_hint_T[0]) | ras_even_write1)),
    .W0_clk  (clk),
    .W0_data (ras_even_write1 ? ras_update1_addr_i : ras_update0_addr_i)
  );
  ras_4x32 ras_odd_stack_ext (
    .R0_addr (ras_top_index[2:1]),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_ras_odd_stack_ext_R0_data),
    .W0_addr
      (ras_update1_push_i & _ras_write1_index_hint_T[0]
         ? _ras_write1_index_hint_T[2:1]
         : _ras_sp0_popped_hint_T[2:1]),
    .W0_en   (~rst & (ras0_do_push & _ras_sp0_popped_hint_T[0] | ras_odd_write1)),
    .W0_clk  (clk),
    .W0_data (ras_odd_write1 ? ras_update1_addr_i : ras_update0_addr_i)
  );
  assign invalidate_req_ready_o = _invalidate_req_ready_o_output;
  assign invalidate_done_o = invalidate_done_o_out_reg;
  assign slot0_valid_o = fault_pending_q | deliver;
  assign slot0_pc_o = fault_pending_q ? fault_pc_q : lookup_pc_q;
  assign slot0_inst_o = fault_pending_q ? 32'h13 : fetch_inst0;
  assign slot0_pred_taken_o = ~fault_pending_q & pred0_taken;
  assign slot0_pred_target_o = fault_pending_q ? 32'h0 : pred0_target;
  assign slot1_valid_o = _slot1_valid_o_output;
  assign slot1_pc_o = second_pc;
  assign slot1_inst_o = second_inst;
  assign slot1_pred_taken_o = second_pred_taken;
  assign slot1_pred_target_o = second_pred_target;
  assign slot0_access_fault_o = fault_pending_q;
  assign imem_cmd_valid_o = _imem_cmd_valid_o_output;
  assign imem_cmd_addr_o = refill_base;
  assign imem_rsp_ready_o = _imem_rsp_ready_o_output;
endmodule

module if_id(
  input         clk,
                rst,
                hold_flag_i,
  input  [31:0] inst_i,
                inst_addr_i,
  output [31:0] inst_addr_o,
                inst_o,
  input         stall,
                prdt_taken_i,
  input  [31:0] prdt_pc_add_op1,
  output        prdt_taken_o,
  output [31:0] prdt_pc_addr,
  input         ex_jump_en_i
);

  reg  [31:0] instQ;
  reg  [31:0] instAddrQ;
  reg         takenQ;
  reg  [31:0] targetQ;
  wire        kill = rst | hold_flag_i | ex_jump_en_i;
  always @(posedge clk) begin
    if (kill) begin
      instQ <= 32'h13;
      instAddrQ <= 32'h0;
      targetQ <= 32'h0;
    end
    else if (stall) begin
    end
    else begin
      instQ <= inst_i;
      instAddrQ <= inst_addr_i;
      targetQ <= prdt_pc_add_op1;
    end
    takenQ <= ~kill & (stall ? takenQ : prdt_taken_i);
  end
  assign inst_addr_o = instAddrQ;
  assign inst_o = instQ;
  assign prdt_taken_o = takenQ;
  assign prdt_pc_addr = targetQ;
endmodule

module id(
  input  [31:0] inst_i,
                inst_addr_i,
  output [4:0]  rs1_addr_o,
                rs2_addr_o,
  input  [31:0] rs1_data_i,
                rs2_data_i,
  output [31:0] inst_o,
                op1_o,
                op2_o,
  output [4:0]  rd_addr_o,
  output        reg_wen_o,
  output [31:0] base_addr_o,
                addr_offset_o,
  output [5:0]  alu_op_o,
  output        is_mdu_o,
  output [2:0]  mdu_op_o,
  output        is_system_o,
  output [3:0]  system_op_o,
  output [11:0] csr_addr_o,
  output [4:0]  csr_zimm_o,
  output        illegal_o,
                is_branch_o,
                is_jump_o,
                is_load_o,
                is_store_o,
  output [2:0]  mem_width_o
);

  wire [31:0] immI = {{20{inst_i[31]}}, inst_i[31:20]};
  wire        _GEN = inst_i[6:0] == 7'h13;
  wire        _isShift_T = inst_i[14:12] == 3'h1;
  wire        shiftLeftLegal = _isShift_T & ~(|(inst_i[31:25]));
  wire        _isShift_T_1 = inst_i[14:12] == 3'h5;
  wire        shiftRightLegal =
    _isShift_T_1 & (~(|(inst_i[31:25])) | inst_i[31:25] == 7'h20);
  wire        isShift = _isShift_T | _isShift_T_1;
  wire        legalShift = shiftLeftLegal | shiftRightLegal;
  wire        _GEN_0 = isShift & ~legalShift;
  wire        _GEN_1 = inst_i[6:0] == 7'h33;
  wire        _GEN_2 = _GEN_1 & inst_i[31:25] == 7'h1;
  wire        _alu_op_o_T_48 = inst_i[14:12] == 3'h5;
  wire        legalFunc7 =
    ~(|(inst_i[31:25])) | inst_i[31:25] == 7'h20 & (~(|(inst_i[14:12])) | _alu_op_o_T_48);
  wire        _GEN_3 = inst_i[6:0] == 7'h63;
  wire        legalBranch =
    ~(|(inst_i[14:12])) | inst_i[14:12] == 3'h1 | inst_i[14:12] == 3'h4
    | inst_i[14:12] == 3'h5 | inst_i[14:12] == 3'h6 | (&(inst_i[14:12]));
  wire        _GEN_4 = _GEN | _GEN_2 | _GEN_1;
  wire        _GEN_5 = inst_i[6:0] == 7'h6F;
  wire        _GEN_6 = inst_i[6:0] == 7'h37;
  wire        _GEN_7 = inst_i[6:0] == 7'h17;
  wire        _GEN_8 = inst_i[6:0] == 7'h67 & ~(|(inst_i[14:12]));
  wire        _GEN_9 = _GEN_6 | _GEN_7;
  wire        _GEN_10 = _GEN_3 | _GEN_5;
  wire        _GEN_11 = inst_i[6:0] == 7'h3;
  wire        legalLoad =
    ~(|(inst_i[14:12])) | inst_i[14:12] == 3'h1 | inst_i[14:12] == 3'h2
    | inst_i[14:12] == 3'h4 | inst_i[14:12] == 3'h5;
  wire        _GEN_12 = _GEN_7 | _GEN_8;
  wire        _GEN_13 = _GEN_5 | _GEN_6 | _GEN_12;
  wire        _GEN_14 = inst_i[6:0] == 7'h23;
  wire        legalStore =
    ~(|(inst_i[14:12])) | inst_i[14:12] == 3'h1 | inst_i[14:12] == 3'h2;
  wire        _GEN_15 = _GEN_8 | _GEN_11;
  wire        _GEN_16 = _GEN_5 | _GEN_6 | _GEN_7 | _GEN_15;
  wire        _GEN_17 = _GEN_8 | _GEN_11 | _GEN_14;
  wire        _GEN_18 = inst_i[14:12] == 3'h1;
  wire        _GEN_19 = inst_i[6:0] == 7'hF & (~(|(inst_i[14:12])) | _GEN_18);
  wire        _GEN_20 = inst_i[6:0] == 7'h73;
  wire        _GEN_21 = inst_i == 32'h73;
  wire        _GEN_22 = inst_i == 32'h100073;
  wire        _GEN_23 = inst_i == 32'h30200073;
  wire        _GEN_24 = _GEN_18 | inst_i[14:12] == 3'h2 | inst_i[14:12] == 3'h3;
  wire        _GEN_25 = _GEN_21 | _GEN_22 | _GEN_23;
  wire        _GEN_26 = _GEN | _GEN_2;
  wire        _GEN_27 = _GEN_14 | _GEN_19;
  wire        _GEN_28 = _GEN_11 | _GEN_27;
  wire        _GEN_29 =
    inst_i[14:12] == 3'h5 | inst_i[14:12] == 3'h6 | (&(inst_i[14:12]));
  wire        _GEN_30 =
    _GEN | _GEN_2 | _GEN_1 | _GEN_3 | _GEN_5 | _GEN_6 | _GEN_7 | _GEN_8 | _GEN_28;
  wire        _GEN_31 = _GEN_21 | _GEN_22 | _GEN_23 | _GEN_24;
  assign rs1_addr_o =
    _GEN_26
    | (_GEN_1
         ? legalFunc7
         : _GEN_3
           | ~(_GEN_5 | _GEN_9 | ~(_GEN_17 | ~(_GEN_19 | ~_GEN_20 | _GEN_25 | ~_GEN_24))))
      ? inst_i[19:15]
      : 5'h0;
  assign rs2_addr_o =
    _GEN | ~(_GEN_2 | (_GEN_1 ? legalFunc7 : _GEN_3 | ~(_GEN_16 | ~_GEN_14)))
      ? 5'h0
      : inst_i[24:20];
  assign inst_o = inst_i;
  assign op1_o =
    _GEN_26
      ? rs1_data_i
      : _GEN_1
          ? (legalFunc7 ? rs1_data_i : 32'h0)
          : _GEN_3
              ? rs1_data_i
              : _GEN_5
                  ? inst_addr_i
                  : _GEN_6
                      ? {inst_i[31:12], 12'h0}
                      : _GEN_12
                          ? inst_addr_i
                          : _GEN_28 | ~_GEN_20 | _GEN_25 | ~_GEN_24 ? 32'h0 : rs1_data_i;
  assign op2_o =
    _GEN
      ? (isShift ? {27'h0, legalShift ? inst_i[24:20] : 5'h0} : immI)
      : _GEN_2
          ? rs2_data_i
          : _GEN_1
              ? (legalFunc7 ? rs2_data_i : 32'h0)
              : _GEN_3
                  ? rs2_data_i
                  : _GEN_5
                      ? 32'h4
                      : _GEN_6
                          ? 32'h0
                          : _GEN_7
                              ? {inst_i[31:12], 12'h0}
                              : _GEN_8 ? 32'h4 : _GEN_11 | ~_GEN_14 ? 32'h0 : rs2_data_i;
  assign rd_addr_o =
    _GEN_26
      ? inst_i[11:7]
      : _GEN_1
          ? (legalFunc7 ? inst_i[11:7] : 5'h0)
          : _GEN_3 | ~(_GEN_16 | ~(_GEN_27 | ~_GEN_20 | _GEN_25 | ~(_GEN_24 | _GEN_29)))
              ? 5'h0
              : inst_i[11:7];
  assign reg_wen_o =
    _GEN
      ? ~_GEN_0
      : _GEN_2
        | (_GEN_1
             ? legalFunc7
             : ~_GEN_3
               & (_GEN_13
                  | (_GEN_11
                       ? legalLoad
                       : ~_GEN_27 & _GEN_20 & ~_GEN_25 & (_GEN_24 | _GEN_29))));
  assign base_addr_o =
    _GEN_4 ? 32'h0 : _GEN_10 ? inst_addr_i : _GEN_9 | ~_GEN_17 ? 32'h0 : rs1_data_i;
  assign addr_offset_o =
    _GEN_4
      ? 32'h0
      : _GEN_3
          ? {{20{inst_i[31]}}, inst_i[7], inst_i[30:25], inst_i[11:8], 1'h0}
          : _GEN_5
              ? {{12{inst_i[31]}}, inst_i[19:12], inst_i[20], inst_i[30:21], 1'h0}
              : _GEN_9
                  ? 32'h0
                  : _GEN_15
                      ? immI
                      : _GEN_14 ? {{20{inst_i[31]}}, inst_i[31:25], inst_i[11:7]} : 32'h0;
  assign alu_op_o =
    _GEN
      ? {6{inst_i[14:12] == 3'h2}} & 6'h3 | {6{inst_i[14:12] == 3'h4}} & 6'h5
        | {6{shiftRightLegal}} & {5'h3, inst_i[30]}
        | {2'h0, inst_i[14:12] == 3'h6, inst_i[14:12] == 3'h3, shiftLeftLegal, 1'h0}
        | {6{&(inst_i[14:12])}} & 6'h9
      : _GEN_2
          ? 6'h0
          : _GEN_1
              ? (legalFunc7
                   ? {6{~(|(inst_i[14:12]))}} & {5'h0, inst_i[30]}
                     | {6{inst_i[14:12] == 3'h2}} & 6'h3 | {6{inst_i[14:12] == 3'h4}}
                     & 6'h5 | {6{_alu_op_o_T_48}} & {5'h3, inst_i[30]}
                     | {2'h0,
                        inst_i[14:12] == 3'h6,
                        inst_i[14:12] == 3'h3,
                        inst_i[14:12] == 3'h1,
                        1'h0} | {6{&(inst_i[14:12])}} & 6'h9
                   : 6'h0)
              : _GEN_10 | ~_GEN_6 ? 6'h0 : 6'hA;
  assign is_mdu_o = ~_GEN & _GEN_2;
  assign mdu_op_o = _GEN | ~_GEN_2 ? 3'h0 : inst_i[14:12];
  assign is_system_o = ~_GEN_30 & _GEN_20 & (_GEN_31 | _GEN_29);
  assign system_op_o =
    _GEN_30 | ~_GEN_20
      ? 4'h0
      : _GEN_21
          ? 4'h8
          : _GEN_22
              ? 4'hA
              : _GEN_23
                  ? 4'h9
                  : _GEN_24
                      ? {1'h0, inst_i[14:12]}
                      : _GEN_29 ? {1'h0, inst_i[14:12]} : 4'h0;
  assign csr_addr_o = inst_i[31:20];
  assign csr_zimm_o = inst_i[19:15];
  assign illegal_o =
    _GEN
      ? _GEN_0
      : ~_GEN_2
        & (_GEN_1
             ? ~legalFunc7
             : _GEN_3
                 ? ~legalBranch
                 : ~_GEN_13
                   & (_GEN_11
                        ? ~legalLoad
                        : _GEN_14
                            ? ~legalStore
                            : ~_GEN_19
                              & (_GEN_20 ? ~_GEN_31 & ~_GEN_29 : inst_i != 32'h13)));
  assign is_branch_o = ~_GEN_4 & _GEN_3 & legalBranch;
  assign is_jump_o = ~(_GEN | _GEN_2 | _GEN_1 | _GEN_3) & (_GEN_5 | ~_GEN_9 & _GEN_8);
  assign is_load_o = ~(_GEN | _GEN_2 | _GEN_1 | _GEN_3 | _GEN_13) & _GEN_11 & legalLoad;
  assign is_store_o = ~(_GEN | _GEN_2 | _GEN_1 | _GEN_3 | _GEN_16) & _GEN_14 & legalStore;
  assign mem_width_o = inst_i[14:12];
endmodule

module bank_32x32(
  input  [4:0]  R0_addr,
  input         R0_en,
                R0_clk,
  output [31:0] R0_data,
  input  [4:0]  W0_addr,
  input         W0_en,
                W0_clk,
  input  [31:0] W0_data
);

  reg [31:0] Memory[0:31];
  always @(posedge W0_clk) begin
    if (W0_en & 1'h1)
      Memory[W0_addr] <= W0_data;
  end
  assign R0_data = R0_en ? Memory[R0_addr] : 32'bx;
endmodule

module regs(
  input         clk,
                rst,
                read_stall_i,
  input  [4:0]  reg1_raddr_i,
                reg2_raddr_i,
                reg3_raddr_i,
                reg4_raddr_i,
  output [31:0] reg1_rdata_o,
                reg2_rdata_o,
                reg3_rdata_o,
                reg4_rdata_o,
  input  [4:0]  reg_waddr_i,
  input  [31:0] reg_wdata_i,
  input         reg_wen,
  input  [4:0]  reg2_waddr_i,
  input  [31:0] reg2_wdata_i,
  input         reg2_wen
);

  wire [31:0] _bank1_r3_ext_R0_data;
  wire [31:0] _bank1_r2_ext_R0_data;
  wire [31:0] _bank1_r1_ext_R0_data;
  wire [31:0] _bank1_r0_ext_R0_data;
  wire [31:0] _bank0_r3_ext_R0_data;
  wire [31:0] _bank0_r2_ext_R0_data;
  wire [31:0] _bank0_r1_ext_R0_data;
  wire [31:0] _bank0_r0_ext_R0_data;
  reg  [31:0] last_writer;
  reg  [31:0] read_data0_q;
  reg  [31:0] read_data1_q;
  reg  [31:0] read_data2_q;
  reg  [31:0] read_data3_q;
  reg  [4:0]  read_addr0_q;
  reg  [4:0]  read_addr1_q;
  reg  [4:0]  read_addr2_q;
  reg  [4:0]  read_addr3_q;
  wire        wb0Live = reg_wen & (|reg_waddr_i);
  wire        wb1Live = reg2_wen & (|reg2_waddr_i);
  wire [31:0] _newRead_T_5 = last_writer >> reg1_raddr_i;
  wire [31:0] _newRead_T_15 = last_writer >> reg2_raddr_i;
  wire [31:0] _newRead_T_25 = last_writer >> reg3_raddr_i;
  wire [31:0] _newRead_T_35 = last_writer >> reg4_raddr_i;
  always @(posedge clk) begin
    if (wb0Live | wb1Live)
      last_writer <=
        {32{wb1Live}} & 32'h1 << reg2_waddr_i | ({32{~wb0Live}} | ~(32'h1 << reg_waddr_i))
        & last_writer;
    if (rst) begin
      read_data0_q <= 32'h0;
      read_data1_q <= 32'h0;
      read_data2_q <= 32'h0;
      read_data3_q <= 32'h0;
      read_addr0_q <= 5'h0;
      read_addr1_q <= 5'h0;
      read_addr2_q <= 5'h0;
      read_addr3_q <= 5'h0;
    end
    else if (read_stall_i) begin
      if (wb1Live & read_addr0_q == reg2_waddr_i)
        read_data0_q <= reg2_wdata_i;
      else if (wb0Live & read_addr0_q == reg_waddr_i)
        read_data0_q <= reg_wdata_i;
      if (wb1Live & read_addr1_q == reg2_waddr_i)
        read_data1_q <= reg2_wdata_i;
      else if (wb0Live & read_addr1_q == reg_waddr_i)
        read_data1_q <= reg_wdata_i;
      if (wb1Live & read_addr2_q == reg2_waddr_i)
        read_data2_q <= reg2_wdata_i;
      else if (wb0Live & read_addr2_q == reg_waddr_i)
        read_data2_q <= reg_wdata_i;
      if (wb1Live & read_addr3_q == reg2_waddr_i)
        read_data3_q <= reg2_wdata_i;
      else if (wb0Live & read_addr3_q == reg_waddr_i)
        read_data3_q <= reg_wdata_i;
    end
    else begin
      read_data0_q <=
        reg1_raddr_i == 5'h0
          ? 32'h0
          : wb1Live & reg1_raddr_i == reg2_waddr_i
              ? reg2_wdata_i
              : wb0Live & reg1_raddr_i == reg_waddr_i
                  ? reg_wdata_i
                  : _newRead_T_5[0] ? _bank1_r0_ext_R0_data : _bank0_r0_ext_R0_data;
      read_data1_q <=
        reg2_raddr_i == 5'h0
          ? 32'h0
          : wb1Live & reg2_raddr_i == reg2_waddr_i
              ? reg2_wdata_i
              : wb0Live & reg2_raddr_i == reg_waddr_i
                  ? reg_wdata_i
                  : _newRead_T_15[0] ? _bank1_r1_ext_R0_data : _bank0_r1_ext_R0_data;
      read_data2_q <=
        reg3_raddr_i == 5'h0
          ? 32'h0
          : wb1Live & reg3_raddr_i == reg2_waddr_i
              ? reg2_wdata_i
              : wb0Live & reg3_raddr_i == reg_waddr_i
                  ? reg_wdata_i
                  : _newRead_T_25[0] ? _bank1_r2_ext_R0_data : _bank0_r2_ext_R0_data;
      read_data3_q <=
        reg4_raddr_i == 5'h0
          ? 32'h0
          : wb1Live & reg4_raddr_i == reg2_waddr_i
              ? reg2_wdata_i
              : wb0Live & reg4_raddr_i == reg_waddr_i
                  ? reg_wdata_i
                  : _newRead_T_35[0] ? _bank1_r3_ext_R0_data : _bank0_r3_ext_R0_data;
      read_addr0_q <= reg1_raddr_i;
      read_addr1_q <= reg2_raddr_i;
      read_addr2_q <= reg3_raddr_i;
      read_addr3_q <= reg4_raddr_i;
    end
  end
  bank_32x32 bank0_r0_ext (
    .R0_addr (reg1_raddr_i),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_bank0_r0_ext_R0_data),
    .W0_addr (reg_waddr_i),
    .W0_en   (wb0Live),
    .W0_clk  (clk),
    .W0_data (reg_wdata_i)
  );
  bank_32x32 bank0_r1_ext (
    .R0_addr (reg2_raddr_i),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_bank0_r1_ext_R0_data),
    .W0_addr (reg_waddr_i),
    .W0_en   (wb0Live),
    .W0_clk  (clk),
    .W0_data (reg_wdata_i)
  );
  bank_32x32 bank0_r2_ext (
    .R0_addr (reg3_raddr_i),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_bank0_r2_ext_R0_data),
    .W0_addr (reg_waddr_i),
    .W0_en   (wb0Live),
    .W0_clk  (clk),
    .W0_data (reg_wdata_i)
  );
  bank_32x32 bank0_r3_ext (
    .R0_addr (reg4_raddr_i),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_bank0_r3_ext_R0_data),
    .W0_addr (reg_waddr_i),
    .W0_en   (wb0Live),
    .W0_clk  (clk),
    .W0_data (reg_wdata_i)
  );
  bank_32x32 bank1_r0_ext (
    .R0_addr (reg1_raddr_i),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_bank1_r0_ext_R0_data),
    .W0_addr (reg2_waddr_i),
    .W0_en   (wb1Live),
    .W0_clk  (clk),
    .W0_data (reg2_wdata_i)
  );
  bank_32x32 bank1_r1_ext (
    .R0_addr (reg2_raddr_i),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_bank1_r1_ext_R0_data),
    .W0_addr (reg2_waddr_i),
    .W0_en   (wb1Live),
    .W0_clk  (clk),
    .W0_data (reg2_wdata_i)
  );
  bank_32x32 bank1_r2_ext (
    .R0_addr (reg3_raddr_i),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_bank1_r2_ext_R0_data),
    .W0_addr (reg2_waddr_i),
    .W0_en   (wb1Live),
    .W0_clk  (clk),
    .W0_data (reg2_wdata_i)
  );
  bank_32x32 bank1_r3_ext (
    .R0_addr (reg4_raddr_i),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_bank1_r3_ext_R0_data),
    .W0_addr (reg2_waddr_i),
    .W0_en   (wb1Live),
    .W0_clk  (clk),
    .W0_data (reg2_wdata_i)
  );
  assign reg1_rdata_o =
    rst | read_addr0_q == 5'h0
      ? 32'h0
      : wb1Live & read_addr0_q == reg2_waddr_i
          ? reg2_wdata_i
          : wb0Live & read_addr0_q == reg_waddr_i ? reg_wdata_i : read_data0_q;
  assign reg2_rdata_o =
    rst | read_addr1_q == 5'h0
      ? 32'h0
      : wb1Live & read_addr1_q == reg2_waddr_i
          ? reg2_wdata_i
          : wb0Live & read_addr1_q == reg_waddr_i ? reg_wdata_i : read_data1_q;
  assign reg3_rdata_o =
    rst | read_addr2_q == 5'h0
      ? 32'h0
      : wb1Live & read_addr2_q == reg2_waddr_i
          ? reg2_wdata_i
          : wb0Live & read_addr2_q == reg_waddr_i ? reg_wdata_i : read_data2_q;
  assign reg4_rdata_o =
    rst | read_addr3_q == 5'h0
      ? 32'h0
      : wb1Live & read_addr3_q == reg2_waddr_i
          ? reg2_wdata_i
          : wb0Live & read_addr3_q == reg_waddr_i ? reg_wdata_i : read_data3_q;
endmodule

module id_ex(
  input         clk,
                rst,
  input  [31:0] inst_i,
                inst_addr_i,
  input  [4:0]  rs1_addr_i,
                rs2_addr_i,
  input  [31:0] op1_i,
                op2_i,
  input  [4:0]  rd_addr_i,
  input         reg_wen_i,
  input  [31:0] base_addr_i,
                addr_offset_i,
  input         hold_flag_i,
                stall_i,
  input  [5:0]  alu_op_i,
  input         is_mdu_i,
  input  [2:0]  mdu_op_i,
  input         is_system_i,
  input  [3:0]  system_op_i,
  input  [11:0] csr_addr_i,
  input  [4:0]  csr_zimm_i,
  input         illegal_i,
                is_branch_i,
                is_jump_i,
                is_load_i,
                is_store_i,
  input  [2:0]  mem_width_i,
  output [31:0] inst_o,
                inst_addr_o,
  output [4:0]  rs1_addr_o,
                rs2_addr_o,
  output [31:0] op1_o,
                op2_o,
  output [4:0]  rd_addr_o,
  output        reg_wen_o,
  output [31:0] base_addr_o,
                addr_offset_o,
  output [5:0]  alu_op_o,
  output        is_mdu_o,
  output [2:0]  mdu_op_o,
  output        is_system_o,
  output [3:0]  system_op_o,
  output [11:0] csr_addr_o,
  output [4:0]  csr_zimm_o,
  output        illegal_o,
                is_branch_o,
                is_jump_o,
                is_load_o,
                is_store_o,
  output [2:0]  mem_width_o,
  input         prdt_taken_i,
  input  [31:0] prdt_pc_addr_i,
  output        prdt_taken_o,
  output [31:0] prdt_pc_addr_o,
  input         ex_jump_en_i
);

  reg  [31:0] instQ;
  reg  [31:0] instAddrQ;
  reg  [4:0]  rs1AddrQ;
  reg  [4:0]  rs2AddrQ;
  reg  [31:0] op1Q;
  reg  [31:0] op2Q;
  reg  [4:0]  rdAddrQ;
  reg         regWenQ;
  reg  [31:0] baseAddrQ;
  reg  [31:0] offsetQ;
  reg  [5:0]  aluOpQ;
  reg         isMduQ;
  reg  [2:0]  mduOpQ;
  reg         isSystemQ;
  reg  [3:0]  systemOpQ;
  reg  [11:0] csrAddrQ;
  reg  [4:0]  csrZimmQ;
  reg         illegalQ;
  reg         isBranchQ;
  reg         isJumpQ;
  reg         isLoadQ;
  reg         isStoreQ;
  reg  [2:0]  memWidthQ;
  reg         predTakenQ;
  reg  [31:0] predTargetQ;
  wire        flush = hold_flag_i | ex_jump_en_i;
  wire        _GEN = rst | flush;
  always @(posedge clk) begin
    if (_GEN) begin
      instQ <= 32'h13;
      instAddrQ <= 32'h0;
      rs1AddrQ <= 5'h0;
      rs2AddrQ <= 5'h0;
      rdAddrQ <= 5'h0;
      offsetQ <= 32'h0;
      aluOpQ <= 6'h0;
      mduOpQ <= 3'h0;
      systemOpQ <= 4'h0;
      csrAddrQ <= 12'h0;
      csrZimmQ <= 5'h0;
      memWidthQ <= 3'h0;
      predTargetQ <= 32'h0;
    end
    else if (stall_i) begin
    end
    else begin
      instQ <= inst_i;
      instAddrQ <= inst_addr_i;
      rs1AddrQ <= rs1_addr_i;
      rs2AddrQ <= rs2_addr_i;
      rdAddrQ <= rd_addr_i;
      offsetQ <= addr_offset_i;
      aluOpQ <= alu_op_i;
      mduOpQ <= mdu_op_i;
      systemOpQ <= system_op_i;
      csrAddrQ <= csr_addr_i;
      csrZimmQ <= csr_zimm_i;
      memWidthQ <= mem_width_i;
      predTargetQ <= prdt_pc_addr_i;
    end
    regWenQ <= ~_GEN & (stall_i ? regWenQ : reg_wen_i);
    isMduQ <= ~_GEN & (stall_i ? isMduQ : is_mdu_i);
    isSystemQ <= ~_GEN & (stall_i ? isSystemQ : is_system_i);
    illegalQ <= ~_GEN & (stall_i ? illegalQ : illegal_i);
    isBranchQ <= ~_GEN & (stall_i ? isBranchQ : is_branch_i);
    isJumpQ <= ~_GEN & (stall_i ? isJumpQ : is_jump_i);
    isLoadQ <= ~_GEN & (stall_i ? isLoadQ : is_load_i);
    isStoreQ <= ~_GEN & (stall_i ? isStoreQ : is_store_i);
    predTakenQ <= ~_GEN & (stall_i ? predTakenQ : prdt_taken_i);
    if (rst) begin
      op1Q <= 32'h0;
      op2Q <= 32'h0;
      baseAddrQ <= 32'h0;
    end
    else if (stall_i) begin
    end
    else begin
      op1Q <= flush ? 32'h0 : op1_i;
      op2Q <= flush ? 32'h0 : op2_i;
      baseAddrQ <= flush ? 32'h0 : base_addr_i;
    end
  end
  assign inst_o = instQ;
  assign inst_addr_o = instAddrQ;
  assign rs1_addr_o = rs1AddrQ;
  assign rs2_addr_o = rs2AddrQ;
  assign op1_o = op1Q;
  assign op2_o = op2Q;
  assign rd_addr_o = rdAddrQ;
  assign reg_wen_o = regWenQ;
  assign base_addr_o = baseAddrQ;
  assign addr_offset_o = offsetQ;
  assign alu_op_o = aluOpQ;
  assign is_mdu_o = isMduQ;
  assign mdu_op_o = mduOpQ;
  assign is_system_o = isSystemQ;
  assign system_op_o = systemOpQ;
  assign csr_addr_o = csrAddrQ;
  assign csr_zimm_o = csrZimmQ;
  assign illegal_o = illegalQ;
  assign is_branch_o = isBranchQ;
  assign is_jump_o = isJumpQ;
  assign is_load_o = isLoadQ;
  assign is_store_o = isStoreQ;
  assign mem_width_o = memWidthQ;
  assign prdt_taken_o = predTakenQ;
  assign prdt_pc_addr_o = predTargetQ;
endmodule

module mdu(
  input         clk,
                rst,
                start,
  input  [2:0]  op,
  input  [31:0] src1,
                src2,
  output [31:0] result,
  output        busy,
                done
);

  reg  [31:0] resultQ;
  reg         busyQ;
  reg         doneQ;
  reg  [2:0]  opQ;
  reg  [5:0]  countQ;
  reg  [63:0] workQ;
  reg  [31:0] operandQ;
  reg         quotientNegQ;
  reg         remainderNegQ;
  reg         quickFinishQ;
  reg         mulNegateQ;
  wire [31:0] _absSrc1_T_3 = 32'h0 - src1;
  wire [31:0] _absSrc2_T_3 = 32'h0 - src2;
  wire        _workQ_T_6 = op == 3'h4;
  wire        _workQ_T_2 = op == 3'h5;
  wire        _signedOp_T_1 = op == 3'h6;
  wire        signedOp = _workQ_T_6 | _signedOp_T_1;
  wire        startSrc2Signed = op == 3'h1;
  wire        _startSrc1Signed_T_1 = op == 3'h2;
  wire        startHighMul = startSrc2Signed | _startSrc1Signed_T_1 | op == 3'h3;
  wire        startSrc1Signed = startSrc2Signed | _startSrc1Signed_T_1;
  wire        _GEN = (_workQ_T_6 | _workQ_T_2 | _signedOp_T_1 | (&op)) & src2 == 32'h0;
  wire        _GEN_0 = (_workQ_T_6 | _signedOp_T_1) & src1 == 32'h80000000 & (&src2);
  wire        _GEN_1 = _GEN | _GEN_0;
  wire        activeHighMul = opQ == 3'h1 | opQ == 3'h2 | opQ == 3'h3;
  wire        _GEN_2 = start & ~busyQ;
  wire        _GEN_3 = countQ == 6'h1F;
  wire        _GEN_4 = quickFinishQ | _GEN_3;
  wire        _GEN_5 = rst | _GEN_2;
  wire [33:0] _arithmeticSum_T_5 =
    {1'h0, activeHighMul ? {1'h0, workQ[63:32]} : workQ[63:31]}
    + {1'h0, activeHighMul ? (workQ[0] ? {1'h0, operandQ} : 33'h0) : {1'h1, ~operandQ}}
    + {33'h0, ~activeHighMul};
  wire [31:0] nextRemainder =
    _arithmeticSum_T_5[33] ? _arithmeticSum_T_5[31:0] : workQ[62:31];
  wire [63:0] _signedMulProduct_T_1 = 64'h0 - {_arithmeticSum_T_5[32:0], workQ[31:1]};
  always @(posedge clk) begin
    if (rst) begin
      resultQ <= 32'h0;
      busyQ <= 1'h0;
      opQ <= 3'h0;
      workQ <= 64'h0;
      operandQ <= 32'h0;
      quotientNegQ <= 1'h0;
      remainderNegQ <= 1'h0;
      quickFinishQ <= 1'h0;
      mulNegateQ <= 1'h0;
    end
    else begin
      if (_GEN_2 | ~busyQ) begin
      end
      else if (activeHighMul) begin
        if (_GEN_3)
          resultQ <= mulNegateQ ? _signedMulProduct_T_1[63:32] : _arithmeticSum_T_5[32:1];
      end
      else if (quickFinishQ)
        resultQ <= workQ[31:0];
      else if (_GEN_3)
        resultQ <=
          opQ == 3'h4 | opQ == 3'h5
            ? (quotientNegQ
                 ? 32'h0 - {workQ[30:0], _arithmeticSum_T_5[33]}
                 : {workQ[30:0], _arithmeticSum_T_5[33]})
            : remainderNegQ ? 32'h0 - nextRemainder : nextRemainder;
      busyQ <=
        _GEN_2 | (busyQ ? (activeHighMul ? ~_GEN_3 & busyQ : ~_GEN_4 & busyQ) : busyQ);
      if (_GEN_2) begin
        opQ <= op;
        workQ <=
          {32'h0,
           startHighMul
             ? (startSrc2Signed & src2[31] ? _absSrc2_T_3 : src2)
             : _GEN
                 ? (_workQ_T_6 | _workQ_T_2 ? 32'hFFFFFFFF : src1)
                 : _GEN_0
                     ? {_workQ_T_6, 31'h0}
                     : signedOp & src1[31] ? _absSrc1_T_3 : src1};
        if (startHighMul)
          operandQ <= startSrc1Signed & src1[31] ? _absSrc1_T_3 : src1;
        else if (~_GEN_1)
          operandQ <= signedOp & src2[31] ? _absSrc2_T_3 : src2;
        quickFinishQ <= ~startHighMul & (_GEN | _GEN_0);
      end
      else if (busyQ) begin
        if (activeHighMul)
          workQ <= {_arithmeticSum_T_5[32:0], workQ[31:1]};
        else if (quickFinishQ) begin
        end
        else
          workQ <= {nextRemainder, workQ[30:0], _arithmeticSum_T_5[33]};
      end
      if (~_GEN_2 | startHighMul | _GEN_1) begin
      end
      else begin
        quotientNegQ <= signedOp & (src1[31] ^ src2[31]);
        remainderNegQ <= signedOp & src1[31];
      end
      if (_GEN_2 & startHighMul)
        mulNegateQ <= startSrc1Signed & src1[31] ^ startSrc2Signed & src2[31];
    end
    doneQ <= ~_GEN_5 & busyQ & (~activeHighMul & quickFinishQ | _GEN_3);
    if (_GEN_5)
      countQ <= 6'h0;
    else if (busyQ) begin
      if (activeHighMul) begin
        if (~_GEN_3)
          countQ <= countQ + 6'h1;
      end
      else if (~_GEN_4)
        countQ <= countQ + 6'h1;
    end
  end
  assign result = resultQ;
  assign busy = busyQ;
  assign done = doneQ;
endmodule

module lowmul_p00(
  input  [15:0] a_i,
                b_i,
  output [31:0] product_o
);

  assign product_o = {16'h0, a_i} * {16'h0, b_i};
endmodule

module lowmul_cross(
  input  [15:0] a0_i,
                a1_i,
                b0_i,
                b1_i,
  output [15:0] cross_o
);

  assign cross_o = a0_i * b1_i + a1_i * b0_i;
endmodule

module ex(
  input         clk,
                rst,
                stall_i,
  input  [31:0] inst_i,
                inst_addr_i,
                op1_i,
                op2_i,
  input  [4:0]  rd_addr_i,
  input         reg_wen_i,
  input  [31:0] base_addr_i,
                addr_offset_i,
  input  [5:0]  alu_op_i,
  input         is_mdu_i,
  input  [2:0]  mdu_op_i,
  input         is_system_i,
                illegal_i,
  input  [31:0] csr_read_value_i,
  input         illegal_csr_i,
                is_branch_i,
                is_load_i,
                is_store_i,
                is_jump_i,
  input  [2:0]  mem_width_i,
  output [31:0] rd_data_o,
                non_mdu_rd_data_o,
  output [4:0]  rd_addr_o,
  output        rd_wen_o,
  output [31:0] real_jump_addr_o,
  output        real_jump_en_o,
                mdu_stall_o,
                mem_rd_req,
  output [31:0] mem_rd_addr,
                mem_wr_data_o,
  output [1:0]  mem_mask,
  output [2:0]  sel,
  input         prdt_taken_i,
  input  [31:0] prdt_pc_addr_i,
  output        ex_real_taken_o,
  output [31:0] resolved_target_o
);

  wire [15:0] _cross_cross_o;
  wire [31:0] _p00_product_o;
  wire [31:0] _mdu_result;
  wire        _mdu_busy;
  wire        _mdu_done;
  wire        longMdu = is_mdu_i & (|mdu_op_i);
  wire        aluResult_unsignedLess = op1_i < op2_i;
  wire [62:0] _aluResult_T_13 = {31'h0, op1_i} << op2_i[4:0];
  wire [31:0] _aluResult_T_17 =
    {32{alu_op_i == 6'h0}} & op1_i + op2_i | {32{alu_op_i == 6'h1}} & op1_i - op2_i
    | {32{alu_op_i == 6'h2}} & _aluResult_T_13[31:0];
  wire [31:0] _GEN = {27'h0, op2_i[4:0]};
  wire [31:0] aluResult =
    {_aluResult_T_17[31:1],
     _aluResult_T_17[0] | alu_op_i == 6'h3 & $signed(op1_i) < $signed(op2_i)
       | alu_op_i == 6'h4 & aluResult_unsignedLess} | {32{alu_op_i == 6'h5}}
    & (op1_i ^ op2_i) | {32{alu_op_i == 6'h6}} & op1_i >> _GEN | {32{alu_op_i == 6'h7}}
    & $signed($signed(op1_i) >>> _GEN) | {32{alu_op_i == 6'h8}} & (op1_i | op2_i)
    | {32{alu_op_i == 6'h9}} & op1_i & op2_i | {32{alu_op_i == 6'hA}} & op1_i;
  wire        jumpActive = ~is_branch_i & is_jump_i;
  wire        loadActive = ~is_branch_i & ~is_jump_i & is_load_i;
  wire        storeActive = ~is_branch_i & ~is_jump_i & ~is_load_i & is_store_i;
  wire        jumpEnable =
    is_branch_i
      ? mem_width_i == 3'h0 & op1_i == op2_i | mem_width_i == 3'h1 & op1_i != op2_i
        | mem_width_i == 3'h4 & $signed(op1_i) < $signed(op2_i) | mem_width_i == 3'h5
        & $signed(op1_i) >= $signed(op2_i) | mem_width_i == 3'h6 & aluResult_unsignedLess
        | (&mem_width_i) & ~aluResult_unsignedLess
      : jumpActive;
  wire [31:0] _addressSum_T = base_addr_i + addr_offset_i;
  wire [31:0] jumpAddress =
    is_branch_i
      ? _addressSum_T
      : jumpActive ? ({32{inst_i[6:0] != 7'h67}} | 32'hFFFFFFFE) & _addressSum_T : 32'h0;
  wire        anyJump = is_branch_i | is_jump_i;
  wire        redirect =
    anyJump
    & (jumpEnable != prdt_taken_i | anyJump & jumpEnable & prdt_taken_i
       & jumpAddress != prdt_pc_addr_i);
  wire        _mem_mask_T = loadActive | storeActive;
  mdu mdu (
    .clk    (clk),
    .rst    (rst),
    .start  (longMdu & ~stall_i & ~_mdu_busy & ~_mdu_done),
    .op     (mdu_op_i),
    .src1   (op1_i),
    .src2   (op2_i),
    .result (_mdu_result),
    .busy   (_mdu_busy),
    .done   (_mdu_done)
  );
  lowmul_p00 p00 (
    .a_i       (op1_i[15:0]),
    .b_i       (op2_i[15:0]),
    .product_o (_p00_product_o)
  );
  lowmul_cross cross_0 (
    .a0_i    (op1_i[15:0]),
    .a1_i    (op1_i[31:16]),
    .b0_i    (op2_i[15:0]),
    .b1_i    (op2_i[31:16]),
    .cross_o (_cross_cross_o)
  );
  assign rd_data_o =
    is_mdu_i
      ? (mdu_op_i == 3'h0
           ? {_p00_product_o[31:16] + _cross_cross_o, _p00_product_o[15:0]}
           : _mdu_result)
      : is_system_i ? csr_read_value_i : aluResult;
  assign non_mdu_rd_data_o = aluResult;
  assign rd_addr_o = rd_addr_i;
  assign rd_wen_o = reg_wen_i & ~illegal_i & ~illegal_csr_i & (~longMdu | _mdu_done);
  assign real_jump_addr_o =
    redirect ? (jumpEnable ? jumpAddress : inst_addr_i + 32'h4) : 32'h0;
  assign real_jump_en_o = redirect;
  assign mdu_stall_o = longMdu & ~_mdu_done;
  assign mem_rd_req = storeActive;
  assign mem_rd_addr = _mem_mask_T ? _addressSum_T : 32'h0;
  assign mem_wr_data_o = storeActive ? op2_i : 32'h0;
  assign mem_mask = _mem_mask_T ? mem_width_i[1:0] : 2'h0;
  assign sel = loadActive ? mem_width_i : 3'h0;
  assign ex_real_taken_o = is_branch_i & jumpEnable;
  assign resolved_target_o = jumpAddress;
endmodule

module ex_lane1(
  input         valid_i,
  input  [31:0] inst_i,
                inst_addr_i,
                op1_i,
                op2_i,
                mdu_op1_i,
                mdu_op2_i,
                control_op1_i,
                control_op2_i,
                control_base_i,
  input  [4:0]  rd_addr_i,
  input         reg_wen_i,
  input  [31:0] base_addr_i,
                addr_offset_i,
  input  [5:0]  alu_op_i,
  input         is_mdu_i,
  input  [2:0]  mdu_op_i,
  input         illegal_i,
                is_branch_i,
                is_load_i,
                is_store_i,
                is_jump_i,
  input  [2:0]  mem_width_i,
  input         pred_taken_i,
  input  [31:0] pred_target_i,
  output [31:0] rd_data_o,
  output [4:0]  rd_addr_o,
  output        rd_wen_o,
                redirect_o,
  output [31:0] redirect_pc_o,
  output        control_valid_o,
                branch_valid_o,
                actual_taken_o,
  output [31:0] resolved_target_o,
  output        mem_valid_o,
                mem_write_o,
  output [31:0] mem_addr_o,
                mem_wdata_o,
  output [1:0]  mem_mask_o,
  output [2:0]  load_sel_o
);

  wire [15:0] _cross_cross_o;
  wire [31:0] _p00_product_o;
  wire        _branchTaken_T_25 = control_op1_i < control_op2_i;
  wire        controlTaken =
    is_jump_i | is_branch_i
    & (mem_width_i == 3'h0 & control_op1_i == control_op2_i | mem_width_i == 3'h1
       & control_op1_i != control_op2_i | mem_width_i == 3'h4
       & $signed(control_op1_i) < $signed(control_op2_i) | mem_width_i == 3'h5
       & $signed(control_op1_i) >= $signed(control_op2_i) | mem_width_i == 3'h6
       & _branchTaken_T_25 | (&mem_width_i) & ~_branchTaken_T_25);
  wire [31:0] controlTarget =
    ({32{~(is_jump_i & inst_i[6:0] == 7'h67)}} | 32'hFFFFFFFE) & control_base_i
    + addr_offset_i;
  wire        controlValid = valid_i & (is_branch_i | is_jump_i);
  wire        redirect =
    controlValid
    & (controlTaken != pred_taken_i | controlTaken & pred_taken_i
       & controlTarget != pred_target_i);
  wire [62:0] _rd_data_o_T_15 = {31'h0, op1_i} << op2_i[4:0];
  wire [31:0] _rd_data_o_T_19 =
    {32{alu_op_i == 6'h0}} & op1_i + op2_i | {32{alu_op_i == 6'h1}} & op1_i - op2_i
    | {32{alu_op_i == 6'h2}} & _rd_data_o_T_15[31:0];
  wire [31:0] _GEN = {27'h0, op2_i[4:0]};
  lowmul_p00 p00 (
    .a_i       (mdu_op1_i[15:0]),
    .b_i       (mdu_op2_i[15:0]),
    .product_o (_p00_product_o)
  );
  lowmul_cross cross_0 (
    .a0_i    (mdu_op1_i[15:0]),
    .a1_i    (mdu_op1_i[31:16]),
    .b0_i    (mdu_op2_i[15:0]),
    .b1_i    (mdu_op2_i[31:16]),
    .cross_o (_cross_cross_o)
  );
  assign rd_data_o =
    is_mdu_i
      ? (mdu_op_i == 3'h0
           ? {_p00_product_o[31:16] + _cross_cross_o, _p00_product_o[15:0]}
           : 32'h0)
      : {_rd_data_o_T_19[31:1],
         _rd_data_o_T_19[0] | alu_op_i == 6'h3 & $signed(op1_i) < $signed(op2_i)
           | alu_op_i == 6'h4 & op1_i < op2_i} | {32{alu_op_i == 6'h5}} & (op1_i ^ op2_i)
        | {32{alu_op_i == 6'h6}} & op1_i >> _GEN | {32{alu_op_i == 6'h7}}
        & $signed($signed(op1_i) >>> _GEN) | {32{alu_op_i == 6'h8}} & (op1_i | op2_i)
        | {32{alu_op_i == 6'h9}} & op1_i & op2_i | {32{alu_op_i == 6'hA}} & op1_i;
  assign rd_addr_o = rd_addr_i;
  assign rd_wen_o = valid_i & reg_wen_i & ~illegal_i;
  assign redirect_o = redirect;
  assign redirect_pc_o =
    redirect ? (controlTaken ? controlTarget : inst_addr_i + 32'h4) : 32'h0;
  assign control_valid_o = controlValid;
  assign branch_valid_o = valid_i & is_branch_i;
  assign actual_taken_o = valid_i & controlTaken;
  assign resolved_target_o = controlTarget;
  assign mem_valid_o = valid_i & (is_load_i | is_store_i);
  assign mem_write_o = valid_i & is_store_i;
  assign mem_addr_o = base_addr_i + addr_offset_i;
  assign mem_wdata_o = op2_i;
  assign mem_mask_o = mem_width_i[1:0];
  assign load_sel_o = mem_width_i;
endmodule

module myCPU_soc_pma(
  input  [31:0] addr_i,
  input  [1:0]  size_i,
  output        readable_o,
                writable_o,
                cacheable_o
);

  wire        sizeValid = size_i != 2'h3;
  wire        _staysInWord_T = size_i == 2'h0;
  wire        _staysInWord_T_1 = size_i == 2'h1;
  wire [17:0] _inRam_lowLast_T_2 =
    {1'h0, addr_i[16:0]}
    + {15'h0, _staysInWord_T ? 3'h0 : {1'h0, ~_staysInWord_T_1, 1'h1}};
  wire        inRam = sizeValid & addr_i[31:17] == 15'hE00 & ~(_inRam_lowLast_T_2[17]);
  wire        staysInWord =
    sizeValid
    & (_staysInWord_T | _staysInWord_T_1 & addr_i[1:0] != 2'h3 | size_i == 2'h2
       & addr_i[1:0] == 2'h0);
  wire        inUartData = staysInWord & addr_i[31:2] == 30'h7F80078;
  wire        inGpioOutput = staysInWord & addr_i[31:2] == 30'h7F80081;
  wire        inGpioOe = staysInWord & addr_i[31:2] == 30'h7F80082;
  wire        timerRegister =
    staysInWord & addr_i[31:2] == 30'h800000 | staysInWord & addr_i[31:2] == 30'h801000
    | staysInWord & addr_i[31:2] == 30'h801001 | staysInWord & addr_i[31:2] == 30'h802FFE
    | staysInWord & addr_i[31:2] == 30'h802FFF;
  assign readable_o =
    inRam | staysInWord & addr_i[31:2] == 30'h7F80000 | inUartData | staysInWord
    & addr_i[31:2] == 30'h7F80079 | timerRegister | staysInWord
    & addr_i[31:2] == 30'h7F80080 | inGpioOutput | inGpioOe;
  assign writable_o = inRam | inUartData | timerRegister | inGpioOutput | inGpioOe;
  assign cacheable_o = inRam;
endmodule

module csr_unit(
  input         clk,
                rst,
                stall_i,
                csr_valid_i,
  input  [3:0]  csr_op_i,
  input  [11:0] csr_addr_i,
  input  [31:0] csr_rs1_value_i,
  input  [4:0]  csr_zimm_i,
  output [31:0] csr_read_value_o,
  output        illegal_csr_o,
  input         trap_valid_i,
  input  [31:0] trap_cause_i,
                trap_pc_i,
                trap_tval_i,
  input         mret_valid_i,
  output        redirect_o,
  output [31:0] redirect_pc_o,
  input         software_irq_i,
                timer_irq_i,
                external_irq_i,
  output        interrupt_request_o,
  output [31:0] interrupt_cause_o,
  input  [1:0]  instret_count_i
);

  reg  [31:0] mstatus_q;
  reg  [31:0] mie_q;
  reg  [31:0] mtvec_q;
  reg  [31:0] mscratch_q;
  reg  [31:0] mepc_q;
  reg  [31:0] mcause_q;
  reg  [31:0] mtval_q;
  reg  [31:0] mcycle_lo_q;
  reg  [31:0] mcycle_hi_q;
  reg  [31:0] minstret_lo_q;
  reg  [31:0] minstret_hi_q;
  wire        _csrWriteEnable_T = csr_op_i == 4'h1;
  wire        _csrWriteEnable_T_1 = csr_op_i == 4'h2;
  wire        _csrWriteEnable_T_2 = csr_op_i == 4'h3;
  wire        _csrWriteEnable_T_6 = csr_op_i == 4'h5;
  wire        _csrWriteEnable_T_8 = csr_op_i == 4'h6;
  wire        _csrWriteEnable_T_9 = csr_op_i == 4'h7;
  wire        csrInstruction =
    csr_valid_i
    & (_csrWriteEnable_T | _csrWriteEnable_T_1 | _csrWriteEnable_T_2 | _csrWriteEnable_T_6
       | _csrWriteEnable_T_8 | _csrWriteEnable_T_9);
  wire        _csrRead_T = csr_addr_i == 12'h300;
  wire        _csrRead_T_3 = csr_addr_i == 12'h301;
  wire        _csrRead_T_7 = csr_addr_i == 12'h304;
  wire        _csrRead_T_11 = csr_addr_i == 12'h305;
  wire        _csrRead_T_15 = csr_addr_i == 12'h340;
  wire        _csrRead_T_19 = csr_addr_i == 12'h341;
  wire        _csrRead_T_23 = csr_addr_i == 12'h342;
  wire        _csrRead_T_27 = csr_addr_i == 12'h343;
  wire        _csrRead_T_31 = csr_addr_i == 12'h344;
  wire        _csrRead_T_36 = csr_addr_i == 12'hB00;
  wire        _csrRead_T_40 = csr_addr_i == 12'hB80;
  wire        _csrRead_T_44 = csr_addr_i == 12'hB02;
  wire        _csrRead_T_48 = csr_addr_i == 12'hB82;
  wire        csrKnown =
    _csrRead_T | _csrRead_T_3 | _csrRead_T_7 | _csrRead_T_11 | _csrRead_T_15
    | _csrRead_T_19 | _csrRead_T_23 | _csrRead_T_27 | _csrRead_T_31 | _csrRead_T_36
    | _csrRead_T_40 | _csrRead_T_44 | _csrRead_T_48;
  wire [31:0] csrRead =
    {32{_csrRead_T}} & mstatus_q | {32{_csrRead_T_3}} & 32'h40001100 | {32{_csrRead_T_7}}
    & mie_q | {32{_csrRead_T_11}} & mtvec_q | {32{_csrRead_T_15}} & mscratch_q
    | {32{_csrRead_T_19}} & mepc_q | {32{_csrRead_T_23}} & mcause_q | {32{_csrRead_T_27}}
    & mtval_q | {32{_csrRead_T_31}}
    & {20'h0, external_irq_i, 3'h0, timer_irq_i, 3'h0, software_irq_i, 3'h0}
    | {32{_csrRead_T_36}} & mcycle_lo_q | {32{_csrRead_T_40}} & mcycle_hi_q
    | {32{_csrRead_T_44}} & minstret_lo_q | {32{_csrRead_T_48}} & minstret_hi_q;
  wire        illegalCsr = csrInstruction & ~csrKnown;
  wire        externalPending = external_irq_i & mie_q[11];
  wire        softwarePending = software_irq_i & mie_q[3];
  wire [31:0] immValue = {27'h0, csr_zimm_i};
  wire [31:0] csrWriteValue =
    {32{_csrWriteEnable_T}} & csr_rs1_value_i | {32{_csrWriteEnable_T_1}}
    & (csrRead | csr_rs1_value_i) | {32{_csrWriteEnable_T_2}} & csrRead & ~csr_rs1_value_i
    | {32{_csrWriteEnable_T_6}} & immValue | {32{_csrWriteEnable_T_8}}
    & (csrRead | immValue) | {32{_csrWriteEnable_T_9}} & csrRead
    & {27'h7FFFFFF, ~csr_zimm_i};
  wire [31:0] _mstatusCsr_T = mstatus_q & 32'hFFFFE777;
  wire        _GEN =
    csrInstruction & csrKnown & ~illegalCsr & ~stall_i & ~trap_valid_i & ~mret_valid_i
    & (_csrWriteEnable_T | (_csrWriteEnable_T_1 | _csrWriteEnable_T_2)
       & (|csr_rs1_value_i) | _csrWriteEnable_T_6
       | (_csrWriteEnable_T_8 | _csrWriteEnable_T_9) & (|csr_zimm_i));
  wire        _GEN_0 = trap_valid_i | mret_valid_i;
  always @(posedge clk) begin
    if (rst) begin
      mstatus_q <= 32'h1800;
      mie_q <= 32'h0;
      mtvec_q <= 32'h0;
      mscratch_q <= 32'h0;
      mepc_q <= 32'h0;
      mcause_q <= 32'h0;
      mtval_q <= 32'h0;
      mcycle_lo_q <= 32'h0;
      mcycle_hi_q <= 32'h0;
      minstret_lo_q <= 32'h0;
      minstret_hi_q <= 32'h0;
    end
    else begin
      if (trap_valid_i) begin
        mstatus_q <= _mstatusCsr_T | {24'h18, mstatus_q[3], 7'h0};
        mepc_q <= {trap_pc_i[31:2], 2'h0};
        mcause_q <= trap_cause_i;
        mtval_q <= trap_tval_i;
      end
      else begin
        if (mret_valid_i)
          mstatus_q <= _mstatusCsr_T | {28'h188, mstatus_q[7], 3'h0};
        else if (_GEN & _csrRead_T)
          mstatus_q <=
            _mstatusCsr_T | {24'h18, csrWriteValue[7], 3'h0, csrWriteValue[3], 3'h0};
        if (mret_valid_i | ~_GEN | _csrRead_T | _csrRead_T_7 | _csrRead_T_11
            | _csrRead_T_15 | ~_csrRead_T_19) begin
        end
        else
          mepc_q <= {csrWriteValue[31:2], 2'h0};
        if (mret_valid_i | ~_GEN | _csrRead_T | _csrRead_T_7 | _csrRead_T_11
            | _csrRead_T_15 | _csrRead_T_19 | ~_csrRead_T_23) begin
        end
        else
          mcause_q <= csrWriteValue;
        if (mret_valid_i | ~_GEN | _csrRead_T | _csrRead_T_7 | _csrRead_T_11
            | _csrRead_T_15 | _csrRead_T_19 | _csrRead_T_23 | ~_csrRead_T_27) begin
        end
        else
          mtval_q <= csrWriteValue;
      end
      if (_GEN_0 | ~_GEN | _csrRead_T | ~_csrRead_T_7) begin
      end
      else
        mie_q <= csrWriteValue & 32'h888;
      if (_GEN_0 | ~_GEN | _csrRead_T | _csrRead_T_7 | ~_csrRead_T_11) begin
      end
      else
        mtvec_q <= {csrWriteValue[31:2], 1'h0, csrWriteValue[1:0] == 2'h1};
      if (_GEN_0 | ~_GEN | _csrRead_T | _csrRead_T_7 | _csrRead_T_11
          | ~_csrRead_T_15) begin
      end
      else
        mscratch_q <= csrWriteValue;
      if (_GEN_0 | ~_GEN | _csrRead_T | _csrRead_T_7 | _csrRead_T_11 | _csrRead_T_15
          | _csrRead_T_19 | _csrRead_T_23 | _csrRead_T_27 | ~_csrRead_T_36)
        mcycle_lo_q <= mcycle_lo_q + 32'h1;
      else
        mcycle_lo_q <= csrWriteValue;
      if (_GEN_0 | ~_GEN | _csrRead_T | _csrRead_T_7 | _csrRead_T_11 | _csrRead_T_15
          | _csrRead_T_19 | _csrRead_T_23 | _csrRead_T_27 | _csrRead_T_36
          | ~_csrRead_T_40)
        mcycle_hi_q <= mcycle_hi_q + {31'h0, &mcycle_lo_q};
      else
        mcycle_hi_q <= csrWriteValue;
      if (_GEN_0 | ~_GEN | _csrRead_T | _csrRead_T_7 | _csrRead_T_11 | _csrRead_T_15
          | _csrRead_T_19 | _csrRead_T_23 | _csrRead_T_27 | _csrRead_T_36 | _csrRead_T_40
          | ~_csrRead_T_44)
        minstret_lo_q <= minstret_lo_q + {30'h0, instret_count_i};
      else
        minstret_lo_q <= csrWriteValue;
      if (_GEN_0 | ~_GEN | _csrRead_T | _csrRead_T_7 | _csrRead_T_11 | _csrRead_T_15
          | _csrRead_T_19 | _csrRead_T_23 | _csrRead_T_27 | _csrRead_T_36 | _csrRead_T_40
          | _csrRead_T_44 | ~_csrRead_T_48)
        minstret_hi_q <=
          minstret_hi_q
          + {31'h0,
             instret_count_i == 2'h1
               ? (&minstret_lo_q)
               : instret_count_i == 2'h2
                   ? (&(minstret_lo_q[31:1]))
                   : (&instret_count_i) & (&(minstret_lo_q[31:2]))
                     & (|(minstret_lo_q[1:0]))};
      else
        minstret_hi_q <= csrWriteValue;
    end
  end
  assign csr_read_value_o = csrRead;
  assign illegal_csr_o = illegalCsr;
  assign redirect_o = trap_valid_i | mret_valid_i;
  assign redirect_pc_o =
    mret_valid_i
      ? mepc_q
      : trap_cause_i[31] & mtvec_q[1:0] == 2'h1
          ? {mtvec_q[31:2], 2'h0} + {25'h0, trap_cause_i[4:0], 2'h0}
          : {mtvec_q[31:2], 2'h0};
  assign interrupt_request_o =
    mstatus_q[3] & (externalPending | softwarePending | timer_irq_i & mie_q[7]);
  assign interrupt_cause_o =
    externalPending ? 32'h8000000B : {29'h10000000, ~softwarePending, 2'h3};
endmodule

module way_128x32(
  input  [6:0]  R0_addr,
  input         R0_en,
                R0_clk,
  output [31:0] R0_data,
  input  [6:0]  W0_addr,
  input         W0_en,
                W0_clk,
  input  [31:0] W0_data
);

  reg [31:0] Memory[0:127] /* synthesis syn_ramstyle = "block_ram" */;
  reg        _R0_en_d0;
  reg [6:0]  _R0_addr_d0;
  always @(posedge R0_clk) begin
    _R0_en_d0 <= R0_en;
    _R0_addr_d0 <= R0_addr;
  end
  always @(posedge W0_clk) begin
    if (W0_en & 1'h1)
      Memory[W0_addr] <= W0_data;
  end
  assign R0_data = _R0_en_d0 ? Memory[_R0_addr_d0] : 32'bx;
endmodule

module way_128x21(
  input  [6:0]  R0_addr,
  input         R0_en,
                R0_clk,
  output [20:0] R0_data,
  input  [6:0]  W0_addr,
  input         W0_en,
                W0_clk,
  input  [20:0] W0_data
);

  reg [20:0] Memory[0:127] /* synthesis syn_ramstyle = "block_ram" */;
  reg        _R0_en_d0;
  reg [6:0]  _R0_addr_d0;
  always @(posedge R0_clk) begin
    _R0_en_d0 <= R0_en;
    _R0_addr_d0 <= R0_addr;
  end
  always @(posedge W0_clk) begin
    if (W0_en & 1'h1)
      Memory[W0_addr] <= W0_data;
  end
  assign R0_data = _R0_en_d0 ? Memory[_R0_addr_d0] : 21'bx;
endmodule

module metadata_128x5(
  input  [6:0] R0_addr,
  input        R0_en,
               R0_clk,
  output [4:0] R0_data,
  input  [6:0] W0_addr,
  input        W0_en,
               W0_clk,
  input  [4:0] W0_data
);

  reg [4:0] Memory[0:127] /* synthesis syn_ramstyle = "block_ram" */;
  reg       _R0_en_d0;
  reg [6:0] _R0_addr_d0;
  always @(posedge R0_clk) begin
    _R0_en_d0 <= R0_en;
    _R0_addr_d0 <= R0_addr;
  end
  always @(posedge W0_clk) begin
    if (W0_en & 1'h1)
      Memory[W0_addr] <= W0_data;
  end
  assign R0_data = _R0_en_d0 ? Memory[_R0_addr_d0] : 5'bx;
endmodule

module dcache_2way(
  input          clk,
                 rst,
                 cpu_req_valid_i,
  output         cpu_req_ready_o,
  input  [1:0]   cpu_req_owner_i,
  input  [31:0]  cpu_req_addr_i,
  input  [6:0]   cpu_req_vindex_i,
  input          cpu_req_write_i,
  input  [1:0]   cpu_req_size_i,
  input  [31:0]  cpu_req_wdata_i,
  input          cpu_req_cacheable_i,
  output         cpu_resp_valid_o,
  output [1:0]   cpu_resp_owner_o,
  output [31:0]  cpu_resp_rdata_o,
  output         cpu_resp_error_o,
                 busy_o,
  input          fence_req_i,
  output         fence_req_ready_o,
                 fence_done_o,
                 fence_error_o,
  output [31:0]  fence_error_addr_o,
  output         mem_cmd_valid_o,
  input          mem_cmd_ready_i,
  output [1:0]   mem_cmd_owner_o,
  output         mem_cmd_write_o,
  output [31:0]  mem_cmd_addr_o,
  output [1:0]   mem_cmd_size_o,
  output [2:0]   mem_cmd_len_o,
  output [127:0] mem_cmd_wdata_o,
  output [15:0]  mem_cmd_wstrb_o,
  input          mem_rsp_valid_i,
  output         mem_rsp_ready_o,
  input  [1:0]   mem_rsp_owner_i,
  input  [31:0]  mem_rsp_rdata_i,
  input          mem_rsp_last_i,
                 mem_rsp_error_i
);

  wire             _mem_rsp_ready_o_output;
  wire [31:0]      lookup_way1_data3_q;
  wire [31:0]      lookup_way1_data2_q;
  wire [31:0]      lookup_way1_data1_q;
  wire [31:0]      lookup_way1_data0_q;
  wire [31:0]      lookup_way0_data3_q;
  wire [31:0]      lookup_way0_data2_q;
  wire [31:0]      lookup_way0_data1_q;
  wire [31:0]      lookup_way0_data0_q;
  wire [4:0]       metadata_q;
  wire             _fence_req_ready_o_output;
  wire             _cpu_req_ready_o_output;
  wire [4:0]       _metadata_ext_R0_data;
  wire [20:0]      _way1_tag_ext_R0_data;
  wire [20:0]      _way0_tag_ext_R0_data;
  wire [31:0]      _way1_data3_ext_R0_data;
  wire [31:0]      _way1_data2_ext_R0_data;
  wire [31:0]      _way1_data1_ext_R0_data;
  wire [31:0]      _way1_data0_ext_R0_data;
  wire [31:0]      _way0_data3_ext_R0_data;
  wire [31:0]      _way0_data2_ext_R0_data;
  wire [31:0]      _way0_data1_ext_R0_data;
  wire [31:0]      _way0_data0_ext_R0_data;
  reg              fence_done_o_out_reg;
  reg              fence_error_o_out_reg;
  reg  [31:0]      fence_error_addr_o_out_reg;
  reg  [3:0]       state_q;
  reg  [6:0]       scrub_index_q;
  reg  [1:0]       req_owner_q;
  reg  [31:0]      req_addr_q;
  reg              req_write_q;
  reg  [1:0]       req_size_q;
  reg  [31:0]      req_wdata_q;
  reg              req_cacheable_q;
  reg              victim_way_q;
  reg  [2:0]       refill_beat_q;
  reg              refill_error_q;
  reg  [31:0]      critical_word_q;
  reg  [6:0]       fence_index_q;
  reg              fence_way_q;
  reg  [1:0]       held_resp_owner_q;
  reg  [31:0]      held_resp_data_q;
  reg              held_resp_error_q;
  wire             cpu_req_accept = cpu_req_valid_i & _cpu_req_ready_o_output;
  wire             fence_req_accept = fence_req_i & _fence_req_ready_o_output;
  wire             hit_way = metadata_q[2] & _way1_tag_ext_R0_data == req_addr_q[31:11];
  wire             cache_hit =
    metadata_q[0] & _way0_tag_ext_R0_data == req_addr_q[31:11] | hit_way;
  wire             selected_victim_way =
    metadata_q[0] & (~(metadata_q[2]) | metadata_q[4]);
  wire             victim_dirty =
    (selected_victim_way ? metadata_q[2] : metadata_q[0])
    & (selected_victim_way ? metadata_q[3] : metadata_q[1]);
  wire [3:0][31:0] _GEN =
    {{lookup_way0_data3_q},
     {lookup_way0_data2_q},
     {lookup_way0_data1_q},
     {lookup_way0_data0_q}};
  wire [3:0][31:0] _GEN_0 =
    {{lookup_way1_data3_q},
     {lookup_way1_data2_q},
     {lookup_way1_data1_q},
     {lookup_way1_data0_q}};
  wire [31:0]      hit_word = hit_way ? _GEN_0[req_addr_q[3:2]] : _GEN[req_addr_q[3:2]];
  wire             _GEN_1 = req_size_q == 2'h0;
  wire [3:0][7:0]  _GEN_2 =
    {{hit_word[31:24]}, {hit_word[23:16]}, {hit_word[15:8]}, {hit_word[7:0]}};
  wire             _GEN_3 = req_size_q == 2'h1;
  wire [6:0]       _req_wstrb_T_1 = 7'h1 << req_addr_q[1:0];
  wire [3:0]       req_wstrb =
    _GEN_1 ? _req_wstrb_T_1[3:0] : _GEN_3 ? (req_addr_q[1] ? 4'hC : 4'h3) : 4'hF;
  wire [31:0]      req_bus_wdata =
    _GEN_1 ? {2{{2{req_wdata_q[7:0]}}}} : _GEN_3 ? {2{req_wdata_q[15:0]}} : req_wdata_q;
  wire [31:0]      req_write_mask =
    {{8{req_wstrb[3]}}, {8{req_wstrb[2]}}, {8{req_wstrb[1]}}, {8{req_wstrb[0]}}};
  wire [31:0]      _refill_word_data_T_5 = req_bus_wdata & req_write_mask;
  wire [31:0]      merged_hit_word = hit_word & ~req_write_mask | _refill_word_data_T_5;
  wire [31:0]      refill_word_data =
    req_write_q & refill_beat_q[1:0] == req_addr_q[3:2]
      ? mem_rsp_rdata_i & ~req_write_mask | _refill_word_data_T_5
      : mem_rsp_rdata_i;
  wire             _refill_complete_T_1 = refill_beat_q == 3'h3;
  wire             refill_protocol_error =
    mem_rsp_last_i & refill_beat_q != 3'h3 | ~mem_rsp_last_i & _refill_complete_T_1;
  wire             _refill_complete_T = mem_rsp_valid_i & _mem_rsp_ready_o_output;
  wire             refill_complete =
    _refill_complete_T & (mem_rsp_last_i | _refill_complete_T_1);
  wire             _refill_error_q_T = refill_error_q | mem_rsp_error_i;
  wire             _held_resp_error_q_T = mem_rsp_owner_i != req_owner_q;
  wire             refill_failed_now =
    _refill_error_q_T | _held_resp_error_q_T | refill_protocol_error;
  wire             fence_line_dirty =
    (fence_way_q ? metadata_q[2] : metadata_q[0])
    & (fence_way_q ? metadata_q[3] : metadata_q[1]);
  wire [20:0]      fence_line_tag =
    fence_way_q ? _way1_tag_ext_R0_data : _way0_tag_ext_R0_data;
  wire             _store_read_collision_T = state_q == 4'h2;
  wire             lookup_can_pipeline =
    _store_read_collision_T & req_cacheable_q & cache_hit;
  wire             _fence_req_ready_o_T = state_q == 4'h1;
  wire             _response_holding_o_T = state_q == 4'h7;
  assign _cpu_req_ready_o_output =
    (_fence_req_ready_o_T | lookup_can_pipeline | _response_holding_o_T) & ~rst
    & ~fence_req_i;
  assign _fence_req_ready_o_output = _fence_req_ready_o_T & ~rst;
  wire             _busy_o_T = state_q != 4'h1;
  reg  [6:0]       array_read_index_q;
  wire [6:0]       _array_read_index_T = fence_req_accept ? 7'h0 : cpu_req_vindex_i;
  wire             _GEN_4 = state_q == 4'h8;
  wire             _GEN_5 = _GEN_4 & ~fence_line_dirty & fence_way_q & ~(&fence_index_q);
  wire [6:0]       _array_read_index_T_1 = fence_index_q + 7'h1;
  wire             _GEN_6 = state_q == 4'h9;
  wire             _GEN_7 =
    _GEN_6 & mem_rsp_valid_i & _mem_rsp_ready_o_output & ~mem_rsp_error_i
    & (&mem_rsp_owner_i) & mem_rsp_last_i;
  wire             _GEN_8 = _GEN_7 & fence_way_q & ~(&fence_index_q);
  wire             array_read_launch =
    _fence_req_ready_o_T | lookup_can_pipeline | _response_holding_o_T | _GEN_5 | _GEN_8;
  wire [6:0]       _array_read_index_T_3 = fence_index_q + 7'h1;
  wire             _GEN_9 = lookup_can_pipeline | _response_holding_o_T;
  wire [6:0]       physical_array_read_index =
    array_read_launch
      ? (_fence_req_ready_o_T
           ? _array_read_index_T
           : _GEN_9
               ? cpu_req_vindex_i
               : _GEN_5
                   ? _array_read_index_T_1
                   : _GEN_8 ? _array_read_index_T_3 : array_read_index_q)
      : array_read_index_q;
  reg              metadata_read_bypass_q;
  reg  [4:0]       metadata_read_bypass_data_q;
  assign metadata_q =
    metadata_read_bypass_q ? metadata_read_bypass_data_q : _metadata_ext_R0_data;
  reg              store_read_bypass_q;
  reg              store_read_bypass_way_q;
  reg  [1:0]       store_read_bypass_word_q;
  reg  [31:0]      store_read_bypass_data_q;
  wire             _lookup_way1_data0_q_T_1 = store_read_bypass_word_q == 2'h0;
  assign lookup_way0_data0_q =
    store_read_bypass_q & ~store_read_bypass_way_q & _lookup_way1_data0_q_T_1
      ? store_read_bypass_data_q
      : _way0_data0_ext_R0_data;
  wire             _lookup_way1_data1_q_T_1 = store_read_bypass_word_q == 2'h1;
  assign lookup_way0_data1_q =
    store_read_bypass_q & ~store_read_bypass_way_q & _lookup_way1_data1_q_T_1
      ? store_read_bypass_data_q
      : _way0_data1_ext_R0_data;
  wire             _lookup_way1_data2_q_T_1 = store_read_bypass_word_q == 2'h2;
  assign lookup_way0_data2_q =
    store_read_bypass_q & ~store_read_bypass_way_q & _lookup_way1_data2_q_T_1
      ? store_read_bypass_data_q
      : _way0_data2_ext_R0_data;
  assign lookup_way0_data3_q =
    store_read_bypass_q & ~store_read_bypass_way_q & (&store_read_bypass_word_q)
      ? store_read_bypass_data_q
      : _way0_data3_ext_R0_data;
  wire             _lookup_way1_data3_q_T = store_read_bypass_q & store_read_bypass_way_q;
  assign lookup_way1_data0_q =
    _lookup_way1_data3_q_T & _lookup_way1_data0_q_T_1
      ? store_read_bypass_data_q
      : _way1_data0_ext_R0_data;
  assign lookup_way1_data1_q =
    _lookup_way1_data3_q_T & _lookup_way1_data1_q_T_1
      ? store_read_bypass_data_q
      : _way1_data1_ext_R0_data;
  assign lookup_way1_data2_q =
    _lookup_way1_data3_q_T & _lookup_way1_data2_q_T_1
      ? store_read_bypass_data_q
      : _way1_data2_ext_R0_data;
  assign lookup_way1_data3_q =
    _lookup_way1_data3_q_T & (&store_read_bypass_word_q)
      ? store_read_bypass_data_q
      : _way1_data3_ext_R0_data;
  wire             _GEN_10 = req_cacheable_q & cache_hit;
  wire             _GEN_11 = state_q == 4'h3;
  wire             _GEN_12 = state_q == 4'h4;
  wire             _GEN_13 = state_q == 4'h5;
  wire             _GEN_14 = state_q == 4'h6;
  wire             _GEN_15 = _GEN_11 | _GEN_12;
  wire             _GEN_16 = _GEN_15 | _GEN_13 | _GEN_14;
  wire             _GEN_17 = _GEN_13 | _GEN_14;
  wire             _GEN_18 = _GEN_11 | _GEN_12 | _GEN_17;
  wire             _GEN_19 = _GEN_4 & fence_line_dirty;
  wire             _mem_cmd_valid_o_output =
    _store_read_collision_T
      ? ~_GEN_10
      : ~_GEN_11 & (_GEN_12 | ~(_GEN_17 | _response_holding_o_T) & _GEN_19);
  wire             _GEN_20 = _GEN_4 & fence_line_dirty;
  wire             _GEN_21 = _GEN_13 | _GEN_14 | _response_holding_o_T;
  wire             _GEN_22 = _GEN_11 | _GEN_12 | _GEN_21;
  wire             _GEN_23 = _store_read_collision_T | _GEN_22;
  wire [1:0]       _mem_cmd_owner_o_output = _GEN_23 | ~_GEN_20 ? req_owner_q : 2'h3;
  wire             _mem_cmd_write_o_output =
    _store_read_collision_T
      ? ~_GEN_10 & (req_cacheable_q ? victim_dirty : req_write_q)
      : ~(_GEN_16 | _response_holding_o_T) & _GEN_19;
  wire             _GEN_24 = _GEN_21 | ~_GEN_20;
  wire [31:0]      _mem_cmd_addr_o_output =
    _store_read_collision_T
      ? (_GEN_10
           ? 32'h0
           : req_cacheable_q
               ? {victim_dirty
                    ? {selected_victim_way
                         ? _way1_tag_ext_R0_data
                         : _way0_tag_ext_R0_data,
                       req_addr_q[10:4]}
                    : req_addr_q[31:4],
                  4'h0}
               : req_addr_q)
      : _GEN_11
          ? 32'h0
          : _GEN_12
              ? {req_addr_q[31:4], 4'h0}
              : _GEN_24 ? 32'h0 : {fence_line_tag, fence_index_q, 4'h0};
  wire [1:0]       _mem_cmd_size_o_output =
    ~_store_read_collision_T | _GEN_10 | req_cacheable_q ? 2'h2 : req_size_q;
  wire [2:0]       _mem_cmd_len_o_output =
    (_store_read_collision_T
       ? _GEN_10 | ~req_cacheable_q
       : _GEN_11 | ~(_GEN_12 | ~_GEN_24))
      ? 3'h0
      : 3'h3;
  wire [127:0]     _mem_cmd_wdata_o_output =
    _store_read_collision_T
      ? (_GEN_10
           ? 128'h0
           : req_cacheable_q
               ? (victim_dirty
                    ? (selected_victim_way
                         ? {lookup_way1_data3_q,
                            lookup_way1_data2_q,
                            lookup_way1_data1_q,
                            lookup_way1_data0_q}
                         : {lookup_way0_data3_q,
                            lookup_way0_data2_q,
                            lookup_way0_data1_q,
                            lookup_way0_data0_q})
                    : 128'h0)
               : {96'h0, req_bus_wdata})
      : _GEN_22 | ~_GEN_20
          ? 128'h0
          : fence_way_q
              ? {_way1_data3_ext_R0_data,
                 _way1_data2_ext_R0_data,
                 _way1_data1_ext_R0_data,
                 _way1_data0_ext_R0_data}
              : {_way0_data3_ext_R0_data,
                 _way0_data2_ext_R0_data,
                 _way0_data1_ext_R0_data,
                 _way0_data0_ext_R0_data};
  wire [15:0]      _mem_cmd_wstrb_o_output =
    _store_read_collision_T
      ? (_GEN_10 ? 16'h0 : req_cacheable_q ? {16{victim_dirty}} : {12'h0, req_wstrb})
      : _GEN_22 ? 16'h0 : {16{_GEN_20}};
  wire             _GEN_25 = _response_holding_o_T | _GEN_4;
  assign _mem_rsp_ready_o_output =
    ~_store_read_collision_T & (_GEN_11 | ~_GEN_12 & (_GEN_17 | ~_GEN_25 & _GEN_6));
  wire             _GEN_26 = state_q == 4'h0;
  wire             _GEN_27 = _store_read_collision_T & req_cacheable_q;
  wire             _GEN_28 = _GEN_27 & cache_hit;
  wire [4:0]       _metadata_write_data_T_1 =
    {~hit_way,
     req_write_q & hit_way | metadata_q[3],
     metadata_q[2],
     req_write_q & ~hit_way | metadata_q[1],
     metadata_q[0]};
  wire             _GEN_29 =
    _GEN_27 & ~cache_hit & _mem_cmd_valid_o_output & mem_cmd_ready_i & ~victim_dirty;
  wire [4:0]       _metadata_write_data_T_2 = {metadata_q[4], 2'h0, metadata_q[1:0]};
  wire [4:0]       _metadata_write_data_T_3 = {metadata_q[4:2], 2'h0};
  wire             _GEN_30 = _GEN_12 & _mem_cmd_valid_o_output & mem_cmd_ready_i;
  wire [4:0]       _metadata_write_data_T_5 = {metadata_q[4], 2'h0, metadata_q[1:0]};
  wire [4:0]       _metadata_write_data_T_6 = {metadata_q[4:2], 2'h0};
  wire             _GEN_31 = _GEN_13 & mem_rsp_valid_i & _mem_rsp_ready_o_output;
  wire             _GEN_32 = _GEN_31 & refill_complete & ~refill_failed_now;
  wire [4:0]       _metadata_write_data_T_10 = {1'h0, req_write_q, 1'h1, metadata_q[1:0]};
  wire [4:0]       _metadata_write_data_T_13 = {1'h1, metadata_q[3:2], req_write_q, 1'h1};
  wire             metadata_write_enable =
    _GEN_26 | _GEN_28 | _GEN_29 | _GEN_30 | _GEN_32 | _GEN_7;
  wire [6:0]       metadata_write_index =
    _GEN_26
      ? scrub_index_q
      : _GEN_28 | _GEN_29 | _GEN_30 | _GEN_32
          ? req_addr_q[10:4]
          : _GEN_7 ? fence_index_q : 7'h0;
  wire [4:0]       _metadata_write_data_T_15 = {metadata_q[4], 1'h0, metadata_q[2:0]};
  wire [4:0]       _metadata_write_data_T_16 = {metadata_q[4:2], 1'h0, metadata_q[0]};
  wire             _GEN_33 = _GEN_28 & req_write_q;
  wire             data_write_enable = _GEN_33 | _GEN_31;
  wire             data_write_way = _GEN_33 ? hit_way : _GEN_31 & victim_way_q;
  wire [6:0]       data_write_index = _GEN_33 | _GEN_31 ? req_addr_q[10:4] : 7'h0;
  wire [1:0]       data_write_word =
    _GEN_33 ? req_addr_q[3:2] : _GEN_31 ? refill_beat_q[1:0] : 2'h0;
  wire [31:0]      data_write_value =
    _GEN_33 ? merged_hit_word : _GEN_31 ? refill_word_data : 32'h0;
  wire             _GEN_34 = data_write_word == 2'h0;
  wire             _GEN_35 = data_write_enable & ~data_write_way;
  wire             _GEN_36 = data_write_word == 2'h1;
  wire             _GEN_37 = data_write_word == 2'h2;
  wire             _GEN_38 = _GEN_34 | _GEN_36;
  wire             _GEN_39 = ~data_write_way | _GEN_38;
  wire             _GEN_40 =
    _GEN_13 & _refill_complete_T & refill_complete & ~refill_failed_now;
  wire             _GEN_41 =
    rst | _GEN_26 | _fence_req_ready_o_T | _store_read_collision_T | _GEN_15;
  reg              held_cpu_req_q;
  reg  [1:0]       held_cpu_owner_q;
  reg  [31:0]      held_cpu_addr_q;
  reg  [6:0]       held_cpu_vindex_q;
  reg              held_cpu_write_q;
  reg  [1:0]       held_cpu_size_q;
  reg  [31:0]      held_cpu_wdata_q;
  reg              held_cpu_cacheable_q;
  reg              held_mem_cmd_q;
  reg  [1:0]       held_mem_owner_q;
  reg              held_mem_write_q;
  reg  [31:0]      held_mem_addr_q;
  reg  [1:0]       held_mem_size_q;
  reg  [2:0]       held_mem_len_q;
  reg  [127:0]     held_mem_wdata_q;
  reg  [15:0]      held_mem_wstrb_q;
  wire             _GEN_43 = ~fence_way_q | (&fence_index_q);
  wire             _GEN_44 = _GEN_13 & _refill_complete_T;
  wire             _GEN_45 = _GEN_14 & _refill_complete_T;
  wire [3:0][7:0]  _GEN_46 =
    {{refill_word_data[31:24]},
     {refill_word_data[23:16]},
     {refill_word_data[15:8]},
     {refill_word_data[7:0]}};
  wire [31:0]      refill_load_data =
    _GEN_1
      ? {24'h0, _GEN_46[req_addr_q[1:0]]}
      : _GEN_3
          ? {16'h0, req_addr_q[1] ? refill_word_data[31:16] : refill_word_data[15:0]}
          : refill_word_data;
  wire [3:0]       _GEN_47 = cpu_req_accept ? 4'h2 : 4'h1;
  wire             _GEN_48 = _mem_cmd_valid_o_output & mem_cmd_ready_i;
  wire             _GEN_49 = _GEN_48 & req_cacheable_q;
  wire             _GEN_50 = _GEN_26 | _fence_req_ready_o_T;
  wire             _GEN_51 = mem_rsp_error_i | _held_resp_error_q_T | ~mem_rsp_last_i;
  wire             _GEN_52 = _refill_complete_T & refill_complete;
  wire             _GEN_53 = _GEN_10 | ~_GEN_49;
  wire             _GEN_54 = _refill_complete_T & _GEN_51;
  wire             _metadata_read_bypass_q_T =
    metadata_write_index == physical_array_read_index;
  wire             store_read_collision =
    _store_read_collision_T & req_cacheable_q & cache_hit & req_write_q & cpu_req_accept
    & cpu_req_vindex_i == req_addr_q[10:4];
  wire             _GEN_55 = fence_way_q & (&fence_index_q);
  wire             _GEN_56 = mem_rsp_error_i | ~(&mem_rsp_owner_i) | ~mem_rsp_last_i;
  wire             _GEN_57 = _GEN_56 | _GEN_55;
  wire             _GEN_58 = _GEN_6 & _refill_complete_T;
  wire             _GEN_59 =
    rst | _GEN_26 | _fence_req_ready_o_T | _store_read_collision_T | _GEN_11 | _GEN_12
    | _GEN_13 | _GEN_14 | _response_holding_o_T;
  wire [15:0][3:0] _GEN_60 =
    {{4'h0},
     {4'h0},
     {4'h0},
     {4'h0},
     {4'h0},
     {4'h0},
     {_refill_complete_T ? (_GEN_57 ? 4'h1 : 4'h8) : state_q},
     {fence_line_dirty ? (_GEN_48 ? 4'h9 : state_q) : _GEN_55 ? 4'h1 : state_q},
     {_GEN_47},
     {_refill_complete_T ? 4'h7 : state_q},
     {_GEN_52 ? 4'h7 : state_q},
     {_GEN_48 ? 4'h5 : state_q},
     {_refill_complete_T ? (_GEN_51 ? 4'h7 : 4'h4) : state_q},
     {_GEN_10
        ? _GEN_47
        : _GEN_48 ? (req_cacheable_q ? (victim_dirty ? 4'h3 : 4'h5) : 4'h6) : state_q},
     {fence_req_accept ? 4'h8 : cpu_req_accept ? 4'h2 : state_q},
     {(&scrub_index_q) ? 4'h1 : state_q}};
  always @(posedge clk) begin
    fence_done_o_out_reg <=
      ~_GEN_59 & (_GEN_4 ? ~fence_line_dirty & _GEN_55 : _GEN_58 & _GEN_57);
    fence_error_o_out_reg <= ~(_GEN_59 | _GEN_4) & _GEN_58 & _GEN_56;
    if (rst | ~(metadata_write_enable & _metadata_read_bypass_q_T)) begin
    end
    else if (_GEN_26)
      metadata_read_bypass_data_q <= 5'h0;
    else if (_GEN_28)
      metadata_read_bypass_data_q <= _metadata_write_data_T_1;
    else if (_GEN_29) begin
      if (selected_victim_way)
        metadata_read_bypass_data_q <= _metadata_write_data_T_2;
      else
        metadata_read_bypass_data_q <= _metadata_write_data_T_3;
    end
    else if (_GEN_30) begin
      if (victim_way_q)
        metadata_read_bypass_data_q <= _metadata_write_data_T_5;
      else
        metadata_read_bypass_data_q <= _metadata_write_data_T_6;
    end
    else if (_GEN_32) begin
      if (victim_way_q)
        metadata_read_bypass_data_q <= _metadata_write_data_T_10;
      else
        metadata_read_bypass_data_q <= _metadata_write_data_T_13;
    end
    else if (_GEN_7) begin
      if (fence_way_q)
        metadata_read_bypass_data_q <= _metadata_write_data_T_15;
      else
        metadata_read_bypass_data_q <= _metadata_write_data_T_16;
    end
    else
      metadata_read_bypass_data_q <= 5'h0;
    if (rst | ~store_read_collision) begin
    end
    else begin
      store_read_bypass_way_q <= hit_way;
      store_read_bypass_word_q <= req_addr_q[3:2];
      store_read_bypass_data_q <= merged_hit_word;
    end
    if (rst) begin
      fence_error_addr_o_out_reg <= 32'h0;
      state_q <= 4'h0;
      scrub_index_q <= 7'h0;
      req_owner_q <= 2'h0;
      req_addr_q <= 32'h0;
      req_write_q <= 1'h0;
      req_size_q <= 2'h0;
      req_wdata_q <= 32'h0;
      req_cacheable_q <= 1'h0;
      victim_way_q <= 1'h0;
      refill_beat_q <= 3'h0;
      refill_error_q <= 1'h0;
      critical_word_q <= 32'h0;
      fence_index_q <= 7'h0;
      fence_way_q <= 1'h0;
      held_resp_owner_q <= 2'h0;
      held_resp_data_q <= 32'h0;
      held_resp_error_q <= 1'h0;
      array_read_index_q <= 7'h0;
      metadata_read_bypass_q <= 1'h0;
      store_read_bypass_q <= 1'h0;
      held_cpu_req_q <= 1'h0;
      held_mem_cmd_q <= 1'h0;
    end
    else begin
      held_cpu_owner_q <= cpu_req_owner_i;
      held_cpu_addr_q <= cpu_req_addr_i;
      held_cpu_vindex_q <= cpu_req_vindex_i;
      held_cpu_write_q <= cpu_req_write_i;
      held_cpu_size_q <= cpu_req_size_i;
      held_cpu_wdata_q <= cpu_req_wdata_i;
      held_cpu_cacheable_q <= cpu_req_cacheable_i;
      held_mem_owner_q <= _mem_cmd_owner_o_output;
      held_mem_write_q <= _mem_cmd_write_o_output;
      held_mem_addr_q <= _mem_cmd_addr_o_output;
      held_mem_size_q <= _mem_cmd_size_o_output;
      held_mem_len_q <= _mem_cmd_len_o_output;
      held_mem_wdata_q <= _mem_cmd_wdata_o_output;
      held_mem_wstrb_q <= _mem_cmd_wstrb_o_output;
      if (_GEN_26 | _fence_req_ready_o_T | _store_read_collision_T | _GEN_11 | _GEN_12
          | _GEN_13 | _GEN_14 | _GEN_25 | ~(_GEN_6 & _refill_complete_T & _GEN_56)) begin
      end
      else
        fence_error_addr_o_out_reg <= {fence_line_tag, fence_index_q, 4'h0};
      state_q <= _GEN_60[state_q];
      if (_GEN_26) begin
        if (&scrub_index_q)
          scrub_index_q <= 7'h0;
        else
          scrub_index_q <= scrub_index_q + 7'h1;
      end
      else if (_fence_req_ready_o_T) begin
        if (fence_req_accept | ~cpu_req_accept) begin
        end
        else begin
          req_owner_q <= cpu_req_owner_i;
          req_addr_q <= cpu_req_addr_i;
          req_write_q <= cpu_req_write_i;
          req_size_q <= cpu_req_size_i;
          req_wdata_q <= cpu_req_wdata_i;
          req_cacheable_q <= cpu_req_cacheable_i;
        end
        if (fence_req_accept)
          fence_index_q <= 7'h0;
        fence_way_q <= ~fence_req_accept & fence_way_q;
      end
      else begin
        if (_store_read_collision_T) begin
          if (_GEN_10 & cpu_req_accept) begin
            req_owner_q <= cpu_req_owner_i;
            req_addr_q <= cpu_req_addr_i;
            req_write_q <= cpu_req_write_i;
            req_size_q <= cpu_req_size_i;
            req_wdata_q <= cpu_req_wdata_i;
            req_cacheable_q <= cpu_req_cacheable_i;
          end
        end
        else if (_GEN_18 | ~(_response_holding_o_T & cpu_req_accept)) begin
        end
        else begin
          req_owner_q <= cpu_req_owner_i;
          req_addr_q <= cpu_req_addr_i;
          req_write_q <= cpu_req_write_i;
          req_size_q <= cpu_req_size_i;
          req_wdata_q <= cpu_req_wdata_i;
          req_cacheable_q <= cpu_req_cacheable_i;
        end
        if (~_GEN_23) begin
          if (_GEN_4) begin
            if (fence_line_dirty | _GEN_43) begin
            end
            else
              fence_index_q <= fence_index_q + 7'h1;
          end
          else if (~_GEN_58 | _GEN_56 | _GEN_43) begin
          end
          else
            fence_index_q <= fence_index_q + 7'h1;
        end
        if (_GEN_23 | (_GEN_4 ? fence_line_dirty : ~_GEN_58 | _GEN_56)) begin
        end
        else
          fence_way_q <= ~fence_way_q | (&fence_index_q) & fence_way_q;
      end
      if (_GEN_50 | ~_store_read_collision_T | _GEN_10 | ~_GEN_49) begin
      end
      else
        victim_way_q <= selected_victim_way;
      if (~_GEN_50) begin
        if (_store_read_collision_T) begin
          if (_GEN_53) begin
          end
          else
            refill_beat_q <= 3'h0;
          refill_error_q <= (_GEN_10 | ~_GEN_48 | ~req_cacheable_q) & refill_error_q;
          if (_GEN_53) begin
          end
          else
            critical_word_q <= 32'h0;
        end
        else if (~_GEN_11) begin
          if (_GEN_12) begin
            if (_GEN_48) begin
              refill_beat_q <= 3'h0;
              critical_word_q <= 32'h0;
            end
            refill_error_q <= ~_GEN_48 & refill_error_q;
          end
          else begin
            if (~_GEN_44 | refill_complete) begin
            end
            else
              refill_beat_q <= refill_beat_q + 3'h1;
            if (_GEN_44)
              refill_error_q <=
                _refill_error_q_T | _held_resp_error_q_T | refill_protocol_error;
            if (_GEN_13 & _refill_complete_T & refill_beat_q[1:0] == req_addr_q[3:2])
              critical_word_q <= refill_load_data;
          end
        end
      end
      if (~(_GEN_50 | _store_read_collision_T)) begin
        if (_GEN_11) begin
          if (_GEN_54) begin
            held_resp_owner_q <= req_owner_q;
            held_resp_data_q <= 32'h0;
          end
          held_resp_error_q <= _GEN_54 | held_resp_error_q;
        end
        else begin
          if (_GEN_12 | ~(_GEN_13 ? _GEN_52 : _GEN_45)) begin
          end
          else
            held_resp_owner_q <= req_owner_q;
          if (~_GEN_12) begin
            if (_GEN_13) begin
              if (_GEN_52) begin
                held_resp_data_q <=
                  req_write_q
                    ? 32'h0
                    : refill_beat_q[1:0] == req_addr_q[3:2]
                        ? refill_load_data
                        : critical_word_q;
                held_resp_error_q <= refill_failed_now;
              end
            end
            else if (_GEN_45) begin
              held_resp_data_q <= mem_rsp_rdata_i;
              held_resp_error_q <= mem_rsp_error_i | _held_resp_error_q_T;
            end
          end
        end
      end
      if (array_read_launch) begin
        if (_fence_req_ready_o_T)
          array_read_index_q <= _array_read_index_T;
        else if (_GEN_9)
          array_read_index_q <= cpu_req_vindex_i;
        else if (_GEN_5)
          array_read_index_q <= _array_read_index_T_1;
        else if (_GEN_8)
          array_read_index_q <= _array_read_index_T_3;
      end
      metadata_read_bypass_q <= ~rst & metadata_write_enable & _metadata_read_bypass_q_T;
      store_read_bypass_q <= ~rst & store_read_collision;
      held_cpu_req_q <= cpu_req_valid_i & ~_cpu_req_ready_o_output;
      held_mem_cmd_q <= _mem_cmd_valid_o_output & ~mem_cmd_ready_i;
    end
  end
  way_128x32 way0_data0_ext (
    .R0_addr (physical_array_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way0_data0_ext_R0_data),
    .W0_addr (data_write_index),
    .W0_en   (_GEN_35 & _GEN_34),
    .W0_clk  (clk),
    .W0_data (data_write_value)
  );
  way_128x32 way0_data1_ext (
    .R0_addr (physical_array_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way0_data1_ext_R0_data),
    .W0_addr (data_write_index),
    .W0_en   (_GEN_35 & ~_GEN_34 & _GEN_36),
    .W0_clk  (clk),
    .W0_data (data_write_value)
  );
  way_128x32 way0_data2_ext (
    .R0_addr (physical_array_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way0_data2_ext_R0_data),
    .W0_addr (data_write_index),
    .W0_en   (_GEN_35 & ~_GEN_38 & _GEN_37),
    .W0_clk  (clk),
    .W0_data (data_write_value)
  );
  way_128x32 way0_data3_ext (
    .R0_addr (physical_array_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way0_data3_ext_R0_data),
    .W0_addr (data_write_index),
    .W0_en   (_GEN_35 & ~_GEN_38 & ~_GEN_37),
    .W0_clk  (clk),
    .W0_data (data_write_value)
  );
  way_128x32 way1_data0_ext (
    .R0_addr (physical_array_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way1_data0_ext_R0_data),
    .W0_addr (data_write_index),
    .W0_en   (data_write_enable & data_write_way & _GEN_34),
    .W0_clk  (clk),
    .W0_data (data_write_value)
  );
  way_128x32 way1_data1_ext (
    .R0_addr (physical_array_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way1_data1_ext_R0_data),
    .W0_addr (data_write_index),
    .W0_en   (data_write_enable & ~(~data_write_way | _GEN_34) & _GEN_36),
    .W0_clk  (clk),
    .W0_data (data_write_value)
  );
  way_128x32 way1_data2_ext (
    .R0_addr (physical_array_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way1_data2_ext_R0_data),
    .W0_addr (data_write_index),
    .W0_en   (data_write_enable & ~_GEN_39 & _GEN_37),
    .W0_clk  (clk),
    .W0_data (data_write_value)
  );
  way_128x32 way1_data3_ext (
    .R0_addr (physical_array_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way1_data3_ext_R0_data),
    .W0_addr (data_write_index),
    .W0_en   (data_write_enable & ~_GEN_39 & ~_GEN_37),
    .W0_clk  (clk),
    .W0_data (data_write_value)
  );
  way_128x21 way0_tag_ext (
    .R0_addr (physical_array_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way0_tag_ext_R0_data),
    .W0_addr (req_addr_q[10:4]),
    .W0_en   (~_GEN_41 & _GEN_40 & ~victim_way_q),
    .W0_clk  (clk),
    .W0_data (req_addr_q[31:11])
  );
  way_128x21 way1_tag_ext (
    .R0_addr (physical_array_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_way1_tag_ext_R0_data),
    .W0_addr (req_addr_q[10:4]),
    .W0_en   (~_GEN_41 & _GEN_40 & victim_way_q),
    .W0_clk  (clk),
    .W0_data (req_addr_q[31:11])
  );
  metadata_128x5 metadata_ext (
    .R0_addr (physical_array_read_index),
    .R0_en   (1'h1),
    .R0_clk  (clk),
    .R0_data (_metadata_ext_R0_data),
    .W0_addr (metadata_write_index),
    .W0_en   (metadata_write_enable),
    .W0_clk  (clk),
    .W0_data
      (_GEN_26
         ? 5'h0
         : _GEN_28
             ? _metadata_write_data_T_1
             : _GEN_29
                 ? (selected_victim_way
                      ? _metadata_write_data_T_2
                      : _metadata_write_data_T_3)
                 : _GEN_30
                     ? (victim_way_q
                          ? _metadata_write_data_T_5
                          : _metadata_write_data_T_6)
                     : _GEN_32
                         ? (victim_way_q
                              ? _metadata_write_data_T_10
                              : _metadata_write_data_T_13)
                         : _GEN_7
                             ? (fence_way_q
                                  ? _metadata_write_data_T_15
                                  : _metadata_write_data_T_16)
                             : 5'h0)
  );
  assign cpu_req_ready_o = _cpu_req_ready_o_output;
  assign cpu_resp_valid_o =
    _store_read_collision_T ? _GEN_10 : ~_GEN_16 & _response_holding_o_T;
  assign cpu_resp_owner_o =
    _store_read_collision_T | _GEN_18 | ~_response_holding_o_T
      ? req_owner_q
      : held_resp_owner_q;
  assign cpu_resp_rdata_o =
    _store_read_collision_T
      ? (~_GEN_10 | req_write_q
           ? 32'h0
           : _GEN_1
               ? {24'h0, _GEN_2[req_addr_q[1:0]]}
               : _GEN_3
                   ? {16'h0, req_addr_q[1] ? hit_word[31:16] : hit_word[15:0]}
                   : hit_word)
      : _GEN_18 | ~_response_holding_o_T ? 32'h0 : held_resp_data_q;
  assign cpu_resp_error_o =
    ~(_store_read_collision_T | _GEN_11 | _GEN_12 | _GEN_13 | _GEN_14)
    & _response_holding_o_T & held_resp_error_q;
  assign busy_o = _busy_o_T;
  assign fence_req_ready_o = _fence_req_ready_o_output;
  assign fence_done_o = fence_done_o_out_reg;
  assign fence_error_o = fence_error_o_out_reg;
  assign fence_error_addr_o = fence_error_addr_o_out_reg;
  assign mem_cmd_valid_o = _mem_cmd_valid_o_output;
  assign mem_cmd_owner_o = _mem_cmd_owner_o_output;
  assign mem_cmd_write_o = _mem_cmd_write_o_output;
  assign mem_cmd_addr_o = _mem_cmd_addr_o_output;
  assign mem_cmd_size_o = _mem_cmd_size_o_output;
  assign mem_cmd_len_o = _mem_cmd_len_o_output;
  assign mem_cmd_wdata_o = _mem_cmd_wdata_o_output;
  assign mem_cmd_wstrb_o = _mem_cmd_wstrb_o_output;
  assign mem_rsp_ready_o = _mem_rsp_ready_o_output;
endmodule

module ex_mem1(
  input         clk,
                rst,
                stall_i,
                mem_rd_req_i,
  input  [31:0] mem_rd_addr_i,
  input         reg_wen_i,
  input  [4:0]  rd_addr_i,
  input  [31:0] rd_data_i,
  input  [2:0]  reg_wr_sel_i,
  output        mem_rd_req_o,
  output [31:0] mem_rd_addr_o,
  output        reg_wen_o,
  output [4:0]  rd_addr_o,
  output [31:0] rd_data_o,
  output [2:0]  reg_wr_sel_o
);

  reg        reqQ;
  reg [31:0] addrQ;
  reg        wenQ;
  reg [4:0]  rdQ;
  reg [31:0] dataQ;
  reg [2:0]  selQ;
  always @(posedge clk) begin
    if (rst) begin
      reqQ <= 1'h0;
      addrQ <= 32'h0;
      wenQ <= 1'h0;
      rdQ <= 5'h0;
      dataQ <= 32'h0;
      selQ <= 3'h0;
    end
    else if (stall_i) begin
    end
    else begin
      reqQ <= mem_rd_req_i;
      addrQ <= mem_rd_addr_i;
      wenQ <= reg_wen_i;
      rdQ <= rd_addr_i;
      dataQ <= rd_data_i;
      selQ <= reg_wr_sel_i;
    end
  end
  assign mem_rd_req_o = reqQ;
  assign mem_rd_addr_o = addrQ;
  assign reg_wen_o = wenQ;
  assign rd_addr_o = rdQ;
  assign rd_data_o = dataQ;
  assign reg_wr_sel_o = selQ;
endmodule

module mem1(
  input         clk,
                rst,
                stall_i,
  input  [2:0]  sel,
  input         mem_rd_req_i,
  input  [31:0] mem_rd_addr_i,
  input         reg_wen_i,
  input  [4:0]  rd_addr_i,
  input  [31:0] rd_data_i,
                mem_rd_data_i,
  output        reg_wen_o,
  output [4:0]  rd_addr_o,
  output [31:0] rd_data_o
);

  reg [2:0]  selQ;
  reg [31:0] rdDataQ;
  reg [31:0] memDataQ;
  reg        regWenQ;
  reg [4:0]  rdAddrQ;
  reg        isLoadQ;
  always @(posedge clk) begin
    if (rst) begin
      selQ <= 3'h0;
      rdDataQ <= 32'h0;
      memDataQ <= 32'h0;
      rdAddrQ <= 5'h0;
      isLoadQ <= 1'h0;
    end
    else if (stall_i) begin
    end
    else begin
      selQ <= sel;
      rdDataQ <= rd_data_i;
      memDataQ <= mem_rd_data_i;
      rdAddrQ <= rd_addr_i;
      isLoadQ <= ~mem_rd_req_i & (|mem_rd_addr_i);
    end
    regWenQ <= ~(rst | stall_i) & reg_wen_i;
  end
  assign reg_wen_o = regWenQ;
  assign rd_addr_o = rdAddrQ;
  assign rd_data_o =
    isLoadQ
      ? {32{selQ == 3'h2}} & memDataQ | {32{selQ == 3'h1}}
        & {{16{memDataQ[15]}}, memDataQ[15:0]} | {32{selQ == 3'h0}}
        & {{24{memDataQ[7]}}, memDataQ[7:0]} | {32{selQ == 3'h5}}
        & {16'h0, memDataQ[15:0]} | {32{selQ == 3'h4}} & {24'h0, memDataQ[7:0]}
      : rdDataQ;
endmodule

module mem1_wb(
  input         clk,
                rst,
                reg_wen_i,
  input  [4:0]  rd_addr_i,
  input  [31:0] rd_data_i,
  output        reg_wen_o,
  output [4:0]  rd_addr_o,
  output [31:0] rd_data_o
);

  reg        wenQ;
  reg [4:0]  addrQ;
  reg [31:0] dataQ;
  always @(posedge clk) begin
    if (rst) begin
      wenQ <= 1'h0;
      addrQ <= 5'h0;
      dataQ <= 32'h0;
    end
    else begin
      wenQ <= reg_wen_i;
      addrQ <= rd_addr_i;
      dataQ <= rd_data_i;
    end
  end
  assign reg_wen_o = wenQ;
  assign rd_addr_o = addrQ;
  assign rd_data_o = dataQ;
endmodule

module wb(
  input         reg_wen_i,
  input  [4:0]  rd_addr_i,
  input  [31:0] rd_data_i,
  output        reg_wen_o,
  output [4:0]  rd_addr_o,
  output [31:0] rd_data_o
);

  assign reg_wen_o = reg_wen_i & (|rd_addr_i);
  assign rd_addr_o = (|rd_addr_i) ? rd_addr_i : 5'h0;
  assign rd_data_o = (|rd_addr_i) ? rd_data_i : 32'h0;
endmodule

module store_buffer_3x32(
  input  [1:0]  R0_addr,
  input         R0_en,
                R0_clk,
  output [31:0] R0_data,
  input  [1:0]  W0_addr,
  input         W0_en,
                W0_clk,
  input  [31:0] W0_data,
  input  [1:0]  W1_addr,
  input         W1_en,
                W1_clk,
  input  [31:0] W1_data,
  input  [1:0]  W2_addr,
  input         W2_en,
                W2_clk,
  input  [31:0] W2_data
);

  reg [31:0] Memory[0:2];
  always @(posedge W0_clk) begin
    if (W0_en & 1'h1)
      Memory[W0_addr] <= W0_data;
    if (W1_en & 1'h1)
      Memory[W1_addr] <= W1_data;
    if (W2_en & 1'h1)
      Memory[W2_addr] <= W2_data;
  end
  assign R0_data = R0_en ? Memory[R0_addr] : 32'bx;
endmodule

module store_buffer_size_q_3x2(
  input  [1:0] R0_addr,
  input        R0_en,
               R0_clk,
  output [1:0] R0_data,
  input  [1:0] W0_addr,
  input        W0_en,
               W0_clk,
  input  [1:0] W0_data,
               W1_addr,
  input        W1_en,
               W1_clk,
  input  [1:0] W1_data,
               W2_addr,
  input        W2_en,
               W2_clk,
  input  [1:0] W2_data
);

  reg [1:0] Memory[0:2];
  always @(posedge W0_clk) begin
    if (W0_en & 1'h1)
      Memory[W0_addr] <= W0_data;
    if (W1_en & 1'h1)
      Memory[W1_addr] <= W1_data;
    if (W2_en & 1'h1)
      Memory[W2_addr] <= W2_data;
  end
  assign R0_data = R0_en ? Memory[R0_addr] : 2'bx;
endmodule

module store_buffer_wstrb_q_3x4(
  input  [1:0] R0_addr,
  input        R0_en,
               R0_clk,
  output [3:0] R0_data,
  input  [1:0] W0_addr,
  input        W0_en,
               W0_clk,
  input  [3:0] W0_data,
  input  [1:0] W1_addr,
  input        W1_en,
               W1_clk,
  input  [3:0] W1_data,
  input  [1:0] W2_addr,
  input        W2_en,
               W2_clk,
  input  [3:0] W2_data
);

  reg [3:0] Memory[0:2];
  always @(posedge W0_clk) begin
    if (W0_en & 1'h1)
      Memory[W0_addr] <= W0_data;
    if (W1_en & 1'h1)
      Memory[W1_addr] <= W1_data;
    if (W2_en & 1'h1)
      Memory[W2_addr] <= W2_data;
  end
  assign R0_data = R0_en ? Memory[R0_addr] : 4'bx;
endmodule

module myCPU_soc(
  input          cpu_clk,
                 cpu_rst,
                 software_irq_i,
                 timer_irq_i,
                 external_irq_i,
  output         imem_cmd_valid_o,
  input          imem_cmd_ready_i,
  output [31:0]  imem_cmd_addr_o,
  input          imem_rsp_valid_i,
  output         imem_rsp_ready_o,
  input  [31:0]  imem_rsp_data_i,
  input          imem_rsp_last_i,
                 imem_rsp_error_i,
  output         dmem_cmd_valid_o,
  input          dmem_cmd_ready_i,
  output [1:0]   dmem_cmd_owner_o,
  output         dmem_cmd_write_o,
  output [31:0]  dmem_cmd_addr_o,
  output [1:0]   dmem_cmd_size_o,
  output [2:0]   dmem_cmd_len_o,
  output [127:0] dmem_cmd_wdata_o,
  output [15:0]  dmem_cmd_wstrb_o,
  input          dmem_rsp_valid_i,
  output         dmem_rsp_ready_o,
  input  [1:0]   dmem_rsp_owner_i,
  input  [31:0]  dmem_rsp_data_i,
  input          dmem_rsp_last_i,
                 dmem_rsp_error_i
);

  wire             lane0_commit_live;
  wire             take_interrupt;
  wire             interrupt_commit_block;
  wire             lane1_sync_trap;
  wire             lane1_memory_sync_trap;
  wire             lane0_exception_candidate;
  wire             fence_stall;
  wire             older_data_fault;
  wire             dcache_stall;
  wire             ex1_commit_live;
  wire             resolve1_live;
  wire             resolve0_taken;
  wire             resolve0_control;
  wire             ras1_hint_live;
  wire             ras0_hint_live;
  wire             _accepted_request_pma_readable_o;
  wire             _accepted_request_pma_writable_o;
  wire             _accepted_request_pma_cacheable_o;
  wire             _wb1_inst_reg_wen_o;
  wire [4:0]       _wb1_inst_rd_addr_o;
  wire [31:0]      _wb1_inst_rd_data_o;
  wire             _wb0_inst_reg_wen_o;
  wire [4:0]       _wb0_inst_rd_addr_o;
  wire [31:0]      _wb0_inst_rd_data_o;
  wire             _memwb1_inst_reg_wen_o;
  wire [4:0]       _memwb1_inst_rd_addr_o;
  wire [31:0]      _memwb1_inst_rd_data_o;
  wire             _memwb0_inst_reg_wen_o;
  wire [4:0]       _memwb0_inst_rd_addr_o;
  wire [31:0]      _memwb0_inst_rd_data_o;
  wire             _mem1_inst_reg_wen_o;
  wire [4:0]       _mem1_inst_rd_addr_o;
  wire [31:0]      _mem1_inst_rd_data_o;
  wire             _mem0_inst_reg_wen_o;
  wire [4:0]       _mem0_inst_rd_addr_o;
  wire [31:0]      _mem0_inst_rd_data_o;
  wire             _ex_mem1_inst_mem_rd_req_o;
  wire [31:0]      _ex_mem1_inst_mem_rd_addr_o;
  wire             _ex_mem1_inst_reg_wen_o;
  wire [4:0]       _ex_mem1_inst_rd_addr_o;
  wire [31:0]      _ex_mem1_inst_rd_data_o;
  wire [2:0]       _ex_mem1_inst_reg_wr_sel_o;
  wire             _ex_mem0_inst_mem_rd_req_o;
  wire [31:0]      _ex_mem0_inst_mem_rd_addr_o;
  wire             _ex_mem0_inst_reg_wen_o;
  wire [4:0]       _ex_mem0_inst_rd_addr_o;
  wire [31:0]      _ex_mem0_inst_rd_data_o;
  wire [2:0]       _ex_mem0_inst_reg_wr_sel_o;
  wire             _dcache_inst_cpu_req_ready_o;
  wire             _dcache_inst_cpu_resp_valid_o;
  wire [1:0]       _dcache_inst_cpu_resp_owner_o;
  wire [31:0]      _dcache_inst_cpu_resp_rdata_o;
  wire             _dcache_inst_cpu_resp_error_o;
  wire             _dcache_inst_busy_o;
  wire             _dcache_inst_fence_req_ready_o;
  wire             _dcache_inst_fence_done_o;
  wire             _dcache_inst_fence_error_o;
  wire [31:0]      _dcache_inst_fence_error_addr_o;
  wire             _dcache_inst_mem_cmd_valid_o;
  wire [1:0]       _dcache_inst_mem_cmd_owner_o;
  wire             _dcache_inst_mem_cmd_write_o;
  wire [31:0]      _dcache_inst_mem_cmd_addr_o;
  wire [1:0]       _dcache_inst_mem_cmd_size_o;
  wire [2:0]       _dcache_inst_mem_cmd_len_o;
  wire [127:0]     _dcache_inst_mem_cmd_wdata_o;
  wire [15:0]      _dcache_inst_mem_cmd_wstrb_o;
  wire             _dcache_inst_mem_rsp_ready_o;
  wire [31:0]      _csr_inst_csr_read_value_o;
  wire             _csr_inst_illegal_csr_o;
  wire             _csr_inst_redirect_o;
  wire [31:0]      _csr_inst_redirect_pc_o;
  wire             _csr_inst_interrupt_request_o;
  wire [31:0]      _csr_inst_interrupt_cause_o;
  wire [3:0]       _store_buffer_wstrb_q_ext_R0_data;
  wire [31:0]      _store_buffer_data_q_ext_R0_data;
  wire [1:0]       _store_buffer_size_q_ext_R0_data;
  wire [31:0]      _store_buffer_addr_q_ext_R0_data;
  wire             _data_pma_readable_o;
  wire             _data_pma_writable_o;
  wire             _data_pma_cacheable_o;
  wire [31:0]      _ex1_inst_rd_data_o;
  wire [4:0]       _ex1_inst_rd_addr_o;
  wire             _ex1_inst_rd_wen_o;
  wire             _ex1_inst_redirect_o;
  wire [31:0]      _ex1_inst_redirect_pc_o;
  wire             _ex1_inst_control_valid_o;
  wire             _ex1_inst_branch_valid_o;
  wire             _ex1_inst_actual_taken_o;
  wire [31:0]      _ex1_inst_resolved_target_o;
  wire             _ex1_inst_mem_valid_o;
  wire             _ex1_inst_mem_write_o;
  wire [31:0]      _ex1_inst_mem_addr_o;
  wire [31:0]      _ex1_inst_mem_wdata_o;
  wire [1:0]       _ex1_inst_mem_mask_o;
  wire [2:0]       _ex1_inst_load_sel_o;
  wire [31:0]      _ex0_inst_rd_data_o;
  wire [31:0]      _ex0_inst_non_mdu_rd_data_o;
  wire [4:0]       _ex0_inst_rd_addr_o;
  wire             _ex0_inst_rd_wen_o;
  wire [31:0]      _ex0_inst_real_jump_addr_o;
  wire             _ex0_inst_real_jump_en_o;
  wire             _ex0_inst_mdu_stall_o;
  wire             _ex0_inst_mem_rd_req;
  wire [31:0]      _ex0_inst_mem_rd_addr;
  wire [31:0]      _ex0_inst_mem_wr_data_o;
  wire [1:0]       _ex0_inst_mem_mask;
  wire [2:0]       _ex0_inst_sel;
  wire             _ex0_inst_ex_real_taken_o;
  wire [31:0]      _ex0_inst_resolved_target_o;
  wire [31:0]      _id_ex1_inst_inst_o;
  wire [31:0]      _id_ex1_inst_inst_addr_o;
  wire [4:0]       _id_ex1_inst_rs1_addr_o;
  wire [4:0]       _id_ex1_inst_rs2_addr_o;
  wire [31:0]      _id_ex1_inst_op1_o;
  wire [31:0]      _id_ex1_inst_op2_o;
  wire [4:0]       _id_ex1_inst_rd_addr_o;
  wire             _id_ex1_inst_reg_wen_o;
  wire [31:0]      _id_ex1_inst_base_addr_o;
  wire [31:0]      _id_ex1_inst_addr_offset_o;
  wire [5:0]       _id_ex1_inst_alu_op_o;
  wire             _id_ex1_inst_is_mdu_o;
  wire [2:0]       _id_ex1_inst_mdu_op_o;
  wire             _id_ex1_inst_illegal_o;
  wire             _id_ex1_inst_is_branch_o;
  wire             _id_ex1_inst_is_jump_o;
  wire             _id_ex1_inst_is_load_o;
  wire             _id_ex1_inst_is_store_o;
  wire [2:0]       _id_ex1_inst_mem_width_o;
  wire             _id_ex1_inst_prdt_taken_o;
  wire [31:0]      _id_ex1_inst_prdt_pc_addr_o;
  wire [31:0]      _id_ex0_inst_inst_o;
  wire [31:0]      _id_ex0_inst_inst_addr_o;
  wire [4:0]       _id_ex0_inst_rs1_addr_o;
  wire [4:0]       _id_ex0_inst_rs2_addr_o;
  wire [31:0]      _id_ex0_inst_op1_o;
  wire [31:0]      _id_ex0_inst_op2_o;
  wire [4:0]       _id_ex0_inst_rd_addr_o;
  wire             _id_ex0_inst_reg_wen_o;
  wire [31:0]      _id_ex0_inst_base_addr_o;
  wire [31:0]      _id_ex0_inst_addr_offset_o;
  wire [5:0]       _id_ex0_inst_alu_op_o;
  wire             _id_ex0_inst_is_mdu_o;
  wire [2:0]       _id_ex0_inst_mdu_op_o;
  wire             _id_ex0_inst_is_system_o;
  wire [3:0]       _id_ex0_inst_system_op_o;
  wire [11:0]      _id_ex0_inst_csr_addr_o;
  wire [4:0]       _id_ex0_inst_csr_zimm_o;
  wire             _id_ex0_inst_illegal_o;
  wire             _id_ex0_inst_is_branch_o;
  wire             _id_ex0_inst_is_jump_o;
  wire             _id_ex0_inst_is_load_o;
  wire             _id_ex0_inst_is_store_o;
  wire [2:0]       _id_ex0_inst_mem_width_o;
  wire             _id_ex0_inst_prdt_taken_o;
  wire [31:0]      _id_ex0_inst_prdt_pc_addr_o;
  wire [31:0]      _regs_inst_reg1_rdata_o;
  wire [31:0]      _regs_inst_reg2_rdata_o;
  wire [31:0]      _regs_inst_reg3_rdata_o;
  wire [31:0]      _regs_inst_reg4_rdata_o;
  wire [4:0]       _decode1_inst_rs1_addr_o;
  wire [4:0]       _decode1_inst_rs2_addr_o;
  wire [31:0]      _decode1_inst_inst_o;
  wire [31:0]      _decode1_inst_op1_o;
  wire [31:0]      _decode1_inst_op2_o;
  wire [4:0]       _decode1_inst_rd_addr_o;
  wire             _decode1_inst_reg_wen_o;
  wire [31:0]      _decode1_inst_base_addr_o;
  wire [31:0]      _decode1_inst_addr_offset_o;
  wire [5:0]       _decode1_inst_alu_op_o;
  wire             _decode1_inst_is_mdu_o;
  wire [2:0]       _decode1_inst_mdu_op_o;
  wire [11:0]      _decode1_inst_csr_addr_o;
  wire [4:0]       _decode1_inst_csr_zimm_o;
  wire             _decode1_inst_illegal_o;
  wire             _decode1_inst_is_branch_o;
  wire             _decode1_inst_is_jump_o;
  wire             _decode1_inst_is_load_o;
  wire             _decode1_inst_is_store_o;
  wire [2:0]       _decode1_inst_mem_width_o;
  wire [4:0]       _decode0_inst_rs1_addr_o;
  wire [4:0]       _decode0_inst_rs2_addr_o;
  wire [31:0]      _decode0_inst_inst_o;
  wire [31:0]      _decode0_inst_op1_o;
  wire [31:0]      _decode0_inst_op2_o;
  wire [4:0]       _decode0_inst_rd_addr_o;
  wire             _decode0_inst_reg_wen_o;
  wire [31:0]      _decode0_inst_base_addr_o;
  wire [31:0]      _decode0_inst_addr_offset_o;
  wire [5:0]       _decode0_inst_alu_op_o;
  wire             _decode0_inst_is_mdu_o;
  wire [2:0]       _decode0_inst_mdu_op_o;
  wire             _decode0_inst_is_system_o;
  wire [3:0]       _decode0_inst_system_op_o;
  wire [11:0]      _decode0_inst_csr_addr_o;
  wire [4:0]       _decode0_inst_csr_zimm_o;
  wire             _decode0_inst_illegal_o;
  wire             _decode0_inst_is_branch_o;
  wire             _decode0_inst_is_jump_o;
  wire             _decode0_inst_is_load_o;
  wire             _decode0_inst_is_store_o;
  wire [2:0]       _decode0_inst_mem_width_o;
  wire [31:0]      _if_id1_inst_inst_addr_o;
  wire [31:0]      _if_id1_inst_inst_o;
  wire             _if_id1_inst_prdt_taken_o;
  wire [31:0]      _if_id1_inst_prdt_pc_addr;
  wire [31:0]      _if_id0_inst_inst_addr_o;
  wire [31:0]      _if_id0_inst_inst_o;
  wire             _if_id0_inst_prdt_taken_o;
  wire [31:0]      _if_id0_inst_prdt_pc_addr;
  wire             _frontend_inst_invalidate_req_ready_o;
  wire             _frontend_inst_invalidate_done_o;
  wire             _frontend_inst_slot0_valid_o;
  wire [31:0]      _frontend_inst_slot0_pc_o;
  wire [31:0]      _frontend_inst_slot0_inst_o;
  wire             _frontend_inst_slot0_pred_taken_o;
  wire [31:0]      _frontend_inst_slot0_pred_target_o;
  wire             _frontend_inst_slot1_valid_o;
  wire [31:0]      _frontend_inst_slot1_pc_o;
  wire [31:0]      _frontend_inst_slot1_inst_o;
  wire             _frontend_inst_slot1_pred_taken_o;
  wire [31:0]      _frontend_inst_slot1_pred_target_o;
  wire             _frontend_inst_slot0_access_fault_o;
  wire             pipeline_stall = _ex0_inst_mdu_stall_o | dcache_stall | fence_stall;
  wire             bht_extra_valid =
    resolve0_control & _id_ex0_inst_is_branch_o & resolve1_live & ~pipeline_stall;
  wire             ras0_is_jalr = ras0_hint_live & _id_ex0_inst_inst_o[6:0] == 7'h67;
  wire             ras0_rd_link =
    _id_ex0_inst_inst_o[11:7] == 5'h1 | _id_ex0_inst_inst_o[11:7] == 5'h5;
  wire             ras0_pop =
    ras0_is_jalr
    & (_id_ex0_inst_inst_o[19:15] == 5'h1 | _id_ex0_inst_inst_o[19:15] == 5'h5)
    & (~ras0_rd_link | _id_ex0_inst_inst_o[11:7] != _id_ex0_inst_inst_o[19:15]);
  wire             ras0_push =
    (ras0_hint_live & _id_ex0_inst_inst_o[6:0] == 7'h6F | ras0_is_jalr) & ras0_rd_link;
  wire             ras0_update_valid =
    ~pipeline_stall & resolve0_control & (ras0_pop | ras0_push);
  wire             ras1_is_jalr = ras1_hint_live & _id_ex1_inst_inst_o[6:0] == 7'h67;
  wire             ras1_rd_link =
    _id_ex1_inst_inst_o[11:7] == 5'h1 | _id_ex1_inst_inst_o[11:7] == 5'h5;
  wire             ras1_pop =
    ras1_is_jalr
    & (_id_ex1_inst_inst_o[19:15] == 5'h1 | _id_ex1_inst_inst_o[19:15] == 5'h5)
    & (~ras1_rd_link | _id_ex1_inst_inst_o[11:7] != _id_ex1_inst_inst_o[19:15]);
  wire             ras1_push =
    (ras1_hint_live & _id_ex1_inst_inst_o[6:0] == 7'h6F | ras1_is_jalr) & ras1_rd_link;
  wire             ras1_update_valid =
    ~pipeline_stall & resolve1_live & (ras1_pop | ras1_push);
  reg              if0_valid;
  reg              if1_valid;
  reg              if0_access_fault;
  reg              idex0_valid;
  reg              idex1_valid;
  reg              idex0_access_fault;
  assign ras0_hint_live = idex0_valid & _id_ex0_inst_is_jump_o;
  assign ras1_hint_live = idex1_valid & _id_ex1_inst_is_jump_o;
  reg              ex_mem1_is_load;
  reg              ex1_mem_is_load;
  reg              ex1_mem_valid;
  wire             mem0_load_response_live =
    _dcache_inst_cpu_resp_valid_o & ~(|_dcache_inst_cpu_resp_owner_o);
  wire             _mem1_fault_response_T = _dcache_inst_cpu_resp_owner_o == 2'h1;
  wire             mem1_load_response_live =
    _dcache_inst_cpu_resp_valid_o & _mem1_fault_response_T;
  wire [7:0][31:0] _GEN =
    {{32'h0},
     {32'h0},
     {{16'h0, _dcache_inst_cpu_resp_rdata_o[15:0]}},
     {{24'h0, _dcache_inst_cpu_resp_rdata_o[7:0]}},
     {32'h0},
     {_dcache_inst_cpu_resp_rdata_o},
     {{{16{_dcache_inst_cpu_resp_rdata_o[15]}}, _dcache_inst_cpu_resp_rdata_o[15:0]}},
     {{{24{_dcache_inst_cpu_resp_rdata_o[7]}}, _dcache_inst_cpu_resp_rdata_o[7:0]}}};
  wire [31:0]      formatted_load_data =
    _GEN[ex1_mem_valid & ex1_mem_is_load
           ? _ex_mem1_inst_reg_wr_sel_o
           : _ex_mem0_inst_reg_wr_sel_o];
  wire [31:0]      exmem0_forward_data =
    ex_mem1_is_load ? formatted_load_data : _ex_mem0_inst_rd_data_o;
  wire [31:0]      exmem1_forward_data =
    ex1_mem_is_load ? formatted_load_data : _ex_mem1_inst_rd_data_o;
  wire             exmem1_forward_valid =
    _ex_mem1_inst_reg_wen_o & (~ex1_mem_is_load | mem1_load_response_live);
  wire             exmem0_forward_valid =
    _ex_mem0_inst_reg_wen_o & (~ex_mem1_is_load | mem0_load_response_live);
  wire             _ex0_mem_base_wait_T_6 =
    _id_ex0_inst_rs1_addr_o == _ex_mem1_inst_rd_addr_o;
  wire             s0_xm1_rs1 =
    exmem1_forward_valid & (|_ex_mem1_inst_rd_addr_o) & _ex0_mem_base_wait_T_6;
  wire             _ex0_mem_base_wait_T_2 =
    _id_ex0_inst_rs1_addr_o == _ex_mem0_inst_rd_addr_o;
  wire             s0_xm0_rs1 =
    exmem0_forward_valid & (|_ex_mem0_inst_rd_addr_o) & _ex0_mem_base_wait_T_2;
  wire             s0_m1_rs1 =
    _mem1_inst_reg_wen_o & (|_mem1_inst_rd_addr_o)
    & _id_ex0_inst_rs1_addr_o == _mem1_inst_rd_addr_o;
  wire             s0_m0_rs1 =
    _mem0_inst_reg_wen_o & (|_mem0_inst_rd_addr_o)
    & _id_ex0_inst_rs1_addr_o == _mem0_inst_rd_addr_o;
  wire             s0_w1_rs1 =
    _wb1_inst_reg_wen_o & (|_wb1_inst_rd_addr_o)
    & _id_ex0_inst_rs1_addr_o == _wb1_inst_rd_addr_o;
  wire             s0_w0_rs1 =
    _wb0_inst_reg_wen_o & (|_wb0_inst_rd_addr_o)
    & _id_ex0_inst_rs1_addr_o == _wb0_inst_rd_addr_o;
  wire [31:0]      s0_rs1_value =
    s0_xm1_rs1
      ? exmem1_forward_data
      : s0_xm0_rs1
          ? exmem0_forward_data
          : s0_m1_rs1
              ? _mem1_inst_rd_data_o
              : s0_m0_rs1
                  ? _mem0_inst_rd_data_o
                  : s0_w1_rs1
                      ? _wb1_inst_rd_data_o
                      : s0_w0_rs1 ? _wb0_inst_rd_data_o : _id_ex0_inst_op1_o;
  wire             s0_rs1_forwarded =
    s0_xm1_rs1 | s0_xm0_rs1 | s0_m1_rs1 | s0_m0_rs1 | s0_w1_rs1 | s0_w0_rs1;
  wire             _ex0_store_data_wait_T_6 =
    _id_ex0_inst_rs2_addr_o == _ex_mem1_inst_rd_addr_o;
  wire             s0_xm1_rs2 =
    exmem1_forward_valid & (|_ex_mem1_inst_rd_addr_o) & _ex0_store_data_wait_T_6;
  wire             _ex0_store_data_wait_T_2 =
    _id_ex0_inst_rs2_addr_o == _ex_mem0_inst_rd_addr_o;
  wire             s0_xm0_rs2 =
    exmem0_forward_valid & (|_ex_mem0_inst_rd_addr_o) & _ex0_store_data_wait_T_2;
  wire             s0_m1_rs2 =
    _mem1_inst_reg_wen_o & (|_mem1_inst_rd_addr_o)
    & _id_ex0_inst_rs2_addr_o == _mem1_inst_rd_addr_o;
  wire             s0_m0_rs2 =
    _mem0_inst_reg_wen_o & (|_mem0_inst_rd_addr_o)
    & _id_ex0_inst_rs2_addr_o == _mem0_inst_rd_addr_o;
  wire             s0_w1_rs2 =
    _wb1_inst_reg_wen_o & (|_wb1_inst_rd_addr_o)
    & _id_ex0_inst_rs2_addr_o == _wb1_inst_rd_addr_o;
  wire             s0_w0_rs2 =
    _wb0_inst_reg_wen_o & (|_wb0_inst_rd_addr_o)
    & _id_ex0_inst_rs2_addr_o == _wb0_inst_rd_addr_o;
  wire [31:0]      s0_rs2_value =
    s0_xm1_rs2
      ? exmem1_forward_data
      : s0_xm0_rs2
          ? exmem0_forward_data
          : s0_m1_rs2
              ? _mem1_inst_rd_data_o
              : s0_m0_rs2
                  ? _mem0_inst_rd_data_o
                  : s0_w1_rs2
                      ? _wb1_inst_rd_data_o
                      : s0_w0_rs2 ? _wb0_inst_rd_data_o : _id_ex0_inst_op2_o;
  wire             s0_rs2_forwarded =
    s0_xm1_rs2 | s0_xm0_rs2 | s0_m1_rs2 | s0_m0_rs2 | s0_w1_rs2 | s0_w0_rs2;
  reg              s0_operand_hold;
  reg              s0_rs1_forward_seen;
  reg  [31:0]      s0_rs1_held;
  reg  [31:0]      s0_rs2_held;
  wire             _GEN_0 = s0_operand_hold & s0_rs1_forward_seen;
  wire [31:0]      s0_rs1_execute =
    s0_operand_hold & ~s0_rs1_forwarded ? s0_rs1_held : s0_rs1_value;
  wire             _retire0_nonmemory_T_2 =
    _id_ex0_inst_is_load_o | _id_ex0_inst_is_store_o;
  wire             idex0_base_uses_rs1 =
    _retire0_nonmemory_T_2 | _id_ex0_inst_is_jump_o & _id_ex0_inst_inst_o[6:0] == 7'h67;
  wire [31:0]      ex0_op1 = idex0_base_uses_rs1 ? _id_ex0_inst_op1_o : s0_rs1_execute;
  wire             _csr_inst_csr_valid_i_T = idex0_valid & _id_ex0_inst_is_system_o;
  wire             _lane0_load_access_fault_T = idex0_valid & _id_ex0_inst_is_load_o;
  wire             _lane0_store_access_fault_T = idex0_valid & _id_ex0_inst_is_store_o;
  assign resolve0_control =
    lane0_commit_live & (_id_ex0_inst_is_branch_o | _id_ex0_inst_is_jump_o);
  wire             _lane0_control_taken_T =
    _id_ex0_inst_is_branch_o & _ex0_inst_ex_real_taken_o;
  assign resolve0_taken = _id_ex0_inst_is_jump_o | _lane0_control_taken_T;
  wire             s1_current_rs1 =
    _ex0_inst_rd_wen_o & (|_ex0_inst_rd_addr_o)
    & _id_ex1_inst_rs1_addr_o == _ex0_inst_rd_addr_o;
  wire             _ex1_mem_base_wait_T_6 =
    _id_ex1_inst_rs1_addr_o == _ex_mem1_inst_rd_addr_o;
  wire             s1_xm1_rs1 =
    exmem1_forward_valid & (|_ex_mem1_inst_rd_addr_o) & _ex1_mem_base_wait_T_6;
  wire             _ex1_mem_base_wait_T_2 =
    _id_ex1_inst_rs1_addr_o == _ex_mem0_inst_rd_addr_o;
  wire             s1_xm0_rs1 =
    exmem0_forward_valid & (|_ex_mem0_inst_rd_addr_o) & _ex1_mem_base_wait_T_2;
  wire             s1_m1_rs1 =
    _mem1_inst_reg_wen_o & (|_mem1_inst_rd_addr_o)
    & _id_ex1_inst_rs1_addr_o == _mem1_inst_rd_addr_o;
  wire             s1_m0_rs1 =
    _mem0_inst_reg_wen_o & (|_mem0_inst_rd_addr_o)
    & _id_ex1_inst_rs1_addr_o == _mem0_inst_rd_addr_o;
  wire             s1_w1_rs1 =
    _wb1_inst_reg_wen_o & (|_wb1_inst_rd_addr_o)
    & _id_ex1_inst_rs1_addr_o == _wb1_inst_rd_addr_o;
  wire             s1_w0_rs1 =
    _wb0_inst_reg_wen_o & (|_wb0_inst_rd_addr_o)
    & _id_ex1_inst_rs1_addr_o == _wb0_inst_rd_addr_o;
  wire [31:0]      s1_older_rs1_value =
    s1_xm1_rs1
      ? exmem1_forward_data
      : s1_xm0_rs1
          ? exmem0_forward_data
          : s1_m1_rs1
              ? _mem1_inst_rd_data_o
              : s1_m0_rs1
                  ? _mem0_inst_rd_data_o
                  : s1_w1_rs1
                      ? _wb1_inst_rd_data_o
                      : s1_w0_rs1 ? _wb0_inst_rd_data_o : _id_ex1_inst_op1_o;
  wire             s1_current_rs2 =
    _ex0_inst_rd_wen_o & (|_ex0_inst_rd_addr_o)
    & _id_ex1_inst_rs2_addr_o == _ex0_inst_rd_addr_o;
  wire             _ex1_store_data_wait_T_6 =
    _id_ex1_inst_rs2_addr_o == _ex_mem1_inst_rd_addr_o;
  wire             s1_xm1_rs2 =
    exmem1_forward_valid & (|_ex_mem1_inst_rd_addr_o) & _ex1_store_data_wait_T_6;
  wire             _ex1_store_data_wait_T_2 =
    _id_ex1_inst_rs2_addr_o == _ex_mem0_inst_rd_addr_o;
  wire             s1_xm0_rs2 =
    exmem0_forward_valid & (|_ex_mem0_inst_rd_addr_o) & _ex1_store_data_wait_T_2;
  wire             s1_m1_rs2 =
    _mem1_inst_reg_wen_o & (|_mem1_inst_rd_addr_o)
    & _id_ex1_inst_rs2_addr_o == _mem1_inst_rd_addr_o;
  wire             s1_m0_rs2 =
    _mem0_inst_reg_wen_o & (|_mem0_inst_rd_addr_o)
    & _id_ex1_inst_rs2_addr_o == _mem0_inst_rd_addr_o;
  wire             s1_w1_rs2 =
    _wb1_inst_reg_wen_o & (|_wb1_inst_rd_addr_o)
    & _id_ex1_inst_rs2_addr_o == _wb1_inst_rd_addr_o;
  wire             s1_w0_rs2 =
    _wb0_inst_reg_wen_o & (|_wb0_inst_rd_addr_o)
    & _id_ex1_inst_rs2_addr_o == _wb0_inst_rd_addr_o;
  wire [31:0]      s1_older_rs2_value =
    s1_xm1_rs2
      ? exmem1_forward_data
      : s1_xm0_rs2
          ? exmem0_forward_data
          : s1_m1_rs2
              ? _mem1_inst_rd_data_o
              : s1_m0_rs2
                  ? _mem0_inst_rd_data_o
                  : s1_w1_rs2
                      ? _wb1_inst_rd_data_o
                      : s1_w0_rs2 ? _wb0_inst_rd_data_o : _id_ex1_inst_op2_o;
  wire             s1_older_rs1_forwarded =
    s1_xm1_rs1 | s1_xm0_rs1 | s1_m1_rs1 | s1_m0_rs1 | s1_w1_rs1 | s1_w0_rs1;
  wire             s1_older_rs2_forwarded =
    s1_xm1_rs2 | s1_xm0_rs2 | s1_m1_rs2 | s1_m0_rs2 | s1_w1_rs2 | s1_w0_rs2;
  reg              s1_operand_hold;
  reg              s1_rs1_forward_seen;
  reg  [31:0]      s1_rs1_held;
  reg  [31:0]      s1_rs2_held;
  wire             _GEN_1 = s1_operand_hold & s1_rs1_forward_seen;
  wire [31:0]      s1_older_rs1_execute =
    s1_operand_hold & ~s1_older_rs1_forwarded ? s1_rs1_held : s1_older_rs1_value;
  wire [31:0]      s1_older_rs2_execute =
    s1_operand_hold & ~s1_older_rs2_forwarded ? s1_rs2_held : s1_older_rs2_value;
  wire             s1_current_is_fast_mul =
    _id_ex0_inst_is_mdu_o & _id_ex0_inst_mdu_op_o == 3'h0;
  wire             s1_base_forwarded = _GEN_1 | s1_older_rs1_forwarded;
  wire             _retire1_nonmemory_T_2 =
    _id_ex1_inst_is_load_o | _id_ex1_inst_is_store_o;
  wire             s1_current_base_rs1 = s1_current_rs1 & ~s1_current_is_fast_mul;
  wire             ex1_live =
    idex1_valid & ~older_data_fault & ~lane0_exception_candidate
    & ~_ex0_inst_real_jump_en_o;
  assign resolve1_live = _ex1_inst_control_valid_o & ex1_commit_live;
  wire             ex0_mem_valid_now = lane0_commit_live & _retire0_nonmemory_T_2;
  assign ex1_commit_live = ex1_live & ~lane1_sync_trap & ~take_interrupt;
  wire             ex1_mem_commit_valid_now =
    _ex1_inst_mem_valid_o & ex1_live & ~lane1_memory_sync_trap & ~interrupt_commit_block;
  wire             exmem0_load_pending =
    _ex_mem0_inst_reg_wen_o & ex_mem1_is_load & ~mem0_load_response_live;
  wire             exmem1_load_pending =
    _ex_mem1_inst_reg_wen_o & ex1_mem_is_load & ~mem1_load_response_live;
  wire             dcache_live_req_valid =
    (ex0_mem_valid_now | ex1_mem_commit_valid_now)
    & ~(ex1_mem_commit_valid_now
          ? (|_id_ex1_inst_rs1_addr_o) & exmem0_load_pending & _ex1_mem_base_wait_T_2
            | (|_id_ex1_inst_rs1_addr_o) & exmem1_load_pending & _ex1_mem_base_wait_T_6
            | _id_ex1_inst_is_store_o
            & ((|_id_ex1_inst_rs2_addr_o) & exmem0_load_pending & _ex1_store_data_wait_T_2
               | (|_id_ex1_inst_rs2_addr_o) & exmem1_load_pending
               & _ex1_store_data_wait_T_6)
          : (|_id_ex0_inst_rs1_addr_o) & exmem0_load_pending & _ex0_mem_base_wait_T_2
            | (|_id_ex0_inst_rs1_addr_o) & exmem1_load_pending & _ex0_mem_base_wait_T_6
            | _id_ex0_inst_is_store_o
            & ((|_id_ex0_inst_rs2_addr_o) & exmem0_load_pending & _ex0_store_data_wait_T_2
               | (|_id_ex0_inst_rs2_addr_o) & exmem1_load_pending
               & _ex0_store_data_wait_T_6));
  wire [1:0]       dcache_live_req_owner = {1'h0, ex1_mem_commit_valid_now};
  wire             dcache_live_req_write =
    ex1_mem_commit_valid_now ? _ex1_inst_mem_write_o : _ex0_inst_mem_rd_req;
  wire [31:0]      dcache_live_req_addr =
    ex1_mem_commit_valid_now ? _ex1_inst_mem_addr_o : _ex0_inst_mem_rd_addr;
  wire [31:0]      dcache_live_req_wdata =
    ex1_mem_commit_valid_now ? _ex1_inst_mem_wdata_o : _ex0_inst_mem_wr_data_o;
  wire [1:0]       dcache_live_req_size =
    ex1_mem_commit_valid_now ? _ex1_inst_mem_mask_o : _ex0_inst_mem_mask;
  wire             data_pma_select_lane1 =
    ~(idex0_valid & _retire0_nonmemory_T_2) & idex1_valid & _retire1_nonmemory_T_2;
  reg              dcache_req_held;
  reg  [1:0]       dcache_req_owner_q;
  reg              dcache_req_write_q;
  reg  [31:0]      dcache_req_addr_q;
  reg  [31:0]      dcache_req_wdata_q;
  reg  [1:0]       dcache_req_size_q;
  reg              dcache_req_cacheable_q;
  wire             dcache_cpu_req_valid = dcache_req_held | dcache_live_req_valid;
  wire [1:0]       dcache_cpu_req_owner =
    dcache_req_held ? dcache_req_owner_q : dcache_live_req_owner;
  wire             dcache_cpu_req_write =
    dcache_req_held ? dcache_req_write_q : dcache_live_req_write;
  wire [31:0]      dcache_cpu_req_addr =
    dcache_req_held ? dcache_req_addr_q : dcache_live_req_addr;
  wire [1:0]       dcache_cpu_req_size =
    dcache_req_held ? dcache_req_size_q : dcache_live_req_size;
  wire             dcache_cpu_req_cacheable =
    dcache_req_held ? dcache_req_cacheable_q : _data_pma_cacheable_o;
  reg  [1:0]       store_buffer_count;
  reg  [1:0]       store_buffer_head;
  wire             dcache_internal_req_valid = dcache_cpu_req_valid & ~older_data_fault;
  wire             dcache_response_wait =
    _dcache_inst_busy_o & ~_dcache_inst_cpu_resp_valid_o;
  assign dcache_stall =
    dcache_response_wait | dcache_cpu_req_valid & ~_dcache_inst_cpu_req_ready_o;
  reg  [31:0]      memory_owner_pc_q;
  reg  [31:0]      memory_owner_addr_q;
  reg              memory_owner_store_q;
  wire             dcache_cpu_req_accept =
    dcache_internal_req_valid & _dcache_inst_cpu_req_ready_o;
  assign older_data_fault = _dcache_inst_cpu_resp_valid_o & _dcache_inst_cpu_resp_error_o;
  reg  [2:0]       fence_state_q;
  reg              fence_is_i_q;
  reg  [31:0]      fence_pc_q;
  reg  [31:0]      fence_fault_addr_q;
  wire             lane0_is_fence_i =
    idex0_valid & _id_ex0_inst_inst_o[6:0] == 7'hF & _id_ex0_inst_inst_o[14:12] == 3'h1;
  wire             _fence_start_T = fence_state_q == 3'h0;
  wire             fence_start =
    (idex0_valid & _id_ex0_inst_inst_o[6:0] == 7'hF & _id_ex0_inst_inst_o[14:12] == 3'h0
     | lane0_is_fence_i) & _fence_start_T & ~older_data_fault & ~_id_ex0_inst_illegal_o
    & ~_ex0_inst_mdu_stall_o & ~dcache_response_wait;
  assign fence_stall =
    fence_start | (|fence_state_q) & fence_state_q != 3'h5 & fence_state_q != 3'h6;
  wire             dcache_fence_req = fence_state_q == 3'h1;
  wire             fence_redirect = fence_state_q == 3'h5 & fence_is_i_q;
  wire             fence_fault_pending = fence_state_q == 3'h6;
  wire             lane0_control_misaligned =
    idex0_valid & (_id_ex0_inst_is_jump_o | _lane0_control_taken_T)
    & (|(_ex0_inst_resolved_target_o[1:0]));
  wire             _lane0_store_misaligned_T_1 = _ex0_inst_mem_mask == 2'h1;
  wire             _lane0_store_misaligned_T_4 = _ex0_inst_mem_mask == 2'h2;
  wire             lane0_load_misaligned =
    _lane0_load_access_fault_T
    & (_lane0_store_misaligned_T_1 & _ex0_inst_mem_rd_addr[0]
       | _lane0_store_misaligned_T_4 & (|(_ex0_inst_mem_rd_addr[1:0])));
  wire             lane0_store_misaligned =
    _lane0_store_access_fault_T
    & (_lane0_store_misaligned_T_1 & _ex0_inst_mem_rd_addr[0]
       | _lane0_store_misaligned_T_4 & (|(_ex0_inst_mem_rd_addr[1:0])));
  wire             lane0_load_access_fault =
    _lane0_load_access_fault_T & ~_data_pma_readable_o;
  wire             lane0_store_access_fault =
    _lane0_store_access_fault_T & ~_data_pma_writable_o;
  wire             _retire0_nonmemory_T_5 = _id_ex0_inst_system_op_o == 4'h8;
  wire             lane0_ecall = _csr_inst_csr_valid_i_T & _retire0_nonmemory_T_5;
  wire             _retire0_nonmemory_T_6 = _id_ex0_inst_system_op_o == 4'hA;
  wire             lane0_ebreak = _csr_inst_csr_valid_i_T & _retire0_nonmemory_T_6;
  assign lane0_exception_candidate =
    idex0_valid & ~_ex0_inst_mdu_stall_o & ~dcache_response_wait
    & (idex0_access_fault | _id_ex0_inst_illegal_o | _csr_inst_illegal_csr_o
       | lane0_ebreak | lane0_control_misaligned | lane0_load_misaligned
       | lane0_store_misaligned | lane0_load_access_fault | lane0_store_access_fault
       | lane0_ecall | fence_fault_pending);
  wire             _GEN_2 = _id_ex0_inst_illegal_o | _csr_inst_illegal_csr_o;
  wire             lane1_control_misaligned =
    ex1_live & _ex1_inst_actual_taken_o & (|(_ex1_inst_resolved_target_o[1:0]));
  wire             _lane1_load_access_fault_T = ex1_live & _id_ex1_inst_is_load_o;
  wire             _lane1_store_misaligned_T_1 = _ex1_inst_mem_mask_o == 2'h1;
  wire             _lane1_store_misaligned_T_4 = _ex1_inst_mem_mask_o == 2'h2;
  wire             lane1_load_misaligned =
    _lane1_load_access_fault_T
    & (_lane1_store_misaligned_T_1 & _ex1_inst_mem_addr_o[0] | _lane1_store_misaligned_T_4
       & (|(_ex1_inst_mem_addr_o[1:0])));
  wire             _lane1_store_access_fault_T = ex1_live & _id_ex1_inst_is_store_o;
  wire             lane1_store_misaligned =
    _lane1_store_access_fault_T
    & (_lane1_store_misaligned_T_1 & _ex1_inst_mem_addr_o[0] | _lane1_store_misaligned_T_4
       & (|(_ex1_inst_mem_addr_o[1:0])));
  wire             lane1_load_access_fault =
    _lane1_load_access_fault_T & ~_data_pma_readable_o;
  wire             lane1_store_access_fault =
    _lane1_store_access_fault_T & ~_data_pma_writable_o;
  wire             lane1_trap_window =
    ex1_live & ~_ex0_inst_mdu_stall_o & ~dcache_response_wait;
  assign lane1_memory_sync_trap =
    lane1_trap_window
    & (_id_ex1_inst_illegal_o | lane1_load_misaligned | lane1_store_misaligned
       | lane1_load_access_fault | lane1_store_access_fault);
  assign lane1_sync_trap =
    lane1_memory_sync_trap | lane1_trap_window & lane1_control_misaligned;
  wire             any_sync_trap =
    older_data_fault | lane0_exception_candidate | lane1_sync_trap;
  assign interrupt_commit_block =
    _csr_inst_interrupt_request_o & idex0_valid & ~_ex0_inst_mdu_stall_o
    & ~dcache_response_wait & ~fence_stall;
  assign take_interrupt = interrupt_commit_block & ~any_sync_trap;
  assign lane0_commit_live =
    idex0_valid & ~older_data_fault & ~lane0_exception_candidate & ~take_interrupt;
  wire             ex0_branch_redirect_live =
    _ex0_inst_real_jump_en_o & lane0_commit_live & ~pipeline_stall;
  wire             ex_jump_en_o =
    _csr_inst_redirect_o | fence_redirect | ex0_branch_redirect_live
    | _ex1_inst_redirect_o & ex1_commit_live & ~pipeline_stall;
  wire             adapter_cmd_valid =
    (|store_buffer_count) | _dcache_inst_mem_cmd_valid_o;
  wire [1:0]       adapter_cmd_owner =
    (|store_buffer_count) ? 2'h2 : _dcache_inst_mem_cmd_owner_o;
  wire             _adapter_rsp_ready_T = dmem_rsp_owner_i == 2'h2;
  wire             adapter_rsp_ready =
    _adapter_rsp_ready_T | _dcache_inst_mem_rsp_ready_o;
  reg              store_owner_outstanding_q;
  wire             _GEN_3 =
    adapter_cmd_valid & dmem_cmd_ready_i & adapter_cmd_owner == 2'h2;
  wire             _GEN_4 = dmem_rsp_valid_i & adapter_rsp_ready & _adapter_rsp_ready_T;
  reg              exmem_pair_drained;
  wire             mem0_stage_wen =
    ~exmem_pair_drained & ~(older_data_fault & ~(|_dcache_inst_cpu_resp_owner_o))
    & _ex_mem0_inst_reg_wen_o & (~ex_mem1_is_load | mem0_load_response_live);
  wire             mem1_stage_wen =
    ~exmem_pair_drained & ~(older_data_fault & _mem1_fault_response_T)
    & _ex_mem1_inst_reg_wen_o & (~ex1_mem_is_load | mem1_load_response_live);
  wire             dcache_mem_stage_stall = dcache_stall & ~_dcache_inst_cpu_resp_valid_o;
  wire             _GEN_5 =
    ~dcache_req_held & dcache_live_req_valid & ~_dcache_inst_cpu_req_ready_o;
  wire [7:0][2:0]  _GEN_6 =
    {{3'h0},
     {3'h0},
     {3'h0},
     {_frontend_inst_invalidate_done_o ? 3'h5 : fence_state_q},
     {_frontend_inst_invalidate_req_ready_o ? 3'h4 : fence_state_q},
     {_dcache_inst_fence_done_o
        ? (_dcache_inst_fence_error_o ? 3'h6 : fence_is_i_q ? 3'h3 : 3'h5)
        : fence_state_q},
     {_dcache_inst_fence_req_ready_o ? 3'h2 : fence_state_q},
     {fence_start ? 3'h1 : fence_state_q}};
  wire             _GEN_7 = cpu_rst | ex_jump_en_o;
  always @(posedge cpu_clk) begin
    if0_valid <= ~_GEN_7 & (pipeline_stall ? if0_valid : _frontend_inst_slot0_valid_o);
    if1_valid <= ~_GEN_7 & (pipeline_stall ? if1_valid : _frontend_inst_slot1_valid_o);
    if0_access_fault <=
      ~_GEN_7 & (pipeline_stall ? if0_access_fault : _frontend_inst_slot0_access_fault_o);
    idex0_valid <= ~_GEN_7 & (pipeline_stall ? idex0_valid : if0_valid);
    idex1_valid <= ~_GEN_7 & (pipeline_stall ? idex1_valid : if1_valid);
    idex0_access_fault <=
      ~_GEN_7 & (pipeline_stall ? idex0_access_fault : if0_access_fault);
    store_owner_outstanding_q <=
      ~(cpu_rst | _GEN_4) & (_GEN_3 | store_owner_outstanding_q);
    exmem_pair_drained <=
      ~(cpu_rst | ~dcache_stall) & (_dcache_inst_cpu_resp_valid_o | exmem_pair_drained);
    if (cpu_rst) begin
      ex_mem1_is_load <= 1'h0;
      ex1_mem_is_load <= 1'h0;
      ex1_mem_valid <= 1'h0;
      s0_operand_hold <= 1'h0;
      s0_rs1_forward_seen <= 1'h0;
      s0_rs1_held <= 32'h0;
      s0_rs2_held <= 32'h0;
      s1_operand_hold <= 1'h0;
      s1_rs1_forward_seen <= 1'h0;
      s1_rs1_held <= 32'h0;
      s1_rs2_held <= 32'h0;
      dcache_req_held <= 1'h0;
      dcache_req_owner_q <= 2'h0;
      dcache_req_write_q <= 1'h0;
      dcache_req_addr_q <= 32'h0;
      dcache_req_wdata_q <= 32'h0;
      dcache_req_size_q <= 2'h0;
      dcache_req_cacheable_q <= 1'h0;
      store_buffer_count <= 2'h0;
      store_buffer_head <= 2'h0;
      memory_owner_pc_q <= 32'h0;
      memory_owner_addr_q <= 32'h0;
      memory_owner_store_q <= 1'h0;
      fence_state_q <= 3'h0;
      fence_is_i_q <= 1'h0;
      fence_pc_q <= 32'h0;
      fence_fault_addr_q <= 32'h0;
    end
    else begin
      if (~dcache_stall) begin
        ex_mem1_is_load <= ex0_mem_valid_now & _id_ex0_inst_is_load_o;
        ex1_mem_is_load <= ex1_mem_commit_valid_now & _id_ex1_inst_is_load_o;
        ex1_mem_valid <= ex1_mem_commit_valid_now;
      end
      s0_operand_hold <= dcache_stall;
      s0_rs1_forward_seen <= dcache_stall & (_GEN_0 | s0_rs1_forwarded);
      if (dcache_stall & (~s0_operand_hold | s0_rs1_forwarded))
        s0_rs1_held <= s0_rs1_value;
      if (dcache_stall & (~s0_operand_hold | s0_rs2_forwarded))
        s0_rs2_held <= s0_rs2_value;
      s1_operand_hold <= dcache_stall;
      s1_rs1_forward_seen <= dcache_stall & (_GEN_1 | s1_older_rs1_forwarded);
      if (dcache_stall & (~s1_operand_hold | s1_older_rs1_forwarded))
        s1_rs1_held <= s1_older_rs1_value;
      if (dcache_stall & (~s1_operand_hold | s1_older_rs2_forwarded))
        s1_rs2_held <= s1_older_rs2_value;
      dcache_req_held <=
        _GEN_5 | ~(dcache_req_held & _dcache_inst_cpu_req_ready_o) & dcache_req_held;
      if (_GEN_5) begin
        dcache_req_owner_q <= dcache_live_req_owner;
        dcache_req_write_q <= dcache_live_req_write;
        dcache_req_addr_q <= dcache_live_req_addr;
        dcache_req_wdata_q <= dcache_live_req_wdata;
        dcache_req_size_q <= dcache_live_req_size;
        dcache_req_cacheable_q <= _data_pma_cacheable_o;
      end
      if ((|store_buffer_count) & dmem_cmd_ready_i) begin
        store_buffer_count <= store_buffer_count - 2'h1;
        if (store_buffer_head == 2'h2)
          store_buffer_head <= 2'h0;
        else
          store_buffer_head <= store_buffer_head + 2'h1;
      end
      if (dcache_cpu_req_accept) begin
        memory_owner_pc_q <=
          dcache_cpu_req_owner == 2'h1
            ? _id_ex1_inst_inst_addr_o
            : _id_ex0_inst_inst_addr_o;
        memory_owner_addr_q <= dcache_cpu_req_addr;
        memory_owner_store_q <= dcache_cpu_req_write;
      end
      fence_state_q <= _GEN_6[fence_state_q];
      if (_fence_start_T & fence_start) begin
        fence_is_i_q <= lane0_is_fence_i;
        fence_pc_q <= _id_ex0_inst_inst_addr_o;
      end
      if (_fence_start_T) begin
        if (fence_start)
          fence_fault_addr_q <= 32'h0;
      end
      else if (dcache_fence_req
               | ~(fence_state_q == 3'h2 & _dcache_inst_fence_done_o
                   & _dcache_inst_fence_error_o)) begin
      end
      else
        fence_fault_addr_q <= _dcache_inst_fence_error_addr_o;
    end
  end
  fetch2_frontend_soc frontend_inst (
    .clk                    (cpu_clk),
    .rst                    (cpu_rst),
    .stall_i                (pipeline_stall),
    .invalidate_req_i       (fence_state_q == 3'h3),
    .invalidate_req_ready_o (_frontend_inst_invalidate_req_ready_o),
    .invalidate_done_o      (_frontend_inst_invalidate_done_o),
    .redirect_valid_i       (ex_jump_en_o),
    .redirect_pc_i
      (_csr_inst_redirect_o
         ? _csr_inst_redirect_pc_o
         : fence_redirect
             ? fence_pc_q + 32'h4
             : ex0_branch_redirect_live
                 ? _ex0_inst_real_jump_addr_o
                 : _ex1_inst_redirect_pc_o),
    .resolve_valid_i        ((resolve0_control | resolve1_live) & ~dcache_stall),
    .resolve_is_branch_i
      (resolve1_live ? _ex1_inst_branch_valid_o : _id_ex0_inst_is_branch_o),
    .resolve_pc_i
      (resolve1_live ? _id_ex1_inst_inst_addr_o : _id_ex0_inst_inst_addr_o),
    .resolve_taken_i        (resolve1_live ? _ex1_inst_actual_taken_o : resolve0_taken),
    .resolve_target_i
      (resolve1_live ? _ex1_inst_resolved_target_o : _ex0_inst_resolved_target_o),
    .bht_extra_valid_i      (bht_extra_valid),
    .bht_extra_pc_i         (_id_ex0_inst_inst_addr_o),
    .bht_extra_taken_i      (resolve0_taken),
    .ras_update0_valid_i    (ras0_update_valid),
    .ras_update0_pop_i      (ras0_pop),
    .ras_update0_push_i     (ras0_push),
    .ras_update0_addr_i     (_id_ex0_inst_inst_addr_o + 32'h4),
    .ras_update1_valid_i    (ras1_update_valid),
    .ras_update1_pop_i      (ras1_pop),
    .ras_update1_push_i     (ras1_push),
    .ras_update1_addr_i     (_id_ex1_inst_inst_addr_o + 32'h4),
    .slot0_valid_o          (_frontend_inst_slot0_valid_o),
    .slot0_pc_o             (_frontend_inst_slot0_pc_o),
    .slot0_inst_o           (_frontend_inst_slot0_inst_o),
    .slot0_pred_taken_o     (_frontend_inst_slot0_pred_taken_o),
    .slot0_pred_target_o    (_frontend_inst_slot0_pred_target_o),
    .slot1_valid_o          (_frontend_inst_slot1_valid_o),
    .slot1_pc_o             (_frontend_inst_slot1_pc_o),
    .slot1_inst_o           (_frontend_inst_slot1_inst_o),
    .slot1_pred_taken_o     (_frontend_inst_slot1_pred_taken_o),
    .slot1_pred_target_o    (_frontend_inst_slot1_pred_target_o),
    .slot0_access_fault_o   (_frontend_inst_slot0_access_fault_o),
    .imem_cmd_valid_o       (imem_cmd_valid_o),
    .imem_cmd_ready_i       (imem_cmd_ready_i),
    .imem_cmd_addr_o        (imem_cmd_addr_o),
    .imem_rsp_valid_i       (imem_rsp_valid_i),
    .imem_rsp_ready_o       (imem_rsp_ready_o),
    .imem_rsp_data_i        (imem_rsp_data_i),
    .imem_rsp_last_i        (imem_rsp_last_i),
    .imem_rsp_error_i       (imem_rsp_error_i)
  );
  if_id if_id0_inst (
    .clk             (cpu_clk),
    .rst             (cpu_rst),
    .hold_flag_i     (ex_jump_en_o),
    .inst_i
      (_frontend_inst_slot0_valid_o ? _frontend_inst_slot0_inst_o : 32'h13),
    .inst_addr_i     (_frontend_inst_slot0_pc_o),
    .inst_addr_o     (_if_id0_inst_inst_addr_o),
    .inst_o          (_if_id0_inst_inst_o),
    .stall           (pipeline_stall),
    .prdt_taken_i    (_frontend_inst_slot0_pred_taken_o),
    .prdt_pc_add_op1 (_frontend_inst_slot0_pred_target_o),
    .prdt_taken_o    (_if_id0_inst_prdt_taken_o),
    .prdt_pc_addr    (_if_id0_inst_prdt_pc_addr),
    .ex_jump_en_i    (ex_jump_en_o)
  );
  if_id if_id1_inst (
    .clk             (cpu_clk),
    .rst             (cpu_rst),
    .hold_flag_i     (ex_jump_en_o),
    .inst_i
      (_frontend_inst_slot1_valid_o ? _frontend_inst_slot1_inst_o : 32'h13),
    .inst_addr_i     (_frontend_inst_slot1_pc_o),
    .inst_addr_o     (_if_id1_inst_inst_addr_o),
    .inst_o          (_if_id1_inst_inst_o),
    .stall           (pipeline_stall),
    .prdt_taken_i    (_frontend_inst_slot1_pred_taken_o),
    .prdt_pc_add_op1 (_frontend_inst_slot1_pred_target_o),
    .prdt_taken_o    (_if_id1_inst_prdt_taken_o),
    .prdt_pc_addr    (_if_id1_inst_prdt_pc_addr),
    .ex_jump_en_i    (ex_jump_en_o)
  );
  id decode0_inst (
    .inst_i        (_if_id0_inst_inst_o),
    .inst_addr_i   (_if_id0_inst_inst_addr_o),
    .rs1_addr_o    (_decode0_inst_rs1_addr_o),
    .rs2_addr_o    (_decode0_inst_rs2_addr_o),
    .rs1_data_i    (_regs_inst_reg1_rdata_o),
    .rs2_data_i    (_regs_inst_reg2_rdata_o),
    .inst_o        (_decode0_inst_inst_o),
    .op1_o         (_decode0_inst_op1_o),
    .op2_o         (_decode0_inst_op2_o),
    .rd_addr_o     (_decode0_inst_rd_addr_o),
    .reg_wen_o     (_decode0_inst_reg_wen_o),
    .base_addr_o   (_decode0_inst_base_addr_o),
    .addr_offset_o (_decode0_inst_addr_offset_o),
    .alu_op_o      (_decode0_inst_alu_op_o),
    .is_mdu_o      (_decode0_inst_is_mdu_o),
    .mdu_op_o      (_decode0_inst_mdu_op_o),
    .is_system_o   (_decode0_inst_is_system_o),
    .system_op_o   (_decode0_inst_system_op_o),
    .csr_addr_o    (_decode0_inst_csr_addr_o),
    .csr_zimm_o    (_decode0_inst_csr_zimm_o),
    .illegal_o     (_decode0_inst_illegal_o),
    .is_branch_o   (_decode0_inst_is_branch_o),
    .is_jump_o     (_decode0_inst_is_jump_o),
    .is_load_o     (_decode0_inst_is_load_o),
    .is_store_o    (_decode0_inst_is_store_o),
    .mem_width_o   (_decode0_inst_mem_width_o)
  );
  id decode1_inst (
    .inst_i        (_if_id1_inst_inst_o),
    .inst_addr_i   (_if_id1_inst_inst_addr_o),
    .rs1_addr_o    (_decode1_inst_rs1_addr_o),
    .rs2_addr_o    (_decode1_inst_rs2_addr_o),
    .rs1_data_i    (_regs_inst_reg3_rdata_o),
    .rs2_data_i    (_regs_inst_reg4_rdata_o),
    .inst_o        (_decode1_inst_inst_o),
    .op1_o         (_decode1_inst_op1_o),
    .op2_o         (_decode1_inst_op2_o),
    .rd_addr_o     (_decode1_inst_rd_addr_o),
    .reg_wen_o     (_decode1_inst_reg_wen_o),
    .base_addr_o   (_decode1_inst_base_addr_o),
    .addr_offset_o (_decode1_inst_addr_offset_o),
    .alu_op_o      (_decode1_inst_alu_op_o),
    .is_mdu_o      (_decode1_inst_is_mdu_o),
    .mdu_op_o      (_decode1_inst_mdu_op_o),
    .is_system_o   (/* unused */),
    .system_op_o   (/* unused */),
    .csr_addr_o    (_decode1_inst_csr_addr_o),
    .csr_zimm_o    (_decode1_inst_csr_zimm_o),
    .illegal_o     (_decode1_inst_illegal_o),
    .is_branch_o   (_decode1_inst_is_branch_o),
    .is_jump_o     (_decode1_inst_is_jump_o),
    .is_load_o     (_decode1_inst_is_load_o),
    .is_store_o    (_decode1_inst_is_store_o),
    .mem_width_o   (_decode1_inst_mem_width_o)
  );
  regs regs_inst (
    .clk          (cpu_clk),
    .rst          (cpu_rst),
    .read_stall_i (pipeline_stall),
    .reg1_raddr_i (_frontend_inst_slot0_inst_o[19:15]),
    .reg2_raddr_i (_frontend_inst_slot0_inst_o[24:20]),
    .reg3_raddr_i (_frontend_inst_slot1_inst_o[19:15]),
    .reg4_raddr_i (_frontend_inst_slot1_inst_o[24:20]),
    .reg1_rdata_o (_regs_inst_reg1_rdata_o),
    .reg2_rdata_o (_regs_inst_reg2_rdata_o),
    .reg3_rdata_o (_regs_inst_reg3_rdata_o),
    .reg4_rdata_o (_regs_inst_reg4_rdata_o),
    .reg_waddr_i  (_wb0_inst_rd_addr_o),
    .reg_wdata_i  (_wb0_inst_rd_data_o),
    .reg_wen      (_wb0_inst_reg_wen_o),
    .reg2_waddr_i (_wb1_inst_rd_addr_o),
    .reg2_wdata_i (_wb1_inst_rd_data_o),
    .reg2_wen     (_wb1_inst_reg_wen_o)
  );
  id_ex id_ex0_inst (
    .clk            (cpu_clk),
    .rst            (cpu_rst),
    .inst_i         (_decode0_inst_inst_o),
    .inst_addr_i    (_if_id0_inst_inst_addr_o),
    .rs1_addr_i     (_decode0_inst_rs1_addr_o),
    .rs2_addr_i     (_decode0_inst_rs2_addr_o),
    .op1_i          (_decode0_inst_op1_o),
    .op2_i          (_decode0_inst_op2_o),
    .rd_addr_i      (_decode0_inst_rd_addr_o),
    .reg_wen_i      (_decode0_inst_reg_wen_o & if0_valid),
    .base_addr_i    (_decode0_inst_base_addr_o),
    .addr_offset_i  (_decode0_inst_addr_offset_o),
    .hold_flag_i    (ex_jump_en_o),
    .stall_i        (pipeline_stall),
    .alu_op_i       (_decode0_inst_alu_op_o),
    .is_mdu_i       (_decode0_inst_is_mdu_o & if0_valid),
    .mdu_op_i       (_decode0_inst_mdu_op_o),
    .is_system_i    (_decode0_inst_is_system_o & if0_valid),
    .system_op_i    (_decode0_inst_system_op_o),
    .csr_addr_i     (_decode0_inst_csr_addr_o),
    .csr_zimm_i     (_decode0_inst_csr_zimm_o),
    .illegal_i      (_decode0_inst_illegal_o & if0_valid),
    .is_branch_i    (_decode0_inst_is_branch_o & if0_valid),
    .is_jump_i      (_decode0_inst_is_jump_o & if0_valid),
    .is_load_i      (_decode0_inst_is_load_o & if0_valid),
    .is_store_i     (_decode0_inst_is_store_o & if0_valid),
    .mem_width_i    (_decode0_inst_mem_width_o),
    .inst_o         (_id_ex0_inst_inst_o),
    .inst_addr_o    (_id_ex0_inst_inst_addr_o),
    .rs1_addr_o     (_id_ex0_inst_rs1_addr_o),
    .rs2_addr_o     (_id_ex0_inst_rs2_addr_o),
    .op1_o          (_id_ex0_inst_op1_o),
    .op2_o          (_id_ex0_inst_op2_o),
    .rd_addr_o      (_id_ex0_inst_rd_addr_o),
    .reg_wen_o      (_id_ex0_inst_reg_wen_o),
    .base_addr_o    (_id_ex0_inst_base_addr_o),
    .addr_offset_o  (_id_ex0_inst_addr_offset_o),
    .alu_op_o       (_id_ex0_inst_alu_op_o),
    .is_mdu_o       (_id_ex0_inst_is_mdu_o),
    .mdu_op_o       (_id_ex0_inst_mdu_op_o),
    .is_system_o    (_id_ex0_inst_is_system_o),
    .system_op_o    (_id_ex0_inst_system_op_o),
    .csr_addr_o     (_id_ex0_inst_csr_addr_o),
    .csr_zimm_o     (_id_ex0_inst_csr_zimm_o),
    .illegal_o      (_id_ex0_inst_illegal_o),
    .is_branch_o    (_id_ex0_inst_is_branch_o),
    .is_jump_o      (_id_ex0_inst_is_jump_o),
    .is_load_o      (_id_ex0_inst_is_load_o),
    .is_store_o     (_id_ex0_inst_is_store_o),
    .mem_width_o    (_id_ex0_inst_mem_width_o),
    .prdt_taken_i   (_if_id0_inst_prdt_taken_o),
    .prdt_pc_addr_i (_if_id0_inst_prdt_pc_addr),
    .prdt_taken_o   (_id_ex0_inst_prdt_taken_o),
    .prdt_pc_addr_o (_id_ex0_inst_prdt_pc_addr_o),
    .ex_jump_en_i   (ex_jump_en_o)
  );
  id_ex id_ex1_inst (
    .clk            (cpu_clk),
    .rst            (cpu_rst),
    .inst_i         (_decode1_inst_inst_o),
    .inst_addr_i    (_if_id1_inst_inst_addr_o),
    .rs1_addr_i     (_decode1_inst_rs1_addr_o),
    .rs2_addr_i     (_decode1_inst_rs2_addr_o),
    .op1_i          (_decode1_inst_op1_o),
    .op2_i          (_decode1_inst_op2_o),
    .rd_addr_i      (_decode1_inst_rd_addr_o),
    .reg_wen_i      (_decode1_inst_reg_wen_o & if1_valid),
    .base_addr_i    (_decode1_inst_base_addr_o),
    .addr_offset_i  (_decode1_inst_addr_offset_o),
    .hold_flag_i    (ex_jump_en_o),
    .stall_i        (pipeline_stall),
    .alu_op_i       (_decode1_inst_alu_op_o),
    .is_mdu_i       (_decode1_inst_is_mdu_o & if1_valid),
    .mdu_op_i       (_decode1_inst_mdu_op_o),
    .is_system_i    (1'h0),
    .system_op_i    (4'h0),
    .csr_addr_i     (_decode1_inst_csr_addr_o),
    .csr_zimm_i     (_decode1_inst_csr_zimm_o),
    .illegal_i      (_decode1_inst_illegal_o & if1_valid),
    .is_branch_i    (_decode1_inst_is_branch_o & if1_valid),
    .is_jump_i      (_decode1_inst_is_jump_o & if1_valid),
    .is_load_i      (_decode1_inst_is_load_o & if1_valid),
    .is_store_i     (_decode1_inst_is_store_o & if1_valid),
    .mem_width_i    (_decode1_inst_mem_width_o),
    .inst_o         (_id_ex1_inst_inst_o),
    .inst_addr_o    (_id_ex1_inst_inst_addr_o),
    .rs1_addr_o     (_id_ex1_inst_rs1_addr_o),
    .rs2_addr_o     (_id_ex1_inst_rs2_addr_o),
    .op1_o          (_id_ex1_inst_op1_o),
    .op2_o          (_id_ex1_inst_op2_o),
    .rd_addr_o      (_id_ex1_inst_rd_addr_o),
    .reg_wen_o      (_id_ex1_inst_reg_wen_o),
    .base_addr_o    (_id_ex1_inst_base_addr_o),
    .addr_offset_o  (_id_ex1_inst_addr_offset_o),
    .alu_op_o       (_id_ex1_inst_alu_op_o),
    .is_mdu_o       (_id_ex1_inst_is_mdu_o),
    .mdu_op_o       (_id_ex1_inst_mdu_op_o),
    .is_system_o    (/* unused */),
    .system_op_o    (/* unused */),
    .csr_addr_o     (/* unused */),
    .csr_zimm_o     (/* unused */),
    .illegal_o      (_id_ex1_inst_illegal_o),
    .is_branch_o    (_id_ex1_inst_is_branch_o),
    .is_jump_o      (_id_ex1_inst_is_jump_o),
    .is_load_o      (_id_ex1_inst_is_load_o),
    .is_store_o     (_id_ex1_inst_is_store_o),
    .mem_width_o    (_id_ex1_inst_mem_width_o),
    .prdt_taken_i   (_if_id1_inst_prdt_taken_o),
    .prdt_pc_addr_i (_if_id1_inst_prdt_pc_addr),
    .prdt_taken_o   (_id_ex1_inst_prdt_taken_o),
    .prdt_pc_addr_o (_id_ex1_inst_prdt_pc_addr_o),
    .ex_jump_en_i   (ex_jump_en_o)
  );
  ex ex0_inst (
    .clk               (cpu_clk),
    .rst               (cpu_rst),
    .stall_i           (dcache_stall),
    .inst_i            (_id_ex0_inst_inst_o),
    .inst_addr_i       (_id_ex0_inst_inst_addr_o),
    .op1_i             (ex0_op1),
    .op2_i
      ((|_id_ex0_inst_rs2_addr_o)
         ? (s0_operand_hold & ~s0_rs2_forwarded ? s0_rs2_held : s0_rs2_value)
         : _id_ex0_inst_op2_o),
    .rd_addr_i         (_id_ex0_inst_rd_addr_o),
    .reg_wen_i         (idex0_valid & _id_ex0_inst_reg_wen_o),
    .base_addr_i
      (idex0_base_uses_rs1 & (_GEN_0 | s0_rs1_forwarded)
         ? s0_rs1_execute
         : _id_ex0_inst_base_addr_o),
    .addr_offset_i     (_id_ex0_inst_addr_offset_o),
    .alu_op_i          (_id_ex0_inst_alu_op_o),
    .is_mdu_i          (idex0_valid & _id_ex0_inst_is_mdu_o),
    .mdu_op_i          (_id_ex0_inst_mdu_op_o),
    .is_system_i       (_csr_inst_csr_valid_i_T),
    .illegal_i         (idex0_valid & _id_ex0_inst_illegal_o),
    .csr_read_value_i  (_csr_inst_csr_read_value_o),
    .illegal_csr_i     (_csr_inst_illegal_csr_o),
    .is_branch_i       (idex0_valid & _id_ex0_inst_is_branch_o),
    .is_load_i         (_lane0_load_access_fault_T),
    .is_store_i        (_lane0_store_access_fault_T),
    .is_jump_i         (ras0_hint_live),
    .mem_width_i       (_id_ex0_inst_mem_width_o),
    .rd_data_o         (_ex0_inst_rd_data_o),
    .non_mdu_rd_data_o (_ex0_inst_non_mdu_rd_data_o),
    .rd_addr_o         (_ex0_inst_rd_addr_o),
    .rd_wen_o          (_ex0_inst_rd_wen_o),
    .real_jump_addr_o  (_ex0_inst_real_jump_addr_o),
    .real_jump_en_o    (_ex0_inst_real_jump_en_o),
    .mdu_stall_o       (_ex0_inst_mdu_stall_o),
    .mem_rd_req        (_ex0_inst_mem_rd_req),
    .mem_rd_addr       (_ex0_inst_mem_rd_addr),
    .mem_wr_data_o     (_ex0_inst_mem_wr_data_o),
    .mem_mask          (_ex0_inst_mem_mask),
    .sel               (_ex0_inst_sel),
    .prdt_taken_i      (_id_ex0_inst_prdt_taken_o),
    .prdt_pc_addr_i    (_id_ex0_inst_prdt_pc_addr_o),
    .ex_real_taken_o   (_ex0_inst_ex_real_taken_o),
    .resolved_target_o (_ex0_inst_resolved_target_o)
  );
  ex_lane1 ex1_inst (
    .valid_i           (ex1_live),
    .inst_i            (_id_ex1_inst_inst_o),
    .inst_addr_i       (_id_ex1_inst_inst_addr_o),
    .op1_i
      (_retire1_nonmemory_T_2 | _id_ex1_inst_is_jump_o & _id_ex1_inst_inst_o[6:0] == 7'h67
         ? _id_ex1_inst_op1_o
         : s1_current_rs1 ? _ex0_inst_non_mdu_rd_data_o : s1_older_rs1_execute),
    .op2_i
      ((|_id_ex1_inst_rs2_addr_o)
         ? (s1_current_rs2 ? _ex0_inst_non_mdu_rd_data_o : s1_older_rs2_execute)
         : _id_ex1_inst_op2_o),
    .mdu_op1_i         (s1_older_rs1_value),
    .mdu_op2_i         (s1_older_rs2_value),
    .control_op1_i
      ((|_id_ex1_inst_rs1_addr_o)
         ? (s1_current_rs1 & ~s1_current_is_fast_mul
              ? _ex0_inst_non_mdu_rd_data_o
              : s1_older_rs1_execute)
         : _id_ex1_inst_op1_o),
    .control_op2_i
      ((|_id_ex1_inst_rs2_addr_o)
         ? (s1_current_rs2 & ~s1_current_is_fast_mul
              ? _ex0_inst_non_mdu_rd_data_o
              : s1_older_rs2_execute)
         : _id_ex1_inst_op2_o),
    .control_base_i
      (_id_ex1_inst_is_jump_o & _id_ex1_inst_inst_o[6:0] == 7'h67
       & (s1_current_base_rs1 | s1_base_forwarded)
         ? (s1_current_base_rs1 ? _ex0_inst_non_mdu_rd_data_o : s1_older_rs1_execute)
         : _id_ex1_inst_base_addr_o),
    .rd_addr_i         (_id_ex1_inst_rd_addr_o),
    .reg_wen_i         (_id_ex1_inst_reg_wen_o),
    .base_addr_i
      (_retire1_nonmemory_T_2 & s1_base_forwarded
         ? s1_older_rs1_execute
         : _id_ex1_inst_base_addr_o),
    .addr_offset_i     (_id_ex1_inst_addr_offset_o),
    .alu_op_i          (_id_ex1_inst_alu_op_o),
    .is_mdu_i          (_id_ex1_inst_is_mdu_o),
    .mdu_op_i          (_id_ex1_inst_mdu_op_o),
    .illegal_i         (_id_ex1_inst_illegal_o),
    .is_branch_i       (_id_ex1_inst_is_branch_o),
    .is_load_i         (_id_ex1_inst_is_load_o),
    .is_store_i        (_id_ex1_inst_is_store_o),
    .is_jump_i         (_id_ex1_inst_is_jump_o),
    .mem_width_i       (_id_ex1_inst_mem_width_o),
    .pred_taken_i      (_id_ex1_inst_prdt_taken_o),
    .pred_target_i     (_id_ex1_inst_prdt_pc_addr_o),
    .rd_data_o         (_ex1_inst_rd_data_o),
    .rd_addr_o         (_ex1_inst_rd_addr_o),
    .rd_wen_o          (_ex1_inst_rd_wen_o),
    .redirect_o        (_ex1_inst_redirect_o),
    .redirect_pc_o     (_ex1_inst_redirect_pc_o),
    .control_valid_o   (_ex1_inst_control_valid_o),
    .branch_valid_o    (_ex1_inst_branch_valid_o),
    .actual_taken_o    (_ex1_inst_actual_taken_o),
    .resolved_target_o (_ex1_inst_resolved_target_o),
    .mem_valid_o       (_ex1_inst_mem_valid_o),
    .mem_write_o       (_ex1_inst_mem_write_o),
    .mem_addr_o        (_ex1_inst_mem_addr_o),
    .mem_wdata_o       (_ex1_inst_mem_wdata_o),
    .mem_mask_o        (_ex1_inst_mem_mask_o),
    .load_sel_o        (_ex1_inst_load_sel_o)
  );
  myCPU_soc_pma data_pma (
    .addr_i      (data_pma_select_lane1 ? _ex1_inst_mem_addr_o : _ex0_inst_mem_rd_addr),
    .size_i      (data_pma_select_lane1 ? _ex1_inst_mem_mask_o : _ex0_inst_mem_mask),
    .readable_o  (_data_pma_readable_o),
    .writable_o  (_data_pma_writable_o),
    .cacheable_o (_data_pma_cacheable_o)
  );
  store_buffer_3x32 store_buffer_addr_q_ext (
    .R0_addr (store_buffer_head),
    .R0_en   (1'h1),
    .R0_clk  (cpu_clk),
    .R0_data (_store_buffer_addr_q_ext_R0_data),
    .W0_addr (2'h2),
    .W0_en   (cpu_rst),
    .W0_clk  (cpu_clk),
    .W0_data (32'h0),
    .W1_addr (2'h1),
    .W1_en   (cpu_rst),
    .W1_clk  (cpu_clk),
    .W1_data (32'h0),
    .W2_addr (2'h0),
    .W2_en   (cpu_rst),
    .W2_clk  (cpu_clk),
    .W2_data (32'h0)
  );
  store_buffer_size_q_3x2 store_buffer_size_q_ext (
    .R0_addr (store_buffer_head),
    .R0_en   (1'h1),
    .R0_clk  (cpu_clk),
    .R0_data (_store_buffer_size_q_ext_R0_data),
    .W0_addr (2'h2),
    .W0_en   (cpu_rst),
    .W0_clk  (cpu_clk),
    .W0_data (2'h0),
    .W1_addr (2'h1),
    .W1_en   (cpu_rst),
    .W1_clk  (cpu_clk),
    .W1_data (2'h0),
    .W2_addr (2'h0),
    .W2_en   (cpu_rst),
    .W2_clk  (cpu_clk),
    .W2_data (2'h0)
  );
  store_buffer_3x32 store_buffer_data_q_ext (
    .R0_addr (store_buffer_head),
    .R0_en   (1'h1),
    .R0_clk  (cpu_clk),
    .R0_data (_store_buffer_data_q_ext_R0_data),
    .W0_addr (2'h2),
    .W0_en   (cpu_rst),
    .W0_clk  (cpu_clk),
    .W0_data (32'h0),
    .W1_addr (2'h1),
    .W1_en   (cpu_rst),
    .W1_clk  (cpu_clk),
    .W1_data (32'h0),
    .W2_addr (2'h0),
    .W2_en   (cpu_rst),
    .W2_clk  (cpu_clk),
    .W2_data (32'h0)
  );
  store_buffer_wstrb_q_3x4 store_buffer_wstrb_q_ext (
    .R0_addr (store_buffer_head),
    .R0_en   (1'h1),
    .R0_clk  (cpu_clk),
    .R0_data (_store_buffer_wstrb_q_ext_R0_data),
    .W0_addr (2'h0),
    .W0_en   (cpu_rst),
    .W0_clk  (cpu_clk),
    .W0_data (4'h0),
    .W1_addr (2'h2),
    .W1_en   (cpu_rst),
    .W1_clk  (cpu_clk),
    .W1_data (4'h0),
    .W2_addr (2'h1),
    .W2_en   (cpu_rst),
    .W2_clk  (cpu_clk),
    .W2_data (4'h0)
  );
  csr_unit csr_inst (
    .clk                 (cpu_clk),
    .rst                 (cpu_rst),
    .stall_i             (pipeline_stall),
    .csr_valid_i         (_csr_inst_csr_valid_i_T),
    .csr_op_i            (_id_ex0_inst_system_op_o),
    .csr_addr_i          (_id_ex0_inst_csr_addr_o),
    .csr_rs1_value_i     (ex0_op1),
    .csr_zimm_i          (_id_ex0_inst_csr_zimm_o),
    .csr_read_value_o    (_csr_inst_csr_read_value_o),
    .illegal_csr_o       (_csr_inst_illegal_csr_o),
    .trap_valid_i        (any_sync_trap | take_interrupt),
    .trap_cause_i
      (older_data_fault
         ? {30'h1, memory_owner_store_q, 1'h1}
         : lane0_exception_candidate
             ? (idex0_access_fault
                  ? 32'h1
                  : _GEN_2
                      ? 32'h2
                      : lane0_ebreak
                          ? 32'h3
                          : lane0_control_misaligned
                              ? 32'h0
                              : lane0_load_misaligned
                                  ? 32'h4
                                  : lane0_store_misaligned
                                      ? 32'h6
                                      : lane0_load_access_fault
                                          ? 32'h5
                                          : lane0_store_access_fault | fence_fault_pending
                                              ? 32'h7
                                              : lane0_ecall ? 32'hB : 32'h2)
             : lane1_sync_trap
                 ? (_id_ex1_inst_illegal_o
                      ? 32'h2
                      : lane1_control_misaligned
                          ? 32'h0
                          : lane1_load_misaligned
                              ? 32'h4
                              : lane1_store_misaligned
                                  ? 32'h6
                                  : lane1_load_access_fault
                                      ? 32'h5
                                      : lane1_store_access_fault ? 32'h7 : 32'h2)
                 : _csr_inst_interrupt_cause_o),
    .trap_pc_i
      (older_data_fault
         ? memory_owner_pc_q
         : lane0_exception_candidate | ~lane1_sync_trap
             ? _id_ex0_inst_inst_addr_o
             : _id_ex1_inst_inst_addr_o),
    .trap_tval_i
      (older_data_fault
         ? memory_owner_addr_q
         : lane0_exception_candidate
             ? (idex0_access_fault
                  ? _id_ex0_inst_inst_addr_o
                  : _GEN_2
                      ? _id_ex0_inst_inst_o
                      : lane0_ebreak
                          ? 32'h0
                          : lane0_control_misaligned
                              ? _ex0_inst_resolved_target_o
                              : lane0_load_misaligned | lane0_store_misaligned
                                | lane0_load_access_fault | lane0_store_access_fault
                                  ? _ex0_inst_mem_rd_addr
                                  : fence_fault_pending
                                      ? fence_fault_addr_q
                                      : lane0_ecall ? 32'h0 : _id_ex0_inst_inst_o)
             : lane1_sync_trap
                 ? (_id_ex1_inst_illegal_o
                      ? _id_ex1_inst_inst_o
                      : lane1_control_misaligned
                          ? _ex1_inst_resolved_target_o
                          : lane1_load_misaligned | lane1_store_misaligned
                            | lane1_load_access_fault | lane1_store_access_fault
                              ? _ex1_inst_mem_addr_o
                              : _id_ex1_inst_inst_o)
                 : 32'h0),
    .mret_valid_i
      (_csr_inst_csr_valid_i_T & _id_ex0_inst_system_op_o == 4'h9 & ~_ex0_inst_mdu_stall_o
       & ~dcache_response_wait & ~any_sync_trap & ~take_interrupt),
    .redirect_o          (_csr_inst_redirect_o),
    .redirect_pc_o       (_csr_inst_redirect_pc_o),
    .software_irq_i      (software_irq_i),
    .timer_irq_i         (timer_irq_i),
    .external_irq_i      (external_irq_i),
    .interrupt_request_o (_csr_inst_interrupt_request_o),
    .interrupt_cause_o   (_csr_inst_interrupt_cause_o),
    .instret_count_i
      ({1'h0,
        lane0_commit_live & ~pipeline_stall & ~_retire0_nonmemory_T_2
          & ~(_id_ex0_inst_is_system_o
              & (_retire0_nonmemory_T_5 | _retire0_nonmemory_T_6))}
       + {1'h0, ex1_commit_live & ~pipeline_stall & ~_retire1_nonmemory_T_2}
       + {1'h0, _dcache_inst_cpu_resp_valid_o & ~_dcache_inst_cpu_resp_error_o})
  );
  dcache_2way dcache_inst (
    .clk                 (cpu_clk),
    .rst                 (cpu_rst),
    .cpu_req_valid_i     (dcache_internal_req_valid),
    .cpu_req_ready_o     (_dcache_inst_cpu_req_ready_o),
    .cpu_req_owner_i     (dcache_cpu_req_owner),
    .cpu_req_addr_i      (dcache_cpu_req_addr),
    .cpu_req_vindex_i
      (dcache_req_held ? dcache_req_addr_q[10:4] : dcache_live_req_addr[10:4]),
    .cpu_req_write_i     (dcache_cpu_req_write),
    .cpu_req_size_i      (dcache_cpu_req_size),
    .cpu_req_wdata_i     (dcache_req_held ? dcache_req_wdata_q : dcache_live_req_wdata),
    .cpu_req_cacheable_i (dcache_cpu_req_cacheable),
    .cpu_resp_valid_o    (_dcache_inst_cpu_resp_valid_o),
    .cpu_resp_owner_o    (_dcache_inst_cpu_resp_owner_o),
    .cpu_resp_rdata_o    (_dcache_inst_cpu_resp_rdata_o),
    .cpu_resp_error_o    (_dcache_inst_cpu_resp_error_o),
    .busy_o              (_dcache_inst_busy_o),
    .fence_req_i         (dcache_fence_req),
    .fence_req_ready_o   (_dcache_inst_fence_req_ready_o),
    .fence_done_o        (_dcache_inst_fence_done_o),
    .fence_error_o       (_dcache_inst_fence_error_o),
    .fence_error_addr_o  (_dcache_inst_fence_error_addr_o),
    .mem_cmd_valid_o     (_dcache_inst_mem_cmd_valid_o),
    .mem_cmd_ready_i     (dmem_cmd_ready_i & ~(|store_buffer_count)),
    .mem_cmd_owner_o     (_dcache_inst_mem_cmd_owner_o),
    .mem_cmd_write_o     (_dcache_inst_mem_cmd_write_o),
    .mem_cmd_addr_o      (_dcache_inst_mem_cmd_addr_o),
    .mem_cmd_size_o      (_dcache_inst_mem_cmd_size_o),
    .mem_cmd_len_o       (_dcache_inst_mem_cmd_len_o),
    .mem_cmd_wdata_o     (_dcache_inst_mem_cmd_wdata_o),
    .mem_cmd_wstrb_o     (_dcache_inst_mem_cmd_wstrb_o),
    .mem_rsp_valid_i     (dmem_rsp_valid_i & dmem_rsp_owner_i != 2'h2),
    .mem_rsp_ready_o     (_dcache_inst_mem_rsp_ready_o),
    .mem_rsp_owner_i     (dmem_rsp_owner_i),
    .mem_rsp_rdata_i     (dmem_rsp_data_i),
    .mem_rsp_last_i      (dmem_rsp_last_i),
    .mem_rsp_error_i     (dmem_rsp_error_i)
  );
  ex_mem1 ex_mem0_inst (
    .clk           (cpu_clk),
    .rst           (cpu_rst),
    .stall_i       (dcache_stall),
    .mem_rd_req_i  (ex0_mem_valid_now & _ex0_inst_mem_rd_req),
    .mem_rd_addr_i (ex0_mem_valid_now ? _ex0_inst_mem_rd_addr : 32'h0),
    .reg_wen_i     (lane0_commit_live & _ex0_inst_rd_wen_o),
    .rd_addr_i     (_ex0_inst_rd_addr_o),
    .rd_data_i     (_ex0_inst_rd_data_o),
    .reg_wr_sel_i  (_ex0_inst_sel),
    .mem_rd_req_o  (_ex_mem0_inst_mem_rd_req_o),
    .mem_rd_addr_o (_ex_mem0_inst_mem_rd_addr_o),
    .reg_wen_o     (_ex_mem0_inst_reg_wen_o),
    .rd_addr_o     (_ex_mem0_inst_rd_addr_o),
    .rd_data_o     (_ex_mem0_inst_rd_data_o),
    .reg_wr_sel_o  (_ex_mem0_inst_reg_wr_sel_o)
  );
  ex_mem1 ex_mem1_inst (
    .clk           (cpu_clk),
    .rst           (cpu_rst),
    .stall_i       (dcache_stall),
    .mem_rd_req_i  (ex1_mem_commit_valid_now & _ex1_inst_mem_write_o),
    .mem_rd_addr_i (ex1_mem_commit_valid_now ? _ex1_inst_mem_addr_o : 32'h0),
    .reg_wen_i     (ex1_commit_live & _ex1_inst_rd_wen_o),
    .rd_addr_i     (_ex1_inst_rd_addr_o),
    .rd_data_i     (_ex1_inst_rd_data_o),
    .reg_wr_sel_i  (_ex1_inst_load_sel_o),
    .mem_rd_req_o  (_ex_mem1_inst_mem_rd_req_o),
    .mem_rd_addr_o (_ex_mem1_inst_mem_rd_addr_o),
    .reg_wen_o     (_ex_mem1_inst_reg_wen_o),
    .rd_addr_o     (_ex_mem1_inst_rd_addr_o),
    .rd_data_o     (_ex_mem1_inst_rd_data_o),
    .reg_wr_sel_o  (_ex_mem1_inst_reg_wr_sel_o)
  );
  mem1 mem0_inst (
    .clk           (cpu_clk),
    .rst           (cpu_rst),
    .stall_i       (dcache_mem_stage_stall),
    .sel           (_ex_mem0_inst_reg_wr_sel_o),
    .mem_rd_req_i  (_ex_mem0_inst_mem_rd_req_o),
    .mem_rd_addr_i (_ex_mem0_inst_mem_rd_addr_o),
    .reg_wen_i     (mem0_stage_wen),
    .rd_addr_i     (_ex_mem0_inst_rd_addr_o),
    .rd_data_i     (_ex_mem0_inst_rd_data_o),
    .mem_rd_data_i (_dcache_inst_cpu_resp_rdata_o),
    .reg_wen_o     (_mem0_inst_reg_wen_o),
    .rd_addr_o     (_mem0_inst_rd_addr_o),
    .rd_data_o     (_mem0_inst_rd_data_o)
  );
  mem1 mem1_inst (
    .clk           (cpu_clk),
    .rst           (cpu_rst),
    .stall_i       (dcache_mem_stage_stall),
    .sel           (_ex_mem1_inst_reg_wr_sel_o),
    .mem_rd_req_i  (_ex_mem1_inst_mem_rd_req_o),
    .mem_rd_addr_i (_ex_mem1_inst_mem_rd_addr_o),
    .reg_wen_i     (mem1_stage_wen),
    .rd_addr_i     (_ex_mem1_inst_rd_addr_o),
    .rd_data_i     (_ex_mem1_inst_rd_data_o),
    .mem_rd_data_i (_dcache_inst_cpu_resp_rdata_o),
    .reg_wen_o     (_mem1_inst_reg_wen_o),
    .rd_addr_o     (_mem1_inst_rd_addr_o),
    .rd_data_o     (_mem1_inst_rd_data_o)
  );
  mem1_wb memwb0_inst (
    .clk       (cpu_clk),
    .rst       (cpu_rst),
    .reg_wen_i (_mem0_inst_reg_wen_o),
    .rd_addr_i (_mem0_inst_rd_addr_o),
    .rd_data_i (_mem0_inst_rd_data_o),
    .reg_wen_o (_memwb0_inst_reg_wen_o),
    .rd_addr_o (_memwb0_inst_rd_addr_o),
    .rd_data_o (_memwb0_inst_rd_data_o)
  );
  mem1_wb memwb1_inst (
    .clk       (cpu_clk),
    .rst       (cpu_rst),
    .reg_wen_i (_mem1_inst_reg_wen_o),
    .rd_addr_i (_mem1_inst_rd_addr_o),
    .rd_data_i (_mem1_inst_rd_data_o),
    .reg_wen_o (_memwb1_inst_reg_wen_o),
    .rd_addr_o (_memwb1_inst_rd_addr_o),
    .rd_data_o (_memwb1_inst_rd_data_o)
  );
  wb wb0_inst (
    .reg_wen_i (_memwb0_inst_reg_wen_o),
    .rd_addr_i (_memwb0_inst_rd_addr_o),
    .rd_data_i (_memwb0_inst_rd_data_o),
    .reg_wen_o (_wb0_inst_reg_wen_o),
    .rd_addr_o (_wb0_inst_rd_addr_o),
    .rd_data_o (_wb0_inst_rd_data_o)
  );
  wb wb1_inst (
    .reg_wen_i (_memwb1_inst_reg_wen_o),
    .rd_addr_i (_memwb1_inst_rd_addr_o),
    .rd_data_i (_memwb1_inst_rd_data_o),
    .reg_wen_o (_wb1_inst_reg_wen_o),
    .rd_addr_o (_wb1_inst_rd_addr_o),
    .rd_data_o (_wb1_inst_rd_data_o)
  );
  myCPU_soc_pma accepted_request_pma (
    .addr_i      (dcache_cpu_req_addr),
    .size_i      (dcache_cpu_req_size),
    .readable_o  (_accepted_request_pma_readable_o),
    .writable_o  (_accepted_request_pma_writable_o),
    .cacheable_o (_accepted_request_pma_cacheable_o)
  );
  assign dmem_cmd_valid_o = adapter_cmd_valid;
  assign dmem_cmd_owner_o = adapter_cmd_owner;
  assign dmem_cmd_write_o = (|store_buffer_count) | _dcache_inst_mem_cmd_write_o;
  assign dmem_cmd_addr_o =
    (|store_buffer_count)
      ? _store_buffer_addr_q_ext_R0_data
      : _dcache_inst_mem_cmd_addr_o;
  assign dmem_cmd_size_o =
    (|store_buffer_count)
      ? _store_buffer_size_q_ext_R0_data
      : _dcache_inst_mem_cmd_size_o;
  assign dmem_cmd_len_o = (|store_buffer_count) ? 3'h0 : _dcache_inst_mem_cmd_len_o;
  assign dmem_cmd_wdata_o =
    (|store_buffer_count)
      ? {96'h0, _store_buffer_data_q_ext_R0_data}
      : _dcache_inst_mem_cmd_wdata_o;
  assign dmem_cmd_wstrb_o =
    (|store_buffer_count)
      ? {12'h0, _store_buffer_wstrb_q_ext_R0_data}
      : _dcache_inst_mem_cmd_wstrb_o;
  assign dmem_rsp_ready_o = adapter_rsp_ready;
endmodule

module cache_bus_axi_adapter(
  input          clk,
                 rst,
                 cmd_valid_i,
  output         cmd_ready_o,
  input  [2:0]   cmd_owner_i,
  input          cmd_write_i,
  input  [31:0]  cmd_addr_i,
  input  [1:0]   cmd_size_i,
  input  [2:0]   cmd_len_i,
  input  [127:0] cmd_wdata_i,
  input  [15:0]  cmd_wstrb_i,
  output         rsp_valid_o,
  input          rsp_ready_i,
  output [2:0]   rsp_owner_o,
  output [31:0]  rsp_rdata_o,
  output         rsp_last_o,
                 rsp_error_o,
                 busy_o,
  output [31:0]  m_axi_araddr,
  output [7:0]   m_axi_arlen,
  output [2:0]   m_axi_arsize,
  output         m_axi_arvalid,
  input          m_axi_arready,
  input  [31:0]  m_axi_rdata,
  input  [1:0]   m_axi_rresp,
  input          m_axi_rlast,
                 m_axi_rvalid,
  output         m_axi_rready,
  output [31:0]  m_axi_awaddr,
  output [7:0]   m_axi_awlen,
  output [2:0]   m_axi_awsize,
  output         m_axi_awvalid,
  input          m_axi_awready,
  output [31:0]  m_axi_wdata,
  output [3:0]   m_axi_wstrb,
  output         m_axi_wlast,
                 m_axi_wvalid,
  input          m_axi_wready,
  input  [1:0]   m_axi_bresp,
  input          m_axi_bvalid,
  output         m_axi_bready
);

  reg  [2:0]   state_q;
  reg  [2:0]   owner_q;
  reg  [31:0]  addr_q;
  reg  [1:0]   size_q;
  reg  [2:0]   len_q;
  reg  [2:0]   beat_q;
  reg  [127:0] wdata_q;
  reg  [15:0]  wstrb_q;
  reg          rsp_valid_q;
  reg  [31:0]  rsp_data_q;
  reg          rsp_last_q;
  reg          rsp_error_q;
  wire [7:0]   _m_axi_awlen_output = {5'h0, len_q};
  wire [2:0]   _m_axi_awsize_output = {1'h0, size_q};
  wire         _m_axi_arvalid_output = state_q == 3'h1;
  wire         _m_axi_rready_output = state_q == 3'h2 & ~rsp_valid_q;
  wire         _m_axi_awvalid_output = state_q == 3'h3;
  wire         _m_axi_wlast_output = beat_q == len_q;
  wire         _m_axi_wvalid_output = state_q == 3'h4;
  wire         _rspCaptureData_T = state_q == 3'h5;
  wire         _m_axi_bready_output = _rspCaptureData_T & ~rsp_valid_q;
  wire [31:0]  _m_axi_wdata_output =
    (|(beat_q[1:0]))
      ? (beat_q[1:0] == 2'h1
           ? wdata_q[63:32]
           : beat_q[1:0] == 2'h2 ? wdata_q[95:64] : wdata_q[127:96])
      : wdata_q[31:0];
  wire [3:0]   _m_axi_wstrb_output =
    (|(beat_q[1:0]))
      ? (beat_q[1:0] == 2'h1
           ? wstrb_q[7:4]
           : beat_q[1:0] == 2'h2 ? wstrb_q[11:8] : wstrb_q[15:12])
      : wstrb_q[3:0];
  reg          heldArQ;
  reg  [31:0]  heldArAddrQ;
  reg  [7:0]   heldArLenQ;
  reg  [2:0]   heldArSizeQ;
  reg          heldAwQ;
  reg  [31:0]  heldAwAddrQ;
  reg  [7:0]   heldAwLenQ;
  reg  [2:0]   heldAwSizeQ;
  reg          heldWQ;
  reg  [31:0]  heldWDataQ;
  reg  [3:0]   heldWStrobeQ;
  reg          heldWLastQ;
  wire         _GEN = m_axi_rvalid & _m_axi_rready_output;
  wire         _GEN_0 = rsp_valid_q & rsp_ready_i;
  wire         _GEN_1 = ~_GEN_0 & rsp_valid_q;
  wire         _GEN_2 = state_q == 3'h1;
  wire         _GEN_3 = state_q == 3'h2;
  wire         _GEN_4 = state_q == 3'h3;
  wire         _GEN_5 = state_q == 3'h4;
  wire         _GEN_6 = state_q == 3'h5;
  wire         _GEN_7 = _GEN_6 & m_axi_bvalid & _m_axi_bready_output;
  wire         _GEN_8 = _GEN_4 | _GEN_5;
  wire         _GEN_9 = ~_GEN_8 & _GEN_7;
  wire         _GEN_10 = _GEN_8 | ~_GEN_7;
  always @(posedge clk) begin
    if (rst) begin
      state_q <= 3'h0;
      owner_q <= 3'h0;
      addr_q <= 32'h0;
      size_q <= 2'h0;
      len_q <= 3'h0;
      beat_q <= 3'h0;
      wdata_q <= 128'h0;
      wstrb_q <= 16'h0;
      rsp_valid_q <= 1'h0;
      rsp_data_q <= 32'h0;
      rsp_last_q <= 1'h0;
      rsp_error_q <= 1'h0;
      heldArQ <= 1'h0;
      heldAwQ <= 1'h0;
      heldWQ <= 1'h0;
    end
    else begin
      if (|state_q) begin
        if (_GEN_2) begin
          if (m_axi_arready)
            state_q <= 3'h2;
        end
        else if (_GEN_3) begin
          if (_GEN_0 & rsp_last_q)
            state_q <= 3'h0;
        end
        else if (_GEN_4) begin
          if (m_axi_awready)
            state_q <= 3'h4;
        end
        else if (_GEN_5) begin
          if (m_axi_wready & _m_axi_wlast_output)
            state_q <= 3'h5;
        end
        else if (_GEN_6 & _GEN_0)
          state_q <= 3'h0;
        if (_GEN_2 | _GEN_3 | _GEN_4 | ~(_GEN_5 & m_axi_wready)) begin
        end
        else if (_m_axi_wlast_output)
          beat_q <= 3'h0;
        else
          beat_q <= beat_q + 3'h1;
      end
      else if (cmd_valid_i) begin
        state_q <= {1'h0, cmd_write_i, 1'h1};
        beat_q <= 3'h0;
      end
      if (~(|state_q) & cmd_valid_i) begin
        owner_q <= cmd_owner_i;
        addr_q <= cmd_addr_i;
        size_q <= cmd_size_i;
        len_q <= cmd_len_i;
        wdata_q <= cmd_wdata_i;
        wstrb_q <= cmd_wstrb_i;
      end
      if (~(|state_q) | _GEN_2)
        rsp_valid_q <= _GEN_1;
      else if (_GEN_3) begin
        rsp_valid_q <= _GEN | _GEN_1;
        if (_GEN) begin
          rsp_data_q <=
            _rspCaptureData_T
              ? 32'h0
              : size_q == 2'h0
                  ? {24'h0,
                     {8{addr_q[1:0] == 2'h0}} & m_axi_rdata[7:0]
                       | {8{addr_q[1:0] == 2'h1}} & m_axi_rdata[15:8]
                       | {8{addr_q[1:0] == 2'h2}} & m_axi_rdata[23:16]
                       | {8{&(addr_q[1:0])}} & m_axi_rdata[31:24]}
                  : size_q == 2'h1
                      ? {16'h0, addr_q[1] ? m_axi_rdata[31:16] : m_axi_rdata[15:0]}
                      : m_axi_rdata;
          rsp_last_q <= m_axi_rlast;
          rsp_error_q <= |m_axi_rresp;
        end
      end
      else begin
        rsp_valid_q <= _GEN_9 | _GEN_1;
        if (_GEN_10) begin
        end
        else
          rsp_data_q <= 32'h0;
        rsp_last_q <= _GEN_9 | rsp_last_q;
        if (_GEN_10) begin
        end
        else
          rsp_error_q <= |m_axi_bresp;
      end
      heldArQ <= _m_axi_arvalid_output & ~m_axi_arready;
      heldAwQ <= _m_axi_awvalid_output & ~m_axi_awready;
      heldWQ <= _m_axi_wvalid_output & ~m_axi_wready;
    end
    heldArAddrQ <= addr_q;
    heldArLenQ <= _m_axi_awlen_output;
    heldArSizeQ <= _m_axi_awsize_output;
    heldAwAddrQ <= addr_q;
    heldAwLenQ <= _m_axi_awlen_output;
    heldAwSizeQ <= _m_axi_awsize_output;
    heldWDataQ <= _m_axi_wdata_output;
    heldWStrobeQ <= _m_axi_wstrb_output;
    heldWLastQ <= _m_axi_wlast_output;
  end
  assign cmd_ready_o = ~(|state_q);
  assign rsp_valid_o = rsp_valid_q;
  assign rsp_owner_o = owner_q;
  assign rsp_rdata_o = rsp_data_q;
  assign rsp_last_o = rsp_last_q;
  assign rsp_error_o = rsp_error_q;
  assign busy_o = |state_q;
  assign m_axi_araddr = addr_q;
  assign m_axi_arlen = _m_axi_awlen_output;
  assign m_axi_arsize = _m_axi_awsize_output;
  assign m_axi_arvalid = _m_axi_arvalid_output;
  assign m_axi_rready = _m_axi_rready_output;
  assign m_axi_awaddr = addr_q;
  assign m_axi_awlen = _m_axi_awlen_output;
  assign m_axi_awsize = _m_axi_awsize_output;
  assign m_axi_awvalid = _m_axi_awvalid_output;
  assign m_axi_wdata = _m_axi_wdata_output;
  assign m_axi_wstrb = _m_axi_wstrb_output;
  assign m_axi_wlast = _m_axi_wlast_output;
  assign m_axi_wvalid = _m_axi_wvalid_output;
  assign m_axi_bready = _m_axi_bready_output;
endmodule

module core_top(
  input         aclk,
                aresetn,
                software_irq_i,
                timer_irq_i,
                external_irq_i,
  output [3:0]  arid,
  output [31:0] araddr,
  output [7:0]  arlen,
  output [2:0]  arsize,
  output [1:0]  arburst,
                arlock,
  output [3:0]  arcache,
  output [2:0]  arprot,
  output        arvalid,
  input         arready,
  input  [3:0]  rid,
  input  [31:0] rdata,
  input  [1:0]  rresp,
  input         rlast,
                rvalid,
  output        rready,
  output [3:0]  awid,
  output [31:0] awaddr,
  output [7:0]  awlen,
  output [2:0]  awsize,
  output [1:0]  awburst,
                awlock,
  output [3:0]  awcache,
  output [2:0]  awprot,
  output        awvalid,
  input         awready,
  output [3:0]  wid,
  output [31:0] wdata,
  output [3:0]  wstrb,
  output        wlast,
                wvalid,
  input         wready,
  input  [3:0]  bid,
  input  [1:0]  bresp,
  input         bvalid,
  output        bready
);

  wire         _axi_cmd_ready_o;
  wire         _axi_rsp_valid_o;
  wire [2:0]   _axi_rsp_owner_o;
  wire [31:0]  _axi_rsp_rdata_o;
  wire         _axi_rsp_last_o;
  wire         _axi_rsp_error_o;
  wire         _axi_busy_o;
  wire         _core_imem_cmd_valid_o;
  wire [31:0]  _core_imem_cmd_addr_o;
  wire         _core_imem_rsp_ready_o;
  wire         _core_dmem_cmd_valid_o;
  wire [1:0]   _core_dmem_cmd_owner_o;
  wire         _core_dmem_cmd_write_o;
  wire [31:0]  _core_dmem_cmd_addr_o;
  wire [1:0]   _core_dmem_cmd_size_o;
  wire [2:0]   _core_dmem_cmd_len_o;
  wire [127:0] _core_dmem_cmd_wdata_o;
  wire [15:0]  _core_dmem_cmd_wstrb_o;
  wire         _core_dmem_rsp_ready_o;
  reg          preferD;
  wire         grantD = _core_dmem_cmd_valid_o & (~_core_imem_cmd_valid_o | preferD);
  wire         grantI = _core_imem_cmd_valid_o & ~grantD;
  wire         busCmdValid = grantI | grantD;
  wire [2:0]   busCmdOwner = grantD ? {1'h1, _core_dmem_cmd_owner_o} : 3'h0;
  wire         commandFire = busCmdValid & _axi_cmd_ready_o;
  wire         busRspReady =
    _axi_rsp_owner_o[2] ? _core_dmem_rsp_ready_o : _core_imem_rsp_ready_o;
  reg          ownerLive;
  reg  [2:0]   owner;
  wire         finalResponseFire = _axi_rsp_valid_o & busRspReady & _axi_rsp_last_o;
  always @(posedge aclk) begin
    if (~aresetn) begin
      preferD <= 1'h1;
      ownerLive <= 1'h0;
      owner <= 3'h0;
    end
    else begin
      if (commandFire) begin
        preferD <= grantI;
        owner <= busCmdOwner;
      end
      ownerLive <= ~finalResponseFire & (commandFire | ownerLive);
    end
  end
  myCPU_soc core (
    .cpu_clk          (aclk),
    .cpu_rst          (~aresetn),
    .software_irq_i   (software_irq_i),
    .timer_irq_i      (timer_irq_i),
    .external_irq_i   (external_irq_i),
    .imem_cmd_valid_o (_core_imem_cmd_valid_o),
    .imem_cmd_ready_i (_axi_cmd_ready_o & grantI),
    .imem_cmd_addr_o  (_core_imem_cmd_addr_o),
    .imem_rsp_valid_i (_axi_rsp_valid_o & ~(_axi_rsp_owner_o[2])),
    .imem_rsp_ready_o (_core_imem_rsp_ready_o),
    .imem_rsp_data_i  (_axi_rsp_rdata_o),
    .imem_rsp_last_i  (_axi_rsp_last_o),
    .imem_rsp_error_i (_axi_rsp_error_o),
    .dmem_cmd_valid_o (_core_dmem_cmd_valid_o),
    .dmem_cmd_ready_i (_axi_cmd_ready_o & grantD),
    .dmem_cmd_owner_o (_core_dmem_cmd_owner_o),
    .dmem_cmd_write_o (_core_dmem_cmd_write_o),
    .dmem_cmd_addr_o  (_core_dmem_cmd_addr_o),
    .dmem_cmd_size_o  (_core_dmem_cmd_size_o),
    .dmem_cmd_len_o   (_core_dmem_cmd_len_o),
    .dmem_cmd_wdata_o (_core_dmem_cmd_wdata_o),
    .dmem_cmd_wstrb_o (_core_dmem_cmd_wstrb_o),
    .dmem_rsp_valid_i (_axi_rsp_valid_o & _axi_rsp_owner_o[2]),
    .dmem_rsp_ready_o (_core_dmem_rsp_ready_o),
    .dmem_rsp_owner_i (_axi_rsp_owner_o[1:0]),
    .dmem_rsp_data_i  (_axi_rsp_rdata_o),
    .dmem_rsp_last_i  (_axi_rsp_last_o),
    .dmem_rsp_error_i (_axi_rsp_error_o)
  );
  cache_bus_axi_adapter axi (
    .clk           (aclk),
    .rst           (~aresetn),
    .cmd_valid_i   (busCmdValid),
    .cmd_ready_o   (_axi_cmd_ready_o),
    .cmd_owner_i   (busCmdOwner),
    .cmd_write_i   (grantD & _core_dmem_cmd_write_o),
    .cmd_addr_i    (grantD ? _core_dmem_cmd_addr_o : _core_imem_cmd_addr_o),
    .cmd_size_i    (grantD ? _core_dmem_cmd_size_o : 2'h2),
    .cmd_len_i     (grantD ? _core_dmem_cmd_len_o : 3'h3),
    .cmd_wdata_i   (grantD ? _core_dmem_cmd_wdata_o : 128'h0),
    .cmd_wstrb_i   (grantD ? _core_dmem_cmd_wstrb_o : 16'h0),
    .rsp_valid_o   (_axi_rsp_valid_o),
    .rsp_ready_i   (busRspReady),
    .rsp_owner_o   (_axi_rsp_owner_o),
    .rsp_rdata_o   (_axi_rsp_rdata_o),
    .rsp_last_o    (_axi_rsp_last_o),
    .rsp_error_o   (_axi_rsp_error_o),
    .busy_o        (_axi_busy_o),
    .m_axi_araddr  (araddr),
    .m_axi_arlen   (arlen),
    .m_axi_arsize  (arsize),
    .m_axi_arvalid (arvalid),
    .m_axi_arready (arready),
    .m_axi_rdata   (rdata),
    .m_axi_rresp   (rresp),
    .m_axi_rlast   (rlast),
    .m_axi_rvalid  (rvalid),
    .m_axi_rready  (rready),
    .m_axi_awaddr  (awaddr),
    .m_axi_awlen   (awlen),
    .m_axi_awsize  (awsize),
    .m_axi_awvalid (awvalid),
    .m_axi_awready (awready),
    .m_axi_wdata   (wdata),
    .m_axi_wstrb   (wstrb),
    .m_axi_wlast   (wlast),
    .m_axi_wvalid  (wvalid),
    .m_axi_wready  (wready),
    .m_axi_bresp   (bresp),
    .m_axi_bvalid  (bvalid),
    .m_axi_bready  (bready)
  );
  assign arid = 4'h0;
  assign arburst = 2'h1;
  assign arlock = 2'h0;
  assign arcache = 4'h3;
  assign arprot = 3'h0;
  assign awid = 4'h0;
  assign awburst = 2'h1;
  assign awlock = 2'h0;
  assign awcache = 4'h3;
  assign awprot = 3'h0;
  assign wid = 4'h0;
endmodule
