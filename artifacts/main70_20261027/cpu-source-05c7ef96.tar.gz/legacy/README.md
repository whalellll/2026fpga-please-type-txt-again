# 历史资料

这里保留 V15 之前的 `core_top.sv`、`coremark_soc_top.sbit` 与原 `doc/` 文档，文件内容未改动。

`coremark_soc_top.sbit` 是 V15 之前旧版 SoC 的比特流，与当前 V15 RTL 无对应关系，不能用于验证 V15。

当前可复现工程在 [`../cpu/`](../cpu/README.md)，请使用该目录的源码、生成 RTL、固定固件和验证入口。
