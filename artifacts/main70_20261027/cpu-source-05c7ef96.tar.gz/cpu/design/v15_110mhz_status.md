V15 优化记录（2026-09-26）
=========================

目标：CPU 核低于 20,000 LUT，110 MHz 约束下时序为正，CoreMark 校准性能不下降。
用户要求保持 RV32IMAC、至少三级流水线、两路组相联 I/D Cache、动态分支预测、异常/中断与 DMA；不接入加速器本体。不使用 skill，不修改旧版本。

GitHub整理说明（2026-09-27）：本分支保留当前候选完整源码、两份RTL与 `evidence/v15/` 报告；下表是原机历史记录，所有历史候选源码目录没有上传。原路径/哈希记录用于追溯，不是新电脑必须存在的目录。

下表的 LUT 是 PDS 层次报告中 `core` 的 LUT，WNS 是 9.0909 ns 约束下报告中的 CPU 核内部寄存器路径。它们是综合估算，不能作为布局布线签核。完整 DMA SoC 顶层约 24k LUT，不能称为整个 SoC 已低于 20k。

| 候选（work/candidates 下目录） | CPU LUT | CPU 核内部 WNS/ns | 本轮精确 RTL 验证 |
| --- | ---: | ---: | --- |
| mepc-direct | 19,588 | -0.098 | 历史基线 |
| pf-parallel-adders | 19,624 | -0.303 | 已回退；本轮性能测试输入曾为旧导出 |
| rsm-early-priority | 19,651 | -0.082 | RsMem 定向测试通过；本轮性能测试输入曾为旧导出 |
| rsm-instret-low3 | 19,506 | -0.191 | CSR 定向测试通过；本轮性能测试输入曾为旧导出 |
| rsm-low3-cache-masks | 19,637 | -0.123 | 正确仿真导出：CoreMark、全部架构回归、前端 6 项通过 |
| rsm-low3-cache-cycle-parallel | 19,627 | -0.112 | 正确仿真导出：CoreMark、全部架构回归、CSR 8 项通过 |
| rsm-low3-cache-cycle-alu-push | 19,637 | -0.212 | 正确仿真导出：CoreMark、全部架构回归、ALU 容量测试通过 |
| rsm-early-alu-push | 19,494 | -0.509 | 正确仿真导出：CoreMark、全部架构回归、RV32C 执行及异常测试通过 |
| parallel-rvc-boundaries | 19,619 | -0.138 | 正确仿真导出：CoreMark、全部架构回归、前端 6 项、RV32C 执行及异常测试通过 |
| parallel-boundaries-mtval-direct | 19,688 | -0.183 | 正确仿真导出：CoreMark、全部架构回归、CSR 8 项、RV32C 异常测试通过 |
| parallel-boundaries-mtval-raw-atomic | 19,654 | -0.180 | 当前源码；正确仿真导出：CoreMark、全部架构回归；迁移入口定向14项、RV32C执行及异常通过 |

目前没有达到正 WNS，尚未进入“保存通过版后压 LUT”的阶段。

改动与验证
----------

保留的改动包括 LSU 加载字节掩码寄存、机器 mepc 写入单独处理、周期/退休计数器进位分段。最近尝试了访存保留站早期命中优先级简化、ICache 并行数据选择、周期计数器并行选择、ALU 操作数寄存器直接写入授权。各候选保存源码、综合 RTL、报告；完成精确验证的候选另保存仿真 RTL、输入哈希、CoreMark 结果与架构回归日志。

完成精确性能验证的近期候选 CoreMark 校准值均为 5.030317724928142/MHz，10 次迭代使用 1,987,946 周期，CRC 为 e714/1fd7/8e3a/fcaf。这是 RTL 仿真校准，不是满足 10 秒规则的正式 CoreMark 或板测成绩。

迁移接手：先阅读 `handoff/NEW_COMPUTER_GUIDE.md` 与 `handoff/CODEX_HANDOVER.md`，用 `scripts/newpc.ps1` 检查环境和重新导出 RTL。当前源码是 parallel-boundaries-mtval-raw-atomic，不是表中最快的 rsm-early-priority；最快候选的部分本轮仿真输入曾为旧导出，恢复它时必须重新做精确验证。

验证输入问题已纠正：旧入口默认读取 `work/v1-probes/CoreTop.sv`，不能假定它对应最近生成的 `generated/core/CoreTop.sv`。仿真必须从当前源码重新导出，并启用现有 `e91c.socProbes=true` 观察选项，供测试台读取内部探针。综合导出保持不启用该选项。

`run_coremark_ab.sh` 现支持 `CORE_TEST_SV` 显式指定 RTL；`run_v1_checks.sh` 同样显式使用该变量并记录 `rtl-input.sha256`。不要在运行中的 Bash 入口脚本上编辑，以免脚本读取位置错乱。

从当前源码生成仿真导出的命令（使用 toolchain.local.json 中的 Java 与 SbtLauncher）：

```
java -De91c.socProbes=true -jar sbt-launch.jar "runMain e91c.core.EmitCore work/v15-verify"
```

运行 CoreMark 与架构回归时，将 `CORE_TEST_SV` 指向上述导出的绝对 WSL 路径。精确验证候选的具体路径与哈希见各候选目录。

签核限制
--------

现有完整顶层有 733 个 I/O，目标器件封装仅有 300 个 I/O（PDS 报告给出的利用率为 244.33%）。当前脚本只运行 synthesize，没有完成板级引脚约束、布局布线与全时钟域签核。因此，即使 CPU 核综合 WNS 转正，也不能称为整个 SoC 在 110 MHz 已物理闭合。

## 2026-09-27 仓库结构整理

整理分支 cpu-v15-reorg-20260927 只移动历史文件、去除重复副本、同步清单和文档；当前源码与 RTL 候选不变。原始综合报告/哈希仍在 evidence/v15/；运行证据统一在 handoff/validation/。固定 RV32IM 固件的分数不代表带压缩指令的 CoreMark 分数。新增复现结果以 handoff/VALIDATION.md 和实际日志为准，不能用历史证据替代。
