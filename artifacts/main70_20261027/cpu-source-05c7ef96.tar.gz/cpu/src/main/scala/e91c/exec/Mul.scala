// ============================================================
// e91c.exec.Mul — cpu/mul.v 的 Chisel 移植（RV32M 32x32 乘法器）
// ------------------------------------------------------------
// 四个并行半字部分积在输入侧编码符号，统一覆盖
// MUL/MULH/MULHSU/MULHU；结果仍在启动后一拍有效、吞吐为一。
// ============================================================
package e91c.exec

import chisel3._
import chisel3.util.{Cat, Fill}

class Mul extends Module {
  val io = IO(new Bundle {
    val valid    = Input(Bool())   // 启动（fu_mdu 保证 busy 期间不重复启动）
    val a        = Input(UInt(32.W))
    val b        = Input(UInt(32.W))
    val signedA  = Input(Bool())
    val signedB  = Input(Bool())
    val result   = Output(UInt(64.W))  // 64 位全乘积
    val done     = Output(Bool())      // 启动后下一拍有效
  })

  // A = lowA + (signed highA << 16), and likewise for B. Dynamic
  // signedness is encoded in a seventeenth input bit, so each product still
  // fits one 18x18 APM. Signed cross terms need 33 bits; only the low 32 bits
  // of the high/high term contribute to the modulo-2^64 result. This removes
  // the separate correction register and post-product 32-bit subtraction.
  val prod00Reg = Reg(UInt(32.W))
  val prod01Reg = Reg(UInt(33.W))
  val prod10Reg = Reg(UInt(33.W))
  val prod11Reg = Reg(UInt(32.W))
  val validReg = RegInit(false.B)

  val lowA = Cat(0.U(1.W), io.a(15, 0)).asSInt
  val lowB = Cat(0.U(1.W), io.b(15, 0)).asSInt
  val highA = Cat(io.signedA && io.a(31), io.a(31, 16)).asSInt
  val highB = Cat(io.signedB && io.b(31), io.b(31, 16)).asSInt

  validReg := io.valid
  when(io.valid) {
    prod00Reg := io.a(15, 0) * io.b(15, 0)
    prod01Reg := (lowA * highB).asUInt
    prod10Reg := (highA * lowB).asUInt
    prod11Reg := (highA * highB).asUInt
  }

  val term00 = prod00Reg.pad(64)
  val term01 = Cat(Fill(15, prod01Reg(32)), prod01Reg, 0.U(16.W))
  val term10 = Cat(Fill(15, prod10Reg(32)), prod10Reg, 0.U(16.W))
  val term11 = Cat(prod11Reg, 0.U(32.W))
  io.result := term00 + term01 + term10 + term11
  io.done   := validReg

  // 原实现带 (* use_dsp = "yes" ) 属性提示综合工具用 DSP 资源；
  // Chisel 6 无 addAttribute 自由函数，综合属性在生成 Verilog 后
  // 由脚本统一回注（33x33 乘法综合器默认也会选 DSP）。
}
