package e91c

import chisel3._
import chiseltest._
import e91c.exec.{Mul, MulGui1080Reference}
import org.scalatest.flatspec.AnyFlatSpec

class MulGui1080Compare extends Module {
  val candidate = Module(new Mul)
  val reference = Module(new MulGui1080Reference)
  val io = IO(chiselTypeOf(candidate.io))
  val allEqual = IO(Output(Bool()))
  for (m <- Seq(candidate.io, reference.io)) {
    m.valid := io.valid; m.a := io.a; m.b := io.b
    m.signedA := io.signedA; m.signedB := io.signedB
  }
  io.result := candidate.io.result; io.done := candidate.io.done
  allEqual := candidate.io.result === reference.io.result &&
    candidate.io.done === reference.io.done
}

class MulGui1080Spec extends AnyFlatSpec with ChiselScalatestTester {
  private val mask32 = (BigInt(1) << 32) - 1
  private val mask64 = (BigInt(1) << 64) - 1
  private def operand(x: BigInt, signed: Boolean): BigInt =
    if (signed && x.testBit(31)) x - (BigInt(1) << 32) else x

  private class Driver(d: MulGui1080Compare) {
    var result = BigInt(0)
    var done = false
    var cycles = 0
    var accepted = 0
    var resetCycles = 0
    d.io.valid.poke(false.B); d.io.a.poke(0.U); d.io.b.poke(0.U)
    d.io.signedA.poke(false.B); d.io.signedB.poke(false.B)
    d.reset.poke(true.B); d.clock.step(2); d.reset.poke(false.B)
    // Product registers have no reset. First capture defines all public data;
    // every subsequent held/invalid/reset cycle is compared without masking.
    d.io.valid.poke(true.B); d.clock.step(); done = true
    check()
    private def check(): Unit = {
      d.allEqual.expect(true.B)
      d.io.result.expect(result.U); d.io.done.expect(done.B)
    }
    def cycle(a: BigInt, b: BigInt, sa: Boolean, sb: Boolean,
              valid: Boolean, reset: Boolean = false): Unit = {
      d.io.a.poke((a & mask32).U); d.io.b.poke((b & mask32).U)
      d.io.signedA.poke(sa.B); d.io.signedB.poke(sb.B)
      d.io.valid.poke(valid.B); d.reset.poke(reset.B)
      check()
      d.clock.step()
      if (valid) {
        result = (operand(a & mask32, sa) * operand(b & mask32, sb)) & mask64
        accepted += 1
      }
      done = valid && !reset
      if (reset) resetCycles += 1
      cycles += 1
      check()
    }
  }

  behavior of "Signed halfword partial-product resource candidate"
  it should "preserve full products and one-cycle completion at signed halfword and carry boundaries" in {
    test(new MulGui1080Compare) { d =>
      val driver = new Driver(d)
      val values = Seq("00000000", "00000001", "00007fff", "00008000",
        "0000ffff", "00010000", "00010001", "7fff0000", "7fff7fff",
        "7fffffff", "80000000", "80000001", "80008000", "ffff0000",
        "ffff0001", "ffff7fff", "fffffffe", "ffffffff").map(BigInt(_, 16))
      for (a <- values; b <- values; flags <- 0 until 4) {
        driver.cycle(a, b, (flags & 1) != 0, (flags & 2) != 0, true)
        if (driver.accepted % 8 == 0)
          driver.cycle(b ^ mask32, a ^ mask32, false, true, false)
      }
      driver.cycle(mask32, mask32, true, false, true, reset = true)
      driver.cycle(1, 1, false, false, false)
      driver.cycle(mask32, mask32, false, true, true)
      println(s"MUL_SIGNED_BOUNDARY_PASS cycles=${driver.cycles} captures=${driver.accepted}")
    }
  }
  it should "match frozen outputs and an independent arithmetic oracle over mixed stalls and resets" in {
    test(new MulGui1080Compare) { d =>
      val driver = new Driver(d)
      val rng = new scala.util.Random(0x85c021L)
      for (i <- 0 until 8192) {
        val a = BigInt(32, rng); val b = BigInt(32, rng)
        driver.cycle(a, b, rng.nextBoolean(), rng.nextBoolean(),
          valid = (i % 11 < 8), reset = i % 257 == 0)
      }
      println(s"MUL_SIGNED_STREAM_PASS cycles=${driver.cycles} captures=${driver.accepted} resets=${driver.resetCycles}")
    }
  }
}
