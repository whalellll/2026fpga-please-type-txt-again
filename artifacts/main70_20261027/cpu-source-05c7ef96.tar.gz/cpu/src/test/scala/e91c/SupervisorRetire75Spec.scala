package e91c
import chisel3._
import chisel3.reflect.DataMirror
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class SupervisorRetire75Spec extends AnyFlatSpec with ChiselScalatestTester {
  "Supervisor retirement counter" should "preserve all byte carries, word writes, inhibition and trap-return priority at the same edge" in {
    test(new SupervisorCsrHead75Compare) { d =>
      val mask32=(BigInt(1)<<32)-1;val mask64=(BigInt(1)<<64)-1
      var expected=BigInt(0);var inhibited=false;var cycles=0
      def clear():Unit=d.io.elements.values.foreach {
        case b:Bool if DataMirror.directionOf(b)==ActualDirection.Input=>b.poke(false.B)
        case u:UInt if DataMirror.directionOf(u)==ActualDirection.Input=>u.poke(0.U)
        case _=>()
      }
      clear();d.reset.poke(true.B);d.clock.step(2);d.reset.poke(false.B)
      def tick(count:Int=0,address:Int=0,value:BigInt=0,write:Boolean=false,controls:Int=0):Unit={
        clear();d.io.retireCount.poke(count.U);d.io.csrNum.poke(address.U);d.io.csrWvalue.poke(value.U);d.io.csrWe.poke(write.B)
        val valid=(controls&8)!=0;val ex=(controls&4)!=0;val sret=(controls&2)!=0;val mret=(controls&1)!=0
        d.io.wbValid.poke(valid.B);d.io.wbEx.poke(ex.B);d.io.wbIsSret.poke(sret.B);d.io.wbIsMret.poke(mret.B)
        val old=expected
        expected=(old+(if(inhibited)0 else count))&mask64
        val allowed=write && !(valid && (ex||sret||mret))
        if(allowed && address==0xb02)expected=(old & (mask32<<32)) | (value&mask32)
        if(allowed && address==0xb82)expected=((value&mask32)<<32) | (old&mask32)
        if(allowed && address==0x320)inhibited=(value&4)!=0
        d.clock.step();cycles+=1
        d.io.csrRnum.poke(0xb02.U);d.io.csrRvalue.expect((expected&mask32).U)
        d.io.csrRnum.poke(0xb82.U);d.io.csrRvalue.expect((expected>>32).U)
      }
      val seeds=(for(bit<-Seq(3,8,16,24,32,40,48,56,64);delta<-Seq(1,3,7))yield ((BigInt(1)<<bit)-delta)&mask64) :+ BigInt("12345678fffffffe",16)
      for(seed<-seeds;count<-0 until 8){
        tick(address=0x320,value=4,write=true)
        tick(address=0xb02,value=seed&mask32,write=true);tick(address=0xb82,value=seed>>32,write=true)
        tick(address=0x320,value=0,write=true)
        tick(count=count);tick(count=count)
        tick(count=7,address=0xb02,value=0x1234,write=true)
        tick(count=7,address=0xb82,value=0x5678,write=true)
        for(controls<-0 until 16)tick(count=count,address=if((controls&1)==0)0xb02 else 0xb82,value=mask32,write=true,controls=controls)
        tick(count=count,address=0x320,value=4,write=true);tick(count=7)
      }
      println(s"SUPERVISOR_RETIRE75_SCOREBOARD_PASS cycles=$cycles seeds=${seeds.size} retire_counts=8 priority_combinations=16")
    }
  }
}
