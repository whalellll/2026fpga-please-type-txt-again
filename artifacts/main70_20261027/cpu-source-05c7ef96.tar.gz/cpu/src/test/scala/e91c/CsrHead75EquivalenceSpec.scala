package e91c

import chisel3._
import chisel3.reflect.DataMirror
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import e91c.backend._

class CommitCsrHead75Compare extends Module {
  val candidate = Module(new Commit)
  val reference = Module(new CommitReference75)
  val io = IO(chiselTypeOf(candidate.io))
  for ((name, port) <- io.elements) {
    if (DataMirror.directionOf(port) == ActualDirection.Input) {
      candidate.io.elements(name) := port; reference.io.elements(name) := port
    } else if (DataMirror.directionOf(port) == ActualDirection.Output) {
      port := candidate.io.elements(name)
      when(!reset.asBool) { assert(candidate.io.elements(name).asUInt === reference.io.elements(name).asUInt, "CPU75 commit output: " + name) }
    } else {
      // c/arf/rat vectors have a uniform direction, recursively connect them.
      if (name == "c") { candidate.io.elements(name) := port; reference.io.elements(name) := port }
      else { port := candidate.io.elements(name); when(!reset.asBool) { assert(candidate.io.elements(name).asUInt === reference.io.elements(name).asUInt, "CPU75 vector output: " + name) } }
    }
  }
}

class SupervisorCsrHead75Compare extends Module {
  val candidate = Module(new SupervisorCsr(true))
  val reference = Module(new SupervisorCsrReference75(true))
  val io = IO(chiselTypeOf(candidate.io))
  for ((name, port) <- io.elements) {
    if (DataMirror.directionOf(port) == ActualDirection.Input) {
      candidate.io.elements(name) := port; reference.io.elements(name) := port
    } else {
      port := candidate.io.elements(name)
      when(!reset.asBool) { assert(candidate.io.elements(name).asUInt === reference.io.elements(name).asUInt, "CPU75 CSR cycle output: " + name) }
    }
  }
}

class CsrHead75EquivalenceSpec extends AnyFlatSpec with ChiselScalatestTester {
  private def inputs(data: Data): Seq[Data] = data match {
    case r: Record => r.elements.values.toSeq.flatMap(inputs)
    case v: Vec[_] => v.toSeq.flatMap(inputs)
    case p if DataMirror.directionOf(p) == ActualDirection.Input => Seq(p)
    case _ => Seq.empty
  }
  private def randomize(ports: Seq[Data], random: scala.util.Random): Unit = ports.foreach {
    case b: Bool => b.poke(random.nextBoolean().B)
    case u: UInt => u.poke(BigInt(u.getWidth, random).U)
    case _ => ()
  }
  "CPU75 commit" should "match every output across independent and consistent exception metadata" in {
    test(new CommitCsrHead75Compare) { d =>
      val ports = inputs(d.io); val random = new scala.util.Random(0x7580c0L)
      randomize(ports,random); d.reset.poke(true.B); d.clock.step(2); d.reset.poke(false.B)
      for (cycle <- 0 until 16384) {
        randomize(ports,random)
        d.io.flushPending.poke((cycle % 31 == 0).B)
        d.io.replayValid.poke((cycle % 17 == 0).B)
        d.io.hasInt.poke((cycle % 11 == 0).B)
        for (lane <- 0 until 2) {
          val c = d.io.c(lane)
          c.valid.poke(((cycle >> lane) % 4 != 0).B)
          c.complete.poke(((cycle >> (lane+2)) % 4 != 0).B)
          c.privVec.poke((if(cycle%3==0) 1 << ((cycle/3+lane)%6) else if(cycle%3==1) 0 else random.nextInt(64)).U)
          c.excp.poke((if(cycle%4==0) random.nextInt(1024) else 0).U)
          if(cycle%2==0) {
            c.hasExcpFast.poke((c.excp.peek().litValue != 0).B)
            c.hasPrivFast.poke((c.privVec.peek().litValue != 0).B)
          }
          c.brTarget.poke((BigInt(30,random)<<2 | (if(cycle%7==0) 2 else 0)).U)
        }
        d.clock.step()
      }
      println("CPU75_COMMIT_FULL_OUTPUT_EQUIVALENCE_PASS cycles=16384")
    }
  }
  "CPU75 supervisor CSR" should "preserve state, priority and cycle counters for competing trap return and write controls" in {
    test(new SupervisorCsrHead75Compare) { d =>
      val ports=inputs(d.io); val random=new scala.util.Random(0x7580c5L)
      val addresses=Seq(0x100,0x104,0x105,0x106,0x140,0x141,0x142,0x143,0x144,0x180,
        0x300,0x302,0x303,0x304,0x305,0x306,0x320,0x340,0x341,0x342,0x343,0x344,0xb00,0xb80,0xb02,0xb82)
      ports.foreach { case b:Bool=>b.poke(false.B);case u:UInt=>u.poke(0.U);case _=>() }
      d.reset.poke(true.B);d.clock.step(2);d.reset.poke(false.B)
      for(cycle <- 0 until 16384) {
        if(cycle>0 && cycle%4096==0) { d.reset.poke(true.B);d.clock.step(2);d.reset.poke(false.B) }
        randomize(ports,random)
        val phase=cycle%64
        val address=addresses((cycle/64)%addresses.size)
        d.io.csrNum.poke(address.U)
        d.io.csrRnum.poke((if(phase<32) addresses(phase%addresses.size) else address).U)
        d.io.csrWe.poke((phase<32 || (phase&1)!=0).B)
        d.io.wbValid.poke((phase>=32 && (phase&16)!=0).B)
        d.io.wbEx.poke(((phase&8)!=0).B)
        d.io.wbIsSret.poke(((phase&4)!=0).B)
        d.io.wbIsMret.poke(((phase&2)!=0).B)
        if(phase==0) d.io.csrWvalue.poke("hffffffff".U)
        if(phase==1) d.io.csrWvalue.poke(0.U)
        if(phase==2) d.io.csrWvalue.poke("h000018aa".U)
        d.clock.step()
      }
      println("CPU75_CSR_FULL_CYCLE_EQUIVALENCE_PASS cycles=16384 resets=4 csr_addresses=26")
    }
  }
}
