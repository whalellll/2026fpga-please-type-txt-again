# CPU 性能开发测试 SoC

本目录服务于 CPU 主频、CoreMark 和小型外设实验。系统集成与 console/debug 验收在兄弟仓库 `performance_soc` 的 `linux` 分支进行；CPU 拷贝接口和范围见 [CPU 开发说明](../README.md) 的“送入集成仓库”。

- 当前入口：`rtl/coremark_soc_top.v`、`sim/tb_coremark_soc.v` 和 `pds/coremark_test_soc.pds`。顶层 module 名仍为 `coremark_soc_top`。
- 当前固件：`sim/coremark_ima`，纯 IMA/Zicsr/Zifencei、ILP32；编译器及优化参数以固件 manifest 为准。构建、周期校准和频率限制见 [sw/README.md](sw/README.md)。
- 从 `cpu` 运行 `scripts/newpc.ps1` 的 Doctor/Emit/Unit/CoreMark/PdsCheck 阶段；工具要求见 [新电脑指南](../handoff/NEW_COMPUTER_GUIDE.md)。
- `rtl`、IP 及其 DMA/SD/视频测试仍为综合或外设实验输入；`linux` 仅是历史参考输入，不表示当前 CPU 已启动 Linux。
- 历史 DMA 等实验的设备地址可能使用旧平台映射，尚未按当前 CPU 的 PMA 规则完成整机验证。原先 `0x1c018000–0x1c01bfff` 的 DMA 数据特例已退出当前 CPU，整段 128 KiB boot BRAM 现在可缓存。旧 DMA 直写该区的实验需另行设计一致性，不能直接套用旧假设。新增运行测试时须先适配地址；当前设备窗口为 `0x02000000–0x0200ffff`（CLINT）和 `0x1fe00000–0x1fefffff`（集成 SoC MMIO）。

未被当前脚本或文档引用的旧代整机测试台 `tb_v7_top.v`、`tb_v8_top.v`、`tb_v10_top.sv` 和重复 CoreMark 测试台 `tb_coremark_v8.v` 已从发布目录移除。旧审计记录中的名称只代表历史状态；当前 CoreMark 只使用 `tb_coremark_soc.v`。开发机保留副本在忽略的 `work/retired-testbenches`，新电脑无需该目录。
