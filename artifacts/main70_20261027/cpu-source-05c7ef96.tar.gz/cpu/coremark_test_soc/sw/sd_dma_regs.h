#ifndef SD_DMA_REGS_H
#define SD_DMA_REGS_H

#include <stdint.h>

#define SD_BASE          UINT32_C(0x1fe13000)
#define SD_ID            (SD_BASE + UINT32_C(0x00))
#define SD_CTRL          (SD_BASE + UINT32_C(0x04))
#define SD_STATUS        (SD_BASE + UINT32_C(0x08))
#define SD_DATA          (SD_BASE + UINT32_C(0x0c))
#define SD_DIV           (SD_BASE + UINT32_C(0x10))
#define SD_PINS          (SD_BASE + UINT32_C(0x14))
#define SD_DMA_DST       (SD_BASE + UINT32_C(0x18))
#define SD_DMA_CTRL      (SD_BASE + UINT32_C(0x1c))
#define SD_DMA_STAT      (SD_BASE + UINT32_C(0x20))
#define SD_DMA_CRC       (SD_BASE + UINT32_C(0x24))
#define SD_DMA_COUNT     (SD_BASE + UINT32_C(0x28))
#define SD_DMA_CAP       (SD_BASE + UINT32_C(0x2c))

#define SD_ID_VALUE      UINT32_C(0x53445331)
#define SD_DMA_CAP_V1    UINT32_C(0x00010200)
#define SD_DMA_START     UINT32_C(0x1)
#define SD_DMA_CLEAR     UINT32_C(0x2)
#define SD_DMA_BUSY      UINT32_C(0x1)
#define SD_DMA_DONE      UINT32_C(0x2)
#define SD_DMA_ERROR     UINT32_C(0x4)
#define SD_DMA_ADDR_ERR  UINT32_C(0x8)
#define SD_DMA_CRC_ERR   UINT32_C(0x10)
#define SD_DMA_AXI_ERR   UINT32_C(0x20)

#endif
