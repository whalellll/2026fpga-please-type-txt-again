#ifndef CORE_PORTME_H
#define CORE_PORTME_H

#include <stddef.h>
#include <stdint.h>

#ifndef ITERATIONS
#define ITERATIONS 3000
#endif

#ifndef PERFORMANCE_RUN
#define PERFORMANCE_RUN 1
#endif
#ifndef VALIDATION_RUN
#define VALIDATION_RUN 0
#endif
#ifndef PROFILE_RUN
#define PROFILE_RUN 0
#endif
#if PERFORMANCE_RUN + VALIDATION_RUN != 1 || PROFILE_RUN
#error "Select exactly one standard performance or validation run"
#endif

#define HAS_FLOAT   1
#define HAS_TIME_H  0
#define USE_CLOCK   0
#define HAS_STDIO   0
#define HAS_PRINTF  1

#define SEED_METHOD SEED_VOLATILE
#define MEM_METHOD  MEM_STATIC
#define MEM_LOCATION "BRAM (static)"
#define MULTITHREAD 1
#define default_num_contexts MULTITHREAD
#define USE_PTHREAD 0
#define USE_FORK    0
#define USE_SOCKET  0

#define MAIN_HAS_NOARGC 1
#define MAIN_HAS_NORETURN 0

#ifndef COMPILER_VERSION
#define COMPILER_VERSION "GCC " __VERSION__
#endif
#ifndef COMPILER_FLAGS
#error "Compile with the generated coremark_build_config.h"
#endif
#ifndef CORE_CLOCKS_PER_SEC
#error "Set CORE_CLOCKS_PER_SEC to the CPU clock used by this run"
#endif

typedef uint8_t   ee_u8;
typedef uint16_t  ee_u16;
typedef uint32_t  ee_u32;
typedef int16_t   ee_s16;
typedef int32_t   ee_s32;
typedef uintptr_t ee_ptr_int;
typedef size_t    ee_size_t;
typedef uint64_t  CORE_TICKS;

typedef struct core_portable_s {
    ee_u8 portable_id;
} core_portable;

#define align_mem(x) \
    (void *)(((ee_ptr_int)(x) + sizeof(ee_u32) - 1) & \
             ~((ee_ptr_int)sizeof(ee_u32) - 1))

int printf(const char *format, ...);
void portable_init(core_portable *p, int *argc, char *argv[]);
void portable_fini(core_portable *p);

#endif
