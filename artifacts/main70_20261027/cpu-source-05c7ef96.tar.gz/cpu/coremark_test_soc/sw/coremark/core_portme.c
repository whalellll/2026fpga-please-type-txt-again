#include "coremark.h"
#include <stdarg.h>

#define UART_THR (*(volatile ee_u8 *)0x1fe001e0u)

#if VALIDATION_RUN
volatile ee_s32 seed1_volatile = 0x3415;
volatile ee_s32 seed2_volatile = 0x3415;
#else
volatile ee_s32 seed1_volatile = 0;
volatile ee_s32 seed2_volatile = 0;
#endif
volatile ee_s32 seed3_volatile = 0x66;
volatile ee_s32 seed4_volatile = ITERATIONS;
volatile ee_s32 seed5_volatile = 0;

static CORE_TICKS start_ticks;
static CORE_TICKS stop_ticks;

/* The CPU exposes cycle aliases as well as mcycle/mcycleh.
   Use the machine counters (0xB00/0xB80) for this M-mode port. */
static CORE_TICKS read_cycle64(void)
{
    ee_u32 hi0;
    ee_u32 lo;
    ee_u32 hi1;
    do {
        __asm__ volatile ("csrr %0, 0xB80" : "=r"(hi0));
        __asm__ volatile ("csrr %0, 0xB00" : "=r"(lo));
        __asm__ volatile ("csrr %0, 0xB80" : "=r"(hi1));
    } while (hi0 != hi1);
    return ((CORE_TICKS)hi1 << 32) | lo;
}

void start_time(void)
{
    start_ticks = read_cycle64();
}

void stop_time(void)
{
    stop_ticks = read_cycle64();
}

CORE_TICKS get_time(void)
{
    return stop_ticks - start_ticks;
}

secs_ret time_in_secs(CORE_TICKS ticks)
{
    return (secs_ret)ticks / (secs_ret)CORE_CLOCKS_PER_SEC;
}

void *portable_malloc(ee_size_t size)
{
    (void)size;
    return NULL;
}

void portable_free(void *p)
{
    (void)p;
}

void portable_init(core_portable *p, int *argc, char *argv[])
{
    (void)argc;
    (void)argv;
    p->portable_id = 1;
}

void portable_fini(core_portable *p)
{
    p->portable_id = 0;
    printf("PORT_TICKS64 : %llu\n", (unsigned long long)get_time());
    printf("COREMARK_DONE\n");
}

static void uart_putc(char c)
{
    if (c == '\n')
        UART_THR = '\r';
    UART_THR = (ee_u8)c;
}

static unsigned print_unsigned(unsigned long long value,
                               unsigned base,
                               unsigned width,
                               char pad,
                               int uppercase)
{
    char digits[24];
    const char *alphabet = uppercase ? "0123456789ABCDEF" : "0123456789abcdef";
    unsigned used = 0;
    unsigned total = 0;

    do {
        digits[used++] = alphabet[value % base];
        value /= base;
    } while (value != 0);

    while (width > used) {
        uart_putc(pad);
        width--;
        total++;
    }
    while (used != 0) {
        uart_putc(digits[--used]);
        total++;
    }
    return total;
}

static unsigned print_signed(long long value, unsigned width, char pad)
{
    unsigned total = 0;
    unsigned long long magnitude;
    if (value < 0) {
        uart_putc('-');
        total++;
        if (width != 0)
            width--;
        magnitude = (unsigned long long)(-(value + 1)) + 1;
    } else {
        magnitude = (unsigned long long)value;
    }
    return total + print_unsigned(magnitude, 10, width, pad, 0);
}

static unsigned print_double(double value, unsigned width, unsigned precision)
{
    unsigned total = 0;
    unsigned i;
    unsigned long long scale = 1;
    unsigned long long whole;
    unsigned long long fraction;

    if (value < 0.0) {
        uart_putc('-');
        total++;
        value = -value;
    }
    for (i = 0; i < precision; i++)
        scale *= 10;

    whole = (unsigned long long)value;
    fraction = (unsigned long long)(((value - (double)whole) * (double)scale) + 0.5);
    if (fraction >= scale) {
        whole++;
        fraction -= scale;
    }

    (void)width;
    total += print_unsigned(whole, 10, 0, ' ', 0);
    if (precision != 0) {
        uart_putc('.');
        total++;
        total += print_unsigned(fraction, 10, precision, '0', 0);
    }
    return total;
}

int printf(const char *format, ...)
{
    va_list ap;
    unsigned total = 0;
    va_start(ap, format);

    while (*format != '\0') {
        unsigned width = 0;
        unsigned precision = 6;
        int long_arg = 0;
        char pad = ' ';

        if (*format != '%') {
            uart_putc(*format++);
            total++;
            continue;
        }
        format++;
        if (*format == '%') {
            uart_putc(*format++);
            total++;
            continue;
        }
        if (*format == '0') {
            pad = '0';
            format++;
        }
        while (*format >= '0' && *format <= '9') {
            width = width * 10 + (unsigned)(*format - '0');
            format++;
        }
        if (*format == '.') {
            precision = 0;
            format++;
            while (*format >= '0' && *format <= '9') {
                precision = precision * 10 + (unsigned)(*format - '0');
                format++;
            }
        }
        if (*format == 'l') {
            long_arg = 1;
            format++;
            if (*format == 'l') {
                long_arg = 2;
                format++;
            }
        }

        switch (*format++) {
        case 'c':
            uart_putc((char)va_arg(ap, int));
            total++;
            break;
        case 's': {
            const char *s = va_arg(ap, const char *);
            if (s == NULL)
                s = "(null)";
            while (*s != '\0') {
                uart_putc(*s++);
                total++;
            }
            break;
        }
        case 'd':
        case 'i':
            if (long_arg == 2)
                total += print_signed(va_arg(ap, long long), width, pad);
            else if (long_arg == 1)
                total += print_signed(va_arg(ap, long), width, pad);
            else
                total += print_signed(va_arg(ap, int), width, pad);
            break;
        case 'u':
            if (long_arg == 2)
                total += print_unsigned(va_arg(ap, unsigned long long), 10, width, pad, 0);
            else if (long_arg == 1)
                total += print_unsigned(va_arg(ap, unsigned long), 10, width, pad, 0);
            else
                total += print_unsigned(va_arg(ap, unsigned int), 10, width, pad, 0);
            break;
        case 'x':
        case 'X': {
            int upper = format[-1] == 'X';
            if (long_arg == 2)
                total += print_unsigned(va_arg(ap, unsigned long long), 16, width, pad, upper);
            else if (long_arg == 1)
                total += print_unsigned(va_arg(ap, unsigned long), 16, width, pad, upper);
            else
                total += print_unsigned(va_arg(ap, unsigned int), 16, width, pad, upper);
            break;
        }
        case 'f':
            total += print_double(va_arg(ap, double), width, precision);
            break;
        default:
            uart_putc('?');
            total++;
            break;
        }
    }
    va_end(ap);
    return (int)total;
}
