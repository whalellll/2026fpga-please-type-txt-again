# CoreMark 固件与编译器比较

本目录包含完整 CoreMark 1.0 基准、许可证、裸机移植层、启动文件和链接脚本。六个基准文件来自 EEMBC 官方 tag `v1.01`，固定提交 `cfa9ab377835911f23d9b0831c7be302ed1f58de`；该版本按官方说明报告为 CoreMark 1.0。`coremark/upstream.json` 记录逐文件 SHA256，构建前拒绝任何基准源码改动。板端移植只在 `core_portme.[ch]`、启动和链接文件中完成。

硬件与固件统一 RV32IMA；参数为 `-march=rv32ima_zicsr_zifencei -mabi=ilp32`，不生成 C 指令。比赛点名 `riscv32-unknown-elf-gcc`，没有指定 GCC 版本或优化级别。当前按实际容量和性能选择 GCC 16.2.0/O2；V3 基座的 5.014670/MHz 是历史短校准，V3.1 正式结果见 [验证记录](../../handoff/V3_1_VALIDATION.md)。完整参数以固件 manifest 和验证记录为准。

## 固件构建与校准

在 `cpu` 目录执行：

```powershell
powershell -NoProfile -File scripts/build_coremark.ps1 -ToolchainRoot C:\tools\riscv -OutputRoot .\work\coremark-calibration
```

工具路径也可通过 `RISCV_TOOLCHAIN_ROOT` 或 PATH 提供。脚本检查真实编译器 target/版本、运行库、ELF32/ILP32、ISA 和链接后的指令，保存完整编译及链接参数、预处理后种子、2000 字节工作集、源码和产物 SHA256。默认十次迭代、49,500,000 Hz、`evidence_class=calibration` 是短校准配置；显式写入 `work/` 避免覆盖已发布的 2600 次固件。49.5 MHz 尚未通过上板验收。当前库选择规则及可复现安装见 [工具链说明](../../handoff/toolchain/README.md)。

比较候选时使用独立输出目录，明确指定版本与优化级别：

```powershell
.\scripts\build_coremark.ps1 -ToolchainRoot C:\tools\riscv `
  -CompilerVersion 16.2.0 -Optimization O3 -OutputRoot .\work\gcc16-o3
.\scripts\build_coremark.ps1 -ToolchainRoot C:\tools\riscv `
  -RunMode validation -OutputRoot .\work\gcc16-validation
```

当前两版 GCC 的 O3 完整集成镜像都不能保留规定的 16 KiB 栈，所以 O3 只作为独立实验选项，不能作为发布固件。对照 14.2 时传入对应工具链目录并显式设置 `-CompilerVersion 14.2.0`。

`performance` 使用种子 0/0/0x66，`validation` 使用 0x3415/0x3415/0x66，均为 2000 字节工作区。所有 CoreMark 源文件用相同参数编译。只在端口中选择种子，官方十秒检查一直有效，没有 `COREMARK_SIM` 开关。

Windows 可运行 `scripts/newpc.ps1 -Stage CoreMark` 重放包内固定性能固件一次；完整 3+1 使用 `scripts/run_coremark_release.ps1 -TimeoutSeconds 28800`。现有 Bash 环境可运行 `bash scripts/run_coremark_ab.sh`，但需自行管理长任务的进程与超时。后者保留历史文件名，当前只支持 IMA。候选可用 `COREMARK_FIRMWARE_ROOT` 指定，结果用 `COREMARK_RESULT_ROOT` 分目录保存；编译器与默认版本不同时显式设置 `COREMARK_EXPECTED_GCC`。需要不同 RTL 时用 `CORE_TEST_SV`，修改 Chisel 后先 Emit，不能手改生成文件。

测量使用 CPU cycle CSR，`CoreMark/MHz = iterations * 1,000,000 / ticks`。端口额外报告完整 64 位 `PORT_TICKS64`，检查器核对它与官方 32 位 tick 输出一致。测试台 UART 加速不在计时区间内；电脑运行耗时不作为 CPU 时间。结果保存 CRC、输入哈希、模拟频率和目标 CPU 时间；十次短测标记为 `CALIBRATION_ONLY`，正式运行须得到严格检查的 `PASS`。

模型构建和十次迭代通常需要几分钟，取决于机器与并发负载。校准默认仿真上限 2000 万周期，正式固件默认 8 亿周期；Windows 单次入口对正式固件默认 4 小时总限时。入口打印所属 PowerShell PID，结束该进程会关闭 Job 及全部子进程。直接 shell 运行可按 Ctrl+C。

## 正式成绩与历史边界

十次短校准不能作为比赛成绩。正式源仓固件固定 2600 次迭代、49.5 MHz，性能与验证各自独立构建并标记 `-EvidenceClass formal_candidate`；完整命令见[新电脑指南](../../handoff/NEW_COMPUTER_GUIDE.md)。批量入口共用一个 `-Os` 主机模型并执行三次性能、一次验证，每次依目标 mcycle 达到至少十秒且通过官方 CRC 检查。`run_coremark_ab.sh` 根据固件 manifest 自动选择校准或正式检查；显式覆盖模式时必须与固件类别一致。长 RTL 仿真可能需要数小时，按本机实测 cycle/s 估算；它也不能替代板测最高频率。

此前 IMA/IMAC、删除 C、访存排序修复和 GCC 13.2/14.2 的历史短校准保留在 [验证目录](../../handoff/validation/ima-release/README.md) 与 [编译器旧基线](../../handoff/validation/compiler-baseline/README.md)。这些使用恢复官方文件之前的移植版，不能冒充官方源码的新成绩。旧移植版曾调整初始化局部变量及结果报告；当前构建已清除这些差异。
