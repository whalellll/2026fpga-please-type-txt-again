# CPU performance test project

`coremark_test_soc.pds` is the portable PDS 2022.2-SP6.4 / PG2L100H-6-FBG676
project for `coremark_soc_top`. This is a CPU/BRAM/UART test harness. It is
not the board-level `performance_soc` project and has no assigned board pins.
The committed FDC constrains its external `clk` to 49.5 MHz, matching the
current IMA calibration firmware. It does not establish a maximum CPU
frequency or complete board timing constraints.

From `cpu`, prepare the tracked ROM inputs, then open the project:

```powershell
.\scripts\prepare_pds_project.ps1
# Open coremark_test_soc/pds/coremark_test_soc.pds in PDS.
```

No old `work/` directory is needed. The preparation verifies the image hash
and copies `ram.hex` and the three CPU zero-initialization files to the
tool's lookup directories. The copies and all PDS outputs stay out of Git.
Run preparation again after changing the selected firmware or cleaning.
The default ROM comes from `coremark_test_soc/sim/coremark_ima`.
Use `-FirmwareDirectory` to select another build containing `manifest.json`
and `ram.hex`; its `cpu_hz` must match the committed FDC. Rebuild software
clock constants and UART division when changing the clock.
For a Windows account with non-ASCII characters, set `-StageRoot` (or
`PdsStageRoot` in the local toolchain config) to a writable ASCII directory.
Do not synthesize while another script or GUI is using the same project.

```powershell
# Fast input/path/hash check, no generated files or PDS process.
.\scripts\prepare_pds_project.ps1 -ValidateOnly
# Opens an isolated copy, including a directory containing a space; 30 s limit.
.\scripts\prepare_pds_project.ps1 -ValidateOnly -VerifyWithPds -PdsShell C:\tools\PDS\bin\pds_shell.exe
# Same isolated copy, compile + ADS followed by the critical-control audit.
.\scripts\prepare_pds_project.ps1 -ValidateOnly -Synthesize -PdsShell C:\tools\PDS\bin\pds_shell.exe -PythonPath C:\tools\Python\python.exe
```

The script retains each attempt's logs and hashes in ignored `work/logs/pds-coremark/`
and prints the temporary netlist directory for inspection. The timeout stops
its child process tree; Ctrl+C can be delayed while PowerShell waits for PDS.
The latest JSON becomes `RUNNING` before launch and records an error or timeout
explicitly. Optional `-ExpectedCoreSha256` pins the generated CPU input.
A synthesis PASS does not establish
place-and-route timing, UART operation on a board, CoreMark validity, or
hardware frequency. Use `performance_soc` for board integration and testing.

The earlier GCC 16.2 firmware run record is
[`handoff/validation/pds-synthesis-gcc16/result.json`](../../handoff/validation/pds-synthesis-gcc16/result.json):
19,034 LUTs, 10,880 registers, zero latches, about nine minutes on this host.
The present `b73b680...` generated CPU and GCC 16.2 ROM also passed compile,
ADS, and the mapped-control audit from an extracted package without old
`work/` in the [CPU V3 release evidence](../../handoff/validation/v3-portable-release/README.md):
19,098 LUTs, 10,880 registers, 90 DRM, and zero latches. This source test
project has no board-level pinout; its synthesis does not prove full-SoC STA.
Compile completion alone is insufficient: ADS must complete and its netlist
must retain the four predecode branch lanes, RsMem address-hint refresh
guard, and current PMA address windows. A timeout is an incomplete tool run,
not synthesis acceptance. The actual duration depends on RTL and concurrent tool load.

`PdsSynthesis` runs the critical-cone audit automatically after synthesis, with
a separate 300-second bound; audit failure prevents the synthesis PASS marker.
`newpc.ps1` reads `PythonPath` from the local toolchain configuration. To inspect
the same netlist again, run the audit directly with Python 3:

```powershell
python .\scripts\audit_pds_controls.py <printed-stage>\coremark_test_soc\pds\synthesize\coremark_soc_top_syn.vm --output .\work\logs\pds-coremark\ads-controls.json
```

It evaluates the actual GTP LUT truth tables for the four branch lanes and
selection, both RsMem refresh guards, and PMA boundaries; it also checks that
the repair cone still contains the branch controls. This is a local
combinational check, not whole-design gate simulation. The script fails if
an expected mapped name or unsupported evaluated cell changes; review such
changes against the new netlist instead of weakening a failed assertion.
The current GCC 16.2 ROM and RTL are bound by hashes in the synthesis record.
The older GCC 13.2 run remains historical evidence. A subsequent firmware
rebuild needs fresh input validation; a recorded result cannot cover a changed ROM.

`scripts/synthesize_dma_soc.ps1` separately preserves the older complete-DMA
integration synthesis experiment. Its many external ports are not a physical
board pinout either; its historical numbers are not this test top's numbers.
