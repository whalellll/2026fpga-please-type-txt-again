`timescale 1ns/1ps

module tb_sd_native_mmio;
    localparam [31:0] BASE = 32'h1fe1_3000;

    reg         clk = 1'b0;
    reg         resetn = 1'b0;
    reg  [31:0] addr = 32'd0;
    reg         wr = 1'b0;
    reg  [31:0] wdata = 32'd0;
    reg  [3:0]  wstrb = 4'd0;
    wire [31:0] rdata;
    wire        hit;
    wire        sd_clk;
    reg         card_cmd = 1'b1;
    wire        sd_cmd_out;
    wire        sd_cmd_oe;
    reg  [3:0]  card_dat = 4'hf;
    reg         sd_detect_n = 1'b0;
    wire [31:0] dma_awaddr;
    wire [7:0]  dma_awlen;
    wire [2:0]  dma_awsize;
    wire [1:0]  dma_awburst;
    wire        dma_awvalid;
    reg         dma_awready = 1'b1;
    wire [31:0] dma_wdata;
    wire [3:0]  dma_wstrb;
    wire        dma_wlast;
    wire        dma_wvalid;
    reg         dma_wready = 1'b1;
    reg  [1:0]  dma_bresp = 2'b00;
    reg         dma_bvalid = 1'b0;
    wire        dma_bready;
    reg [31:0]  dma_memory [0:127];
    reg [31:0]  dma_saved_address;
    integer     dma_write_count;
    integer     dma_index;

    reg [47:0] host_command;
    integer host_command_bits;
    integer sd_rising_edges;

    reg [47:0] response_frame;
    reg [47:0] stop_response_frame;
    reg [135:0] response136_frame;
    reg [127:0] response136_raw;
    reg [63:0] data_pattern;

    always #5 clk = ~clk;

    sd_native_mmio #(
        .BASE(BASE),
        .RESET_DIV(16'd0),
        .DEBOUNCE_CYCLES(2),
        .CMD_TIMEOUT_CLOCKS(64),
        .DATA_TIMEOUT_CLOCKS(256),
        .BUSY_TIMEOUT_CLOCKS(64)
    ) dut (
        .clk(clk),
        .resetn(resetn),
        .addr(addr),
        .wr(wr),
        .wdata(wdata),
        .wstrb(wstrb),
        .rdata(rdata),
        .hit(hit),
        .sd_clk(sd_clk),
        .sd_cmd_in(card_cmd),
        .sd_cmd_out(sd_cmd_out),
        .sd_cmd_oe(sd_cmd_oe),
        .sd_dat_in(card_dat),
        .sd_detect_n(sd_detect_n),
        .m_axi_awaddr(dma_awaddr), .m_axi_awlen(dma_awlen),
        .m_axi_awsize(dma_awsize), .m_axi_awburst(dma_awburst),
        .m_axi_awvalid(dma_awvalid), .m_axi_awready(dma_awready),
        .m_axi_wdata(dma_wdata), .m_axi_wstrb(dma_wstrb),
        .m_axi_wlast(dma_wlast), .m_axi_wvalid(dma_wvalid),
        .m_axi_wready(dma_wready), .m_axi_bresp(dma_bresp),
        .m_axi_bvalid(dma_bvalid), .m_axi_bready(dma_bready)
    );

    always @(posedge clk) begin
        if (!resetn) begin
            dma_bvalid <= 1'b0;
            dma_saved_address <= 32'd0;
            dma_write_count <= 0;
        end else begin
            if (dma_awvalid && dma_awready)
                dma_saved_address <= dma_awaddr;
            if (dma_awvalid && dma_awready && dma_wvalid && dma_wready) begin
                if (dma_awlen !== 8'd0 || dma_awsize !== 3'd2 ||
                    dma_awburst !== 2'b01 || dma_wstrb !== 4'hf ||
                    dma_wlast !== 1'b1)
                    $fatal(1, "DMA AXI attributes mismatch");
                if (dma_awaddr < 32'h0000_1000 ||
                    dma_awaddr >= 32'h0000_1200)
                    $fatal(1, "DMA AXI address out of range: %h", dma_awaddr);
                dma_memory[dma_awaddr[8:2]] <= dma_wdata;
                dma_write_count <= dma_write_count + 1;
                dma_bvalid <= 1'b1;
            end
            if (dma_bvalid && dma_bready)
                dma_bvalid <= 1'b0;
        end
    end

    always @(posedge sd_clk) begin
        sd_rising_edges = sd_rising_edges + 1;
        if (sd_cmd_oe) begin
            host_command = {host_command[46:0], sd_cmd_out};
            host_command_bits = host_command_bits + 1;
        end
    end

    task mmio_write;
        input [31:0] write_addr;
        input [31:0] write_data;
        input [3:0] write_strobe;
        begin
            @(negedge clk);
            addr = write_addr;
            wdata = write_data;
            wstrb = write_strobe;
            wr = 1'b1;
            @(posedge clk);
            #1;
            @(negedge clk);
            wr = 1'b0;
            wstrb = 4'd0;
            wdata = 32'd0;
        end
    endtask

    task select_addr;
        input [31:0] read_addr;
        begin
            @(negedge clk);
            addr = read_addr;
            #1;
        end
    endtask

    task wait_done;
        integer guard;
        begin
            guard = 0;
            while ((dut.busy !== 1'b0) && (guard < 20000)) begin
                @(posedge clk);
                guard = guard + 1;
            end
            if (guard >= 20000)
                $fatal(1, "operation did not finish");
            if (dut.done !== 1'b1)
                $fatal(1, "DONE was not set");
        end
    endtask

    task build_r48;
        input [5:0] response_index;
        input [31:0] response_payload;
        output [47:0] frame;
        reg [39:0] protected_bits;
        reg [6:0] crc;
        integer bit_number;
        begin
            protected_bits = {2'b00, response_index, response_payload};
            crc = 7'd0;
            for (bit_number = 39; bit_number >= 0;
                 bit_number = bit_number - 1) begin
                if (crc[6] ^ protected_bits[bit_number])
                    crc = {crc[5:0], 1'b0} ^ 7'h09;
                else
                    crc = {crc[5:0], 1'b0};
            end
            frame = {protected_bits, crc, 1'b1};
        end
    endtask

    task send_r48;
        input [47:0] frame;
        integer bit_number;
        begin
            wait (sd_cmd_oe === 1'b1);
            wait (sd_cmd_oe === 1'b0);
            card_cmd = frame[47];
            for (bit_number = 47; bit_number >= 0;
                 bit_number = bit_number - 1) begin
                @(posedge sd_clk);
                if (bit_number != 0) begin
                    @(negedge sd_clk);
                    card_cmd = frame[bit_number - 1];
                end
            end
            @(negedge sd_clk);
            card_cmd = 1'b1;
        end
    endtask

    task build_r136;
        input [119:0] register_top_bits;
        output [135:0] frame;
        reg [6:0] crc;
        integer bit_number;
        begin
            crc = 7'd0;
            for (bit_number = 119; bit_number >= 0;
                 bit_number = bit_number - 1) begin
                if (crc[6] ^ register_top_bits[bit_number])
                    crc = {crc[5:0], 1'b0} ^ 7'h09;
                else
                    crc = {crc[5:0], 1'b0};
            end
            frame = {8'b0011_1111, register_top_bits, crc, 1'b1};
        end
    endtask

    task send_r136;
        input [135:0] frame;
        integer bit_number;
        begin
            wait (sd_cmd_oe === 1'b1);
            wait (sd_cmd_oe === 1'b0);
            card_cmd = frame[135];
            for (bit_number = 135; bit_number >= 0;
                 bit_number = bit_number - 1) begin
                @(posedge sd_clk);
                if (bit_number != 0) begin
                    @(negedge sd_clk);
                    card_cmd = frame[bit_number - 1];
                end
            end
            @(negedge sd_clk);
            card_cmd = 1'b1;
        end
    endtask

    task send_data_1bit;
        input [63:0] payload;
        reg [15:0] crc;
        integer bit_number;
        begin
            card_dat = 4'b1110;
            @(posedge sd_clk);
            crc = 16'd0;
            for (bit_number = 63; bit_number >= 0;
                 bit_number = bit_number - 1) begin
                @(negedge sd_clk);
                card_dat[0] = payload[bit_number];
                @(posedge sd_clk);
                if (crc[15] ^ payload[bit_number])
                    crc = {crc[14:0], 1'b0} ^ 16'h1021;
                else
                    crc = {crc[14:0], 1'b0};
            end
            for (bit_number = 15; bit_number >= 0;
                 bit_number = bit_number - 1) begin
                @(negedge sd_clk);
                card_dat[0] = crc[bit_number];
                @(posedge sd_clk);
            end
            @(negedge sd_clk);
            card_dat = 4'hf;
            @(posedge sd_clk);
        end
    endtask

    task send_scr_overlap_fixed;
        integer bit_number;
        reg [63:0] payload;
        reg [15:0] crc;
        begin
            /* Independent board-captured vector.  Keep the CRC literal so
             * this regression cannot agree with a broken host CRC equation. */
            payload = 64'h0235_8003_0000_0000;
            crc = 16'h957e;
            card_dat = 4'b1110;
            @(posedge sd_clk);
            for (bit_number = 63; bit_number >= 0;
                 bit_number = bit_number - 1) begin
                @(negedge sd_clk);
                card_dat[0] = payload[bit_number];
                @(posedge sd_clk);
            end
            for (bit_number = 15; bit_number >= 0;
                 bit_number = bit_number - 1) begin
                @(negedge sd_clk);
                card_dat[0] = crc[bit_number];
                @(posedge sd_clk);
            end
            @(negedge sd_clk);
            card_dat = 4'hf;
            @(posedge sd_clk);
        end
    endtask

    task send_data_4bit;
        input [63:0] payload;
        input corrupt_crc;
        reg [15:0] crc0;
        reg [15:0] crc1;
        reg [15:0] crc2;
        reg [15:0] crc3;
        reg [3:0] nibble;
        integer nibble_number;
        integer bit_number;
        begin
            card_dat = 4'b0000;
            @(posedge sd_clk);
            crc0 = 16'd0;
            crc1 = 16'd0;
            crc2 = 16'd0;
            crc3 = 16'd0;
            for (nibble_number = 15; nibble_number >= 0;
                 nibble_number = nibble_number - 1) begin
                @(negedge sd_clk);
                nibble = payload[nibble_number * 4 +: 4];
                card_dat = nibble;
                @(posedge sd_clk);
                if (crc0[15] ^ nibble[0])
                    crc0 = {crc0[14:0], 1'b0} ^ 16'h1021;
                else
                    crc0 = {crc0[14:0], 1'b0};
                if (crc1[15] ^ nibble[1])
                    crc1 = {crc1[14:0], 1'b0} ^ 16'h1021;
                else
                    crc1 = {crc1[14:0], 1'b0};
                if (crc2[15] ^ nibble[2])
                    crc2 = {crc2[14:0], 1'b0} ^ 16'h1021;
                else
                    crc2 = {crc2[14:0], 1'b0};
                if (crc3[15] ^ nibble[3])
                    crc3 = {crc3[14:0], 1'b0} ^ 16'h1021;
                else
                    crc3 = {crc3[14:0], 1'b0};
            end
            for (bit_number = 15; bit_number >= 0;
                 bit_number = bit_number - 1) begin
                @(negedge sd_clk);
                card_dat = {crc3[bit_number], crc2[bit_number],
                            crc1[bit_number], crc0[bit_number]};
                if (corrupt_crc && (bit_number == 15))
                    card_dat[0] = ~card_dat[0];
                @(posedge sd_clk);
            end
            @(negedge sd_clk);
            card_dat = 4'hf;
            @(posedge sd_clk);
        end
    endtask

    initial begin
        host_command = 48'd0;
        host_command_bits = 0;
        sd_rising_edges = 0;
        data_pattern = 64'h0102_0304_0506_0708;

        repeat (4) @(posedge clk);
        #1;
        if (sd_clk !== 1'b0 || sd_cmd_oe !== 1'b0 ||
            sd_cmd_out !== 1'b1)
            $fatal(1, "native SD reset pins mismatch");

        resetn = 1'b1;
        repeat (6) @(posedge clk);
        select_addr(BASE + 32'h000);
        if (!hit || rdata !== 32'h5344_4e32)
            $fatal(1, "ID mismatch: %h", rdata);
        select_addr(BASE + 32'h004);
        if (rdata !== 32'h0004_0300)
            $fatal(1, "version mismatch: %h", rdata);
        select_addr(BASE + 32'h00c);
        if (rdata[4:3] !== 2'b11)
            $fatal(1, "card detect mismatch: %h", rdata);
        select_addr(BASE + 32'h500);
        if (hit || rdata !== 32'd0)
            $fatal(1, "MMIO end decode mismatch");

        // Clock-only operation generates exactly the requested rising edges.
        sd_rising_edges = 0;
        mmio_write(BASE + 32'h048, 32'd5, 4'hf);
        wait_done();
        if (sd_rising_edges != 5 || sd_clk !== 1'b0)
            $fatal(1, "idle clocks mismatch: %0d", sd_rising_edges);

        // CMD0 has a normative CRC vector: 0x400000000095.
        mmio_write(BASE + 32'h008, 32'h0000_0004, 4'h1);
        host_command = 48'd0;
        host_command_bits = 0;
        mmio_write(BASE + 32'h014, 32'd0, 4'hf);
        mmio_write(BASE + 32'h018, 32'h0000_0800, 4'hf);
        wait_done();
        if (host_command_bits != 48 ||
            host_command !== 48'h4000_0000_0095)
            $fatal(1, "CMD0 frame mismatch: bits=%0d frame=%h",
                   host_command_bits, host_command);
        if (dut.error_sticky !== 8'd0)
            $fatal(1, "CMD0 reported error %h", dut.error_sticky);

        // Capture a complete CRC-protected R7 response as a raw 48-bit frame.
        mmio_write(BASE + 32'h008, 32'h0000_0004, 4'h1);
        build_r48(6'd8, 32'h0000_01aa, response_frame);
        host_command = 48'd0;
        host_command_bits = 0;
        fork
            send_r48(response_frame);
            begin
                mmio_write(BASE + 32'h014, 32'h0000_01aa, 4'hf);
                mmio_write(BASE + 32'h018,
                           32'h0000_0800 | (32'd1 << 6) | 32'd8,
                           4'hf);
            end
        join
        wait_done();
        select_addr(BASE + 32'h01c);
        if (rdata !== response_frame[31:0])
            $fatal(1, "R48 RESP0 mismatch: %h", rdata);
        select_addr(BASE + 32'h020);
        if (rdata[15:0] !== response_frame[47:32])
            $fatal(1, "R48 RESP1 mismatch: %h", rdata);
        if (dut.error_sticky !== 8'd0)
            $fatal(1, "valid R48 reported error %h", dut.error_sticky);

        // Initialization data path: an eight-byte SCR arrives on DAT0 only.
        mmio_write(BASE + 32'h008, 32'h0000_0004, 4'h1);
        mmio_write(BASE + 32'h030, 32'd8, 4'hf);
        mmio_write(BASE + 32'h034, 32'd1, 4'hf);
        build_r48(6'd51, 32'd0, response_frame);
        fork
            send_r48(response_frame);
            begin
                /* A native-SD read data token may overlap the R1 response.
                 * Start early enough that the first 22 payload bits arrive
                 * before the host has sampled the R1 end bit. */
                wait (sd_cmd_oe === 1'b1);
                wait (sd_cmd_oe === 1'b0);
                repeat (25) @(posedge sd_clk);
                send_scr_overlap_fixed();
            end
            begin
                mmio_write(BASE + 32'h014, 32'd0, 4'hf);
                mmio_write(BASE + 32'h018,
                           32'h0000_0800 | 32'h0000_0200 |
                           (32'd1 << 6) | 32'd51,
                           4'hf);
            end
        join
        wait_done();
        select_addr(BASE + 32'h03c);
        if (rdata[1:0] !== 2'b01)
            $fatal(1, "1-bit buffer ready mismatch: %h", rdata);
        select_addr(BASE + 32'h100);
        if (rdata !== 32'h0380_3502)
            $fatal(1, "1-bit buffer word0 mismatch: %h", rdata);
        select_addr(BASE + 32'h104);
        if (rdata !== 32'h0000_0000)
            $fatal(1, "1-bit buffer word1 mismatch: %h", rdata);
        if (dut.error_sticky !== 8'd0)
            $fatal(1, "1-bit read reported error %h", dut.error_sticky);

        // Release buffer 0, switch width, and repeat over all four DAT lanes.
        mmio_write(BASE + 32'h03c, 32'h0000_0001, 4'h1);
        mmio_write(BASE + 32'h008, 32'h0000_0006, 4'h1);
        build_r48(6'd17, 32'd0, response_frame);
        fork
            begin
                send_r48(response_frame);
                send_data_4bit(data_pattern, 1'b0);
            end
            begin
                mmio_write(BASE + 32'h014, 32'd0, 4'hf);
                mmio_write(BASE + 32'h018,
                           32'h0000_0800 | 32'h0000_0200 |
                           (32'd1 << 6) | 32'd17,
                           4'hf);
            end
        join
        wait_done();
        select_addr(BASE + 32'h03c);
        if (rdata[1:0] !== 2'b01)
            $fatal(1, "4-bit buffer ready mismatch: %h", rdata);
        select_addr(BASE + 32'h100);
        if (rdata !== 32'h0403_0201)
            $fatal(1, "4-bit buffer word0 mismatch: %h", rdata);
        select_addr(BASE + 32'h104);
        if (rdata !== 32'h0807_0605)
            $fatal(1, "4-bit buffer word1 mismatch: %h", rdata);
        if (dut.error_sticky !== 8'd0)
            $fatal(1, "4-bit read reported error %h", dut.error_sticky);

        // R2 has an eight-bit unprotected header.  The following 120 register
        // bits use their own CRC7 and the returned registers drop the header.
        mmio_write(BASE + 32'h03c, 32'h0000_0001, 4'h1);
        mmio_write(BASE + 32'h008, 32'h0000_0006, 4'h1);
        build_r136(120'h0123_4567_89ab_cdef_1020_3040_5060_70,
                   response136_frame);
        response136_raw = response136_frame[127:0];
        fork
            send_r136(response136_frame);
            begin
                mmio_write(BASE + 32'h014, 32'd0, 4'hf);
                mmio_write(BASE + 32'h018,
                           32'h0000_0800 | (32'd3 << 6) | 32'd2,
                           4'hf);
            end
        join
        wait_done();
        select_addr(BASE + 32'h01c);
        if (rdata !== response136_raw[31:0])
            $fatal(1, "R136 RESP0 mismatch: %h", rdata);
        select_addr(BASE + 32'h020);
        if (rdata !== response136_raw[63:32])
            $fatal(1, "R136 RESP1 mismatch: %h", rdata);
        select_addr(BASE + 32'h024);
        if (rdata !== response136_raw[95:64])
            $fatal(1, "R136 RESP2 mismatch: %h", rdata);
        select_addr(BASE + 32'h028);
        if (rdata !== response136_raw[127:96])
            $fatal(1, "R136 RESP3 mismatch: %h", rdata);
        if (dut.error_sticky !== 8'd0)
            $fatal(1, "valid R136 reported error %h", dut.error_sticky);

        // Three blocks exercise both buffers.  Holding the first two buffers
        // forces a safe low-clock pause; releasing buffer 0 resumes block 2.
        mmio_write(BASE + 32'h008, 32'h0000_0006, 4'h1);
        mmio_write(BASE + 32'h030, 32'd8, 4'hf);
        mmio_write(BASE + 32'h034, 32'd3, 4'hf);
        build_r48(6'd18, 32'd0, response_frame);
        build_r48(6'd12, 32'd0, stop_response_frame);
        host_command = 48'd0;
        host_command_bits = 0;
        fork
            begin
                send_r48(response_frame);
                send_data_4bit(64'h0102_0304_0506_0708, 1'b0);
                send_data_4bit(64'h1112_1314_1516_1718, 1'b0);
                send_data_4bit(64'h2122_2324_2526_2728, 1'b0);
                send_r48(stop_response_frame);
            end
            begin
                mmio_write(BASE + 32'h014, 32'd0, 4'hf);
                mmio_write(BASE + 32'h018,
                           32'h0000_0800 | 32'h0000_0400 |
                           32'h0000_0200 | (32'd1 << 6) | 32'd18,
                           4'hf);
                wait (dut.buffer0_ready && dut.buffer1_ready &&
                      (sd_clk == 1'b0));
                repeat (6) begin
                    @(posedge clk);
                    if (sd_clk !== 1'b0)
                        $fatal(1, "clock did not remain low while full");
                end
                select_addr(BASE + 32'h040);
                if (rdata[5:0] !== 6'd0)
                    $fatal(1, "buffer0 first index mismatch: %h", rdata);
                select_addr(BASE + 32'h100);
                if (rdata !== 32'h0403_0201)
                    $fatal(1, "multi block0 data mismatch: %h", rdata);
                select_addr(BASE + 32'h044);
                if (rdata[5:0] !== 6'd1)
                    $fatal(1, "buffer1 index mismatch: %h", rdata);
                select_addr(BASE + 32'h300);
                if (rdata !== 32'h1413_1211)
                    $fatal(1, "multi block1 data mismatch: %h", rdata);
                mmio_write(BASE + 32'h03c, 32'h0000_0001, 4'h1);
                mmio_write(BASE + 32'h03c, 32'h0000_0002, 4'h1);
                wait (dut.buffer0_ready &&
                      (dut.buffer0_block_index == 6'd2));
                select_addr(BASE + 32'h100);
                if (rdata !== 32'h2423_2221)
                    $fatal(1, "multi block2 data mismatch: %h", rdata);
                mmio_write(BASE + 32'h03c, 32'h0000_0001, 4'h1);
            end
        join
        wait_done();
        if (dut.blocks_done !== 6'd3)
            $fatal(1, "multi block count mismatch: %0d", dut.blocks_done);
        if (host_command_bits != 96 ||
            host_command !== 48'h4c00_0000_0061)
            $fatal(1, "automatic CMD12 missing: bits=%0d frame=%h",
                   host_command_bits, host_command);
        if (dut.error_sticky !== 8'd0)
            $fatal(1, "multi read reported error %h", dut.error_sticky);

        // A CRC-damaged R48b can still have been accepted by the card.  Keep
        // clocking until DAT0 busy releases, then publish the response error.
        mmio_write(BASE + 32'h008, 32'h0000_0006, 4'h1);
        build_r48(6'd12, 32'd0, stop_response_frame);
        stop_response_frame[1] = ~stop_response_frame[1];
        fork
            begin
                send_r48(stop_response_frame);
                card_dat = 4'b1110;
                repeat (40) begin
                    @(posedge clk);
                    #1;
                    if (dut.busy !== 1'b1)
                        $fatal(1, "bad R48b stopped before DAT0 busy release");
                    if (dut.error_sticky[1] !== 1'b0)
                        $fatal(1, "bad R48b CRC published before DAT0 busy release");
                end
                card_dat = 4'hf;
            end
            begin
                mmio_write(BASE + 32'h014, 32'd0, 4'hf);
                mmio_write(BASE + 32'h018,
                           32'h0000_0800 | (32'd4 << 6) | 32'd12,
                           4'hf);
            end
        join
        wait_done();
        select_addr(BASE + 32'h02c);
        if (rdata[1] !== 1'b1 || sd_clk !== 1'b0)
            $fatal(1, "bad R48b CRC/busy termination mismatch: %h", rdata);

        // A bad per-lane CRC must never publish the partially written block.
        mmio_write(BASE + 32'h008, 32'h0000_0006, 4'h1);
        mmio_write(BASE + 32'h034, 32'd1, 4'hf);
        build_r48(6'd17, 32'd0, response_frame);
        fork
            begin
                send_r48(response_frame);
                send_data_4bit(data_pattern, 1'b1);
            end
            begin
                mmio_write(BASE + 32'h014, 32'd0, 4'hf);
                mmio_write(BASE + 32'h018,
                           32'h0000_0800 | 32'h0000_0200 |
                           (32'd1 << 6) | 32'd17,
                           4'hf);
            end
        join
        wait_done();
        select_addr(BASE + 32'h02c);
        if (rdata[4] !== 1'b1)
            $fatal(1, "bad DAT CRC was not reported: %h", rdata);
        select_addr(BASE + 32'h03c);
        if (rdata[1:0] !== 2'b00)
            $fatal(1, "bad DAT CRC published a buffer: %h", rdata);

        // A completed native buffer is written to DDR without CPU reads.
        // Single-beat responses deliberately exercise all 128 words and the
        // release handshake that lets the SD receiver reuse the buffer.
        mmio_write(BASE + 32'h008, 32'h0000_0006, 4'h1);
        mmio_write(BASE + 32'h030, 32'd512, 4'hf);
        mmio_write(BASE + 32'h034, 32'd1, 4'hf);
        mmio_write(BASE + 32'h050, 32'h0000_1000, 4'hf);
        mmio_write(BASE + 32'h054, 32'h0000_0003, 4'h1);
        for (dma_index = 0; dma_index < 128; dma_index = dma_index + 1) begin
            dut.buffer0[dma_index] = 32'h6000_0000 + dma_index;
            dma_memory[dma_index] = 32'd0;
        end
        dma_write_count = 0;
        mmio_write(BASE + 32'h014, 32'd0, 4'hf);
        mmio_write(BASE + 32'h018,
                   32'h0000_0800 | 32'h0000_0200 |
                   (32'd1 << 6) | 32'd17, 4'hf);
        wait (dut.dma_busy === 1'b1);
        @(negedge clk);
        dut.buffer0_block_index = 6'd0;
        dut.buffer0_ready = 1'b1;
        wait (dut.dma_done === 1'b1);
        repeat (3) @(posedge clk);
        if (dut.dma_error !== 1'b0 || dut.dma_blocks_done !== 6'd1 ||
            dma_write_count != 128 || dut.buffer0_ready !== 1'b0)
            $fatal(1, "DMA completion mismatch err=%b blocks=%0d writes=%0d ready=%b",
                   dut.dma_error, dut.dma_blocks_done, dma_write_count,
                   dut.buffer0_ready);
        for (dma_index = 0; dma_index < 128; dma_index = dma_index + 1)
            if (dma_memory[dma_index] !== (32'h6000_0000 + dma_index))
                $fatal(1, "DMA data mismatch word=%0d value=%h",
                       dma_index, dma_memory[dma_index]);
        mmio_write(BASE + 32'h008, 32'h0000_000a, 4'h1);

        // Missing response, hot removal, and explicit abort all return the
        // externally visible pins to a deterministic low-clock/released-CMD
        // state.
        mmio_write(BASE + 32'h008, 32'h0000_0006, 4'h1);
        mmio_write(BASE + 32'h014, 32'd0, 4'hf);
        mmio_write(BASE + 32'h018,
                   32'h0000_0800 | (32'd1 << 6) | 32'd13, 4'hf);
        wait_done();
        select_addr(BASE + 32'h02c);
        if (rdata !== 32'h0000_0001 || sd_clk !== 1'b0 ||
            sd_cmd_oe !== 1'b0)
            $fatal(1, "command timeout termination mismatch: %h", rdata);

        mmio_write(BASE + 32'h008, 32'h0000_0006, 4'h1);
        mmio_write(BASE + 32'h018,
                   32'h0000_0800 | (32'd1 << 6) | 32'd13, 4'hf);
        wait (dut.state == 5'd3);
        @(negedge clk);
        sd_detect_n = 1'b1;
        wait (dut.busy == 1'b0);
        select_addr(BASE + 32'h02c);
        if (rdata[6] !== 1'b1 || sd_clk !== 1'b0 ||
            sd_cmd_oe !== 1'b0)
            $fatal(1, "removal termination mismatch: %h", rdata);
        @(negedge clk);
        sd_detect_n = 1'b0;
        repeat (6) @(posedge clk);

        mmio_write(BASE + 32'h008, 32'h0000_0006, 4'h1);
        mmio_write(BASE + 32'h018,
                   32'h0000_0800 | (32'd1 << 6) | 32'd13, 4'hf);
        wait (dut.state == 5'd3);
        mmio_write(BASE + 32'h008, 32'h0000_000a, 4'h1);
        select_addr(BASE + 32'h00c);
        if (rdata[10] !== 1'b1 || rdata[0] !== 1'b0 ||
            sd_clk !== 1'b0 || sd_cmd_oe !== 1'b0)
            $fatal(1, "abort did not retain bus4/quiesce: %h", rdata);

        $display("SD_NATIVE_MMIO_PASS");
        $finish;
    end
endmodule
