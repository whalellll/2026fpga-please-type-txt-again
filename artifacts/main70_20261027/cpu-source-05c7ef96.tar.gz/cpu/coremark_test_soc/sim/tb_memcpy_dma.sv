`timescale 1ns/1ps

module tb_memcpy_dma;
    reg clk = 1'b0, resetn = 1'b0;
    always #5 clk = ~clk;
    reg reg_wr_en = 1'b0;
    reg [7:0] reg_wr_addr = 8'd0, reg_rd_addr = 8'd0;
    reg [31:0] reg_wr_data = 32'd0;
    reg [3:0] reg_wr_strb = 4'hf;
    wire [31:0] reg_rd_data;
    wire irq;
    wire [31:0] awaddr, wdata, araddr, rdata;
    wire [7:0] awlen, arlen;
    wire [2:0] awsize, arsize;
    wire [1:0] awburst, arburst, bresp, rresp;
    wire awvalid, awready, wlast, wvalid, wready;
    wire bvalid, bready, arvalid, arready, rlast, rvalid, rready;
    wire [3:0] wstrb, rid, bid;
    integer i, cycles, read_bursts, write_bursts;

    memcpy_dma_top #(.DDR_BASE(32'h1b00_0000), .DDR_BYTES(4096)) dut (
        .clk(clk), .resetn(resetn),
        .reg_wr_en(reg_wr_en), .reg_wr_addr(reg_wr_addr),
        .reg_wr_data(reg_wr_data), .reg_wr_strb(reg_wr_strb),
        .reg_rd_addr(reg_rd_addr), .reg_rd_data(reg_rd_data), .irq(irq),
        .m_axi_awaddr(awaddr), .m_axi_awlen(awlen),
        .m_axi_awsize(awsize), .m_axi_awburst(awburst),
        .m_axi_awvalid(awvalid), .m_axi_awready(awready),
        .m_axi_wdata(wdata), .m_axi_wstrb(wstrb),
        .m_axi_wlast(wlast), .m_axi_wvalid(wvalid),
        .m_axi_wready(wready), .m_axi_bresp(bresp),
        .m_axi_bvalid(bvalid), .m_axi_bready(bready),
        .m_axi_araddr(araddr), .m_axi_arlen(arlen),
        .m_axi_arsize(arsize), .m_axi_arburst(arburst),
        .m_axi_arvalid(arvalid), .m_axi_arready(arready),
        .m_axi_rdata(rdata), .m_axi_rresp(rresp),
        .m_axi_rlast(rlast), .m_axi_rvalid(rvalid),
        .m_axi_rready(rready)
    );
    axi_shared_ram #(.BASE(32'h1b00_0000), .BYTES(4096)) ram (
        .clk(clk), .resetn(resetn),
        .arid(4'hf), .araddr(araddr), .arlen(arlen),
        .arsize(arsize), .arburst(arburst), .arvalid(arvalid),
        .arready(arready), .rid(rid), .rdata(rdata),
        .rresp(rresp), .rlast(rlast), .rvalid(rvalid),
        .rready(rready), .awid(4'hf), .awaddr(awaddr),
        .awlen(awlen), .awsize(awsize), .awburst(awburst),
        .awvalid(awvalid), .awready(awready), .wid(4'hf),
        .wdata(wdata), .wstrb(wstrb), .wlast(wlast),
        .wvalid(wvalid), .wready(wready), .bid(bid),
        .bresp(bresp), .bvalid(bvalid), .bready(bready)
    );

    task write_reg(input [7:0] addr, input [31:0] data);
        begin
            @(negedge clk);
            reg_wr_addr = addr;
            reg_wr_data = data;
            reg_wr_en = 1'b1;
            @(negedge clk);
            reg_wr_en = 1'b0;
        end
    endtask

    always @(posedge clk) begin
        if (resetn) begin
            if (arvalid && arready) begin
                read_bursts <= read_bursts + 1;
                if ({1'b0, araddr[4:0]} + (({1'b0, arlen} + 1) << 2) > 32)
                    $fatal(1, "read burst crossed a DDR line");
            end
            if (awvalid && awready) begin
                write_bursts <= write_bursts + 1;
                if ({1'b0, awaddr[4:0]} + (({1'b0, awlen} + 1) << 2) > 32)
                    $fatal(1, "write burst crossed a DDR line");
            end
        end
    end

    initial begin
        read_bursts = 0;
        write_bursts = 0;
        for (i = 0; i < 20; i = i + 1) begin
            ram.memory[3+i] = 32'h1234_0000 + i;
            ram.memory[33+i] = 32'd0;
        end
        repeat (4) @(negedge clk);
        resetn = 1'b1;
        reg_rd_addr = 8'h00;
        #1;
        if (reg_rd_data != 32'h444d_4139)
            $fatal(1, "DMA ID mismatch");
        write_reg(8'h10, 32'h1b00_000c);
        write_reg(8'h14, 32'h1b00_0084);
        write_reg(8'h18, 32'd20);
        write_reg(8'h08, 32'h0000_0101);
        cycles = 0;
        while (!irq && cycles < 3000) begin
            @(negedge clk);
            cycles = cycles + 1;
        end
        if (!irq) $fatal(1, "DMA timed out");
        reg_rd_addr = 8'h0c;
        #1;
        if (reg_rd_data[1:0] != 2'b01)
            $fatal(1, "DMA status reports error: %h", reg_rd_data);
        reg_rd_addr = 8'h1c;
        #1;
        if (reg_rd_data != 32'd20)
            $fatal(1, "DMA word count mismatch: %d", reg_rd_data);
        for (i = 0; i < 20; i = i + 1)
            if (ram.memory[33+i] != 32'h1234_0000 + i)
                $fatal(1, "copy mismatch at word %0d", i);
        if (read_bursts < 3 || write_bursts < 3)
            $fatal(1, "expected multiple DDR-line-limited bursts");

        write_reg(8'h08, 32'h0000_0002);
        write_reg(8'h14, 32'h1b00_0010);
        write_reg(8'h08, 32'h0000_0001);
        reg_rd_addr = 8'h0c;
        #1;
        if (reg_rd_data[1:0] != 2'b11)
            $fatal(1, "overlapping copy was not rejected");
        $display("MEMCPY_DMA_PASS bursts=%0d/%0d cycles=%0d",
                 read_bursts, write_bursts, cycles);
        $finish;
    end
endmodule
