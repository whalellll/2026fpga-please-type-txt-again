`timescale 1ns/1ps

module tb_sd_spi_dma;
    localparam [31:0] BASE = 32'h1fe1_3000;
    localparam [31:0] DEST = 32'h0300_0000;

    reg clk = 1'b0;
    reg resetn = 1'b0;
    reg [31:0] addr = 32'd0;
    reg wr = 1'b0;
    reg [31:0] wdata = 32'd0;
    reg [3:0] wstrb = 4'd0;
    wire [31:0] rdata;
    wire hit;
    wire sd_clk;
    wire sd_mosi;
    reg sd_miso = 1'b1;
    wire sd_cs_n;
    reg sd_detect_n = 1'b1;

    wire [31:0] m_axi_awaddr;
    wire [7:0] m_axi_awlen;
    wire [2:0] m_axi_awsize;
    wire [1:0] m_axi_awburst;
    wire m_axi_awvalid;
    reg m_axi_awready = 1'b0;
    wire [31:0] m_axi_wdata;
    wire [3:0] m_axi_wstrb;
    wire m_axi_wlast;
    wire m_axi_wvalid;
    reg m_axi_wready = 1'b0;
    reg [1:0] m_axi_bresp = 2'b00;
    reg m_axi_bvalid = 1'b0;
    wire m_axi_bready;

    reg [31:0] write_addresses [0:127];
    reg [31:0] write_data [0:127];
    integer write_count = 0;
    reg aw_seen = 1'b0;
    reg w_seen = 1'b0;
    reg [31:0] saved_awaddr = 32'd0;
    reg [31:0] saved_wdata = 32'd0;
    reg corrupt_crc = 1'b0;
    reg force_axi_error = 1'b0;
    reg [7:0] card_shift = 8'hff;
    reg [15:0] payload_crc = 16'd0;
    reg [31:0] expected_word = 32'd0;
    integer i;

    always #5 clk = ~clk;

    task crc16_accumulate;
        input [7:0] value;
        integer bit_index;
        begin
            payload_crc = payload_crc ^ {value, 8'h00};
            for (bit_index = 0; bit_index < 8; bit_index = bit_index + 1)
                payload_crc = payload_crc[15]
                    ? {payload_crc[14:0], 1'b0} ^ 16'h1021
                    : {payload_crc[14:0], 1'b0};
        end
    endtask

    task payload_word_at;
        input integer index;
        output [31:0] value;
        begin
            value[7:0] = (index * 29 + 7) & 8'hff;
            value[15:8] = ((index + 1) * 29 + 7) & 8'hff;
            value[23:16] = ((index + 2) * 29 + 7) & 8'hff;
            value[31:24] = ((index + 3) * 29 + 7) & 8'hff;
        end
    endtask

    sd_spi_mmio #(
        .BASE(BASE),
        .RESET_DIV(16'd0),
        .DEBOUNCE_CYCLES(2)
    ) dut (
        .clk(clk), .resetn(resetn),
        .addr(addr), .wr(wr), .wdata(wdata), .wstrb(wstrb),
        .rdata(rdata), .hit(hit),
        .sd_clk(sd_clk), .sd_mosi(sd_mosi), .sd_miso(sd_miso),
        .sd_cs_n(sd_cs_n), .sd_detect_n(sd_detect_n),
        .m_axi_awaddr(m_axi_awaddr), .m_axi_awlen(m_axi_awlen),
        .m_axi_awsize(m_axi_awsize), .m_axi_awburst(m_axi_awburst),
        .m_axi_awvalid(m_axi_awvalid), .m_axi_awready(m_axi_awready),
        .m_axi_wdata(m_axi_wdata), .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wlast(m_axi_wlast), .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wready(m_axi_wready), .m_axi_bresp(m_axi_bresp),
        .m_axi_bvalid(m_axi_bvalid), .m_axi_bready(m_axi_bready)
    );

    task mmio_write;
        input [31:0] write_addr;
        input [31:0] write_data_value;
        begin
            @(negedge clk);
            addr = write_addr;
            wdata = write_data_value;
            wstrb = 4'h1;
            wr = 1'b1;
            @(posedge clk);
            #1;
            @(negedge clk);
            wr = 1'b0;
            wstrb = 4'd0;
            wdata = 32'd0;
        end
    endtask

    task start_transfer;
        input [31:0] destination;
        begin
            mmio_write(BASE + 32'h1c, 32'd2);
            mmio_write(BASE + 32'h18, destination);
            mmio_write(BASE + 32'h1c, 32'd1);
        end
    endtask

    // Supply the first bit before each automatically launched SPI byte.
    always @(negedge clk) begin
        if (resetn && dut.dma_busy && !dut.busy && !dut.dma_word_full) begin
            if (dut.dma_phase == 2'd0)
                card_shift = (dut.dma_bytes_done * 29 + 7) & 8'hff;
            else if (dut.dma_phase == 2'd1)
                card_shift = payload_crc[15:8];
            else
                card_shift = corrupt_crc ? (payload_crc[7:0] ^ 8'h01) :
                                           payload_crc[7:0];
            sd_miso = card_shift[7];
        end
    end

    always @(negedge sd_clk) begin
        if (dut.busy && dut.byte_dma) begin
            sd_miso = card_shift[6];
            card_shift = {card_shift[6:0], 1'b1};
        end
    end

    // Accept address and data independently, then return one AXI response.
    // Delaying every other data handshake exercises controller backpressure.
    always @(posedge clk) begin
        if (!resetn) begin
            m_axi_awready <= 1'b0;
            m_axi_wready <= 1'b0;
            m_axi_bvalid <= 1'b0;
            aw_seen <= 1'b0;
            w_seen <= 1'b0;
            write_count <= 0;
        end else begin
            m_axi_awready <= !aw_seen && !m_axi_bvalid;
            m_axi_wready <= !w_seen && !m_axi_bvalid &&
                            (write_count[0] == 1'b0 || aw_seen);

            if (m_axi_awvalid && m_axi_awready) begin
                aw_seen <= 1'b1;
                saved_awaddr <= m_axi_awaddr;
            end
            if (m_axi_wvalid && m_axi_wready) begin
                w_seen <= 1'b1;
                saved_wdata <= m_axi_wdata;
            end
            if ((aw_seen || (m_axi_awvalid && m_axi_awready)) &&
                (w_seen || (m_axi_wvalid && m_axi_wready)) &&
                !m_axi_bvalid) begin
                if (write_count >= 128)
                    $fatal(1, "too many AXI writes");
                write_addresses[write_count] <= aw_seen ? saved_awaddr :
                                                           m_axi_awaddr;
                write_data[write_count] <= w_seen ? saved_wdata : m_axi_wdata;
                write_count <= write_count + 1;
                aw_seen <= 1'b0;
                w_seen <= 1'b0;
                m_axi_bresp <= force_axi_error ? 2'b10 : 2'b00;
                m_axi_bvalid <= 1'b1;
            end
            if (m_axi_bvalid && m_axi_bready)
                m_axi_bvalid <= 1'b0;
        end
    end

    initial begin
        payload_crc = 16'd0;
        for (i = 0; i < 512; i = i + 1)
            crc16_accumulate((i * 29 + 7) & 8'hff);

        repeat (4) @(posedge clk);
        resetn = 1'b1;
        @(negedge clk);
        sd_detect_n = 1'b0;
        repeat (6) @(posedge clk);
        if (!dut.card_present)
            $fatal(1, "card insertion did not debounce");

        write_count = 0;
        corrupt_crc = 1'b0;
        start_transfer(DEST);
        wait (dut.dma_done);
        @(posedge clk);
        if (dut.dma_error || dut.dma_crc_error || dut.dma_axi_error ||
            dut.dma_address_error || dut.dma_bytes_done != 11'd512)
            $fatal(1, "DMA status mismatch busy=%b done=%b error=%b addr=%b crc=%b axi=%b count=%0d writes=%0d received=%h calculated=%h expected=%h",
                   dut.dma_busy, dut.dma_done, dut.dma_error,
                   dut.dma_address_error, dut.dma_crc_error,
                   dut.dma_axi_error, dut.dma_bytes_done, write_count,
                   dut.dma_received_crc, dut.dma_crc, payload_crc);
        if (dut.dma_received_crc != payload_crc || dut.dma_crc != payload_crc)
            $fatal(1, "DMA CRC mismatch: received=%h calculated=%h expected=%h",
                   dut.dma_received_crc, dut.dma_crc, payload_crc);
        if (write_count != 128)
            $fatal(1, "DMA write count mismatch: %0d", write_count);
        for (i = 0; i < 128; i = i + 1) begin
            if (write_addresses[i] !== DEST + i * 4)
                $fatal(1, "DMA address mismatch at %0d: %h", i,
                       write_addresses[i]);
            payload_word_at(i * 4, expected_word);
            if (write_data[i] !== expected_word)
                $fatal(1, "DMA data mismatch at %0d: %h", i, write_data[i]);
        end
        if (m_axi_awlen !== 8'd0 || m_axi_awsize !== 3'd2 ||
            m_axi_awburst !== 2'b01 || m_axi_wstrb !== 4'hf || !m_axi_wlast)
            $fatal(1, "DMA AXI attributes mismatch");

        write_count = 0;
        corrupt_crc = 1'b1;
        start_transfer(DEST + 32'h200);
        wait (dut.dma_done);
        @(posedge clk);
        if (!dut.dma_error || !dut.dma_crc_error || dut.dma_axi_error ||
            dut.dma_bytes_done != 11'd512 || write_count != 128)
            $fatal(1, "CRC error status mismatch");

        write_count = 0;
        corrupt_crc = 1'b0;
        start_transfer(DEST + 32'd2);
        @(posedge clk);
        if (!dut.dma_done || !dut.dma_error || !dut.dma_address_error ||
            dut.dma_busy || write_count != 0)
            $fatal(1, "unaligned destination was not rejected");

        $display("SD_SPI_DMA_PASS crc=%04x writes=128", payload_crc);
        $finish;
    end

    initial begin
        #2000000;
        $fatal(1, "SD DMA test timed out");
    end
endmodule
