# 新电脑开发与集成指南

## V3.5 当前适用范围（2026-10-08）

当前版本是未验收候选，开发分支为 `cpu-v3.5-development`，SoC 为
`soc-v6.5-development`。Doctor、Emit、Unit、Functional 和同步流程继续适用。
本轮只跑十次 CoreMark 短 RTL；下文 2600 次固件、Long/3+1 仿真命令及独立平台
正式成绩是 V3.1 历史复现说明，**不用于本次验收，不要求重新运行**。

本轮正式平台为完整 performance_soc 板卡：CPU >59.4 MHz，SYS/TIMEBASE=49.5 MHz，
最终双 corner STA、DRM <=140，连续三次有效 performance 均值至少
5.120849733668798 CoreMark/MHz，再一次 validation；各次 >=10 秒。新 CPU 另需
59.4 MHz 同频对照。只允许易失性 CRAM，不写 Flash 或 SD。

新源码包 schema 3 明确 `candidate` / `integrated_board`。正式打包传
`-ReleaseManifest <本仓库显式清单>`、`-PythonPath`、`-HostGccPath`，清单绑定本轮
SoC receipt。离线验包重新检查源码/RTL、原始 UART、CRC 和分数；host GCC 仅重算
正确性 CRC，不用于性能计分。未达标用 `-Candidate`，不建正式 tag。
旧 schema-2 V3.1 包仍使用原验收规则。

### 当前候选的重现入口

离线 ZIP 应先在原样解压目录验包，再添加本机配置或生成缓存。schema 3 会拒绝
清单以外的文件；`toolchain.local.json` 也应在首次验包后创建，或通过外部
`-Config C:\tools\cpu-local.json` 使用。可以直接指定解释器进行验包：

```powershell
.\cpu\scripts\verify_cpu_package.ps1 -Root . `
  -PythonPath C:\tools\python\python.exe -HostGccPath C:\msys64\mingw64\bin\gcc.exe
```

在 `cpu/` 中，先配置 Java、sbt、Verilator 和真实 GCC 16.2.0，再运行
`newpc.ps1 -Stage Emit`、`Unit`、`Functional`。当前 C1 默认为
`aluEntries=4, memEntries=2, fallbackSets=64, fallbackHash=true, rasDepth=2`；
两种生成 RTL 的配置与源码绑定在 `generated/manifest.json`。
本轮固件与短仿真入口如下，第二种模式使用独立结果目录：

```powershell
.\scripts\build_coremark.ps1 -Iterations 10 -RunMode performance `
  -EvidenceClass calibration -ToolchainRoot C:\tools\riscv32
.\scripts\build_coremark.ps1 -Iterations 10 -RunMode validation `
  -EvidenceClass calibration -OutputRoot .\coremark_test_soc\sim\coremark_validation `
  -ToolchainRoot C:\tools\riscv32
.\scripts\newpc.ps1 -Stage CoreMark
```

验证种子短测通过 `COREMARK_FIRMWARE_ROOT` 指向上述 validation 固件，配合独立
`COREMARK_RESULT_ROOT` 和 `COREMARK_BUILD_ROOT` 后使用同一 CoreMark 入口。
两种十次迭代测试均是 `CALIBRATION_ONLY`，官方最短运行时间检查不会给出正式成绩。
详细实际运行命令与原始结果在 [V3.5 验证记录](V3_5_VALIDATION.md)。

从 SoC 仓库执行 `scripts/sync_cpu.ps1 -SourceRepo ..\src` 后核对来源。
完成正式板测后才可按 `performance_soc/docs/BOARD_RELEASE.md` 导出可移植 receipt，
由 CPU 显式发布清单引用；仅文档交付提交不改变该 CPU 实现提交的来源身份。

```powershell
# 以下打包命令从 src 仓库根目录运行；二选一。
.\cpu\scripts\package_handoff.ps1 -Candidate
.\cpu\scripts\package_handoff.ps1 -ReleaseManifest <本轮CPU发布清单> `
  -PythonPath C:\tools\python\python.exe -HostGccPath C:\msys64\mingw64\bin\gcc.exe
```

## V3.1 历史复现与共用工具细节

本指南适用于 `src/main` 中的 CPU V3.1 开发目录 `cpu`。`src` 负责 CPU 优化，`coremark_test_soc` 负责低成本验证；独立 `performance_soc/linux` 负责完整板级集成。复制整个仓库即可取得源码、测试、固定固件、PDS 工程和文档；工具、许可和缓存需要在新电脑准备。

当前硬件与软件统一 RV32IMA，C 扩展及配置开关已退出当前源码。已选 GCC/ISA 的历史证据见 [V3 记录](VALIDATION.md)，本轮结果见 [V3.1 记录](V3_1_VALIDATION.md)。CPU 测试基座和完整 SoC 的时钟、计时器及最终时序分别验证。

## 1. 安装工具

比赛口径取自《全国大学生嵌入式芯片与系统设计竞赛 2026 FPGA 赛道选题指南—紫光同创》
正文第 8–9 页（PDF 第 10–11 页）：工具链 `riscv32-unknown-elf-gcc`、CoreMark v1.0、
计时不低于 10 秒，CPU 基础任务支持 RV32I。指南未锁定 GCC 版本、优化等级或扩展指令集。
当前工程按完整固件容量和同条件性能测试选择 GCC 16.2.0、O2、RV32IMA/ILP32；不是声称指南指定了这些值。
原 PDF SHA256：`8581797a38a82bd7879a936e1c7a140c62c5285f432bfb8c18877cfe7974dcaf`。

| 工具 | 用途与版本 |
| --- | --- |
| Windows PowerShell 5.1、Git | 工程入口、输入清单与哈希 |
| Windows x64 JDK 17 | 运行 sbt / Chisel |
| sbt launcher 1.10.1 | 项目固定 Scala 2.13.16、Chisel 6.7.0、chiseltest 6.0.0 |
| MSYS2、Verilator 5.050、make、MinGW g++、Python 3 | Windows 原生 RTL 回归，无需 WSL |
| 原生 RISC-V GCC 16.2.0 | 真实 `riscv32-unknown-elf-*`；默认 RV32IMA/ILP32 单一运行库，来源和构建配方已固定 |
| PDS 2022.2-SP6.4，合法许可 | PG2L100H-6-FBG676 综合及板级实现 |

工具链准备见 [工具链说明](toolchain/README.md) 和 [GCC 16.2 配方](toolchain/gcc16_2/README.md)。16.2 已通过真实构建、独立运行库检查、原目录隐藏且 PATH 清理后的迁移编译，以及两种 CoreMark 种子校验。本次原生源码构建与增量安装合计约 2 小时 38 分钟；也可使用哈希固定的可选 Windows 工具链 ZIP。GCC 14.2 的固定包安装器保留作比较基线及源码构建依赖准备，不能把它当作当前默认工具链。当前选择只代表已测试候选中更优，不保证所有 GCC 版本与选项的全局最优。

原生 Windows/MSYS2 是本次实际验证的可复建路线。已有 WSL2/Ubuntu 可使用替代入口，但需另行准备满足相同 target、版本和 RV32/ILP32 运行库契约的 Linux 工具链；本仓库提供的 UCRT GCC 安装包不能直接作为 Linux 工具链，Ubuntu 常见的 riscv64 编译器也不满足当前检查。WSL 路线本轮未运行，且不是打开或综合 PDS 的前提。不要为了修环境升级项目依赖；工具版本变化要记录并重新建立基线。

MSYS2 需要可运行的 `bash`、`python3`、`make`、`g++`、`sha256sum` 和支持 `--binary --timing` 的 Verilator。原生路线通过 `NativeBash` 与 `NativePath` 在同一环境运行，不混用两套编译器的工作目录。

sbt 首次启动需要下载依赖。可以在当前 PowerShell 设置 Maven Central 入口：

```powershell
$env:COURSIER_REPOSITORIES = 'https://repo.maven.apache.org/maven2'
```

若 sbt 启动器本身仍无法下载，创建本机 repositories 文件，例如：

```text
[repositories]
local
maven-central: https://repo.maven.apache.org/maven2/
```

在本机 JSON 设置 `MavenRepositories` 为该文件路径，入口自动传入
`-Dsbt.override.build.repos=true` 与 `-Dsbt.repository.config=...`。
`CoursierRepositories` 可直接设置上述 Coursier 地址；留空则沿用当前进程环境。
两种配置分别作用于 sbt 仓库选择和 Coursier 依赖下载。记录配置，不把下载失败当作 RTL 失败，
也不把代理凭证写入仓库。

## 2. 配置本机路径

进入复制后的 `src/cpu`：

```powershell
Copy-Item .\toolchain.native.example.json .\toolchain.local.json
```

编辑 `NativeBash`、`NativePath`、`Java`、`SbtLauncher`、`PdsShell` 与 `PdsStageRoot`，使用本机路径。`NativePath` 用 Windows 分号分隔，把 RISC-V bin 放在前面，再包含 MSYS2 MinGW 和 MSYS2 usr/bin；`RiscvPrefix` 为 `riscv32-unknown-elf-`。示例只是格式，不要求模仿原电脑盘符。

可选 `MavenRepositories` 路径相对本机 JSON 所在目录解析，也可填绝对路径。
`SbtJvmArguments` 是传给 Java、位于 `-jar` 之前的字符串数组，例如
`["-Dsbt.supershell=false"]`；`SbtArguments` 是 launcher 后、本次任务前的附加 sbt 参数/命令数组，
默认 `[]`。不需要这些设置时保留空值即可。

Windows PowerShell 5.1 会把重定向的普通 stderr 包成错误记录，`java -version` 与编译器警告也使用 stderr。
入口在 Java、WSL 调用期间允许这些输出，立即保存退出码、恢复原错误策略，再按退出码判断成败；
不能仅凭日志中的 `NativeCommandError` 字样判失败，也不能忽略实际非零退出码。

原生 Bash 使用本项目的 `scripts/bounded_process.cs` 启动器：进程先挂起、加入 Windows
Job Object 后再开始运行，后续 MSYS `exec`、编译器和仿真子进程都由同一个 job 管理。
stdout/stderr 直接写入 `work/logs/newpc-native/` 的独立文件，以实际进程退出码判定成败；
普通编译警告不会因此中止，而非零退出码仍会失败。

可选本机配置 `SimulationTimeoutSeconds` 对每次原生 Bash 调用设置总上限；普通阶段
默认 5400 秒，单次正式 CoreMark 重放默认 14400 秒，均允许 1～86400 秒，包含编译及其
后代进程。此字段不改变 WSL 调用；3+1 批量入口另用自己的 `-TimeoutSeconds` 参数。
超时会结束整个 job。入口打印 `owner_powershell_pid`；需要提前停止时，结束该 PowerShell
进程会关闭 job 并收束后代。阻塞的原生调用期间 Ctrl+C 可能延后处理，不保证即时响应，
也不能只杀 Bash 并假定脱链的 g++/仿真器已经停止。

PDS 暂存目录宜为可写 ASCII 路径；用户名含中文时显式设置 `PdsStageRoot`。打开检查使用含空格的子目录验证可移植性。本机配置和临时目录不进入 Git。

已有 WSL 路线使用 `toolchain.newpc.example.json`，配置 `WslDistribution`、Verilator 与 RISC-V 前缀，不设置 `NativeBash`。Windows 端仍需 JDK、sbt 和 PDS。

## 3. 先验环境，再重生成

逐条执行，失败先检查本步错误。不要同时运行两个 sbt，也不并行运行共享仿真目录的回归。

```powershell
.\scripts\newpc.ps1 -Stage Doctor
.\scripts\newpc.ps1 -Stage Emit
.\scripts\newpc.ps1 -Stage Unit
.\scripts\newpc.ps1 -Stage Functional
```

Doctor 检查工具并准备当前 IMA 固定输入，不安装工具。Emit 从固定 IMA 源码导出综合和带探针仿真 RTL，并刷新 `generated/sim/CoreTop.sv`；不再设置已移除的压缩扩展开关。单测覆盖 Decoder、CSR、PMA、RsMem 写回、LoadOrder 和前端流水线；包含访存顺序、call/return、反压及 flush 期间旧 refill。其他 `e91c.*` 属性由 `build.sbt` 传给 fork 的测试 JVM；旧 RVC 专项不是当前回归入口。

功能回归读取 `work/handoff-probes/CoreTop.sv`，必须来自本次 Emit，不能复制旧文件跳过重生成。综合交付使用 `generated/core/CoreTop.sv`；两种输出观察端口不同，不能混用。

Functional 共八项，新增 IALIGN32 整核测试覆盖 taken branch/JAL/JALR 的非字对齐目标、
未 taken 分支不应异常、压缩编码非法异常，以及精确 mepc/mtval 和 MRET。
只运行这一项可用 `scripts/newpc.ps1 -Stage Ialign32`；正常完整回归仍用 Functional。

Emit 前后核对源码清单，并生成 schema 2 的 `generated/manifest.json`，绑定全部 Scala/Chisel 输入、两份 RTL 及各自的 `emit-config.json`。配置文件来自实际 elaboration 参数；综合与仿真必须使用相同架构参数，探针模式分别为关闭和开启，不能只在清单里填写配置。Doctor、PDS 准备、功能/CoreMark 运行和对集成仓库的同步会拒绝过期产物；修改源码后必须重新 Emit。固件同样核对源文件、构建参数和五份程序输入，不能只改 JSON 标签。

当前架构参数为 `aluEntries=3`、`memEntries=2`、`fallbackSets=32`、
`fallbackHash=false`、`rasDepth=2`；精确命令保存在 `generated/manifest.json` 的 `generation`。
后续优化这些参数时，应让两次导出使用相同参数并重跑验证；不得手改 sidecar 或清单来匹配旧 RTL。

重编固件后，Doctor 若报告旧 `work/coremark-ima` 与当前输入不同，先保留该目录的实验结果，
再将整个目录改名归档并重新运行 Doctor。不要用重新 Emit 解决固件差异，也不要删除旧证据。
独立比较可通过 `COREMARK_FIRMWARE_ROOT`、`COREMARK_RESULT_ROOT` 与 `COREMARK_BUILD_ROOT`
指定不同输入、结果和模型目录，避免覆盖已有实验。

有缓存时 Doctor 通常不到 1 分钟；Emit/Unit 需数分钟，穷举译码、新机器或并发负载会更久。功能回归每个模型编译可能需数分钟，各仿真有 300 万周期上限；实际时间取决于工具和负载。首次依赖下载可能 5～20 分钟。长任务开始前说明时长及本节相应停止方式；不用无限重试或持续 DEBUG 日志。

## 4. 固件、ISA 与 CoreMark

六份 CoreMark 核心源码固定为官方 tag `v1.01`（程序报告 CoreMark 1.0），逐字节不修改。来源和哈希见 `coremark_test_soc/sw/coremark/upstream.json`，完整规则和构建选项见 [固件说明](../coremark_test_soc/sw/README.md)。所有核心文件使用相同编译选项；性能种子和验证种子分别运行。

当前软件目标为：

```text
-march=rv32ima_zicsr_zifencei -mabi=ilp32
```

`build_coremark.ps1` 从 `coremark_test_soc/sw` 自包含源码重编，不依赖相邻 `sw` 仓库。实际 CPU 时钟、固件 `CpuHz`、UART 分频和 PDS 约束必须匹配。具体候选配置以固件 `manifest.json` 和 VALIDATION 为准；调频后重编固件，不能只改输出标题。

```powershell
.\scripts\newpc.ps1 -Stage CoreMark
```

此命令重放包内固定的性能固件一次：正式固件自动使用计时检查、800M 周期上限和
默认 4 小时主机进程上限；校准固件自动使用短测检查。完整 3+1 正式矩阵使用下方
批量入口。直接不带参数运行 `build_coremark.ps1` 会产生十次迭代校准固件，
不应覆盖已发布的 2600 次正式 ROM。

当前 `coremark_test_soc/sim/coremark_ima` 保存正式性能 IMA 的 ELF、BIN、RAM hex、宏定义与完整构建清单；`coremark_test_soc/sim/coremark_validation` 保存独立验证固件。旧 ISA 比较只保留在 `handoff/validation/isa-comparison` 的结果、日志和构建清单中，重复固件已移除；当前 CPU 不运行 IMAC 软件。

十次迭代的 5.0146704183 CoreMark/MHz 是 V3 历史短仿真校准，仅用于估算正式迭代数。本轮三次性能种子 `(0,0,0x66)` 与一次验证种子 `(0x3415,0x3415,0x66)` 已分别按 CPU mcycle 计时至少 10 秒且通过 CRC 检查。三次性能均值为 5.052514868 CoreMark/MHz；[四例原始证据](validation/v3_1/source-coremark/README.md)与完整输入见 [V3.1 记录](V3_1_VALIDATION.md)。主机仿真耗时不是被测 CPU 时间，源仓结果不能充当集成 SoC 或板测成绩。

正式源仓测量固定 2600 次迭代、测试时钟 49.5 MHz。在 `cpu/` 内先分别构建两种
固件，再启动一次编译、四次独立仿真的批量入口：

```powershell
.\scripts\build_coremark.ps1 -Iterations 2600 -CpuHz 49500000 -RunMode performance -EvidenceClass formal_candidate -ToolchainRoot C:\tools\riscv32
.\scripts\build_coremark.ps1 -Iterations 2600 -CpuHz 49500000 -RunMode validation -EvidenceClass formal_candidate -OutputRoot .\coremark_test_soc\sim\coremark_validation -ToolchainRoot C:\tools\riscv32
.\scripts\run_coremark_release.ps1 -TimeoutSeconds 28800
```

批量入口使用同一份 Verilator `-Os` 主机模型，目标固件仍是 GCC 16.2.0 `-O2`；
每次结果目录包含原始 UART 日志、严格 CRC/时长检查、固件及 RTL 哈希。四个仿真并行，
默认总上限 5 小时，本次正式记录设置为 8 小时安全上限。结束启动它的 PowerShell
进程会关闭 Windows 作业并停止子进程。发布分数取四例正式结果与预先声明的三次性能均值/范围，
不能用一次重放或十次迭代短测代替。

构建脚本核实 GCC 版本与 `-dumpmachine`，不能从命令名字猜测实际 target。
当前 GCC 16.2 配方只有默认 RV32IMA/ILP32 运行库；用
`-march=rv32ima -mabi=ilp32 -print-libgcc-file-name` 查询并显式链接。
其 multilib 为 `.`；即便用 IM 查询仍会返回同一 IMA 库，不能声称它是独立 RV32IM 库。
GCC 14.2 比较包才需要显式查询 `rv32im/ilp32`，避免错误回退到浮点默认库。
真实运行库路径和哈希写入清单。库成员与最终 ELF 的 ELF32、soft-float、无 C 属性需要核验，
最终链接代码还要检查实际指令：通用 libgcc 中未被当前固件链接的 unwind 成员含 `vlenb` CSR，
仅看 ISA 属性不能证明整个库的所有函数适用。旧 13.2/15.3 固件仅作历史对照。

## 5. 从干净目录打开 PDS

```powershell
.\scripts\newpc.ps1 -Stage PdsPrepare
.\scripts\newpc.ps1 -Stage PdsCheck
```

然后在 GUI 打开 `coremark_test_soc/pds/coremark_test_soc.pds`。准备脚本验证五个工程输入和固件哈希，把 `ram.hex` 与三个 `scripts/meminit/zero_*.hex` 复制到工具所需位置，无需原电脑的 work。

原问题来自引用忽略的 `work/core-generated/CoreTop.sv`、缺少 FDC 和 ROM 准备。修复通过提交真实输入和可重建流程完成，不需要上传综合数据库。

`PdsCheck` 在全新暂存树中实际打开项目，上限 30 秒。`PdsSynthesis` 执行 Compile 和 ADS 综合，默认上限 60 分钟；超时停止本次进程树，PowerShell 等待 PDS 时 Ctrl+C 可能延迟响应。本机新 CPU / GCC 16.2 固件的本轮综合约六分钟，实际时间取决于电脑、RTL 与并发负载。每次尝试分别保留日志，状态会明确区分 `RUNNING`、`PASS`、`ERROR` 与 `TIMEOUT`；完成 Compile 不等于 ADS 综合完成。

```powershell
.\scripts\newpc.ps1 -Stage PdsSynthesis
```

日志和哈希在忽略的 `work/logs/pds-coremark`；脚本打印保留的 ADS 暂存目录。此测试 top 无真实板级管脚约束，综合通过不等于 P&R、实板运行或最高频率通过。旧 `Synthesis` 阶段保留完整 DMA 实验，不混用其历史数字。

综合后自动用配置中的 `PythonPath` 检查实际 ADS 网表，单独上限 300 秒。
四个分支通道、PMA 和地址提示控制必须通过，入口才报告综合 PASS；检查脚本随输入冻结。

本版固定 2600 次性能 ROM 的阶段状态、输入哈希、ADS 控制审计和资源数见
[V3.1 CPU 测试基座 PDS 记录](validation/v3_1/source-pds/README.md)；
[旧 GCC 16.2 PDS 记录](validation/pds-synthesis-gcc16/result.json)保留为修复前对照。
必须同时有 ADS 完成和关键控制路径保留证据，不能把 Compile 完成或有界超时写成综合通过。

## 6. 同步到 performance_soc

确认目标仓库为 `linux` 分支并保留现有改动，再在其根目录执行：

```powershell
.\scripts\sync_cpu.ps1 -SourceRepo '..\src'
.\scripts\sync_cpu.ps1 -SourceRepo '..\src' -Check
.\scripts\prepare_pds_project.ps1
.\scripts\run_all_tests.ps1
```

CPU 源文件映射为 `src/cpu/generated/core/CoreTop.sv` → `performance_soc/rtl/cpu/CoreTop.sv`。同步脚本同时复制综合侧 `emit-config.json`，并从 `src/cpu/scripts/meminit/` 复制三个初始化文件到 `rtl/cpu/meminit/`；干净副本无需先运行 Java/Emit 即可同步。`source.json` 记录源提交/工作区状态、生成源码摘要和输入哈希。不带 `.git` 的源码包也可同步：记录为 `exported_directory`，Git 提交/工作区状态为 null，仍严格校验生成清单；不会冒充干净 Git 提交。同步不等于发布或验收。

`performance_soc/rtl/cpu_top.v` 的 `cpu_core_top` 是兼容包装层，维护 32 位 AXI 数据、4 位 ID、复位向量 `0x1c000000`、CLINT 和中断接线。不要用 `coremark_soc_top` 或旧 VexRiscv 文件替换它。包装层、DDR 缓存/高别名属性变化需要独立集成回归。

CPU 引用的初始化路径为 `scripts/meminit/zero_1024.hex`、`zero_2048.hex`、`zero_4096.hex`。performance_soc 的准备脚本将它们复制到 `pds/scripts/meminit/`，CLI 构建也调用同一准备入口。初始化受 `ENABLE_INITIAL_MEM_` 宏控制；保留完整输入，不依赖旧目录碰巧存在，也不随意新增宏改变硬件。

完成 RTL 回归、最终综合、P&R 时序和 ADS 关键控制信号检查后，再进行板测。console、debug、DDR、SD、视频/相机、音频、键鼠及其他非 Linux 功能按集成仓库验收。Linux 启动本轮未测试，旧 CPU 的 Linux 成功记录不能沿用。

## 7. 交付与故障排查

`.pds`、`.fdc`、初始化源、固件及哈希清单跟随源码。work、sbt/PDS 缓存、本机配置和调试日志不进入源码包。`package_handoff.ps1` 按 Git 输入清单生成 ZIP 与清单，`VerifyPackage` 验证该清单；源码变化导致旧清单失效属于预期，哈希检查不代替回归。

正式交接优先完整克隆或复制 `src` 仓库。离线发布包名为 `CPU_V3.1_source.zip`；
解压后保留 `CPU/README.md`、`CPU/AGENTS.md`、`CPU/VERSION`、根 `.gitattributes`/`.gitignore`
与 `CPU/cpu/` 的仓库层次，
从后者运行脚本，不能把根规则移入子项目导致路径错层。清单 schema 2 的文件路径
相对 `CPU`，包含根说明与 Git 规则；`newpc -Stage VerifyPackage` 自动按此范围核验。
根文件固定 LF，子项目按受控属性保存字节，避免 Windows `core.autocrlf` 破坏交接哈希。

```powershell
python .\scripts\export_handoff_docx.py
.\scripts\package_handoff.ps1
```

DOCX 输出 `handoff/新电脑开发与集成指南.docx`，仅使用 Python 标准库，可重复生成；Markdown 为权威源。`package_handoff.ps1` 需要源仓库的 Git 输入清单，因此上述打包命令在 Git 工作区运行。无 `.git` 的离线包仍可验证、构建和同步；再次打包前须建立正确层次的 Git 仓库并核对要交付的文件。

| 故障 | 处理 |
| --- | --- |
| PDS 指向 work 或缺 ROM | 运行 PdsPrepare/PdsCheck，不复制旧数据库 |
| 找不到 Java/sbt | 修正本机 JSON，使用 Windows JDK 17 |
| 依赖下载失败 | 检查 Maven 与网络，保持依赖版本不变 |
| MSYS 找不到工具 | 检查 NativeBash/NativePath，运行 Doctor |
| 仿真缺探针或结果异常 | 重跑 Emit，核对输入 RTL 哈希 |
| ELF 出现 RVC/ELF64 | 检查 march、ABI、libgcc，重新构建 |
| JTAG 无器件/无串口 | 记录硬件缺口，不填写板测数据 |
