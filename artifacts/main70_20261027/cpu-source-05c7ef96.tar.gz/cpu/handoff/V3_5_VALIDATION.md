# CPU V3.5 候选验证（尚未正式发布）

本轮开发始于2026-10-08北京时间20:55:41，24小时或6次完整PDS布局布线为上限。
完整SoC统一管理预算，包括新CPU 59.4 MHz对照和最终冻结构建。

首选C1：ROB结果归属写入去除rename分配控制，逐tag valid保持清除优先；
后备BTB 64组、索引哈希开启，ALU保留站4项，MEM2/RAS2保持。
没有新增流水级。实际参数以两份emit-config和生成manifest为准。

| 验证/测量 | 当前事实 | 限制 |
|---|---|---|
| ROB tag复用定向测试 | 5项通过，含5写回来源×2分配lane | 模块行为，不是ADS/时序证明 |
| C1 源码与双导出 | schema 2 绑定通过，实际参数64组/hash/ALU4/MEM2/RAS2 | RTL与筛选C1字节相同，源码默认值另有最终哈希 |
| 同固件基线与ROB-only短测 | 都为1,994,149 mcycle，CRC一致 | 原历史GCC16.2十次固件，本轮重新运行 |
| BTB64哈希+ALU4短测 | 1,922,718 mcycle，相对独立短测基线约+3.715% | 不是集成板测或正式CoreMark分数 |
| 全CPU单元套件 | 本轮C1：32 suite / 93 tests全部通过；780秒 | 模块级回归，不替代整核与板测 |
| BTB哈希补充定向 | 32/64/128组共3项全部通过；169秒 | 补64组容量的冲突/替换覆盖，原93项归档不改写 |
| 本轮默认短固件 | performance/validation各10次，GCC16.2.0/O2重新构建完成 | performance bin/ram.hex与筛选固件相同；执行结果另行记录 |
| 本轮新短测执行 | performance 1,922,718 ticks / validation 1,929,662 ticks；全部CRC一致 | 仅约0.039秒，均为CALIBRATION_ONLY，不能作正式分数 |
| 短测证据检查正反例 | 12项通过 | 拒绝错final CRC、缺DONE、错时钟、错固件、短测伪正式 |
| CPU整核8项 | 本轮8项全部通过，GCC16.2.0，双job构建 | 45分钟硬上限；每项3M cycle上限 |
| SoC RTL回归 | 由集成仓库单独记录 | CPU整核通过不替代SoC回归 |
| C1集成ADS诊断 | LUT49,222 / FF37,933 / LUTRAM4,530 / DRM140 / latch0；控制保留有限审查通过 | 旧ROM、59.4 MHz隔离综合，无PnR/STA/板测结论 |
| 最终输入ADS/资源/slow-fast STA | 未完成 | DRM上限140，不能以诊断综合估频代替 |
| 新CPU 59.4 MHz对照 | 未完成 | 正式板测需要连接及加载身份 |
| 最终频率板测3+1 | 未完成 | CPU须>59.4 MHz，均值须>=5.120849733668798 |

完整候选原始UART、ticks、CRC、profile计数和共同源快照见
[candidate-search](validation/v3_5/candidate-search/README.md)。主机Verilator的-Os
只影响仿真速度；目标固件固定GCC16.2.0/O2/RV32IMA。

正式比较基线是V6.1完整SoC在59.4 MHz、SYS/TIMEBASE49.5 MHz的板测三次均值
5.070148251157226 CoreMark/MHz。用户确认历史板上使用V6.1发布文件；历史记录无
FPGA配置读回。独立CPU V3.1的5.052514868来自mcycle长仿真，单独保留，不作本轮基线。
没有本轮独立CPU平台正式分数。Linux启动和全部外设全面验收不作新增目标。

本轮 C1 综合 RTL SHA256 为
`24a90e98139ea0f26dd431f28d448b75196193b90aa6fecc258c3d3e09fa16c6`，
仿真 RTL 为 `21bab67fda4bd95a589cbda6822fb85d126dccc2d635b36ee39b7c2aec033c15`。
两者与 `hash64-alu4` 筛选原字节相同，见 `candidate-search/selection.json`。
生成清单为 `66100bfd497708141af0b087e897663560bff9bf3edf8b0db078ae1d854e5660`。
改变默认值前的全部50个生成输入已归档为 `candidate-search/common-source`，
每一候选由同一源快照加各自显式 generation 参数重现。

完整CPU单元原始日志、32份XML报告、测试源码哈希及实际生成配置见
[c1-unit/result.json](validation/v3_5/c1-unit/result.json)。执行命令为
`;set Test / parallelExecution := false; test`，单次硬上限1800秒；93项全部成功，0失败、0中止、0忽略。
随后仅在 `FallbackIndexSpec` 参数列表加入64组，再执行该suite的32/64/128组共3项，
169秒全部成功，单次硬上限300秒。原93项的日志和测试源码哈希保持原样；补充日志、XML、
测试源码原文及其与原回归的关联见 [c1-btb64-index/result.json](validation/v3_5/c1-btb64-index/result.json)。
此补测没有改变主源码或生成RTL。

整核基础指令、原子操作、机器态、访存顺序、总线错误、IALIGN32及两种写错误注入均通过，
见 [c1-functional/result.json](validation/v3_5/c1-functional/result.json)。保存八项原始日志、
现有runner生成的oracle和42项输入文件哈希，并在归档时再次核对输入未变。
`write-bresp` 原runner仅保存原始PASS日志，其oracle可由归档生成器和模式参数重建；
`write-fill` 另保留最后的原始oracle。没有把RTL错误注入测试描述为板上外设验收。

新短固件构建身份和新旧映像比较见 [c1-firmware/result.json](validation/v3_5/c1-firmware/result.json)。
performance 的 bin 和 ram.hex 字节相同；ELF差异仅在不加载的 `.debug_info`、`.debug_line`、
`.debug_line_str`，完整差异哈希另行保留。没有将历史构建冒称本轮重新编译。
新固件两种短测的完整原始UART、ticks、CRC、仿真输入、主机模型哈希及验收正反例见
[c1-short-rtl/summary.json](validation/v3_5/c1-short-rtl/summary.json)。performance周期精确复现筛选C1；
validation只作独立正确性检查，不计入performance比较。模式对应最终CRC为performance10 `fcaf`、
validation10 `c64e`；已由同一固定官方算法源码的主机正确性oracle独立核验。
主机oracle不是性能测量；其wrapper和源文件哈希保存在c1-firmware中。

C1诊断综合摘要副本和BTB结构审查见 [c1-ads-diagnostic/soc-summary.json](validation/v3_5/c1-ads-diagnostic/soc-summary.json)。
集成仓库完整原始证据位于 `performance_soc/docs/validation/v6_5-c1-ads-20261008/`；
run ID为 `2cb924fe380a46fa8ac3186cf60dfecf`，VM哈希见摘要。BTB两路均为64深度LUTRAM，
valid0/valid1/replaceWay各64 FF；query/update六位XOR均保留，query低两位与TAGE逻辑合法共享。
此诊断使用旧ROM，不消耗PnR次数，也不替代最终冻结输入的ADS、完整STA和板测。

正式源码包须绑定本轮集成SoC receipt，验证源码/RTL与板测输入一致。
全部门禁通过前不建V3.5/v6.5 tag；若预算用完或验收不全，只交付可复现候选及明确缺口。
