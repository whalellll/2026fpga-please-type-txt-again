volatile unsigned long long dividend = 0x1234567812345678ULL;
volatile unsigned long long divisor = 97;
volatile unsigned long long quotient;
volatile unsigned counter = 3;

void _start(void) {
    quotient = dividend / divisor;
    __atomic_fetch_add(&counter, 2U, __ATOMIC_RELAXED);
    for (;;) __asm__ volatile ("nop");
}
