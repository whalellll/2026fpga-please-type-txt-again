# 独立 RISC-V 工具链

当前默认是 **GCC 16.2.0 / O2 / RV32IMA / ILP32**，实际目标为
`riscv32-unknown-elf`。在相同 CPU 与官方源码下，它通过性能和验证种子检查，
比 14.2/O2 更快；完整集成固件也能保留至少 16 KiB 栈。两版 O3 都不满足完整固件容量要求。
比较见 [当前 CPU 校准](../validation/compiler-comparison/cpu01747/README.md)。

新电脑优先按 [GCC 16.2 构建与迁移说明](gcc16_2/README.md) 准备当前版本。
锁定的 GNU 源码、实际宿主工具、构建配方、运行库检查、迁移证据与许可说明都在该目录。
它生成 Windows 原生编译器，只有一个默认 RV32IMA/ILP32 libgcc，没有 RV32IM multilib。
源码构建耗时较长；可选便利包为 `contest-riscv32-gcc16.2.0-windows-rv32ima.zip`，
62,328,332 字节，SHA256
`fd02cc748d605497be00e7ea0af7b3b87c9b7634fd05361a4e6a3068249e81d3`。
该 ZIP 位于开发机独立工具目录，不进入 Git，也不是源码重建配方的必要输入；
单独交接 ZIP 时按 [归档记录](gcc16_2/binary-bundle.json) 校验。

将实际安装目录的 `bin` 配入本机 `NativePath`；固件构建的 `-ToolchainRoot`
传入安装根目录，即 `bin` 的父目录。不能只把 14.2 的目录改名为 16.2；Doctor 和构建入口会核实实际版本。

## GCC 14.2 比较基线

`gcc14_2/packages.lock.json` 固定 12 个 MSYS2 官方 UCRT64 包的版本、下载 URL、
SHA256、大小和依赖。可执行文件的真实配置目标为 `riscv32-unknown-elf`，
GCC 版本为 `14.2.0`；没有将其他 target 的编译器改名。

比赛指南点名 `riscv32-unknown-elf-gcc`，没有指定 GCC 14.2 或唯一优化等级。
这里的 14.2 是已验证、可重现的 Windows 比较基线，不是当前默认版本。
下面的安装器也提供 GCC 16.2 源码构建所复用的固定 binutils、新库头文件及包缓存。

## 安装比较基线与构建依赖

需要 Windows x86_64、带可用 HTTPS/SSL 的原生 Windows Python 3.8 以上，以及明确指定的、内置 `libzstd` 支持的
`bsdtar.exe`。例如 MSYS2 的 `usr/bin/bsdtar.exe`；不需要现有 `mingw64` 编译器
或 DLL。用 `bsdtar --version` 核对输出包含 `libzstd/`。
部分 Windows 自带 `tar.exe` 没有该能力，脚本会提前拒绝。
可用 `python -c "import ssl; print(ssl.OPENSSL_VERSION)"` 检查 Python；若使用
Anaconda，应在其正确激活的环境中调用。完整离线缓存不需要发起 HTTPS 请求。

从 `src/cpu` 执行，目标目录必须尚不存在，建议使用简短的 ASCII 路径：

```powershell
python .\scripts\install_contest_toolchain.py `
  --destination C:\tools\cpu-gcc-14.2 `
  --tar C:\msys64\usr\bin\bsdtar.exe
```

约下载 200 MB、解压 1.32 GB，预留至少 2 GiB 空间。首次下载通常需要数分钟，
受网络影响；默认总时限 1800 秒，可用 `--timeout-seconds` 在 60～3600 秒内调整。
每个包下载最多 300 秒，网络读操作超时 15 秒；外部命令单独限时。
Ctrl+C 中断会保留已下载文件和诊断记录；外部命令异常时会停止其进程树。
网络调用中的中断可能等待当前读操作返回。

脚本不调用 pacman、不运行包安装脚本、不修改系统 PATH、不覆盖已有工具链，
也不递归删除目录。目标/缓存路径拒绝符号链接和 Windows junction。
每个包先按受控 SHA256 校验，再检查归档路径、条目类型和硬链接目标，
仅提取 `ucrt64/*`；符号链接和越界路径会失败。

已有包缓存可复用：

```powershell
python .\scripts\install_contest_toolchain.py `
  --destination C:\tools\cpu-gcc-14.2-new `
  --tar C:\msys64\usr\bin\bsdtar.exe --cache D:\downloads\riscv-packages
```

缓存内容仍逐包核对 SHA256。中断后的 `.partial` 或哈希错误文件会保留，需检查后
再处理；重试安装应使用新的目标目录。若官方已移除某个固定版本，使用原始包缓存，
不能自动替换成同名更新版本。

## 使用与验证边界

安装末尾只给子进程设置 `新目录/ucrt64/bin + Windows 系统目录` 的 PATH，
核对 target、版本、运行库哈希，并重建含 AMO 和 64 位除法的裸机探针。
探针必须与独立审计过的 ELF 字节哈希相同。结果在目标目录的
`install-result.json`，编译诊断在 `validation/`。探针只被编译、反汇编审计，
没有在 CPU 或开发板上执行。

构建项目时，将安装后的 `ucrt64/bin` 放入当前进程或 `toolchain.local.json`
的 `NativePath`，并配置 `RiscvPrefix` 为 `riscv32-unknown-elf-`。
脚本本身不替你修改本机配置或永久环境变量。

这套发行包没有精确 IMA multilib 映射。应用编译参数为
`-march=rv32ima_zicsr_zifencei -mabi=ilp32`，但自动查询 IMA 运行库会选到不兼容的
默认浮点库。必须用 `-march=rv32im -mabi=ilp32 -print-libgcc-file-name` 查询
兼容的 `rv32im/ilp32/libgcc.a` 并显式链接，应用代码仍按 IMA 编译。
该库哈希也在锁文件中。最终应用 ELF 仍需检查 ISA、ABI 和实际指令；通用库中
未被链接的 unwind 成员含 `vlenb` CSR 读取，不能仅凭整个库名称宣称所有成员适用。

`gcc14_2/baseline-result.json` 保存初始工具链审计；`probe.c`、ELF 属性和反汇编
给出对应输入与证据。原始 12 个包和数据库曾使用 MSYS2 开发密钥环验证签名，
简明记录在 `package-signature-evidence.json`。新安装脚本校验受控 SHA256，
没有声称重新执行 OpenPGP 签名验证。

`recipe-source.json` 区分当前审阅配方 commit 与二进制包 `.BUILDINFO` 中的配方
SHA256；二者不能等同。精确历史构建配方 Git commit 尚未解析，固定官方二进制包
的下载、哈希和安装不依赖这一未解决项。

七份架构汇编的 GCC 13.2/14.2 原始 BIN 对照见
`../validation/architecture-gcc13_2/compiler14_2-bin-comparison.json`。
其全部字节相同，因此对应原有仿真程序；这是编译对照，没有重新运行仿真。
