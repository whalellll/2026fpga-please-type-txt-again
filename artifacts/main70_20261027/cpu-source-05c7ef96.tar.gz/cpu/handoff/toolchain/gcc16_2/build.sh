#!/usr/bin/env bash
set -euo pipefail
export PATH=/mingw64/bin:/usr/bin:/usr/bin/core_perl
TASK_ROOT=$(cygpath -u "$1")
DEPS=$(cygpath -u "$2")
CACHE=$(cygpath -u "$3")
RECIPE=$(cygpath -u "$4")
MODE=$5
PREFIX="$TASK_ROOT/native"
SOURCE="$TASK_ROOT/source/gcc-16.2.0"
export PATH=/mingw64/bin:/usr/bin:/usr/bin/core_perl
export MSYSTEM=MINGW64 MINGW_PREFIX=/mingw64 LC_ALL=C LANG=C
unset GCC_EXEC_PREFIX COMPILER_PATH LIBRARY_PATH CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH OBJC_INCLUDE_PATH
export CC=/mingw64/bin/gcc CXX=/mingw64/bin/g++
export CFLAGS='-O2 -g0' CXXFLAGS='-O2 -g0'
export LDFLAGS='-static -static-libgcc -static-libstdc++ -Wl,--stack,12582912'
export CFLAGS_FOR_TARGET='-g -Os -ffunction-sections -fdata-sections'
export CXXFLAGS_FOR_TARGET="$CFLAGS_FOR_TARGET"
mkdir -p "$TASK_ROOT/logs" "$TASK_ROOT/metadata" "$TASK_ROOT/downloads" "$TASK_ROOT/source" "$TASK_ROOT/build" "$PREFIX"
for command in make bison flex gawk sed patch tar bsdtar m4 diff cmp perl python3 curl sha256sum sha512sum; do command -v "$command" >/dev/null; done
for file in /mingw64/include/gmp.h /mingw64/include/mpfr.h /mingw64/include/mpc.h /mingw64/lib/libgmp.a /mingw64/lib/libmpfr.a /mingw64/lib/libmpc.a /mingw64/lib/libiconv.a /mingw64/lib/libzstd.a /mingw64/lib/libwinpthread.a; do test -f "$file"; done
test "$("$CC" -dumpmachine)" = x86_64-w64-mingw32
{
  date -u +%Y-%m-%dT%H:%M:%SZ
  "$CC" --version | head -1
  "$CXX" --version | head -1
  make --version | head -1
  /usr/bin/pacman -Q mingw-w64-x86_64-gcc mingw-w64-x86_64-gmp mingw-w64-x86_64-mpfr mingw-w64-x86_64-mpc mingw-w64-x86_64-libiconv mingw-w64-x86_64-zstd mingw-w64-x86_64-libwinpthread make bison flex gawk sed patch tar m4 diffutils perl python
  sha256sum /mingw64/bin/gcc.exe /mingw64/bin/g++.exe /mingw64/lib/libgmp.a /mingw64/lib/libmpfr.a /mingw64/lib/libmpc.a /mingw64/lib/libiconv.a /mingw64/lib/libzstd.a /mingw64/lib/libwinpthread.a
} > "$TASK_ROOT/metadata/host-dependencies.txt"
python3 "$RECIPE/prepare.py" "$TASK_ROOT" "$CACHE" "$RECIPE" "$MODE"
if [[ "$MODE" == preflight ]]; then echo PREFLIGHT_PASS; exit 0; fi
export PATH="/mingw64/bin:$PREFIX/bin:/usr/bin:/usr/bin/core_perl"
for tool in ar as ld nm ranlib objcopy objdump; do
  name="${tool^^}_FOR_TARGET"
  export "$name=$PREFIX/bin/riscv32-unknown-elf-$tool.exe"
done
if [[ ! -f "$SOURCE/configure" ]]; then
  echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) extracting GCC source"
  tar -xf "$TASK_ROOT/downloads/gcc-16.2.0.tar.xz" -C "$TASK_ROOT/source"
fi
cd "$TASK_ROOT/build"
CONFIGURE_ARGS=(
  --build=x86_64-w64-mingw32 --host=x86_64-w64-mingw32 --target=riscv32-unknown-elf
  --prefix="$PREFIX" --libexecdir="$PREFIX/lib"
  --enable-languages=c --with-arch=rv32ima --with-abi=ilp32
  --without-headers --with-newlib --disable-bootstrap --disable-multilib
  --disable-nls --disable-shared --disable-threads --disable-tls
  --disable-libssp --disable-libgomp --disable-libquadmath --disable-libatomic
  --disable-libsanitizer --disable-libstdcxx --disable-libvtv --disable-libada
  --disable-lto --disable-plugin --disable-werror --disable-decimal-float
  --with-gmp=/mingw64 --with-mpfr=/mingw64 --with-mpc=/mingw64 --without-isl
  --with-gnu-as --with-gnu-ld
  --with-as="$(cygpath -m "$AS_FOR_TARGET")" --with-ld="$(cygpath -m "$LD_FOR_TARGET")"
)
printf '%q ' ../source/gcc-16.2.0/configure "${CONFIGURE_ARGS[@]}" > "$TASK_ROOT/metadata/configure-command.txt"
printf '\n' >> "$TASK_ROOT/metadata/configure-command.txt"
STAMP=$(date -u +%Y%m%d-%H%M%S)
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) configuring GCC"
../source/gcc-16.2.0/configure "${CONFIGURE_ARGS[@]}" > "$TASK_ROOT/logs/$STAMP-configure.log" 2>&1
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) make -j2 all-gcc"
make -j2 all-gcc > "$TASK_ROOT/logs/$STAMP-all-gcc.log" 2>&1
test "$(df -Pk "$TASK_ROOT" | awk 'NR==2 {print $4}')" -ge 12582912
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) make -j2 all-target-libgcc"
make -j2 all-target-libgcc INHIBIT_LIBC_CFLAGS='-Dinhibit_libc -DUSE_TM_CLONE_REGISTRY=0' > "$TASK_ROOT/logs/$STAMP-libgcc.log" 2>&1
make -j2 install-gcc install-target-libgcc > "$TASK_ROOT/logs/$STAMP-install.log" 2>&1
python3 "$RECIPE/prepare.py" "$TASK_ROOT" "$CACHE" "$RECIPE" headers
mkdir -p "$PREFIX/share/licenses/gcc-source-build"
cp "$SOURCE"/COPYING* "$PREFIX/share/licenses/gcc-source-build/"
cp "$RECIPE/sources.lock.json" "$PREFIX/share/licenses/gcc-source-build/"
"$PREFIX/bin/riscv32-unknown-elf-gcc.exe" -dumpmachine
"$PREFIX/bin/riscv32-unknown-elf-gcc.exe" -dumpfullversion
echo GCC_BUILD_COMPLETE_PENDING_VALIDATION
