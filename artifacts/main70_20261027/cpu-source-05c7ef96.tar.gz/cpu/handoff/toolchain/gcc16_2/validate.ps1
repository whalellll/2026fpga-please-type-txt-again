[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$MsysRoot,
    [Parameter(Mandatory=$true)][string]$BuildRoot,
    [Parameter(Mandatory=$true)][string]$RelocatedRoot
)
$ErrorActionPreference = 'Stop'
$recipeRoot = $PSScriptRoot
$projectRoot = [IO.Path]::GetFullPath((Join-Path $recipeRoot '..\..\..'))
$MsysRoot = [IO.Path]::GetFullPath($MsysRoot)
$BuildRoot = [IO.Path]::GetFullPath($BuildRoot)
$RelocatedRoot = [IO.Path]::GetFullPath($RelocatedRoot)
$ownerFile = Join-Path $BuildRoot 'build-owner.json'
if (!(Test-Path -LiteralPath $ownerFile)) { $ownerFile = Join-Path $BuildRoot 'metadata\build-owner.json' }
$owner = Get-Content -LiteralPath $ownerFile -Raw | ConvertFrom-Json
if (!$owner.end_utc -or $owner.exit_code -ne 0) { throw 'The build must have completed successfully before validation.' }
if ($owner.mode -eq 'preflight') { throw 'A successful preflight is not a completed compiler build.' }
if (Test-Path -LiteralPath $RelocatedRoot) { throw 'Choose a new relocation destination; never overwrite an existing toolchain.' }
if ($RelocatedRoot.StartsWith($BuildRoot.TrimEnd('\') + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Relocation directory must be outside the original build directory.' }
Add-Type -Path (Join-Path $projectRoot 'scripts\bounded_process.cs')
New-Item -ItemType Directory -Path (Join-Path $BuildRoot 'validation') -Force | Out-Null
$bash = Join-Path $MsysRoot 'usr\bin\bash.exe'
$arguments = '"' + (Join-Path $recipeRoot 'validate.sh').Replace('\','/') + '" "' + $BuildRoot.Replace('\','/') + '"'
Write-Output "Validation owner PID $PID; each stage bounded; stop with Stop-Process -Id $PID"
$exit = [CpuSimulation.BoundedProcess]::Run($bash,$arguments,$BuildRoot,(Join-Path $BuildRoot 'validation\driver.log'),(Join-Path $BuildRoot 'validation\driver.stderr.log'),300)
if ($exit -ne 0) { throw "Compiler/runtime validation failed: $exit" }
$arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $recipeRoot 'relocate.ps1').Replace('\','/') + '" -BuildRoot "' + $BuildRoot.Replace('\','/') + '" -RelocatedRoot "' + $RelocatedRoot.Replace('\','/') + '"'
$exit = [CpuSimulation.BoundedProcess]::Run((Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'),$arguments,$BuildRoot,(Join-Path $BuildRoot 'validation\relocation-driver.log'),(Join-Path $BuildRoot 'validation\relocation-driver.stderr.log'),600)
if ($exit -ne 0) { throw "Relocation validation failed: $exit; inspect any native.relocation-hidden directory before further use." }
Write-Output 'COMPILER_RUNTIME_AND_RELOCATION_VALIDATION_PASS'
