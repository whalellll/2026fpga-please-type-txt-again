# First build observations

The experiment began on 2026-10-01 at 10:56:19 UTC with two make jobs and a
four-hour deadline. The main build completed successfully at 13:18:50 UTC; the
tracked portable recipe then reused that object tree and completed its incremental
configuration/runtime/installation at 13:35:29 UTC. Static and relocation checks
passed subsequently. These are compiler-build results, not CPU or CoreMark results.

The first `all-gcc` attempt stopped when the native Windows `gengtype.exe` read
`gtyp-input.list`. An absolute MSYS source directory had written `/d/...` names
inside that text file. Shell argument conversion does not apply to strings read
later from a file, so the generator reported `libcpp/include/line-map.h` missing
although the source file existed. The resumed configure invocation uses the
relative `../source/gcc-16.2.0/configure` path. The old generated GCC Makefile was
preserved before regeneration. GNU source files were not patched.

The target runtime make override preserves both `-Dinhibit_libc` and
`-DUSE_TM_CLONE_REGISTRY=0`. The generated Makefile explicitly set
`inhibit_libc = true`; overriding `INHIBIT_LIBC_CFLAGS` with only the second define
would incorrectly remove the header-free build setting. The installed
`/usr/bin/core_perl/pod2man` is included in PATH for the normal manual-page step.

Resumption retained the original deadline, source files, architecture, ABI and
host optimization. No system package was installed or upgraded. Full ordinary
build logs remain in the ignored local build directory; only compact evidence
belongs in this handoff directory.

The tracked portable wrapper was independently preflighted using the existing
host and pinned package cache. Its preflight does not start the four-hour build
timer, and cannot overwrite an active build owner. A fresh compiler build starts
the timer; subsequent resumes retain it. Its full build and relocation checks
are separate from preflight success. The incremental run repeated cached GNU
configuration checks (which took about ten minutes on this Windows host), reused
the GCC compiler objects, rebuilt the smaller target runtime and attached the
pinned headers/licenses. It was not a second full compiler build or a fresh
computer reproduction. Both attempts retained the original four-hour deadline.
