# GCC 16.2 原生 RV32 工具链

本目录保留可随 `src` 单独复制的构建配方。它生成真实目标为 `riscv32-unknown-elf` 的 Windows 原生 GCC 16.2.0，默认 `rv32ima` / `ilp32`，仅 C 前端和单一 libgcc。没有把其他目标的编译器改名。2026-10-01 的构建、运行库静态检查和带空格目录迁移编译已通过。源侧与集成 SoC 的性能、验证种子 CRC 及完整固件容量比较完成后，项目已选择 **GCC 16.2.0 / `-O2`** 为当前默认；应用参数为 `-march=rv32ima_zicsr_zifencei -mabi=ilp32`。

源侧十次迭代短校准为 1,994,149 ticks、5.0146704183 CoreMark/MHz，见 [当前 CPU 编译器比较](../../validation/compiler-comparison/cpu01747/README.md)。恢复 Flash 裸机自动启动后的集成完整固件为 1,968,626 ticks、5.079685 CoreMark/MHz，完整 O2 固件容量检查通过，见 [固定集成证据](https://github.com/whalellll/performance_soc/blob/7168d3814cbd21de95233de5e72201221b40c001/docs/validation/flash-autoboot-restore/compiler-selection.json)。此前两版 O3 已因容量不足排除。这些结果用于选择编译器，仍不满足比赛至少十秒计时要求，也不是实板成绩。

`sources.lock.json` 固定 GNU GCC、新库许可证源码的来源和哈希；binutils 2.47、新库头文件及 zstd 的二进制包复用旁边 `../gcc14_2/packages.lock.json` 的固定记录。GNU 源码没有打补丁。GCC 源码实际下载的 SHA512 和 SHA256 都已核验；newlib 源码 SHA256 也已核验。这里不声称另外验证过 GNU 源码的 OpenPGP 签名。

## 新电脑重建

需要 Windows x86_64、MSYS2 的 `mingw64` 原生宿主编译环境，以及既有 GCC14.2 独立安装脚本所需的原生 Windows Python。宿主 GCC/G++ 必须支持 C++14；本次观察到的宿主为 GCC 15.2.0，GMP 6.3.0、MPFR 4.2.2、MPC 1.4.1。必须有对应头文件和静态库，以及 MSYS make、bash、bison、flex、gawk、sed、patch、tar、带 zstd 支持的 bsdtar、m4、diffutils、Perl、Python3、curl。构建脚本只查询已安装包，不调用 pacman 安装或升级。

当前宿主还检测并静态链接 libiconv、zstd，并提供 winpthread 静态库；预检查也核对这些输入。实际宿主包版本和静态库哈希见 `host-observation.json`。这里的宿主 zstd 与随目标 binutils 搬移的 UCRT `libzstd.dll` 属于不同用途，不能混用。

从 `src/cpu` 执行，下面的盘符和目录可自行选择；使用简短、无空格的 ASCII 路径。先按现有固定包安装器准备依赖缓存，它会同时提供可用的 GCC14.2 基线：

```powershell
python .\scripts\install_contest_toolchain.py `
  --destination C:\cpu-tools\contest-dependencies `
  --tar C:\msys64\usr\bin\bsdtar.exe

powershell -NoProfile -ExecutionPolicy Bypass `
  -File .\handoff\toolchain\gcc16_2\build.ps1 `
  -MsysRoot C:\msys64 `
  -DependencyRoot C:\cpu-tools\contest-dependencies `
  -BuildRoot C:\cpu-tools\gcc16-build
```

默认使用依赖目录中的 `packages` 缓存；若安装器使用了其他缓存，增加 `-PackageCache C:\downloads\riscv-packages`。所有所需包都会重新核对 SHA256 和大小。编译器安装到所选构建目录的 `native` 子目录，不依赖原开发机的盘符、用户名、兄弟仓库或本机 zip。

可先使用 `-PreflightOnly`，只核对本机宿主工具和固定依赖包，不下载或编译。预检建立的目录随后需要显式 `-Resume` 继续。单独预检不启动构建的四小时总计时；第一次实际构建才开始计时，其后的所有续建和预检都保留原截止，不以重试重置时限。需要一个全新实验时使用新的空构建目录；脚本不递归删除已有目录。

本机初始估计为 1–3 小时，两个 make 作业，峰值内存约 3–6 GiB，磁盘约 8–12 GiB；这些不是实测完成值。启动要求至少 24 GiB 空闲，以保留 12 GiB 余量。Windows Job 包含 bash 和所有编译子进程，硬时限四小时。控制台和 `build-owner.json` 给出 owner PID；`Stop-Process -Id <owner PID>` 会结束整棵进程树。中止后可显式 `-Resume`；脚本确认原 owner 已不存在后保留旧记录并继续，活动构建会被拒绝，原截止时间不会重置。日志只记录普通构建输出，没有启用 TRACE 或逐周期记录。

## 构建和验证边界

使用相对 `srcdir`，避免原生 `gengtype.exe` 无法读取文本清单中的 `/d/...` 路径。host 程序静态链接，避免与 UCRT binutils 的 DLL 混用。目标 libgcc 保留 `-Dinhibit_libc`，没有安装或链接 newlib/libgloss 库；完成编译后仅附加固定 newlib 包中的头文件及同版版权文件，以提供集成固件需要的 `string.h` 等声明。CoreMark 使用自己的运行库和 `-ffreestanding -nostdlib`。

构建成功不等于发布验收。后续必须核对实际 target/version、所有 libgcc 成员的 ELF32/软浮点 ABI/无 C 指令属性、最终链接程序的指令范围，并在原安装目录不可见、PATH 仅含新目录和 Windows 系统目录时实际编译。迁移前后 ELF 哈希需要相同。最后还需按项目入口重建固件，运行 CPU CRC 测试和同条件 CoreMark 比较；较新的 GCC 不自动代表分数更高。

构建完成后运行所附验证入口，迁移目标必须尚未存在：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass `
  -File .\handoff\toolchain\gcc16_2\validate.ps1 `
  -MsysRoot C:\msys64 `
  -BuildRoot C:\cpu-tools\gcc16-build `
  -RelocatedRoot 'C:\CPU Tools\riscv32-gcc16'
```

静态审计限时 300 秒，迁移/复制/真实编译限时 600 秒，仍由 Windows Job 包含所有后代。构建目录需无空格；迁移目标允许空格，上例专门检查这一使用方式。迁移检查会临时把原 `native` 改为 `native.relocation-hidden`，正常结束或异常返回时恢复；若整个进程被强制结束，先检查这个保留目录，不要删除或覆盖它。探针包含 `string.h`、AMO 与 64 位整数除法；分别核对 IM/IMA 查询均选到同一默认 IMA 运行库，不能把它写成 GCC14 的 RV32IM multilib。通过结果写入构建目录的 `validation/summary.json` 和 `validation/relocation-summary.json`。该编译探针没有在 CPU 上执行，也不能替代 CoreMark CRC 测试。

工具链自身从源码重编可能因宿主工具、构建路径和 PE 时间戳而产生不同二进制哈希；本配方不承诺跨宿主重编 GCC 字节一致。交付边界是保留实际工具哈希，并证明同一套工具迁移后能重建相同固件。大工具二进制无需放进 Git；便捷 zip 不能替代这里的锁定来源和构建配方。

实际结果见 `build-result.json`、`runtime-validation.json` 和 `relocation-validation.json`。主构建从最初启动到成功耗时约 2 小时 23 分钟，含一次原生路径修复；随后以同一对象目录运行受控便携入口，增量配置/运行库/安装收尾约 15 分钟。没有从第二台电脑重新进行完整源码构建；迁移检查使用同一组已构建工具，并隐藏原安装目录。168 个 libgcc 成员均为 ELF32、soft-float、无 C，最终探针的 271 条指令通过完整代码区白名单，迁移前后 ELF SHA256 相同。

通用 `unwind-dw2.o` 仍有原始 `0xc2202573`（读取 vector `vlenb` CSR）；该函数未进入探针。`library-scope.json` 记录这一边界：整个库的 ISA 属性不能替代最终程序的指令审计。每份 CoreMark/SoC 固件仍必须通过最终 ELF 白名单和 CPU CRC 测试，不能仅凭本工具链探针宣称可运行或更快。

可选的 Windows 工具链 ZIP 放在仓库外，文件名、大小和 SHA256 见 `binary-bundle.json`；339 个归档文件已逐项核对解压字节。解压后以 `contest riscv32 gcc16` 目录作为 `ToolchainRoot`。该约 62 MB 压缩包只是搬移同一套工具的便利附件；Git 交付仍依靠本目录的锁定源码、依赖记录和可重建配方，不要求新电脑存在原开发机的 ZIP 路径。

现有冻结工具链 ZIP 和验证记录保留其创建时的 `share/licenses/cpu-v3-toolchain`
元数据目录；后续按当前配方重建时使用 `share/licenses/cpu-toolchain`。
此目录只存包来源/许可记录，不参与编译器执行或固件 ABI。
