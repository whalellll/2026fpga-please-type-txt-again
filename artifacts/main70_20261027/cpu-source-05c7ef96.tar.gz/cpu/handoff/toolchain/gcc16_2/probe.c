#include <stdint.h>
#include <string.h>
#if __riscv_xlen != 32 || !defined(__riscv_float_abi_soft) || defined(__riscv_compressed)
#error Probe requires RV32 soft-float without compressed instructions
#endif
volatile uint64_t numerator = UINT64_C(0x123456789abcdef0);
volatile uint64_t denominator = 7;
volatile uint64_t quotient;
volatile unsigned counter;
void _start(void) {
    quotient = numerator / denominator;
    __atomic_fetch_add(&counter, 1u, __ATOMIC_RELAXED);
    for (;;) __asm__ volatile ("nop");
}
