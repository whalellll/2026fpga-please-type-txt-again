#!/usr/bin/env bash
set -euo pipefail
export PATH=/mingw64/bin:/usr/bin:/usr/bin/core_perl
TASK_ROOT=$(cygpath -u "$1")
RECIPE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
PREFIX="$TASK_ROOT/native"
export PATH="$PREFIX/bin:/mingw64/bin:/usr/bin"
export LC_ALL=C LANG=C
unset GCC_EXEC_PREFIX COMPILER_PATH LIBRARY_PATH CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH OBJC_INCLUDE_PATH
CC="$PREFIX/bin/riscv32-unknown-elf-gcc.exe"
READELF="$PREFIX/bin/riscv32-unknown-elf-readelf.exe"
OBJDUMP="$PREFIX/bin/riscv32-unknown-elf-objdump.exe"
mkdir -p "$TASK_ROOT/validation"
cd "$TASK_ROOT/validation"
test "$("$CC" -dumpmachine)" = riscv32-unknown-elf
test "$("$CC" -dumpfullversion)" = 16.2.0
"$CC" -v > compiler-version.txt 2>&1
"$CC" -print-multi-lib > multilib.txt
"$CC" -Q --help=target > default-target-options.txt
"$CC" -march=rv32ima_zicsr_zifencei -mabi=ilp32 -print-libgcc-file-name > selected-libgcc.txt
"$CC" -march=rv32im -mabi=ilp32 -print-libgcc-file-name > queried-rv32im-libgcc.txt
# This compiler intentionally has one IMA runtime, unlike the GCC14 multilib package.
cmp selected-libgcc.txt queried-rv32im-libgcc.txt
LIBGCC=$(tr -d '\r' < selected-libgcc.txt)
test -f "$LIBGCC"
sha256sum "$CC" "$LIBGCC" > compiler-and-libgcc.sha256
"$READELF" -h -A "$LIBGCC" > libgcc-headers.txt
"$OBJDUMP" -d "$LIBGCC" > libgcc-disassembly.txt
"$CC" -O2 -march=rv32ima_zicsr_zifencei -mabi=ilp32 -mcmodel=medany -mno-relax \
  -msmall-data-limit=0 -mstrict-align -ffreestanding -fno-builtin -nostartfiles -nostdlib \
  -Wl,-Ttext=0x80000000 -Wl,-e,_start -Wl,--build-id=none "$RECIPE/probe.c" "$LIBGCC" -o probe.elf
"$READELF" -h -A probe.elf > probe-headers.txt
"$OBJDUMP" -d -M no-aliases probe.elf > probe-disassembly.txt
/mingw64/bin/objdump -p "$CC" | sed -n '/DLL Name:/p' > host-gcc-pe.txt
/mingw64/bin/objdump -p "$PREFIX/lib/gcc/riscv32-unknown-elf/16.2.0/cc1.exe" | sed -n '/DLL Name:/p' > host-cc1-pe.txt
/mingw64/bin/objdump -p "$PREFIX/lib/gcc/riscv32-unknown-elf/16.2.0/collect2.exe" | sed -n '/DLL Name:/p' > host-collect2-pe.txt
python3 "$RECIPE/validate.py" "$TASK_ROOT"
