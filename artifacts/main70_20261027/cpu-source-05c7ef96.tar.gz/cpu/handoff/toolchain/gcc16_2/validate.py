import hashlib
import json
import re
import struct
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
out = root / "validation"
headers = (out / "libgcc-headers.txt").read_text()
classes = re.findall(r"Class:\s+(\S+)", headers)
flags = re.findall(r"Flags:\s+([^\n]+)", headers)
attrs = re.findall(r'Tag_RISCV_arch:\s+"([^"]+)"', headers)
assert classes and all(x == "ELF32" for x in classes), classes
assert len(classes) == len(flags) == len(attrs)
assert all(x.strip() == "0x0" for x in flags), sorted(set(flags))
allowed = {"i", "m", "a", "zaamo", "zalrsc", "zmmul", "zicsr", "zifencei"}
for arch in attrs:
    assert arch.startswith("rv32i"), arch
    extensions = {re.sub(r"\d+p\d+$", "", part) for part in arch[4:].split("_")}
    assert extensions <= allowed, (arch, extensions - allowed)

def check_words(name):
    disassembly = (out / name).read_text()
    encodings = re.findall(r"^\s*[0-9a-f]+:\s+([0-9a-f]+)\s+", disassembly, re.MULTILINE)
    assert encodings and all(len(x) == 8 and int(x, 16) & 3 == 3 for x in encodings), name
    return len(encodings)

lib_words = check_words("libgcc-disassembly.txt")
probe_words = check_words("probe-disassembly.txt")
probe_headers = (out / "probe-headers.txt").read_text()
assert re.search(r"Class:\s+ELF32", probe_headers)
assert re.search(r"Flags:\s+0x0\s", probe_headers)
probe_disasm = (out / "probe-disassembly.txt").read_text()
assert "amoadd.w" in probe_disasm
assert "__udivdi3" in probe_disasm
assert ".insn" not in probe_disasm and "vlenb" not in probe_disasm
allowed_mnemonics = set("""
lui auipc jal jalr beq bne blt bge bltu bgeu
lb lh lw lbu lhu sb sh sw addi slti sltiu xori ori andi
slli srli srai add sub sll slt sltu xor srl sra or and
fence fence.i ecall ebreak mret wfi csrrw csrrs csrrc csrrwi csrrsi csrrci
mul mulh mulhsu mulhu div divu rem remu
lr.w sc.w amoadd.w amoswap.w amoxor.w amoor.w amoand.w
amomin.w amomax.w amominu.w amomaxu.w
""".split())
probe_bytes = (out / "probe.elf").read_bytes()
assert probe_bytes[:6] == b"\x7fELF\x01\x01"
section_offset = struct.unpack_from("<I", probe_bytes, 32)[0]
section_stride, section_count = struct.unpack_from("<HH", probe_bytes, 46)
code_ranges = []
for index in range(section_count):
    section = struct.unpack_from("<IIIIIIIIII", probe_bytes, section_offset + index * section_stride)
    if section[2] & 4 and section[5]:
        code_ranges.append((section[3], section[3] + section[5]))
seen_addresses = set()
for address, encoding, mnemonic in re.findall(r"^\s*([0-9a-f]+):\s+([0-9a-f]+)\s+(\S+)", probe_disasm, re.MULTILINE):
    address = int(address, 16)
    word = int(encoding, 16)
    mnemonic = re.sub(r"\.(aqrl|aq|rl)$", "", mnemonic)
    assert address % 4 == 0 and mnemonic in allowed_mnemonics, (hex(address), mnemonic)
    assert any(start <= address < end for start, end in code_ranges), hex(address)
    assert address not in seen_addresses, hex(address)
    assert not (word & 127 == 115 and (word >> 12) & 7 and word >> 20 == 0xc22), hex(address)
    seen_addresses.add(address)
assert len(seen_addresses) * 4 == sum(end - start for start, end in code_ranges)
host_dlls = {}
for name in ("host-gcc-pe.txt", "host-cc1-pe.txt", "host-collect2-pe.txt"):
    dlls = re.findall(r"DLL Name:\s+(\S+)", (out / name).read_text())
    assert dlls and not any(re.match(r"(?:lib|zlib|msys-)", dll, re.I) for dll in dlls), dlls
    host_dlls[name] = dlls
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
result = {
    "status": "PASS",
    "compiler_target": "riscv32-unknown-elf",
    "compiler_version": "16.2.0",
    "app_march": "rv32ima_zicsr_zifencei",
    "abi": "ilp32",
    "libgcc_members": len(classes),
    "libgcc_attributes": sorted(set(attrs)),
    "libgcc_selection": {
        "rv32ima_zicsr_zifencei_ilp32": "default single runtime",
        "rv32im_ilp32_query": "same default IMA runtime; not an RV32IM multilib",
        "both_queries_identical": (out / "selected-libgcc.txt").read_bytes() == (out / "queried-rv32im-libgcc.txt").read_bytes(),
    },
    "libgcc_instruction_words": lib_words,
    "probe_instruction_words": probe_words,
    "probe_code_validation": "Complete executable section RV32IMA mnemonic/width whitelist; unsupported vector CSR rejected",
    "probe_sha256": sha(out / "probe.elf"),
    "host_dlls": host_dlls,
    "cpu_execution": "not performed by this toolchain probe; CoreMark CRC required separately",
}
(out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
