"""Prepare locked source/binutils or attach headers; invoked within Windows Job."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root, cache, recipe = (Path(value).resolve() for value in sys.argv[1:4])
mode = sys.argv[4]
sources = json.loads((recipe / 'sources.lock.json').read_text())
packages = json.loads((recipe.parent / 'gcc14_2/packages.lock.json').read_text())['packages']
selected = {p['name']: p for p in packages if p['name'] in sources['reused_packages']}
assert len(selected) == 3

def digest(path, algorithm='sha256'):
    value = hashlib.new(algorithm)
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()

def run(argv, stdout=None, timeout=120):
    subprocess.run([str(x) for x in argv], check=True, stdout=stdout, timeout=timeout)

def package(name):
    item = selected[name]
    path = cache / item['filename']
    if not path.is_file() or path.stat().st_size != item['compressed_bytes'] or digest(path) != item['sha256']:
        raise ValueError('Missing/mismatching locked dependency package: ' + str(path))
    return path

for name in selected:
    package(name)
(root / 'metadata/reused-packages.json').write_text(json.dumps(list(selected.values()), indent=2) + '\n')
if mode == 'preflight':
    print('Locked binutils/newlib/zstd package cache verified; no download or build performed')
    raise SystemExit(0)
if mode not in ('build', 'headers'):
    raise ValueError('Unexpected mode')
if mode == 'build':
    for item in (sources['gcc'], sources['newlib']):
        target = root / 'downloads' / item['filename']
        if not target.exists():
            partial = target.with_name(target.name + '.partial')
            if partial.exists():
                raise ValueError('Inspect the existing partial download before retrying: ' + str(partial))
            run(['curl', '--fail', '--location', '--silent', '--show-error', '--connect-timeout', '15', '--max-time', '300', '--retry', '1', '--retry-delay', '2', item['url'], '-o', partial], timeout=620)
            if digest(partial) != item['sha256']:
                raise ValueError('Source SHA256 mismatch: ' + item['filename'])
            partial.rename(target)
        if digest(target) != item['sha256'] or ('sha512' in item and digest(target, 'sha512') != item['sha512']):
            raise ValueError('Source hash mismatch: ' + item['filename'])
    prefix = root / 'native'
    run(['bsdtar', '-xf', package('mingw-w64-ucrt-x86_64-riscv32-unknown-elf-binutils'), '-C', prefix, '--strip-components', '1', '--include', 'ucrt64/*'])
    run(['bsdtar', '-xf', package('mingw-w64-ucrt-x86_64-zstd'), '-C', prefix, '--strip-components', '1', '--include', 'ucrt64/bin/libzstd.dll', '--include', 'ucrt64/share/licenses/zstd/*'])
    provenance = prefix / 'share/licenses/cpu-toolchain'
    provenance.mkdir(parents=True, exist_ok=True)
    (provenance / 'reused-packages.json').write_text(json.dumps(list(selected.values()), indent=2) + '\n')
    for name in selected:
        with (provenance / (name + '.PKGINFO')).open('wb') as output:
            run(['bsdtar', '-xOf', package(name), '.PKGINFO'], stdout=output)
    (provenance / 'README.txt').write_text(
        'These pinned package records identify the target binutils, zstd runtime and newlib headers.\n'
        'The binutils package declares GNU GPL/LGPL licenses but does not carry separate license files.\n'
        'The common GNU license texts are included in ../gcc-source-build/COPYING*.\n'
        'zstd and newlib notices are in their adjacent license directories.\n'
        'GCC and libgcc were built from the unmodified source locked by ../gcc-source-build/sources.lock.json.\n'
        'The complete rebuild recipe remains in the src repository; this directory is not a source-code bundle.\n')
else:
    prefix = root / 'native'
    if digest(root / 'downloads' / sources['newlib']['filename']) != sources['newlib']['sha256']:
        raise ValueError('Newlib license source changed after initial verification')
    run(['bsdtar', '-xf', package('mingw-w64-ucrt-x86_64-riscv32-unknown-elf-newlib'), '-C', prefix, '--strip-components', '1', '--include', 'ucrt64/riscv32-unknown-elf/include/*'])
    license_dir = prefix / 'share/licenses/newlib-headers'
    license_dir.mkdir(parents=True, exist_ok=True)
    for name in ('COPYING', 'COPYING3', 'COPYING.NEWLIB', 'COPYING.LIB', 'COPYING3.LIB'):
        with (license_dir / name).open('wb') as output:
            run(['bsdtar', '-xOf', root / 'downloads' / sources['newlib']['filename'], 'newlib-4.5.0.20241231/' + name], stdout=output)
    (license_dir / 'provenance.json').write_text(json.dumps(sources['newlib'], indent=2) + '\n')
    if (prefix / 'riscv32-unknown-elf/lib/libc.a').exists():
        raise ValueError('Unexpected newlib library in the headers-only toolchain')
    print('Pinned newlib headers and licenses attached; no libc/libgloss objects installed')
