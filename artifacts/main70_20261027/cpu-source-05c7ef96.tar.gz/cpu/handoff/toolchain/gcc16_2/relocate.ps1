[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$BuildRoot,[Parameter(Mandatory=$true)][string]$RelocatedRoot)
$ErrorActionPreference = 'Stop'
$BuildRoot = [IO.Path]::GetFullPath($BuildRoot)
$RelocatedRoot = [IO.Path]::GetFullPath($RelocatedRoot)
$original = Join-Path $BuildRoot 'native'
$hidden = Join-Path $BuildRoot 'native.relocation-hidden'
if ($RelocatedRoot.StartsWith($BuildRoot.TrimEnd('\') + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Relocation destination must be outside the original build directory.' }
if (Test-Path -LiteralPath $hidden) { throw 'A previous relocation backup exists; inspect it before retrying.' }
if (Test-Path -LiteralPath $RelocatedRoot) { throw 'Relocation destination already exists.' }
if (!(Test-Path -LiteralPath "$BuildRoot\validation\summary.json")) { throw 'Run compiler/runtime validation first.' }
foreach ($path in @($original,$hidden)) {
    if (![IO.Path]::GetFullPath($path).StartsWith($BuildRoot.TrimEnd('\') + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid relocation move path.' }
}
foreach ($path in @($BuildRoot,$original,$hidden,$RelocatedRoot)) {
    $item = $path
    while ($item) {
        if (Test-Path -LiteralPath $item) {
            if ((Get-Item -LiteralPath $item -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Linked path is not supported: $item" }
        }
        $parent = Split-Path -Parent $item
        if ($parent -eq $item) { break }
        $item = $parent
    }
}
Copy-Item -LiteralPath $original -Destination $RelocatedRoot -Recurse
$priorPath = $env:PATH
$searchEnvironment = @{}
foreach ($name in @('GCC_EXEC_PREFIX','COMPILER_PATH','LIBRARY_PATH','CPATH','C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','OBJC_INCLUDE_PATH')) {
    $searchEnvironment[$name] = [Environment]::GetEnvironmentVariable($name,'Process')
}
$moved = $false
try {
    Move-Item -LiteralPath $original -Destination $hidden
    $moved = $true
    $env:PATH = "$RelocatedRoot\bin;$env:SystemRoot\System32;$env:SystemRoot"
    foreach ($name in $searchEnvironment.Keys) { [Environment]::SetEnvironmentVariable($name,$null,'Process') }
    $gcc = Join-Path $RelocatedRoot 'bin\riscv32-unknown-elf-gcc.exe'
    $target = (& $gcc -dumpmachine | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or $target -ne 'riscv32-unknown-elf') { throw 'Relocated target mismatch.' }
    $version = (& $gcc -dumpfullversion | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or $version -ne '16.2.0') { throw 'Relocated version mismatch.' }
    $libgcc = (& $gcc '-march=rv32ima_zicsr_zifencei' '-mabi=ilp32' '-print-libgcc-file-name' | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or !(Test-Path -LiteralPath $libgcc -PathType Leaf)) { throw 'Relocated libgcc missing.' }
    $libgccPath = (Resolve-Path -LiteralPath $libgcc).Path
    if (!$libgccPath.StartsWith($RelocatedRoot.TrimEnd('\') + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Relocated driver selected an external libgcc.' }
    $imQuery = (& $gcc '-march=rv32im' '-mabi=ilp32' '-print-libgcc-file-name' | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or !(Test-Path -LiteralPath $imQuery -PathType Leaf)) { throw 'Relocated RV32IM runtime query failed.' }
    if ((Resolve-Path -LiteralPath $imQuery).Path -ine $libgccPath) { throw 'The single-runtime GCC16 driver selected different IM and IMA archives.' }
    $elf = Join-Path $BuildRoot 'validation\relocated-probe.elf'
    $compileArguments = @('-O2','-march=rv32ima_zicsr_zifencei','-mabi=ilp32','-mcmodel=medany','-mno-relax','-msmall-data-limit=0','-mstrict-align','-ffreestanding','-fno-builtin','-nostartfiles','-nostdlib','-Wl,-Ttext=0x80000000','-Wl,-e,_start','-Wl,--build-id=none',(Join-Path $PSScriptRoot 'probe.c'),$libgcc,'-o',$elf)
    $priorNativePreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        & $gcc @compileArguments 2> "$BuildRoot\validation\relocated-compile.stderr.log"
        $compileExit = $LASTEXITCODE
    } finally { $ErrorActionPreference = $priorNativePreference }
    if ($compileExit -ne 0) { throw 'Clean-PATH relocated compile/link failed.' }
    $oldSha = (Get-FileHash -LiteralPath "$BuildRoot\validation\probe.elf" -Algorithm SHA256).Hash.ToLowerInvariant()
    $newSha = (Get-FileHash -LiteralPath $elf -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($oldSha -ne $newSha) { throw 'Probe ELF differs after relocating identical compiler tools.' }
    [ordered]@{
        status='PASS'; compiler_target=$target; compiler_version=$version
        original_prefix_hidden=$true; gcc_exec_prefix_unset=$true
        compiler_library_and_header_search_environment_unset=$true
        relocated_path_contains_spaces=$RelocatedRoot.Contains(' ')
        string_h_include_compiled=$true
        rv32im_and_rv32ima_queries_select_same_default_ima_libgcc=$true
        path='Only relocated bin and Windows system directories'
        compiler_sha256=(Get-FileHash -LiteralPath $gcc -Algorithm SHA256).Hash.ToLowerInvariant()
        libgcc_sha256=(Get-FileHash -LiteralPath $libgcc -Algorithm SHA256).Hash.ToLowerInvariant()
        original_probe_sha256=$oldSha; relocated_probe_sha256=$newSha
        relocated_directory=$RelocatedRoot
        cpu_execution='Not performed by this compile/link probe; project CRC tests required separately'
    } | ConvertTo-Json | Set-Content -LiteralPath "$BuildRoot\validation\relocation-summary.json" -Encoding utf8
    Write-Output "RELOCATION_PASS probe_sha256=$newSha"
} finally {
    $env:PATH = $priorPath
    foreach ($name in $searchEnvironment.Keys) { [Environment]::SetEnvironmentVariable($name,$searchEnvironment[$name],'Process') }
    if ($moved) { Move-Item -LiteralPath $hidden -Destination $original }
}
