[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$MsysRoot,
    [Parameter(Mandatory=$true)][string]$DependencyRoot,
    [Parameter(Mandatory=$true)][string]$BuildRoot,
    [string]$PackageCache,
    [switch]$Resume,
    [switch]$PreflightOnly
)
$ErrorActionPreference = 'Stop'
$recipeRoot = $PSScriptRoot
$projectRoot = [IO.Path]::GetFullPath((Join-Path $recipeRoot '..\..\..'))
$MsysRoot = [IO.Path]::GetFullPath($MsysRoot)
$DependencyRoot = [IO.Path]::GetFullPath($DependencyRoot)
$BuildRoot = [IO.Path]::GetFullPath($BuildRoot)
if (!$PackageCache) { $PackageCache = Join-Path $DependencyRoot 'packages' }
$PackageCache = [IO.Path]::GetFullPath($PackageCache)
foreach ($path in @($MsysRoot,$DependencyRoot,$BuildRoot,$PackageCache,$recipeRoot)) {
    if ($path -match '[^\x21-\x7e]' -or $path -match '[";&`$]') { throw "Use short ASCII paths without spaces/shell metacharacters: $path" }
    $item = $path
    while ($item) {
        if (Test-Path -LiteralPath $item) {
            if ((Get-Item -LiteralPath $item -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Linked path is not supported: $item" }
        }
        $parent = Split-Path -Parent $item
        if ($parent -eq $item) { break }
        $item = $parent
    }
}
$bash = Join-Path $MsysRoot 'usr\bin\bash.exe'
foreach ($file in @($bash,(Join-Path $MsysRoot 'mingw64\bin\gcc.exe'),(Join-Path $MsysRoot 'mingw64\bin\g++.exe'))) {
    if (!(Test-Path -LiteralPath $file -PathType Leaf)) { throw "Required native MSYS2 host tool missing: $file" }
}
$marker = Join-Path $BuildRoot 'build-owner.json'
if (Test-Path -LiteralPath $BuildRoot) {
    if (!$Resume -and !$PreflightOnly) { throw 'Choose a new build directory or explicitly use -Resume.' }
    if (!(Test-Path -LiteralPath $marker -PathType Leaf)) { throw 'An existing build directory requires this recipe ownership marker.' }
} else { New-Item -ItemType Directory -Path $BuildRoot -Force | Out-Null }
New-Item -ItemType Directory -Path (Join-Path $BuildRoot 'logs') -Force | Out-Null
$drive = Get-PSDrive -Name ([IO.Path]::GetPathRoot($BuildRoot).Substring(0,1))
if ($drive.Free -lt 24GB) { throw 'Need 24 GiB free: 12 GiB build allowance and 12 GiB reserve.' }
$firstStart = $null
if (Test-Path -LiteralPath $marker) {
    $previous = Get-Content -LiteralPath $marker -Raw | ConvertFrom-Json
    if (!$previous.end_utc) {
        $oldOwner = Get-Process -Id $previous.owner_pid -ErrorAction SilentlyContinue
        $oldStart = [DateTime]::Parse($previous.start_utc).ToUniversalTime()
        if ($oldOwner -and $oldOwner.StartTime.ToUniversalTime() -le $oldStart.AddSeconds(1)) { throw 'The previous build owner is still active.' }
        # Closing that owner's kill-on-close Job already terminates its descendants.
        # A new explicit invocation may resume, but cannot reset the original deadline.
        Write-Output 'Previous owner no longer exists; preserving interrupted attempt and original deadline.'
    }
    if ($previous.compiler_target -ne 'riscv32-unknown-elf' -or $previous.compiler_version -ne '16.2.0') { throw 'Ownership marker target/version mismatch.' }
    if ($previous.build_has_started -or ($previous.mode -ne 'preflight' -and $previous.overall_start_utc)) {
        $firstStart = [DateTime]::Parse($previous.overall_start_utc).ToUniversalTime()
    }
}
if ($PreflightOnly) {
    $remaining = 120
} else {
    if (!$firstStart) { $firstStart = [DateTime]::UtcNow }
    $remaining = [int][Math]::Floor(($firstStart.AddHours(4) - [DateTime]::UtcNow).TotalSeconds)
    if ($remaining -le 0) { throw 'Original four-hour build deadline has elapsed.' }
}
$stamp = [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')
$mode = if ($PreflightOnly) { 'preflight' } else { 'build' }
$record = [ordered]@{
    compiler_target='riscv32-unknown-elf'; compiler_version='16.2.0'
    owner_pid=$PID; overall_start_utc=$(if ($firstStart) { $firstStart.ToString('o') } else { $null })
    build_has_started=[bool]$firstStart; start_utc=[DateTime]::UtcNow.ToString('o')
    timeout_seconds=$remaining; make_jobs=2; mode=$mode
    stop_command="Stop-Process -Id $PID"
    build_root=$BuildRoot; dependency_root=$DependencyRoot; msys_root=$MsysRoot
    stdout=(Join-Path $BuildRoot "logs\$stamp-$mode.log")
    stderr=(Join-Path $BuildRoot "logs\$stamp-$mode.stderr.log")
}
if (Test-Path -LiteralPath $marker) { Copy-Item -LiteralPath $marker -Destination (Join-Path $BuildRoot "logs\$stamp-prior-owner.json") }
$record | ConvertTo-Json | Set-Content -LiteralPath $marker -Encoding utf8
Add-Type -Path (Join-Path $projectRoot 'scripts\bounded_process.cs')
$arguments = @((Join-Path $recipeRoot 'build.sh'),$BuildRoot,$DependencyRoot,$PackageCache,$recipeRoot,$mode) | ForEach-Object { '"' + $_.Replace('\','/') + '"' }
$arguments = $arguments -join ' '
Write-Output "GCC16 owner PID $PID; maximum $remaining seconds; jobs=2; stop: Stop-Process -Id $PID"
try {
    $result = [CpuSimulation.BoundedProcess]::Run($bash,$arguments,$BuildRoot,$record.stdout,$record.stderr,$remaining)
    $record.exit_code = $result
    if ($result -ne 0) { throw "GCC16 $mode failed with exit $result; inspect $($record.stderr) and stage logs." }
} catch {
    $record.failure = $_.Exception.Message
    throw
} finally {
    $record.end_utc = [DateTime]::UtcNow.ToString('o')
    $record | ConvertTo-Json | Set-Content -LiteralPath $marker -Encoding utf8
}
