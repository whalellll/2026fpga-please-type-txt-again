# CPU80 GUI1080 multiplier candidate

Local implementation freeze from fefd93052c4974c5a45fcebb7a34cc3d44f9a8d9. Only Mul.scala changes production logic: signed halfword products remove redundant correction state and output subtraction while retaining four product capture boundaries, hold behavior and one-cycle completion.

Baseline differential comparison, candidate focused tests and paired synthesis/simulation generation passed. Both emitted designs change only module Mul after CRLF/LF normalization. Full CPU/SoC regression, measured resources, native DSP mapping/vendor checks, final all-corner STA and fresh board acceptance remain required. No hardware acceptance or remote promotion is claimed.

Campaign evidence: G:/fpga/performance_soc_voice_hw/build/cpu80-gui1080-accept-20261023/resource-priority-03/.
