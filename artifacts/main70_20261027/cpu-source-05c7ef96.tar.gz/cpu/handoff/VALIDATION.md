# CPU V3 发布验证记录

> 历史冻结记录：以下结论属于 CPU V3 / SoC v6.0 基线。
> CPU V3.1 当前输入与本轮结果见 [V3.1 验证记录](V3_1_VALIDATION.md)。

日期：2026-10-01～03。`main` 已快进合并 `cpu-v15-reorg-20260927`，原 `soc` 改名为
`coremark_test_soc`。本仓库负责 CPU 优化，独立 performance_soc/linux 负责板级集成。
本次用户选择原有 49.5 MHz 集成 SoC 已布线基线，不继续本轮调频布线。当前未接
开发板，最高可实现频率、实板稳定频率与板测成绩未测明；比赛要求的至少 10 秒
CoreMark 也尚未完成。本次列出的 CoreMark/MHz 全是明确标记的 RTL 短校准。
更高频率尝试、最终时序报告和被取消的尝试由 `performance_soc/docs/validation/frequency-grid/`
记录；不把失败的 DDR 路径或未完成的构建写成 CPU 最高频率结论。

## 当前配置与编译器选择

硬件及固件统一 RV32IMA；C 扩展和开关已删除。编译目标为
`-march=rv32ima_zicsr_zifencei -mabi=ilp32`，本次发布时钟 49.5 MHz。
默认工具链选用真实 `riscv32-unknown-elf` GCC 16.2.0，CoreMark 使用 O2。
这是已测 14.2/16.2、O2/O3 候选中能容纳完整集成固件且归一性能更高的配置，
不表示所有 GCC 版本与选项的全局最优。

| 产物 | 当前 SHA256 |
| --- | --- |
| 综合 RTL | `b73b680b108df9ee5c3819a4c4399ef4424ab1e112e4cc329ac52e58235c0c70` |
| 仿真 RTL | `d3e15490900dd111f85d07ff27696da16b75e888e7a14ca71c466dad706735ad` |
| 固定 CoreMark RAM | `0b8ab4a1c59d9756b8ba8bad84711c19b7bc1b45011c010e871d6fae666f405f` |

六份核心文件固定为官方 tag `v1.01`、提交 `cfa9ab377835911f23d9b0831c7be302ed1f58de`，
程序报告 CoreMark 1.0。全部核心文件使用同一组选项，算法和官方十秒检查未修改。
赛题指定 `riscv32-unknown-elf-gcc`、CoreMark v1.0 和至少十秒计时，没有限定 GCC 版本或优化等级。
比赛页码与原 PDF 哈希见 [新电脑指南](NEW_COMPUTER_GUIDE.md)。

同一仿真 RTL 的十次迭代对照：14.2 是先前基线，16.2 性能种子在本轮
ICache 综合写入口修复后以相同固件重新运行。

| 编译器 / 优化 | 性能种子 ticks | CoreMark/MHz 短校准 | 验证种子 ticks |
| --- | ---: | ---: | ---: |
| GCC 14.2.0 / O2 | 2,123,909 | 4.7082996494 | 2,130,346 |
| GCC 16.2.0 / O2 | 1,994,149 | 5.0146704183 | 2,002,620 |

两种种子的 CRC 全部正确，16.2/O2 的归一性能提高约 6.51%。记录绑定当前 CPU、
官方源码、编译选项、各工具链配套 libgcc、固件和原始输出，见
[当前 CPU 对照](validation/compiler-comparison/cpu01747/README.md)。默认版本切换后已重新构建固定固件，
五份程序输入与已测 16.2/O2 固件逐字节相同，见
[固定固件绑定](validation/compiler-comparison/cpu01747/selected-firmware.json)。
本轮新综合 RTL 的十次性能种子为同样的 **1,994,149 周期、5.0146704183/MHz**，
CRC 全部一致；仿真 RTL 与修复前逐字节相同。见
[ICache 修复回归](validation/icache-write-pad/README.md)。验证种子仍引用先前
同一仿真 RTL 的结果，本轮没有声称重新运行该种子。

恢复 Flash 裸机自动启动前的集成对照中，performance_soc 使用生产端口和各版本完整固件的真实工作区地址，14.2/O2 为 2,134,922 ticks、
4.684012/MHz，16.2/O2 为 1,969,503 ticks、5.077423/MHz，归一性能提高约 8.4%；
独立验证种子也通过。16.2/O2 留有 16,696 字节栈；14.2/O3 和 16.2/O3 分别比原有
16 KiB 门槛少 2,664 和 2,592 字节，因此两版 O3 均排除。这是阶段记录；恢复 Flash 自动启动后的
完整镜像布局、容量和重新校准由集成仓库 `docs/Validation.md` 及其选型证据记录。
测试基座和集成布局使用不同端口、地址与总线环境，不能将两张表混成同一实验。

恢复 Flash 裸机自动启动后的完整固件布局中，GCC 14.2/O2 为 2,128,603 ticks（4.697917/MHz），
GCC 16.2/O2 为 1,968,626 ticks（5.079685/MHz），归一性能提高约 8.13%。
16.2/O2 栈预留为 16,400 B，仅高于 16 KiB 门槛 16 B；这是链接预留空间，不是最坏栈水位实测。
两种种子的 CRC 均通过，仍是十次迭代 RTL 短校准，不是至少十秒成绩或板测结果。见
[恢复 Flash 后的固定集成证据](https://github.com/whalellll/performance_soc/blob/7168d3814cbd21de95233de5e72201221b40c001/docs/validation/flash-autoboot-restore/compiler-selection.json)。

上述计时只有约 0.040～0.043 秒，保留官方时长不足提示，仅作校准，不能作为比赛十秒成绩或板测结果。
比赛成绩要求最终硬件、固件和频率下每次实际 CPU 计时不少于十秒，并通过
CRC 等有效性检查。当前短仿真没有满足该时长，因此 5.0146704183/MHz
只能用于源码测试基座校准；集成 SoC 的成绩须单独引用其同输入、同位流记录。
上板功能验收、板测成绩和最高频率探索留待后续版本，不影响本次按已知
49.5 MHz 基线交付，但不得把本次报告写成上述验收已经完成。

## 当前功能、工程与交付检查

- ICache 两路 RAM 写入口共用一个 128 位双输出 LUT 恒等缓冲，原响应旁路和寄存器周期不变。
  新源码经 Unit 49/49、两路缓存额外 2/2、Functional 8/8 与固定十次 CoreMark 复测；
  单模块实际 ADS 的 64 个原语、128 位及两路写连接均通过检查。
  [原始回归与 ADS 证据](validation/icache-write-pad/README.md)不代表整机保持时间已修复。
- 最新 BRAM 映射修复先在旧逻辑上复现失败，再通过 6 套件 30 项定向测试，见
  [RED/GREEN 证据](validation/bram-map-fix/result.json)。
- 当前 RTL 通过普通/原子指令、机器态异常、访存顺序、读总线错误和两种写总线错误共七项回归，见
  [架构证据](validation/architecture-gcc14_2-cpu01747/result.json)。这些程序用 GCC 14.2/16.2
  实际重编后 BIN 全部相同，见 [编译对照](validation/architecture-gcc14_2-cpu01747/compiler16_2-bin-comparison.json)；
  不将这次字节对照描述为重新运行七项仿真。
- 新 IALIGN32 整核用例通过 6 次精确异常及不应异常的分支检查，1185 cycles / 361 retired；
  当前前端六项定向复验也全部通过，含嵌套 call/return、反压和 flush 后旧 refill。
  见 [补充覆盖](validation/ialign32-cpu01747/README.md)。Functional 现包含这第八项，Unit 纳入前端套件。
- 同一综合 CPU 已通过集成 AXI/CLINT/UART/DDR、生产 console、SDHC/SDSC、写入/取消与 FAT 测试。
  切换 16.2 后的完整固件回归由 performance_soc 记录，不能只凭 CoreMark CRC 代替外设验收。
- GCC 16.2 的源码构建、真实 target、运行库、带空格路径迁移和干净 PATH 编译检查通过；
  原安装目录隐藏时探针 ELF 仍相同。见 [工具链证据](toolchain/gcc16_2/README.md)。
- `.pds` 已解除对忽略目录 work 的依赖，真实输入、约束和初始化源进入 Git。
  先前 `01747a11…` CPU + GCC 14.2 固件的干净含空格路径工程已由 PDS 打开，见
  [打开记录](validation/pds-coremark-open-01747.json)。该核 + 16.2 固件的独立 compile/ADS 已通过，
  19,034 LUT / 10,880 寄存器 / 0 latch，见 [先前综合](validation/pds-synthesis-gcc16/result.json)。
  同一实际网表通过 42,880 组前端、2,144 个 PMA 地址、17,152 组提示控制检查；
  三项人为破坏网表均被拒绝，见 [ADS 门禁](validation/pds-controls-gcc16/fixtures.json)。
  本轮新综合 RTL 又在隔离副本中通过该 `.pds` 打开及 compile/ADS，实际为
  19,098 LUT / 10,880 寄存器 / 90 DRM / 0 latch；原控制检查同样通过，见
  [新 PDS 收据](validation/icache-write-pad/portable-pds-synthesis/README.md)。
- `01747a11…` 核的集成 ADS 控制逻辑检查此前已通过；新 `b73b680…` 核的整机
  布线和正式 STA 以 performance_soc 的 49.5 MHz 原有交付物及其输入哈希为准。
  本仓库测试基座综合通过不等于整机时序或板测通过。
- 本轮 49.5 MHz / `b73b680…` / GCC 16.2/O2 的 CPU_V3 源码包在无 `.git`、无旧
  `work/`、路径含空格的独立解压目录中通过 525 项 VerifyPackage 和真实 PDS 打开。
  2026-10-03 08:36:54～08:46:37 UTC 又通过 Compile、ADS 和关键控制网表审查：
  19,098 LUT、10,880 寄存器、90 DRM、0 latch，检查 42,880 组前端、2,144 个
  PMA 地址与 17,152 组 RsMem 提示。CPU SHA256 为 `b73b680b108df9ee5c3819a4c4399ef4424ab1e112e4cc329ac52e58235c0c70`，
  ROM SHA256 为 `0b8ab4a1c59d9756b8ba8bad84711c19b7bc1b45011c010e871d6fae666f405f`；
  UTC 时间、输入和收据哈希见 [本轮干净包验证](validation/v3-portable-release/README.md)。
  这是测试基座综合，不能当作整机 P&R 或上板成绩。此前包的 Doctor 等检查保留于
  [历史封装检查](validation/portable-package-smoke.json)，不能替代本次封包结果。

综合与仿真 RTL 必须一起从 Chisel 生成，各自的 emit-config.json 与 schema 2 生成清单
绑定真实参数、源码和产物。不能手改 RTL、改 JSON 标签或用旧结果替代新输入的验证。

## 集成正确性修复

RsMem 的寄存器写回会先使操作数就绪，地址提示晚一周期更新。旧逻辑可能据过期地址把 MMIO
视为可缓存访存并越过较老 store；修复禁止在提示刷新周期绕过，并检查实际请求地址属性。
新增用例在旧逻辑确实失败，修复后 RsMemWritebackSpec / LoadOrderSpec 共 15 项通过，见
[排序修复](validation/ima-release/rsmem-ordering/result.json)。

完整 PMA 映射修复覆盖 CLINT `02000000–0200ffff`、SoC MMIO `1fe00000–1fefffff`、
原设备地址恢复 DDR、高地址非缓存别名和译后属性；先复现错误，再通过 4 套件 13 项测试，见
[PMA 证据](validation/pma-map-fix/result.json)。

完整 GCC 14.2/O2 bootloader 的 2000 字节工作区位于 `1c01b0a8–1c01b877`，
落入旧平台 `1c018000–1c01bfff` 的不可缓存 DMA 特例。实际集成 DMA 只连接 DDR，
没有通向本地 boot BRAM 的路径，因此删除该例外，使整个 128 KiB boot BRAM 可缓存。
相同 ROM、相同工作区的集成短测由 6,726,768 降到 2,134,922 ticks；真实 MMIO 和高地址别名
仍保持不可缓存及顺序要求。这是平台地址属性修复，不是修改 CoreMark 算法。

## IMA / IMAC 选择与历史阶段

初期集成映射、GCC 13.2/O2、相同 `rv32ima/ilp32/libgcc.a`、相同测试台和十次迭代：

| 硬件 / 固件 | ticks | CoreMark/MHz 短校准 |
| --- | ---: | ---: |
| IMA / IMA | 2,138,066 | 4.6771240925 |
| IMAC / IMA | 2,138,066 | 4.6771240925 |
| IMAC / IMAC | 4,300,843 | 2.325125563 |

全部 CRC 正确，因此选择纯 IMA。关闭及删除 C 均未改变同一 IMA 固件的周期数；
后续 RsMem 正确性修复使该历史固件变为 2,138,457 ticks、4.676269/MHz，增加约 0.01829%。
C 清理后的 11 套件 34 项测试覆盖 49,152 个非 32 位前缀、CSR、ROB、保留站和双发射。
分阶段输入与原始记录见 [IMA 历史校准](validation/ima-release/README.md)。

旧 `a7e758b6…` 综合 / `c81a1b96…` 仿真 RTL 是 BRAM 特例删除前的阶段。
该阶段独立 PDS + GCC 13.2 ROM 综合为 19,042 LUT、10,884 寄存器、0 latch，
并检查了 10,720 组分支、2,132 个 PMA 地址、17,056 组地址提示控制，见
[旧综合](validation/pds-coremark-synthesis.json) 和 [旧 ADS 检查](validation/pds-ads-controls.json)。
这些记录不作为当前 CPU 或当前固件的综合证据。

原分支约 5.0303/MHz 的数据属于 GCC 15.3 / RV32IM / 旧固件组合；
GCC 13.2、14.2 本地移植版与当前官方六份核心文件也不是相同输入。
比较分数必须同时核对工具链、源文件、运行库、地址布局和计时方法，不能只看 CPU 名称。
原 110 MHz 综合 WNS −0.180 ns 不代表时序通过或最高实板频率。
历史材料保留在 `validation/`、`evidence/v15/` 和 Git 提交 `c7167eb`。
