# CPU V3.5 开发交接（尚未验收）

以 2026-10-08 用户要求和根 AGENTS.md 为准。当前在隔离开发分支；本轮事实见
[候选记录](validation/v3_5/candidate-search/README.md)。SoC 的 search-budget.json
管理北京时间 20:55:41 起的 24 小时／6 次完整 PnR（包括同频与最终构建）。
仅根集成流程启动 PDS。正式性能来自本轮集成板测 3+1，不跑长 CoreMark RTL。
V3.1 独立成绩与 V6.1 板测基线必须分开。最终源码和版本先于最终硬件冻结，后续
文档提交不能让 source.json 追逐新提交。未达标不创建正式 V3.5/v6.5 tag。

下面“本轮”“无实板”、2600 次固件和长仿真要求仅指 V3.1 历史记录。

## V3.1 历史交接

先读仓库根 `AGENTS.md`、`README.md`、`VERSION`、本目录 `NEW_COMPUTER_GUIDE.md` 和 `V3_1_VALIDATION.md`。`VALIDATION.md` 保存 V3 历史记录，不能把其短仿真或旧 PDS 结果当成本版验收。

`src/main` 管理 Chisel CPU、`CoreTop` 导出和 `coremark_test_soc` 测试基座；`performance_soc/linux` 管理完整 SoC 的 CPU/SYS 分域、CDC、DDR、外设、板级约束和位流。两个测试环境的时钟、固件、CoreMark 分数与 PDS 范围分别记录。

## 当前 CPU 契约

- 硬件和固件使用 RV32IMA，无 C；编译明确 `-march=rv32ima_zicsr_zifencei -mabi=ilp32`。CoreMark 固定 GCC 16.2.0/O2，实际 target 是 `riscv32-unknown-elf`。
- Chisel 是 CPU RTL 唯一编辑源。运行 `scripts/newpc.ps1 -Stage Emit` 后，核对 `generated/core/CoreTop.sv`、`generated/sim/CoreTop.sv`、两个 `emit-config.json` 和 schema 2 `generated/manifest.json`。不能只手改生成 SV。
- CPU 测试基座的 `cpu_core_top` 位于 `coremark_test_soc/rtl/cpu_top.v`。完整 SoC 的 `rtl/cpu_top.v` 包装层由集成仓库维护；不能互相覆盖。
- 正式同步：`src/cpu/generated/core/CoreTop.sv` → `performance_soc/rtl/cpu/CoreTop.sv`；综合侧 `emit-config.json` 和 `src/cpu/scripts/meminit/zero_*.hex` 同步到集成仓库同名位置。由集成仓库 `scripts/sync_cpu.ps1` 写入来源与 SHA。
- 旧 VexRiscv 包装层和旧 150 MHz/Sv32 Linux 测试文件在 `cpu/legacy/`，不编入当前项目，也不证明当前 CPU 可启动 Linux。

## 复现与验收

从 `cpu/` 运行 Doctor、Emit、Unit、Functional、CoreMark、PdsPrepare、PdsCheck 和 PdsSynthesis；准确命令和工具设置见新电脑指南。`Synthesis` 是保留的完整 DMA 实验，与正式 CPU 测试基座的 `PdsSynthesis` 不同。PDS 测试基座只约束测试时钟；集成 SoC 的最终 slow/fast 布线 STA 由 `performance_soc` 独立签核。

正式 CoreMark 为三次性能种子 `(0,0,0x66)` 和一次验证种子 `(0x3415,0x3415,0x66)`，每次目标 CPU 计时至少 10 秒且 CRC 正确。固定 2600 次固件在 `coremark_test_soc/sim/coremark_ima` 与 `coremark_validation`；`scripts/run_coremark_release.ps1` 用一份主机模型做 3+1 独立测量，`newpc CoreMark` 只重放一次性能。此源仓使用 CSR mcycle；集成 SoC 使用 SYS 域 CLINT mtime。两种得分公式、时钟与输入不能混用。V3 的十次迭代结果仅是短校准。

本轮源仓 3+1 在 49.5 MHz 测试工程全部 PASS；三次性能均为 5.052514868 CoreMark/MHz、10.395863 目标秒，验证例为 5.036012135 CoreMark/MHz、10.429930 目标秒。完整输入、CRC 与原始日志见 [V3.1 记录](V3_1_VALIDATION.md)及其正式证据目录。完整 SoC 主树 div15 在 CPU 59.4 MHz、SYS/TIMEBASE 49.5 MHz 完成新快照、布线、slow/fast 最终 STA 和同轮位流，全部时序约束通过。更高的 div14（63.642857 MHz）也完成布线，但最终 CPU slow setup −2.246 ns、TNS −11.364 ns，7 个端点失败。搜索 49.5–63.642857 MHz 范围内，59.4 MHz 是完整 SoC STA 通过的最高已测 CPU 档位；这只是仿真与 PDS 结论。用户决定完整 SoC 本轮沿用 59.4 MHz 的 10 次 RTL 短测：性能种子折算约 5.025 CoreMark/MHz，计时 0.033504 秒，官方因不足 10 秒拒绝；固定 10 次固件与位流中的生产固件不同，因此不报告正式完整 SoC 成绩。源仓正式分数不能代替集成结果，集成短测与交付证据由集成仓库单独记录。

任何综合敏感控制修改均运行 RTL 回归、检查 ADS 后网表预期分支与选择器未被折叠，并在可行时做门级验证。Verilog/SystemVerilog 不新增 function；PDS 关键组合控制不用 procedural integer 动态索引优先搜索。时钟、复位或 CDC 修改由完整 SoC 的专项测试覆盖。

本机配置 `toolchain.local.json`、`work/`、target 和 PDS 数据库不入 Git。历史证据和第三方 CoreMark/厂商 IP 保留来源边界；当前说明以本轮输入、哈希和真实测试结果为准。当前无实板，Linux 启动未测试。Markdown 是权威文档，修改后从 `scripts/export_handoff_docx.py` 重建 DOCX。
