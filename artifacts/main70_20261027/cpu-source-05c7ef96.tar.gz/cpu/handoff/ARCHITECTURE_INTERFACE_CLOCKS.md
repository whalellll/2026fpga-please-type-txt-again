# CPU V3.5 candidate architecture, interface and clocks

Current work is not yet accepted. Candidate evidence is in
`validation/v3_5/candidate-search/README.md`; generated/core/emit-config.json
records the actual emitted configuration. V3.1 numbers below are historical.
V3.5 formal performance uses the integrated performance_soc board, fixed
SYS/TIMEBASE 49.5 MHz, with no new independent-CPU formal score assumed.
V6.1 has separate board CoreMark evidence from 2026-10-08; older statements
about absent board evidence apply only to their original date.

## V3.1 baseline and stable integration contract

This describes the `src/cpu` source and its CPU test SoC. The complete board
integration, CPU/SYS CDC, DDR, peripherals and routed clock result are owned by
`performance_soc/linux` and have separate evidence.

## Current CPU profile

The emitted `CoreTop` is RV32IMA with Zicsr/Zifencei and no C instruction
support. The release configuration is machine-mode oriented;
`Params.ENABLE_SUPERVISOR=false`. S-mode and Sv32 source/tests remain for
independent validation, but this release cannot claim a Linux boot.

Current C1 configuration includes a four-instruction fetch block, a 32-entry ROB,
four entries in each ALU reservation station, two memory reservation entries
and a two-entry store buffer. The P0 fallback BTB has 64 sets, two ways and
hashed indices; the RAS retains two entries. Active results use ROB tags with
a separate committed architectural register file. `PRF_ENTRIES=48` describes
the retained standalone PhysicalRegisterFile module/tests, not an instantiated
48-entry physical allocator in current CoreTop. Each L1 I/D cache is 128 sets × 32 bytes
× 2 ways = 8 KiB. The L2 is 512 sets × 32 bytes × 1 way = 16 KiB. These are
`Params.scala` values, not a board resource or timing result.

C1 moves tag-reuse invalidation to a clear-priority result-valid update,
removing decode/rename allocation from bank/owner write controls without
adding a pipeline stage. The result-file module still has five write inputs;
current RsMem explicitly disables fused paired-load issue, so integrated ADS
legitimately removes mem2/write-port-3 and bank4. Four active result banks and
valid masking must remain. Short RTL scores do not establish routed frequency.

## `CoreTop` boundary

The generated module takes `io_aclk`, active-low `io_aresetn`, a 32-bit
`io_resetVector`, and eight interrupt bits. Its memory interface is five AXI
ready/valid channels: AR/R and AW/W/B. Addresses and data are 32 bits, IDs and
WID are four bits, LEN is eight bits, LOCK is two bits, WSTRB is four bits,
and response codes are two bits. Burst, size, cache and protection fields
are explicit; each channel can stall independently. The debug/commit ports
are observations and controls, not a replacement for the AXI transaction
contract. The exact port list is in `generated/core/CoreTop.sv`.

The source test wrapper `coremark_test_soc/rtl/cpu_top.v` exposes the same AXI
boundary and a local CLINT for architecture tests. The CoreMark harness
`coremark_soc_top.v` instantiates `CoreTop` directly with a boot vector of
`0x1c00_0000`. The full SoC has its own `rtl/cpu_top.v` and CDC bridge; neither
source wrapper should be copied over the integrated wrapper.

## Test address and clock map

| Region or timer | CPU test SoC behavior |
| --- | --- |
| `0x1c00_0000..0x1c01_ffff` | 128 KiB boot/work BRAM in `axi_bram_uart.v`; the CoreMark workspace stays cacheable. |
| `0x1fe0_01e0` | UART transmit register used by the CoreMark port. |
| `0x1fe0_0000` | Test GPIO register in the BRAM/UART peripheral. |
| `0x0200_0000` window | Local CLINT in `cpu_core_top` architecture wrapper; it is separate from the integrated SYS-domain CLINT. |
| CPU `mcycle` CSR | Formal source CoreMark time base, 64-bit high/low-safe read. |

`coremark_test_soc` has one test `clk`; the tracked FDC constrains it to
20.2020202 ns (49.5 MHz). The CPU pipeline, caches, test BRAM/UART and the
architecture wrapper's local CLINT use that clock. The `CPU_HZ` testbench parameter and
`CORE_CLOCKS_PER_SEC` in the firmware describe this actual test clock; they do
not emulate a faster independent CPU clock. This CPU test project has no
board-level pin constraints or complete routed STA.

For the integrated SoC, `CoreTop` and `mcycle` use `cpu_clk`, while AXI traffic
crosses a full-channel CDC bridge to `sys_clk=49.5 MHz`; system CLINT `mtime`
uses the separate SYS-derived time base. The SoC owns PLL, reset, CDC, FDC and
final slow/fast STA. Its CoreMark seconds use SYS CLINT ticks, so its score
formula and frequency denominator differ from the source test SoC's `mcycle`
formula. See the integrated repository's current clock/CDC docs and validation
for the actual selected CPU/SYS/TIMEBASE frequencies.

## Historical V3.1 / V6.1 clock evidence

The V6.1 integrated main-tree div15 run has its own frozen snapshot, routed PDS
result and same-run bitstream. At `cpu_clk=59.4 MHz`, `sys_clk=49.5 MHz`
and `timebase=49.5 MHz`, final slow/fast STA met all constraints. The higher
div14 setting (`cpu_clk=63.642857 MHz`) routed but failed final CPU slow
setup: −2.246 ns worst slack, −11.364 ns total negative slack and seven
failing endpoints. In the tested 49.5–63.642857 MHz search range, 59.4 MHz
was the highest CPU setting with complete-SoC STA passing in that search.
This original record covered simulation and PDS before board testing. The integrated repository's
59.4 MHz RTL pilot used ten iterations and reported about 5.025 CoreMark/MHz
for the performance seed. Its timed interval was 0.033504 target seconds, so
the official port rejected it under the ten-second rule. The pilot used a
separately compiled fixed-iteration ROM, distinct from the firmware in the
routed production bitstream. It is an estimate, not a formal integrated-SoC
score. The source test SoC retains its separate, formal 49.5 MHz 3+1 result.

The later V6.1 board baseline on 2026-10-08 measured three performance runs
at CPU 59.4 MHz and SYS/TIMEBASE 49.5 MHz: mean 5.070148251157226
CoreMark/MHz. The user identifies the loaded artifact as the V6.1 delivery;
no FPGA configuration readback was recorded. These later board measurements
do not change the failed div14 result and do not validate the new C1 hardware.
