# CPU V3.1 验证记录

本文件记录 `src/main` 的 V3.1 输入与本轮执行结果。CPU 测试 SoC 和
`performance_soc/linux` 是不同工程；完整 SoC 的时序与 CoreMark 由集成仓库单独记录。
旧 [V3 验证记录](VALIDATION.md) 是历史证据，其短仿真分数不能充当本版正式成绩。

## 固定输入

| 项目 | 当前输入 |
| --- | --- |
| 发布版本 | 仓库根 `VERSION` = `3.1.0` |
| ISA / ABI | `rv32ima_zicsr_zifencei` / `ilp32`，无 C、浮点或向量 |
| 编译器 | `riscv32-unknown-elf` GCC 16.2.0，CoreMark `-O2` |
| 官方 CoreMark | commit `cfa9ab377835911f23d9b0831c7be302ed1f58de`，六个固定文件逐 SHA 检查 |
| 综合 CoreTop | `b73b680b108df9ee5c3819a4c4399ef4424ab1e112e4cc329ac52e58235c0c70` |
| 仿真 CoreTop | `d3e15490900dd111f85d07ff27696da16b75e888e7a14ca71c466dad706735ad` |
| 正式迭代/工作集 | 性能与验证各固定 2600 次，`TOTAL_DATA_SIZE=2000` 字节 |
| 正式性能固件 BIN | `fcb06ddb6e81d98eb9f05bf8b46f7a8bf709c3799f1ee6e4f730a0692ab64f7f` |
| 正式验证固件 BIN | `32ad28bee8c94be1330945db9ed8d0918513758cfa04b153d0989556008d0864` |

本次验证机的外部工具位于 `D:\LJL\WORK\GitHub\.cpu-v3-tools\contest riscv32 gcc16`、
`D:\LJL\WORK\GitHub\.cpu-v3-tools\jdk-17.0.20.1+1`、
`D:\LJL\WORK\GitHub\.cpu-v3-tools\sbt-launch-1.10.1.jar`、
`D:\LJL\WORK\msys64`（Verilator 入口为 `mingw64\bin\verilator`）与
`D:\LJL\WORK\pango\PDS_2022.2-SP6.4`。
GCC 16.2.0、Verilator 5.050、PDS 2022.2-SP6.4 是外部安装条件，
不随源码 ZIP 提供；这些绝对路径只记录本机运行来源，新电脑按
[工具安装与本机配置](NEW_COMPUTER_GUIDE.md)选择自己的位置。

Chisel `Emit` 已成功重新生成两份 RTL、两个 `emit-config.json` 和 schema 2
`generated/manifest.json`。本次 Chisel 改动是 CSR 对象改名、六个无消费者的配置常量删除及注释修正，
综合 RTL 字节与 V3 基线相同；此哈希相同是实际导出结果，不是要求新版必须相同。

## 本轮验证

| 检查 | 结果 | 证据边界 |
| --- | --- | --- |
| Chisel Emit | PASS | `scripts/newpc.ps1 -Stage Emit`，实际重新导出 |
| PDS portable open | PASS | `scripts/newpc.ps1 -Stage PdsCheck`，隔离含空格目录，5 个源码/约束输入与 ROM 校验 |
| 单元测试 | PASS，49/49 | `scripts/newpc.ps1 -Stage Unit`，最终 Chisel 清理后重跑，2026-10-03 21:30 CST |
| 架构 RTL 回归 | PASS，8/8 | `scripts/newpc.ps1 -Stage Functional`，最终 Chisel 清理后重跑；`work/logs/newpc-native/Functional-20261003-133231-f9b323.stdout.log` |
| CPU 测试工程 ADS 控制审计 | PASS | 固定 2600 次性能 ROM 的 Compile/ADS 与控制网表审计；[原始报告与网表](validation/v3_1/source-pds/README.md)；不等于整机 P&R |
| CoreMark 正式仿真 | PASS，3+1 | 三次性能与一次验证，各 2600 次、CPU mcycle ≥10 秒；[四例原始日志与结果](validation/v3_1/source-coremark/README.md) |

## 源仓正式 CoreMark 结果

固定 49.5 MHz 的 CPU 测试 SoC RTL 仿真于 2026-10-03 21:52:13 CST 启动，
2026-10-04 00:23:04 CST 完成；有界启动器和四例均以退出码 0 结束。
这是真实单时钟测试工程的 CPU `mcycle` 计时，不是主机墙上时间、集成 SoC
的 CLINT 计时或开发板实测。每例 2600 次迭代、`TOTAL_DATA_SIZE=2000` 字节，
性能种子重复使用 `(0,0,0x66)`，验证种子为 `(0x3415,0x3415,0x66)`。

| 运行 | 目标 CPU mcycle | 目标秒数 | 绝对 iterations/s | CoreMark/MHz | seed CRC / final CRC |
| --- | ---: | ---: | ---: | ---: | --- |
| 性能 1 | 514,595,220 | 10.395863030 | 250.099486 | 5.052514868 | `e9f5` / `25b5` |
| 性能 2 | 514,595,220 | 10.395863030 | 250.099486 | 5.052514868 | `e9f5` / `25b5` |
| 性能 3 | 514,595,220 | 10.395863030 | 250.099486 | 5.052514868 | `e9f5` / `25b5` |
| 验证 1 | 516,281,520 | 10.429929697 | 249.282601 | 5.036012135 | `18f2` / `70a1` |

预先声明的三次性能均值为 **5.052514868 CoreMark/MHz**
（`summary.json` 原值 **5.052514867899473**）、
**250.099486 iterations/s**；范围为 5.052514868–5.052514868 CoreMark/MHz。
验证例独立报告，不参加性能均值。源仓公式为
`CoreMark/MHz = iterations × 1,000,000 / mcycle`；
绝对 `iterations/s = iterations × 49,500,000 / mcycle`。
严格检查器核对官方算法 CRC、最终程序的 `Correct operation validated`、
每例不少于 10 目标秒、实际测试时钟和禁止跳过计时的宏。

[正式证据目录](validation/v3_1/source-coremark/README.md)保存启动器 stdout/stderr、
`group.json`、四次原始 UART 日志、逐例严格检查输出、结果 JSON、运行时元数据、
固件清单、主机模型 SHA 和所有 RTL/初始化输入哈希。四例共享 Verilator 5.050
主机 C++ `-Os` 模型，SHA-256 为
`a547925a34da35a1957ddc5ba760db329393568ab7fade4fc2e66b1a794e3d2c`；
目标固件仍使用 GCC 16.2.0 `-O2`，完整逐源编译参数、链接参数、
libgcc 身份与 SHA 见两套固件的 `compile_arguments`、`build_arguments`、
`common_libgcc` 清单字段。`-Os` 只作用于主机模拟器的 C++ 构建，可能影响模型大小和仿真耗时，不改变目标 ROM 或上述分数。

预发布 10 次迭代校准固件在 49.5 MHz 下测得 1,994,149 CPU mcycle，约
0.04029 目标秒。相同 RTL/固件和严格 CRC 检查下，主机 Verilator C++ `-Os`
仿真用时 16.824 秒，`-O3` 用时 21.444 秒；正式入口选 `-Os`，它只改变
主机仿真器编译，不改变目标 GCC 16.2.0 `-O2` 固件。此轮校准不构成正式分数。

正式固件清单显式记录两组种子、2600 次迭代、2000 字节工作集、完整编译与链接
参数及 GCC/libgcc 哈希。构建脚本对预处理后的五个种子初始化值和工作集宏做门禁；
仿真运行以目标 CPU `mcycle` 而非主机墙上时间判定至少十秒。当前四例共用一份
`-Os` 主机 Verilator 模型，其 SHA-256 为
`a547925a34da35a1957ddc5ba760db329393568ab7fade4fc2e66b1a794e3d2c`。

固定性能 ROM 的 CPU 测试工程 ADS 在 2026-10-03 用时 355.6 秒，通过了
42,880 个前端分支选择、2,144 个 PMA 地址和 17,152 个 RsMem 提示条件测试。
ADS 网表 SHA-256 为 `0dff7dae91c878d0f3a526e343a61bbfd122435d1130350271c9c4a5593d7d4d`；
资源为 19,098 LUT、10,880 寄存器、90 DRM、0 锁存器。完整输入、原始日志、
报告和压缩网表见上述 PDS 证据目录。

## 完整 SoC 的频率搜索与主树签核

集成仓库 `performance_soc/linux` 已物理评估 CPU PLL 分频 18、17、16、15、14，
覆盖 49.5–63.642857 MHz，SYS/TIMEBASE 固定 **49.5 MHz**。分频 15 的 CPU 为
**59.4 MHz**；主树使用新冻结快照独立完成 ADS、布局布线、slow/fast 最终 STA
和同轮位流。主树 PDS run ID 为 `6e934e9f84094159bff9a8870e260e8e`，最终
RTR 报告 `All Constraints Met`，setup、hold、recovery、removal、最小脉宽
均无失败端点；10 组 CDC Gray 最大偏斜在两个角各通过。CPU 同域 slow setup
最差裕量 +1.665 ns，slow/fast hold 最差裕量 +0.062/+0.047 ns。主树冻结快照
SHA-256 为 `1129e12bf8bae09ded908e7b129c9f6a94141f134aec6262a12bfa3b21224b4e`，
最终 RTR SHA-256 为 `a6abeb9e8c0face73f16578cab8a1d5fd3b43206cbe91ec8e49f38edf99d5315`，
同轮 `.sbit` SHA-256 为
`a5defe7bcf91921b38a17d1eec7cea40a69fe8ef3f42536605c2577ab0a3d934`。
原始 RTR、位流、输入快照与归档见集成仓库
`docs/validation/frequency-search/divisor-15.md` 及其 run ID 子目录。

更高的分频 14 为 **63.642857 MHz**，已完成布线，但 post-PnR 最终 CPU slow
setup 的最差裕量为 **−2.246 ns**、TNS **−11.364 ns**、失败端点 **7**，因此
该档位不通过完整 SoC STA。搜索 49.5–63.642857 MHz 范围内，**59.4 MHz
是完整 SoC STA 通过的最高已测 CPU 档位**；这不是芯片理论上限或实板频率。
早期独立 `soc_freq_div15_seed4` 候选 run
`b8e7389b99d948ae9011d2ee8c59ffca` 同样通过最终 STA，但其 `.sbit`
SHA-256 `19c264f2626875e882ea5ff81e0fe5249a9d71193a616dfda8c071d9a021401c`
与主树位流不同，不可互换。

用户决定完整 SoC 本轮沿用主树 59.4 MHz 的 10 次迭代 RTL 短测，不再等待
集成 3 次性能加 1 次验证长跑。集成短测的 SYS/TIMEBASE 为 49.5 MHz：
性能种子 1,658,460 CLINT ticks、0.033504242424 目标秒，按 CPU 59.4 MHz
折算约 **5.024741829 CoreMark/MHz**；验证种子 1,660,157 ticks、
0.033538525253 目标秒，折算约 **5.019605575 CoreMark/MHz**。两例 CRC
与对应短测预期一致，但官方 CoreMark 端口均因运行不足 10 秒报告
`COREMARK_FAIL`；这些数值仅是估值，**没有完整 SoC 正式 CoreMark 成绩**。
短测使用独立编译的固定 10 次迭代 BIN（SHA-256 `212defe1c704999c13b9812ba0ac3dabc3ca55f96ccfe96acd3f4ef269c303e8`）
和 ROM（SHA-256 `ca893d7a41e35fe87c9ff6ab51291a7b4875d126fb9f5ef01d7b8bb8a4c62fd5`），
与通过 PDS 的位流所绑定的生产 BIN/ROM 不同；短测自身未绑定 PDS 快照或位流。
原始结果位于集成仓库 `artifacts/selftest/production_coremark_pilot_f5b3bcc4bca848cf80497bb7ef9e2af4/`，
`summary.json` SHA-256 为 `55a1059262d95fc37c81f12709fa32009233088a94149d062a05b860ef4d5a3b`。
本页源仓 49.5 MHz 单时钟正式均值 **5.052514867899473 CoreMark/MHz**
保持独立，不能充当完整 SoC 的结果。

本次没有开发板，Linux 启动也未测试；当前发布配置未启用 S 态/Sv32，不能宣称
可启动 Linux。历史 Linux 载荷只保留原始来源。CPU 测试工程的 PDS 约束只有测试
`cpu_clk`，不能从其综合或打开结果推断板级最高频率。完整 SoC 本轮的
CoreMark 短测范围与证据以集成仓库记录为准。
