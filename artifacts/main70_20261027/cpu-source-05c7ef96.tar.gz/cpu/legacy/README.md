# Historical CPU references

`reference_cpu_top.v` is the old VexRiscv/Wishbone wrapper, preserved with its
original internal module names. It is not used by current `CoreTop` builds.

`linux/` contains an earlier 150 MHz, Sv32 and address-map simulation experiment.
Its DTS, firmware assumptions and comments describe that historical experiment;
they do not establish S-mode, Sv32 or Linux boot support for CPU V3.1.
