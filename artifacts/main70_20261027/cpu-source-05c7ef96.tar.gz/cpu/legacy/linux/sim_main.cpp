#include "VCoreTop.h"
#include "verilated.h"
#include <cstdint>
#include <cstdlib>
#include <deque>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

// A protocol-level simulation platform. RAM models AXI memory, not an FPGA DDR PHY.
struct Platform {
    std::vector<uint8_t> ram = std::vector<uint8_t>(64u << 20);
    std::vector<uint8_t> rom = std::vector<uint8_t>(128u << 10);
    uint64_t ticks=0, compare=~uint64_t(0);
    uint32_t msip=0, priority=0, enable[2]={0,0}, threshold[2]={0,0};
    uint8_t ier=0, lcr=0, dll=0, dlm=0, scratch=0;
    bool claimed=false, passed=false;
    std::string uart;
    uint8_t* memory(uint32_t a) {
        if(a>=0x80000000u && a<0x84000000u) return &ram[a-0x80000000u];
        if(a>=0x1c000000u && a<0x1c020000u) return &rom[a-0x1c000000u];
        return nullptr;
    }
    void load(const std::string& file,uint32_t address) {
        std::ifstream f(file,std::ios::binary);
        if(!f) throw std::runtime_error("missing image: "+file);
        char c; while(f.get(c)) { auto p=memory(address++); if(!p) throw std::runtime_error("image exceeds RAM"); *p=uint8_t(c); }
    }
    bool irq(unsigned context) const { return (ier&2) && !claimed && (enable[context]&2) && priority>threshold[context]; }
    uint8_t interrupts() const { return (irq(0)?1:0)|(msip?2:0)|(irq(1)?64:0)|(ticks>=compare?128:0); }
    uint32_t read(uint32_t a, uint8_t &error) {
        a &= ~3u; error=0;
        if(auto p=memory(a)) return uint32_t(p[0])|(uint32_t(p[1])<<8)|(uint32_t(p[2])<<16)|(uint32_t(p[3])<<24);
        if(a>=0x10000000u && a<0x10000100u) {
            uint32_t result=0;
            for(unsigned i=0;i<4;i++) {
                uint8_t v=0; unsigned reg=(a+i)&255;
                if(reg==0) v=(lcr&128)?dll:0;
                if(reg==1) v=(lcr&128)?dlm:ier;
                if(reg==2) v=(ier&2)?2:1;
                if(reg==3) v=lcr;
                if(reg==5) v=0x60;
                if(reg==6) v=0xb0;
                if(reg==7) v=scratch;
                result |= uint32_t(v)<<(i*8);
            }
            return result;
        }
        if(a==0x02000000u) return msip;
        if(a==0x02004000u) return uint32_t(compare);
        if(a==0x02004004u) return compare>>32;
        if(a==0x0200bff8u) return uint32_t(ticks);
        if(a==0x0200bffcu) return ticks>>32;
        if(a>=0x0c000000u && a<0x10000000u) {
            unsigned o=a-0x0c000000u;
            if(o==4) return priority;
            if(o==0x1000) return ((ier&2)&&!claimed)?2:0;
            for(unsigned c=0;c<2;c++) {
                if(o==0x2000+c*0x80) return enable[c];
                if(o==0x200000+c*0x1000) return threshold[c];
                if(o==0x200004+c*0x1000) { bool active=irq(c); if(active) claimed=true; return active?1:0; }
            }
            return 0;
        }
        error=3; return 0;
    }
    uint8_t write(uint32_t a,uint32_t value,uint8_t strb) {
        a &= ~3u;
        if(auto p=memory(a)) { for(unsigned i=0;i<4;i++) if(strb&(1<<i)) p[i]=value>>(i*8); return 0; }
        if(a>=0x10000000u && a<0x10000100u) {
            for(unsigned i=0;i<4;i++) if(strb&(1<<i)) {
                uint8_t v=value>>(i*8); unsigned reg=(a+i)&255;
                if(reg==0) {
                    if(lcr&128) dll=v;
                    else { std::cout<<char(v)<<std::flush; uart+=char(v);
                        if(uart.size()>1024) uart.erase(0,512);
                        passed=uart.find("LINUX_USER_INIT_PASS pid=1")!=std::string::npos;
                    }
                }
                if(reg==1) { if(lcr&128) dlm=v; else ier=v; }
                if(reg==3) lcr=v;
                if(reg==7) scratch=v;
            }
            return 0;
        }
        auto merge=[&](uint32_t old) { for(unsigned i=0;i<4;i++) if(strb&(1<<i)) old=(old&~(255u<<(i*8)))|(value&(255u<<(i*8))); return old; };
        if(a==0x02000000u) { msip=merge(msip)&1; return 0; }
        if(a==0x02004000u) { compare=(compare&0xffffffff00000000ull)|merge(uint32_t(compare)); return 0; }
        if(a==0x02004004u) { compare=(compare&0xffffffffull)|(uint64_t(merge(compare>>32))<<32); return 0; }
        if(a==0x0200bff8u) { ticks=(ticks&0xffffffff00000000ull)|merge(uint32_t(ticks)); return 0; }
        if(a==0x0200bffcu) { ticks=(ticks&0xffffffffull)|(uint64_t(merge(ticks>>32))<<32); return 0; }
        if(a>=0x0c000000u && a<0x10000000u) {
            unsigned o=a-0x0c000000u;
            if(o==4) priority=merge(priority)&7;
            for(unsigned c=0;c<2;c++) {
                if(o==0x2000+c*0x80) enable[c]=merge(enable[c])&2;
                if(o==0x200000+c*0x1000) threshold[c]=merge(threshold[c])&7;
                if(o==0x200004+c*0x1000 && value==1) claimed=false;
            }
            return 0;
        }
        return 3;
    }
};
struct Transaction { uint32_t addr; uint8_t id,len,size,burst,beat=0,error=0; uint64_t due=0; };
int main(int argc,char** argv) {
    Verilated::commandArgs(argc,argv);
    Platform p; VCoreTop d;
    p.load("work/linux/images/fw_jump.bin",0x80000000);
    p.load("work/linux/images/Image",0x80400000);
    p.load("work/linux/images/e91-sim.dtb",0x83000000);
    uint32_t boot[]={0x00000513,0x830005b7,0x00000613,0x800002b7,0x00028067};
    for(unsigned i=0;i<5;i++) p.write(0x1c000000+i*4,boot[i],15);
    uint64_t maxCycles=argc>1?std::strtoull(argv[1],nullptr,0):500000000;
    std::deque<Transaction> reads,writes;
    std::deque<std::pair<uint8_t,uint8_t>> responses;
    bool rvalid=false; uint32_t rdata=0; uint8_t rid=0,rresp=0,rlast=0;
    uint64_t nread=0,nwrite=0;
    for(uint64_t cycle=0;cycle<maxCycles && !Verilated::gotFinish();cycle++) {
        bool reset=cycle<16;
        d.io_aresetn=!reset; d.io_resetVector=0x1c000000u;
        d.io_intrpt=reset?0:p.interrupts();
        d.io_break_point=0; d.io_infor_flag=0; d.io_reg_num=0;
        d.io_arready=!reset && reads.size()<8;
        d.io_awready=!reset && writes.size()<8;
        d.io_wready=!reset && !writes.empty();
        if(!rvalid && !reads.empty() && cycle>=reads.front().due) {
            auto &t=reads.front(); rdata=p.read(t.addr,rresp); rid=t.id; rlast=t.beat==t.len; rvalid=true;
        }
        d.io_rvalid=rvalid; d.io_rdata=rdata; d.io_rid=rid; d.io_rresp=rresp; d.io_rlast=rlast;
        d.io_bvalid=!responses.empty(); d.io_bid=responses.empty()?0:responses.front().first;
        d.io_bresp=responses.empty()?0:responses.front().second;
        d.io_aclk=0; d.eval();
        bool ar=d.io_arvalid&&d.io_arready, aw=d.io_awvalid&&d.io_awready;
        bool w=d.io_wvalid&&d.io_wready, r=d.io_rvalid&&d.io_rready, b=d.io_bvalid&&d.io_bready;
        Transaction art{d.io_araddr,d.io_arid,d.io_arlen,d.io_arsize,d.io_arburst,0,0,cycle+8};
        Transaction awt{d.io_awaddr,d.io_awid,d.io_awlen,d.io_awsize,d.io_awburst};
        auto wd=d.io_wdata; auto ws=d.io_wstrb; auto wl=d.io_wlast;
        d.io_aclk=1; d.eval();
        if(!reset && d.io_fatalMemoryError) throw std::runtime_error("CPU reported an unrecoverable committed-store bus error");
        if(b) responses.pop_front();
        if(r) { auto &t=reads.front(); rvalid=false; if(t.beat++==t.len) reads.pop_front(); else if(t.burst) t.addr+=1u<<t.size; }
        if(w) {
            auto &t=writes.front(); t.error|=p.write(t.addr,wd,ws);
            if(bool(wl)!=(t.beat==t.len)) throw std::runtime_error("AXI WLAST mismatch");
            if(t.beat++==t.len) { responses.emplace_back(t.id,t.error); writes.pop_front(); }
            else if(t.burst) t.addr+=1u<<t.size;
            nwrite++;
        }
        if(ar) { reads.push_back(art); nread++; }
        if(aw) writes.push_back(awt);
        if(!reset) p.ticks++;
        if(p.passed) { std::cout<<"\nRTL_LINUX_PASS cycles="<<cycle<<" reads="<<nread<<" writes="<<nwrite<<"\n"; d.final(); return 0; }
        if(cycle && cycle%1000000==0) std::cerr<<"progress cycles="<<cycle<<" reads="<<nread<<" writes="<<nwrite<<" last_ar=0x"<<std::hex<<d.io_araddr<<std::dec<<"\n";
    }
    d.final(); std::cerr<<"RTL_LINUX_TIMEOUT\n"; return 1;
}
