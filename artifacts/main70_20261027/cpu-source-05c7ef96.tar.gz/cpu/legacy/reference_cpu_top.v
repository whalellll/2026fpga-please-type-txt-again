`timescale 1ns/1ps

// Linux-capable legacy-named CPU top. Use this module when external interrupt sources
// are available.  The core_top compatibility wrapper below ties them low.
module cpu_v2_core_top #(
    parameter [31:0] RESET_VECTOR = 32'h1c00_0000
)(
    input  wire        aclk,
    input  wire        aresetn,
    input  wire [31:0] external_interrupts,

    output wire [3:0]  arid,
    output wire [31:0] araddr,
    output wire [7:0]  arlen,
    output wire [2:0]  arsize,
    output wire [1:0]  arburst,
    output wire [1:0]  arlock,
    output wire [3:0]  arcache,
    output wire [2:0]  arprot,
    output wire        arvalid,
    input  wire        arready,
    input  wire [3:0]  rid,
    input  wire [31:0] rdata,
    input  wire [1:0]  rresp,
    input  wire        rlast,
    input  wire        rvalid,
    output wire        rready,
    output wire [3:0]  awid,
    output wire [31:0] awaddr,
    output wire [7:0]  awlen,
    output wire [2:0]  awsize,
    output wire [1:0]  awburst,
    output wire [1:0]  awlock,
    output wire [3:0]  awcache,
    output wire [2:0]  awprot,
    output wire        awvalid,
    input  wire        awready,
    output wire [3:0]  wid,
    output wire [31:0] wdata,
    output wire [3:0]  wstrb,
    output wire        wlast,
    output wire        wvalid,
    input  wire        wready,
    input  wire [3:0]  bid,
    input  wire [1:0]  bresp,
    input  wire        bvalid,
    output wire        bready
);
    wire        i_cyc, i_stb, i_we, i_ack, i_err;
    wire [29:0] i_adr;
    wire [31:0] i_wdata, i_rdata;
    wire [3:0]  i_sel;
    wire [2:0]  i_cti;
    wire [1:0]  i_bte;
    wire        d_cyc, d_stb, d_we, d_ack, d_err;
    wire [29:0] d_adr;
    wire [31:0] d_wdata, d_rdata;
    wire [3:0]  d_sel;
    wire [2:0]  d_cti;
    wire [1:0]  d_bte;

    wire [31:0] d_addr = {d_adr, 2'b00};
    wire d_clint_hit = d_cyc && (d_addr >= 32'h0200_0000) &&
                                  (d_addr <  32'h0201_0000);
    wire [31:0] clint_rdata;
    wire clint_ack, clint_err, timer_irq, software_irq;
    wire [31:0] bridge_d_rdata;
    wire bridge_d_ack, bridge_d_err;

    assign d_rdata = d_clint_hit ? clint_rdata : bridge_d_rdata;
    assign d_ack   = d_clint_hit ? clint_ack   : bridge_d_ack;
    assign d_err   = d_clint_hit ? clint_err   : bridge_d_err;

    cpu_v2_clint u_clint(
        .clk(aclk), .resetn(aresetn), .cyc(d_cyc && d_clint_hit),
        .stb(d_stb), .we(d_we), .addr(d_addr), .wdata(d_wdata),
        .sel(d_sel), .rdata(clint_rdata), .ack(clint_ack),
        .err(clint_err), .timer_irq(timer_irq), .software_irq(software_irq)
    );

    cpu_v2_wb_axi_bridge u_bridge(
        .clk(aclk), .resetn(aresetn),
        .i_cyc(i_cyc), .i_stb(i_stb), .i_we(i_we), .i_adr(i_adr),
        .i_wdata(i_wdata), .i_sel(i_sel), .i_rdata(i_rdata),
        .i_ack(i_ack), .i_err(i_err),
        .d_cyc(d_cyc && !d_clint_hit), .d_stb(d_stb), .d_we(d_we),
        .d_adr(d_adr), .d_wdata(d_wdata), .d_sel(d_sel),
        .d_rdata(bridge_d_rdata), .d_ack(bridge_d_ack), .d_err(bridge_d_err),
        .arid(arid), .araddr(araddr), .arlen(arlen), .arsize(arsize),
        .arburst(arburst), .arlock(arlock), .arcache(arcache), .arprot(arprot),
        .arvalid(arvalid), .arready(arready), .rid(rid), .rdata(rdata),
        .rresp(rresp), .rlast(rlast), .rvalid(rvalid), .rready(rready),
        .awid(awid), .awaddr(awaddr), .awlen(awlen), .awsize(awsize),
        .awburst(awburst), .awlock(awlock), .awcache(awcache), .awprot(awprot),
        .awvalid(awvalid), .awready(awready), .wid(wid), .wdata(wdata),
        .wstrb(wstrb), .wlast(wlast), .wvalid(wvalid), .wready(wready),
        .bid(bid), .bresp(bresp), .bvalid(bvalid), .bready(bready)
    );

    VexRiscv u_cpu(
        .externalResetVector(RESET_VECTOR),
        .timerInterrupt(timer_irq),
        .softwareInterrupt(software_irq),
        .externalInterruptArray(external_interrupts),
        .iBusWishbone_CYC(i_cyc), .iBusWishbone_STB(i_stb),
        .iBusWishbone_ACK(i_ack), .iBusWishbone_WE(i_we),
        .iBusWishbone_ADR(i_adr), .iBusWishbone_DAT_MISO(i_rdata),
        .iBusWishbone_DAT_MOSI(i_wdata), .iBusWishbone_SEL(i_sel),
        .iBusWishbone_ERR(i_err), .iBusWishbone_CTI(i_cti),
        .iBusWishbone_BTE(i_bte),
        .dBusWishbone_CYC(d_cyc), .dBusWishbone_STB(d_stb),
        .dBusWishbone_ACK(d_ack), .dBusWishbone_WE(d_we),
        .dBusWishbone_ADR(d_adr), .dBusWishbone_DAT_MISO(d_rdata),
        .dBusWishbone_DAT_MOSI(d_wdata), .dBusWishbone_SEL(d_sel),
        .dBusWishbone_ERR(d_err), .dBusWishbone_CTI(d_cti),
        .dBusWishbone_BTE(d_bte), .clk(aclk), .reset(~aresetn)
    );

    wire unused = &{1'b0, i_cti, i_bte, d_cti, d_bte};
endmodule

// Drop-in wrapper with exactly the original soc CPU port list.  It is enough
// for boot-to-console Linux.  Instantiate cpu_v2_core_top directly when LAN,
// UART RX, or other device interrupts must be connected.
module core_top #(
    parameter [31:0] RESET_VECTOR = 32'h1c00_0000
)(
    input wire aclk, input wire aresetn,
    output wire [3:0] arid, output wire [31:0] araddr,
    output wire [7:0] arlen, output wire [2:0] arsize,
    output wire [1:0] arburst, output wire [1:0] arlock,
    output wire [3:0] arcache, output wire [2:0] arprot,
    output wire arvalid, input wire arready,
    input wire [3:0] rid, input wire [31:0] rdata,
    input wire [1:0] rresp, input wire rlast, input wire rvalid,
    output wire rready,
    output wire [3:0] awid, output wire [31:0] awaddr,
    output wire [7:0] awlen, output wire [2:0] awsize,
    output wire [1:0] awburst, output wire [1:0] awlock,
    output wire [3:0] awcache, output wire [2:0] awprot,
    output wire awvalid, input wire awready,
    output wire [3:0] wid, output wire [31:0] wdata,
    output wire [3:0] wstrb, output wire wlast, output wire wvalid,
    input wire wready, input wire [3:0] bid, input wire [1:0] bresp,
    input wire bvalid, output wire bready
);
    cpu_v2_core_top #(.RESET_VECTOR(RESET_VECTOR)) u_linux_cpu(
        .aclk(aclk), .aresetn(aresetn), .external_interrupts(32'b0),
        .arid(arid), .araddr(araddr), .arlen(arlen), .arsize(arsize),
        .arburst(arburst), .arlock(arlock), .arcache(arcache), .arprot(arprot),
        .arvalid(arvalid), .arready(arready), .rid(rid), .rdata(rdata),
        .rresp(rresp), .rlast(rlast), .rvalid(rvalid), .rready(rready),
        .awid(awid), .awaddr(awaddr), .awlen(awlen), .awsize(awsize),
        .awburst(awburst), .awlock(awlock), .awcache(awcache), .awprot(awprot),
        .awvalid(awvalid), .awready(awready), .wid(wid), .wdata(wdata),
        .wstrb(wstrb), .wlast(wlast), .wvalid(wvalid), .wready(wready),
        .bid(bid), .bresp(bresp), .bvalid(bvalid), .bready(bready)
    );
endmodule
