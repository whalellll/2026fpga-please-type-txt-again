package e91c
import chisel3._
import chisel3.reflect.DataMirror
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import e91c.exec.{FuAlu,FuAluReference75}
import e91c.config.{AluOpC,BrOp}

class FuAluEquivalence75 extends Module {
  val candidate=Module(new FuAlu)
  val reference=Module(new FuAluReference75)
  val io=IO(chiselTypeOf(candidate.io))
  for((name,port)<-io.elements){
    if(DataMirror.directionOf(port)==ActualDirection.Input){candidate.io.elements(name):=port;reference.io.elements(name):=port}
    else{port:=candidate.io.elements(name);when(!reset.asBool){assert(candidate.io.elements(name).asUInt===reference.io.elements(name).asUInt,"CPU75 FU-ALU cycle mismatch: "+name)}}
  }
}
class FuAluEquivalence75Spec extends AnyFlatSpec with ChiselScalatestTester {
  private def clear(d:FuAluEquivalence75):Unit={
    d.io.elements.values.foreach{
      case b:Bool if DataMirror.directionOf(b)==ActualDirection.Input=>b.poke(false.B)
      case u:UInt if DataMirror.directionOf(u)==ActualDirection.Input=>u.poke(0.U)
      case _=>()
    }
  }
  private def init(d:FuAluEquivalence75):Unit={clear(d);d.reset.poke(true.B);d.clock.step(2);d.reset.poke(false.B);d.clock.step()}
  private val mask=BigInt("ffffffff",16)
  "FU-ALU shift timing" should "preserve every shift amount and immediate/register path at the same cycle" in {
    test(new FuAluEquivalence75){d=>
      init(d)
      val values=Seq("00000000","00000001","40000000","80000000","89abcdef","ffffffff").map(BigInt(_,16))
      for(op<-Seq(AluOpC.SLL,AluOpC.SRL,AluOpC.SRA);amount<-0 until 32;value<-values;imm<-Seq(false,true)){
        clear(d);d.io.issueValid.poke(true.B);d.io.issueAluOp.poke((1<<op).U)
        d.io.issueSrc0.poke(value.U);d.io.issueSrc1.poke((if(imm)31-amount else amount).U)
        d.io.issueImm.poke((if(imm)amount else 31-amount).U);d.io.issueUseImm.poke(imm.B)
        d.io.issuePc.poke(0x1000.U);d.clock.step();d.io.wbValid.expect(true.B)
        val signed=if(value.testBit(31))value-(BigInt(1)<<32)else value
        val expected=if(op==AluOpC.SLL)(value<<amount)&mask else if(op==AluOpC.SRL)value>>amount else (signed>>amount)&mask
        d.io.wbData.expect(expected.U)
      }
    }
  }
  it should "retain nonshift arithmetic, branch/link metadata and bubble/flush timing" in {
    test(new FuAluEquivalence75){d=>
      init(d)
      for(op<-0 until AluOpC.WIDTH;branch<-Seq(0,1<<BrOp.BEQ,1<<BrOp.JAL,1<<BrOp.JALR);phase<-0 until 4){
        clear(d);d.io.issueValid.poke((phase!=1).B);d.io.flush.poke((phase==2).B)
        d.io.issueAluOp.poke((1<<op).U);d.io.issueBrOp.poke(branch.U)
        d.io.issueSrc0.poke(BigInt("fedcba98",16).U);d.io.issueSrc1.poke(13.U)
        d.io.issueImm.poke(0xfffffff4L.U);d.io.issueUseImm.poke((phase==3).B)
        d.io.issuePc.poke(0x1004.U);d.io.issueBrOffs.poke(8.U)
        d.io.issueRobid.poke(7.U);d.io.issueFtqId.poke(2.U);d.io.issuePredTaken.poke(true.B)
        d.clock.step();d.io.wbValid.expect((phase!=1 && phase!=2).B)
      }
    }
  }
  it should "match all outputs for 1600 seeded cycles including multi-bit operation masks" in {
    test(new FuAluEquivalence75){d=>
      init(d);val rng=new scala.util.Random(756018)
      for(cycle<-0 until 1600){
        clear(d)
        d.io.issueValid.poke((rng.nextInt(5)!=0).B);d.io.flush.poke((cycle%47==46).B)
        d.io.issueAluOp.poke(BigInt(AluOpC.WIDTH,rng).U)
        d.io.issueBrOp.poke(BigInt(BrOp.NUM,rng).U)
        d.io.issueSrc0.poke(BigInt(32,rng).U);d.io.issueSrc1.poke(BigInt(32,rng).U)
        d.io.issueImm.poke(BigInt(32,rng).U);d.io.issueUseImm.poke(rng.nextBoolean().B)
        d.io.issuePc.poke((BigInt(30,rng)<<2).U);d.io.issueBrOffs.poke(BigInt(32,rng).U)
        d.io.issueRobid.poke((cycle&31).U);d.io.issueFtqId.poke((cycle&7).U)
        d.io.issuePredTaken.poke(rng.nextBoolean().B);d.clock.step()
      }
    }
  }
}
