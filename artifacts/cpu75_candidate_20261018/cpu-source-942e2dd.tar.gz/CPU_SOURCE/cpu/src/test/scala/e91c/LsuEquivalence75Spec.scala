package e91c
import chisel3._
import chisel3.reflect.DataMirror
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import e91c.mem.{Lsu,LsuReference75}
import e91c.config.MemOp

class LsuEquivalence75 extends Module {
  val candidate=Module(new Lsu)
  val reference=Module(new LsuReference75)
  val io=IO(chiselTypeOf(candidate.io))
  def connect(x:Data,c:Data,r:Data,label:String):Unit=x match {
    case rec:Record=>rec.elements.foreach{case(n,v)=>connect(v,c.asInstanceOf[Record].elements(n),r.asInstanceOf[Record].elements(n),label+"."+n)}
    case vec:Vec[_]=>vec.indices.foreach(i=>connect(vec(i),c.asInstanceOf[Vec[Data]](i),r.asInstanceOf[Vec[Data]](i),label+s"[$i]"))
    case _ if DataMirror.directionOf(x)==ActualDirection.Input=>c:=x;r:=x
    case _=>x:=c;when(!reset.asBool){assert(c.asUInt===r.asUInt,"CPU75 LSU cycle mismatch: "+label)}
  }
  connect(io,candidate.io,reference.io,"io")
}

class LsuEquivalence75Spec extends AnyFlatSpec with ChiselScalatestTester {
  "LSU selector algebra" should "preserve every payload for all guard combinations including invalid writebacks" in {
    val mask=BigInt("ffffffff",16)
    def shape(value:BigInt,b:Boolean,h:Boolean):BigInt=
      if(b)(value&255)*BigInt("01010101",16)else if(h)(value&65535)*65537 else value&mask
    for(bits<-0 until 1024;pattern<-0 until 4){
      def bit(i:Int):Boolean=(bits&(1<<i))!=0
      val mshr=bit(0);val hold=bit(1);val dcReturn=bit(2)
      val mHit=bit(3);val fHit=bit(4);val dcHit=dcReturn && bit(5)
      val uart= !mshr && !hold && !dcReturn && bit(6)
      val b=bit(7);val h=bit(8)
      val d=if(pattern==0)BigInt(0)else if(pattern==1)mask else if(pattern==2)BigInt("89abcdef",16)else BigInt("7f80ff00",16)
      val mData=(d^BigInt("12345678",16))&mask
      val hData=(d^BigInt("cdef0011",16))&mask
      val dcData=(d^BigInt("ff00ff00",16))&mask
      val fast=(d^BigInt("33445566",16))&mask
      val oldReturn=if(mHit)mData else if(dcHit)dcData else fast
      val oldStore=if(mHit||fHit||dcHit)shape(oldReturn,b,h)else d
      val newStore=if(mHit||fHit)shape(if(mHit)mData else fast,b,h)else d
      def select(fallback:BigInt):BigInt=
        if(mshr)mData else if(hold)hData else if(uart)BigInt(0x60)else if(dcReturn)dcData else fallback
      assert(select(oldStore)==select(newStore),s"guard=$bits pattern=$pattern")
    }
  }
  private def clear(x:Data):Unit=x match {
    case r:Record=>r.elements.values.foreach(clear)
    case v:Vec[_]=>v.foreach(clear)
    case b:Bool if DataMirror.directionOf(b)==ActualDirection.Input=>b.poke(false.B)
    case u:UInt if DataMirror.directionOf(u)==ActualDirection.Input=>u.poke(0.U)
    case _=>()
  }
  private def init(d:LsuEquivalence75):Unit={
    clear(d.io);d.reset.poke(true.B);d.clock.step(2);d.reset.poke(false.B);d.clock.step()
  }
  "LSU writeback" should "retain load-hit and dependent word/byte/half stores across DC return" in {
    test(new LsuEquivalence75){d=>
      for(storeOp<-Seq(MemOp.ST_W,MemOp.ST_B,MemOp.ST_H)){
        init(d)
        d.io.issueValid.poke(true.B);d.io.issueRobid.poke(1.U)
        d.io.issueMemOp.poke((1<<MemOp.LD_W).U);d.io.issueBase.poke(0x1000.U)
        d.io.issueBaseReady.poke(true.B);d.io.issueWdataReady.poke(true.B)
        d.io.pmaDReady.poke(true.B);d.io.pmaDMat.poke(1.U);d.io.pmaDPaddr.poke(0x1000.U)
        d.io.dcAddrOk.poke(true.B);d.io.sbEmpty.poke(true.B)
        d.clock.step();d.io.issueValid.poke(false.B)
        var waited=0
        while(!d.io.dcReq.peek().litToBoolean && waited<12){d.clock.step();waited+=1}
        assert(waited<12,"load must reach DCache token allocation")
        d.io.dcRobid.expect(1.U);d.clock.step()
        d.io.issueValid.poke(true.B);d.io.issueRobid.poke(2.U)
        d.io.issueMemOp.poke((1<<storeOp).U);d.io.issueWdataReady.poke(false.B)
        d.io.issueWdataRobid.poke(1.U);d.io.issueBase.poke(0x2000.U)
        d.io.pmaDPaddr.poke(0x2000.U);d.clock.step();d.io.issueValid.poke(false.B)
        d.clock.step(4)
        d.io.dcDataOk.poke(true.B);d.io.dcRespRobid.poke(1.U)
        d.io.dcRdata.poke(BigInt("89abcdef",16).U)
        d.io.wbValid.expect(true.B);d.io.wbRobid.expect(1.U)
        d.io.wbData.expect(BigInt("89abcdef",16).U);d.clock.step()
        d.io.dcDataOk.poke(false.B)
        var storeSeen=false
        for(_<-0 until 12){
          if(d.io.wbValid.peek().litToBoolean && d.io.wbRobid.peek().litValue==2){
            val expected=if(storeOp==MemOp.ST_B)BigInt("efefefef",16)else if(storeOp==MemOp.ST_H)BigInt("cdefcdef",16)else BigInt("89abcdef",16)
            d.io.wbData.expect(expected.U);storeSeen=true
          }
          d.clock.step()
        }
        assert(storeSeen,"dependent store must complete")
      }
    }
  }
  it should "match every output on 1600 seeded cycles with hits, misses, stores and flush" in {
    test(new LsuEquivalence75){d=>
      init(d);val rng=new scala.util.Random(751018)
      var live=Vector.empty[Int];var missed=Vector.empty[Int];var responses=0;var misses=0
      for(cycle<-0 until 1600){
        clear(d.io)
        val flush=cycle%79==78
        d.io.flush.poke(flush.B)
        if(flush){live=Vector.empty;missed=Vector.empty}
        d.io.pmaDReady.poke(true.B);d.io.pmaDMat.poke(1.U);d.io.pmaDPaddr.poke((0x1000+rng.nextInt(32)*4).U)
        d.io.sbEmpty.poke(true.B);d.io.dcAddrOk.poke(true.B)
        d.io.atomicRequest.ready.poke(true.B)
        d.io.retireMask.poke("hffff".U)
        d.io.robHeadValid.poke(true.B);d.io.robHeadRobid.poke((cycle&31).U)
        d.io.stRetireValid.poke(true.B);d.io.stRetireRobid.poke(((cycle-4)&31).U)
        d.io.robABaseReady.poke(true.B);d.io.robABaseData.poke(0x1000.U)
        d.io.robQBaseReady.poke(true.B);d.io.robQBaseData.poke(0x1000.U)
        val op=Seq(MemOp.LD_W,MemOp.LD_B,MemOp.LD_HU,MemOp.ST_W,MemOp.ST_B,MemOp.ST_H)(rng.nextInt(6))
        d.io.issueValid.poke((rng.nextInt(4)!=0 && !flush).B)
        d.io.issueRobid.poke((cycle&31).U);d.io.issueMemOp.poke((1<<op).U)
        d.io.issueBase.poke(0x1000.U);d.io.issueBaseReady.poke(true.B)
        d.io.issueWdata.poke(BigInt(32,rng).U)
        d.io.issueWdataReady.poke((rng.nextInt(3)!=0).B)
        d.io.issueWdataRobid.poke(((cycle-3)&31).U)
        var removed:Option[Int]=None;var addMiss:Option[Int]=None
        if(live.nonEmpty && rng.nextBoolean() && !flush){
          val tag=live.head;d.io.dcRespRobid.poke(tag.U);removed=Some(tag)
          if(rng.nextInt(4)==0){d.io.dcMiss.poke(true.B);addMiss=Some(tag);misses+=1}
          else {d.io.dcDataOk.poke(true.B);d.io.dcRdata.poke(BigInt(32,rng).U);responses+=1}
        }
        if(missed.nonEmpty && rng.nextBoolean() && !flush){
          d.io.dcMshrDataOk.poke(true.B);d.io.dcMshrRobid.poke(missed.head.U)
          d.io.dcMshrRdata.poke(BigInt(32,rng).U);missed=missed.tail
        }
        val fired=d.io.dcReq.peek().litToBoolean
        val tag=d.io.dcRobid.peek().litValue.toInt
        d.clock.step()
        removed.foreach(_=>live=live.tail)
        addMiss.foreach(t=>missed=missed:+t)
        if(fired && !flush)live=live:+tag
      }
      assert(responses>25 && misses>5,s"insufficient response exercise hits=$responses misses=$misses")
    }
  }
}
