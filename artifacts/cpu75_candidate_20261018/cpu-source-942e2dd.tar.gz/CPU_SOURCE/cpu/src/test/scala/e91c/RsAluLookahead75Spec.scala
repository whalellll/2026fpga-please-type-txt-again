package e91c
import chisel3._
import chisel3.reflect.DataMirror
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class RsAluLookahead75Spec extends AnyFlatSpec with ChiselScalatestTester {
  private def clear(x: Data): Unit=x match {
    case r:Record=>r.elements.values.foreach(clear)
    case v:Vec[_]=>v.foreach(clear)
    case b:Bool if DataMirror.directionOf(b)==ActualDirection.Input=>b.poke(false.B)
    case u:UInt if DataMirror.directionOf(u)==ActualDirection.Input=>u.poke(0.U)
    case _=>()
  }
  private def full(d:RsAluEquivalence75,depth:Int): Unit={
    clear(d.io);d.io.flush.poke(true.B);d.clock.step();d.io.flush.poke(false.B)
    d.io.pushSrc1Ready.poke(true.B);d.io.pushSrc0Robid.poke(20.U);d.io.pushSrc1Robid.poke(21.U)
    for(i<-0 until depth){
      d.io.canAccept.expect(true.B);d.io.pushValid.poke(true.B)
      d.io.pushRobid.poke((i+1).U);d.io.pushPc.poke((0x1000+4*i).U);d.io.pushAluOp.poke(1.U)
      d.io.pushSrc0Ready.poke((i==depth-1).B);d.clock.step()
    }
    d.io.occupancy.expect(depth.U);d.io.canAccept.expect(true.B);d.io.issueValid.expect(true.B)
  }
  for(depth<-Seq(4,8)) {
    s"ALU full lookahead depth $depth" should "use both late incoming ready bits when replacing the last ready entry" in {
      test(new RsAluEquivalence75(depth)){d=>
        clear(d.io);d.reset.poke(true.B);d.clock.step(2);d.reset.poke(false.B)
        for(ready<-0 until 4){
          full(d,depth);d.io.issueRobid.expect(depth.U)
          d.io.pushRobid.poke((depth+1).U);d.io.pushPc.poke(0x2000.U)
          d.io.pushSrc0Ready.poke(((ready&1)!=0).B);d.io.pushSrc1Ready.poke(((ready&2)!=0).B)
          d.clock.step();d.io.pushValid.poke(false.B)
          d.io.occupancy.expect(depth.U);d.io.canAccept.expect((ready==3).B)
        }
      }
    }
    s"ALU full lookahead depth $depth" should "retain acceptance for a surviving ready entry and for a freed slot" in {
      test(new RsAluEquivalence75(depth)){d=>
        clear(d.io);d.reset.poke(true.B);d.clock.step(2);d.reset.poke(false.B)
        for(ready<-0 until 4){
          full(d,depth)
          d.io.fast2Valid.poke(true.B);d.io.fast2Robid.poke(20.U);d.io.fast2Data.poke(0x12345678L.U)
          d.io.issueRobid.expect(1.U);d.io.pushRobid.poke((depth+1).U)
          d.io.pushSrc0Ready.poke(((ready&1)!=0).B);d.io.pushSrc1Ready.poke(((ready&2)!=0).B)
          d.clock.step();d.io.pushValid.poke(false.B)
          d.io.occupancy.expect(depth.U);d.io.canAccept.expect(true.B)
        }
        full(d,depth);d.io.pushValid.poke(false.B);d.clock.step()
        d.io.occupancy.expect((depth-1).U);d.io.canAccept.expect(true.B)
        d.io.flush.poke(true.B);d.clock.step();d.io.canAccept.expect(true.B);d.io.occupancy.expect(0.U)
      }
    }
  }
}
