package e91c
import chisel3._
import chisel3.reflect.DataMirror
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import e91c.backend.{EarlyBranchRecovery,EarlyRecoveryReference75}

class EarlyRecoveryEquivalence75 extends Module {
  val candidate=Module(new EarlyBranchRecovery)
  val reference=Module(new EarlyRecoveryReference75)
  val io=IO(chiselTypeOf(candidate.io))
  for((name,port)<-io.elements) {
    if(DataMirror.directionOf(port)==ActualDirection.Input) {
      candidate.io.elements(name) := port;reference.io.elements(name) := port
    } else {
      port := candidate.io.elements(name)
      when(!reset.asBool && (if(name=="redirectPc") reference.io.redirectValid else true.B)) {
        assert(candidate.io.elements(name).asUInt===reference.io.elements(name).asUInt,
          "CPU75 recovery cycle mismatch: "+name)
      }
    }
  }
}

class EarlyRecoveryEquivalence75Spec extends AnyFlatSpec with ChiselScalatestTester {
  private def clear(x:Data):Unit=x match {
    case r:Record=>r.elements.values.foreach(clear)
    case v:Vec[_]=>v.foreach(clear)
    case b:Bool if DataMirror.directionOf(b)==ActualDirection.Input=>b.poke(false.B)
    case u:UInt if DataMirror.directionOf(u)==ActualDirection.Input=>u.poke(0.U)
    case _=>()
  }
  private def init(d:EarlyRecoveryEquivalence75):Unit={
    clear(d.io);d.reset.poke(true.B);d.clock.step(2);d.reset.poke(false.B);d.clock.step()
  }
  private def tag(ordinal:Int):Int=((ordinal&31)>>1)|((ordinal&1)<<4)
  "Early recovery" should "preserve wraparound age, redirect pulses, blocking, alignment and flush for every head" in {
    test(new EarlyRecoveryEquivalence75){d=>
      init(d)
      for(head<-0 until 32){
        clear(d.io);d.io.globalFlush.poke(true.B);d.clock.step();d.io.globalFlush.poke(false.B)
        d.io.headRobid.poke(tag(head).U)
        for(i<-0 until 2){
          d.io.laneValid(i).poke(true.B);d.io.laneIsCond(i).poke(true.B)
          d.io.laneRobid(i).poke(tag(head+(if(i==0)3 else 1)).U)
          d.io.lanePc(i).poke((BigInt("80000000",16)+head*16+i*4).U)
          d.io.laneTaken(i).poke((i==1).B);d.io.lanePredTaken(i).poke((i==0).B)
          d.io.laneTarget(i).poke((BigInt("90000000",16)+head*16+i*4).U)
          d.io.laneFtqId(i).poke((i+2).U)
        }
        d.clock.step();d.io.redirectValid.expect(true.B);d.io.pendingRobid.expect(tag(head+1).U)
        d.io.redirectPc.expect((BigInt("90000000",16)+head*16+4).U)
        d.io.block.poke(true.B);d.io.lanePc(0).poke(0x2000.U);d.clock.step()
        d.io.redirectValid.expect(false.B);d.io.pendingRobid.expect(tag(head+1).U)
        d.io.block.poke(false.B);d.io.laneValid(1).poke(false.B)
        d.io.laneRobid(0).poke(tag(head).U);d.io.laneTaken(0).poke(true.B)
        d.io.lanePredTaken(0).poke(false.B)
        d.io.laneTarget(0).poke(0x3000.U);d.clock.step()
        d.io.redirectValid.expect(true.B);d.io.redirectPc.expect(0x3000.U)
        d.io.laneTarget(0).poke(0x3002.U);d.clock.step();d.io.redirectValid.expect(false.B)
        d.io.globalFlush.poke(true.B);d.clock.step();d.io.pendingValid.expect(false.B)
      }
    }
  }
  it should "match 1200 seeded dual-lane cycles with changing inactive payloads" in {
    test(new EarlyRecoveryEquivalence75){d=>
      init(d);val r=new scala.util.Random(75003)
      for(cycle<-0 until 1200){
        clear(d.io);d.io.headRobid.poke(r.nextInt(32).U)
        d.io.block.poke((cycle%9==0).B);d.io.globalFlush.poke((cycle%23==0).B)
        for(i<-0 until 2){
          d.io.laneValid(i).poke(r.nextBoolean().B);d.io.laneIsCond(i).poke(r.nextBoolean().B)
          d.io.laneRobid(i).poke(r.nextInt(32).U);d.io.lanePc(i).poke((BigInt(30,r)<<2).U)
          d.io.laneTaken(i).poke(r.nextBoolean().B);d.io.lanePredTaken(i).poke(r.nextBoolean().B)
          d.io.laneTarget(i).poke(((BigInt(30,r)<<2)|(if(cycle%7==0)2 else 0)).U)
          d.io.laneFtqId(i).poke(r.nextInt(8).U)
        }
        d.clock.step()
      }
    }
  }
}
