package e91c

import chisel3._
import chisel3.reflect.DataMirror
import chiseltest._
import e91c.backend.{RsMem, ReferenceRsMem75}
import e91c.config.MemOp
import org.scalatest.flatspec.AnyFlatSpec

class RsMemKeyEquivalence75 extends Module {
  val candidate = Module(new RsMem)
  val reference = Module(new ReferenceRsMem75)
  val io = IO(chiselTypeOf(candidate.io))
  val armed = RegNext(true.B, false.B)
  private def connect(parent: Data, left: Data, right: Data): Unit = parent match {
    case v: Vec[_] =>
      for (i <- 0 until v.length)
        connect(v(i), left.asInstanceOf[Vec[Data]](i), right.asInstanceOf[Vec[Data]](i))
    case b: Record =>
      for ((name, field) <- b.elements)
        connect(field, left.asInstanceOf[Record].elements(name), right.asInstanceOf[Record].elements(name))
    case _ =>
      if (DataMirror.directionOf(parent) == ActualDirection.Input) {
        left := parent; right := parent
      } else {
        parent := left
        when(armed) { assert(left.asUInt === right.asUInt, "RsMem full-interface cycle mismatch") }
      }
  }
  connect(io, candidate.io, reference.io)
}

class RsMemKeyEquivalence75Spec extends AnyFlatSpec with ChiselScalatestTester {
  private def clear(data: Data): Unit = data match {
    case v: Vec[_] => v.foreach(clear)
    case b: Record => b.elements.values.foreach(clear)
    case b: Bool if DataMirror.directionOf(b) == ActualDirection.Input => b.poke(false.B)
    case u: UInt if DataMirror.directionOf(u) == ActualDirection.Input => u.poke(0.U)
    case _ => ()
  }
  behavior of "RsMem key arithmetic and selection"
  it should "preserve every output cycle across turnover, wakeup, wrap, backpressure and flush" in {
    test(new RsMemKeyEquivalence75) { d =>
      clear(d.io); d.clock.step()
      val rng = new scala.util.Random(751019L)
      val mask32 = (BigInt(1) << 32) - 1
      val bases = Seq("0200bff8", "1c000100", "1b000000", "9b000000", "00000000", "ffffffff")
        .map(BigInt(_, 16))
      val imms = Seq("00000000", "00000001", "0000001f", "00000020", "000007ff",
        "fffff800", "ffffffff", "80000000", "7fffffff").map(BigInt(_, 16))
      val ops = Seq(MemOp.LD_W, MemOp.LD_B, MemOp.LD_HU, MemOp.ST_W, MemOp.ST_B, MemOp.ST_H)
      var accepted = 0; var issued = 0; var flushed = 0
      for (cycle <- 0 until 768) {
        clear(d.io)
        val prefix = cycle < 192
        val flush = cycle % 67 == 66
        d.io.flush.poke(flush.B)
        if (flush) flushed += 1
        d.io.dataTranslationActive.poke((cycle % 13 < 4).B)
        d.io.lsuReady.poke((prefix || rng.nextInt(4) != 0).B)
        d.io.lsuPlainOnly.poke((!prefix && cycle % 11 == 0).B)
        d.io.lsuPairReady.poke((cycle % 3 == 0).B)
        d.io.pushValid.poke((prefix || rng.nextInt(4) != 0).B)
        d.io.push1Valid.poke((cycle % 3 != 0).B)
        d.io.pushRobid.poke((cycle & 31).U); d.io.push1Robid.poke(((cycle + 1) & 31).U)
        d.io.pushMemOp.poke((BigInt(1) << ops(cycle % ops.size)).U)
        d.io.push1MemOp.poke((BigInt(1) << ops((cycle + 3) % ops.size)).U)
        val base0 = (bases(cycle % bases.size) + (cycle & 31)) & mask32
        val base1 = (bases((cycle + 1) % bases.size) - (cycle & 31)) & mask32
        d.io.pushSrc0Val.poke(base0.U); d.io.pushSrc0KeyVal.poke(base0.U)
        d.io.push1Src0Val.poke(base1.U); d.io.push1Src0KeyVal.poke(base1.U)
        d.io.pushSrc1Val.poke(BigInt(32, rng).U); d.io.push1Src1Val.poke(BigInt(32, rng).U)
        d.io.pushImm.poke(imms(cycle % imms.size).U)
        d.io.push1Imm.poke(imms((cycle + 4) % imms.size).U)
        d.io.pushSrc0Ready.poke((prefix || rng.nextBoolean()).B)
        d.io.pushSrc1Ready.poke((prefix || rng.nextBoolean()).B)
        d.io.push1Src0Ready.poke((prefix || rng.nextBoolean()).B)
        d.io.push1Src1Ready.poke((prefix || rng.nextBoolean()).B)
        d.io.pushSrc0Robid.poke(((cycle - 1) & 31).U)
        d.io.pushSrc1Robid.poke(((cycle - 2) & 31).U)
        d.io.push1Src0Robid.poke(((cycle - 3) & 31).U)
        d.io.push1Src1Robid.poke(((cycle - 4) & 31).U)
        d.io.pushSrc0RobWait.poke((!prefix && cycle % 2 == 0).B)
        d.io.push1Src0RobWait.poke((!prefix && cycle % 3 == 0).B)
        d.io.missWaitValid.poke(BigInt(d.io.missWaitValid.getWidth, rng).U)
        d.io.missWaitRobids.poke(BigInt(d.io.missWaitRobids.getWidth, rng).U)
        d.io.pendingLoadValid.poke(BigInt(d.io.pendingLoadValid.getWidth, rng).U)
        d.io.pendingLoadRobids.poke(BigInt(d.io.pendingLoadRobids.getWidth, rng).U)
        val writes = (0 until 5).map { port =>
          val active = ((cycle & 31) & (1 << port)) != 0
          val tag = (cycle - 1 - (port % 2)) & 31
          val data = (bases(port) + rng.nextInt(64)) & mask32
          d.io.wb(port).valid.poke(active.B)
          d.io.wb(port).bits.robid.poke(tag.U)
          d.io.wb(port).bits.data.poke(data.U)
          (active, tag, data)
        }
        // Dispatch finalizes same-cycle WB before push, including its ready bit.
        def finalizePush(tag: Int, ready: Bool, value: UInt, key: Option[UInt]): Unit = {
          writes.find(w => w._1 && w._2 == tag).foreach { hit =>
            ready.poke(true.B); value.poke(hit._3.U); key.foreach(_.poke(hit._3.U))
          }
        }
        finalizePush((cycle - 1) & 31, d.io.pushSrc0Ready, d.io.pushSrc0Val, Some(d.io.pushSrc0KeyVal))
        finalizePush((cycle - 2) & 31, d.io.pushSrc1Ready, d.io.pushSrc1Val, None)
        finalizePush((cycle - 3) & 31, d.io.push1Src0Ready, d.io.push1Src0Val, Some(d.io.push1Src0KeyVal))
        finalizePush((cycle - 4) & 31, d.io.push1Src1Ready, d.io.push1Src1Val, None)
        for (port <- 0 until 3) {
          d.io.early(port).valid.poke((cycle % (port + 2) == 0).B)
          d.io.early(port).bits.poke(((cycle - 2 - port) & 31).U)
        }
        if (!flush && d.io.pushValid.peek().litToBoolean && d.io.canAccept.peek().litToBoolean)
          accepted += (if (d.io.push1Valid.peek().litToBoolean && d.io.canAcceptTwo.peek().litToBoolean) 2 else 1)
        if (!flush && d.io.issueValid.peek().litToBoolean && d.io.lsuReady.peek().litToBoolean) issued += 1
        d.clock.step()
      }
      assert(accepted > 100 && issued > 50 && flushed == 11,
        s"insufficient exercise accepted=$accepted issued=$issued flush=$flushed")
    }
  }
}
