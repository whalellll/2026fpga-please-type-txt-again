package e91c

import chisel3._
import chisel3.reflect.DataMirror
import chiseltest._
import e91c.config.BrOp
import e91c.exec.FuAlu
import org.scalatest.flatspec.AnyFlatSpec

class FuAluLinkPcSpec extends AnyFlatSpec with ChiselScalatestTester {
  behavior of "FU-ALU link PC preparation"
  it should "retain exact wraparound PC-plus-four and bubble/flush data at the original cycle" in {
    test(new FuAlu) { d =>
      def clear(): Unit = d.io.elements.values.foreach {
        case b: Bool if DataMirror.directionOf(b) == ActualDirection.Input => b.poke(false.B)
        case u: UInt if DataMirror.directionOf(u) == ActualDirection.Input => u.poke(0.U)
        case _ => ()
      }
      clear(); d.clock.step()
      val mask = BigInt("ffffffff",16)
      val pcs = Seq("00000000","00000001","00000003","7ffffffc","80000000",
        "fffffffb","fffffffc","fffffffd","fffffffe","ffffffff").map(BigInt(_,16))
      val branches = Seq(1 << BrOp.JAL, 1 << BrOp.JALR, (1 << BrOp.JAL) | (1 << BrOp.JALR))
      for (pc <- pcs; branch <- branches) {
        clear(); d.io.issueValid.poke(true.B); d.io.issuePc.poke(pc.U)
        d.io.issueBrOp.poke(branch.U); d.io.issueRobid.poke(7.U)
        d.io.issueSrc0.poke("h89abcdef".U); d.io.issueBrOffs.poke(4.U)
        d.clock.step(); d.io.wbValid.expect(true.B)
        val expected = (pc + 4) & mask
        d.io.wbData.expect(expected.U); d.io.wbPc.expect(pc.U); d.io.wbRobid.expect(7.U)
        d.io.flush.poke(true.B); d.io.issuePc.poke((pc ^ mask).U)
        d.clock.step(); d.io.wbValid.expect(false.B); d.io.wbData.expect(expected.U)
        d.io.flush.poke(false.B); d.io.issueValid.poke(false.B)
        d.clock.step(); d.io.wbValid.expect(false.B); d.io.wbData.expect(expected.U)
      }
    }
  }
}
