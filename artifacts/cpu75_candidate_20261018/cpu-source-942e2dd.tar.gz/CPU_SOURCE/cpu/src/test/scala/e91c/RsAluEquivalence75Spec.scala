package e91c
import chisel3._
import chisel3.reflect.DataMirror
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import e91c.backend.{RsAlu, RsAluReference75}

class RsAluEquivalence75(val depth: Int) extends Module {
  val candidate=Module(new RsAlu(depth))
  val reference=Module(new RsAluReference75(depth))
  val io=IO(chiselTypeOf(candidate.io))
  for((name,port)<-io.elements) {
    if(DataMirror.directionOf(port)==ActualDirection.Input) {
      candidate.io.elements(name) := port
      reference.io.elements(name) := port
    } else {
      port := candidate.io.elements(name)
      val always=Set("canAccept","occupancy","issueValid","speculativeSelect","speculativeCancel")
      when(!reset.asBool && (if(always(name)) true.B else reference.io.issueValid)) {
        assert(candidate.io.elements(name).asUInt===reference.io.elements(name).asUInt,
          "CPU75 ALU RS cycle mismatch: "+name)
      }
    }
  }
}

class RsAluEquivalence75Spec extends AnyFlatSpec with ChiselScalatestTester {
  private def clear(x: Data): Unit=x match {
    case r:Record=>r.elements.values.foreach(clear)
    case v:Vec[_]=>v.foreach(clear)
    case b:Bool if DataMirror.directionOf(b)==ActualDirection.Input=>b.poke(false.B)
    case u:UInt if DataMirror.directionOf(u)==ActualDirection.Input=>u.poke(0.U)
    case _=>()
  }
  private def init(d:RsAluEquivalence75): Unit={
    clear(d.io);d.reset.poke(true.B);d.clock.step(2);d.reset.poke(false.B);d.clock.step()
  }
  for(depth<-Seq(4,8)) {
    s"ALU RS depth $depth" should "preserve full turnover, fast wakeup, priority and flush cycle by cycle" in {
      test(new RsAluEquivalence75(depth)){d=>
        init(d)
        for(i<-0 until depth){
          d.io.canAccept.expect(true.B);d.io.pushValid.poke(true.B)
          d.io.pushRobid.poke((i+1).U);d.io.pushPc.poke((0x1000+i*4).U)
          d.io.pushAluOp.poke(1.U);d.io.pushSrc0Robid.poke(20.U);d.io.pushSrc1Robid.poke(21.U)
          d.clock.step()
        }
        d.io.pushValid.poke(false.B);d.io.occupancy.expect(depth.U);d.io.canAccept.expect(false.B)
        // Establish full occupancy with a younger ready entry. Its registered
        // turnover preview permits a push while an older fast consumer wins.
        clear(d.io);d.io.flush.poke(true.B);d.clock.step();d.io.flush.poke(false.B)
        d.io.pushSrc1Ready.poke(true.B);d.io.pushSrc1Val.poke(0x654321L.U)
        for(i<-0 until depth){
          d.io.pushValid.poke(true.B);d.io.pushRobid.poke((i+1).U)
          d.io.pushPc.poke((0x1000+i*4).U);d.io.pushAluOp.poke(1.U)
          d.io.pushSrc0Robid.poke(20.U);d.io.pushSrc0Ready.poke((i==depth-1).B)
          d.clock.step()
        }
        d.io.pushValid.poke(false.B);d.io.occupancy.expect(depth.U)
        d.io.fast2Valid.poke(true.B);d.io.fast2Robid.poke(20.U);d.io.fast2Data.poke(0x12345678L.U)
        d.io.issueValid.expect(true.B);d.io.canAccept.expect(true.B)
        d.io.pushSrc0Ready.poke(true.B);d.io.pushSrc1Ready.poke(true.B)
        d.io.pushSrc0Val.poke(0xabcdefL.U);d.io.pushSrc1Val.poke(0x123abcL.U)
        for(i<-0 until depth*3){
          d.io.pushValid.poke(true.B);d.io.pushRobid.poke(((i+depth+1)%32).U)
          d.io.pushPc.poke((0x2000+i*4).U);d.clock.step()
          d.io.occupancy.expect(depth.U)
        }
        clear(d.io);d.io.flush.poke(true.B);d.clock.step();d.io.flush.poke(false.B)
        d.io.occupancy.expect(0.U);d.io.canAccept.expect(true.B)
      }
    }
    s"ALU RS depth $depth" should "match deterministic mixed dispatch and wakeup traffic" in {
      test(new RsAluEquivalence75(depth)){d=>
        init(d);val rng=new scala.util.Random(75000+depth)
        for(cycle<-0 until 600){
          clear(d.io)
          d.io.flush.poke((cycle%197==196).B)
          val wake=cycle%7==6
          d.io.pushValid.poke((!wake && rng.nextBoolean()).B)
          d.io.pushRobid.poke(rng.nextInt(32).U);d.io.pushPc.poke((cycle*4).U)
          d.io.pushAluOp.poke(1.U);d.io.pushImm.poke((rng.nextInt(4096)).U)
          d.io.pushSrc0Ready.poke(rng.nextBoolean().B);d.io.pushSrc1Ready.poke(rng.nextBoolean().B)
          d.io.pushSrc0Robid.poke(rng.nextInt(16).U);d.io.pushSrc1Robid.poke(rng.nextInt(16).U)
          d.io.pushSrc0Val.poke(BigInt(32,rng).U);d.io.pushSrc1Val.poke(BigInt(32,rng).U)
          d.io.fast2Valid.poke(rng.nextBoolean().B);d.io.fast2Robid.poke(rng.nextInt(16).U)
          d.io.fast2Data.poke(BigInt(32,rng).U)
          for(k<-0 until 3){d.io.earlyValid(k).poke(rng.nextBoolean().B);d.io.earlyRobid(k).poke(rng.nextInt(16).U)}
          if(wake)for(k<-0 until 5){
            d.io.wbValid(k).poke(rng.nextBoolean().B);d.io.wbRobid(k).poke(rng.nextInt(16).U)
            d.io.wbData(k).poke(BigInt(32,rng).U)
          }
          d.clock.step()
        }
      }
    }
  }
}
