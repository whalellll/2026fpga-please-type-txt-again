# CPU V3.1 test SoC synthesis, final 2600-iteration ROM

This is the CPU source repository's `coremark_test_soc` Compile/ADS synthesis
gate, run with PDS 2022.2-SP6.4 on 2026-10-03. It is separate from the routed
`performance_soc` implementation and does not establish a board frequency.

- CPU implementation commit: `dea0200205a1191964e50723e6dc3951617cf5bf`.
- Generated synthesis `CoreTop.sv` SHA-256: `b73b680b108df9ee5c3819a4c4399ef4424ab1e112e4cc329ac52e58235c0c70`.
- Performance ROM: GCC 16.2.0/O2, RV32IMA/Zicsr/Zifencei, ILP32, 2600 iterations,
  seeds `(0,0,0x66)`, `TOTAL_DATA_SIZE=2000`, `cpu_hz=49,500,000`.
- ROM `ram.hex` SHA-256: `6f096cd3f9ce1dba6cb591d108611901b81a7fad1c2a980cd365c93e49d00742`.
- Effective test clock period: 20.2020202 ns. PDS completed in 355.6 seconds.
- Resources: 19,098 LUTs, 10,880 registers, 90 DRM, zero latches. Compile/ADS
  peak memory pools: 263/1,106 MB.
- Post-ADS control audit: PASS; 42,880 frontend, 2,144 PMA address and 17,152
  RsMem hint cases. Branch 0–3, found, selected branch type, repair and refresh
  logic remain represented in the netlist.
- Post-ADS netlist SHA-256: `0dff7dae91c878d0f3a526e343a61bbfd122435d1130350271c9c4a5593d7d4d`.

`synthesis.json`, `synthesis.log`, `coremark_soc_top.snr`, `ads-controls.json`
and `firmware-manifest.json` are retained from the run. `coremark_soc_top_syn.vm.gz`
is a byte-preserving gzip of the 18,340,623-byte ADS netlist; decompress it and
compare with `netlist.sha256.txt`. Absolute machine paths inside the raw logs
and receipt describe this run and are not inputs needed by the packaged project.
