# CPU V3.1 source CoreMark 3+1 RTL evidence

CPU test SoC RTL simulation at 49.5 MHz; no board measurement. The CPU implementation
commit is `dea0200205a1191964e50723e6dc3951617cf5bf`. Three performance runs
used `(0,0,0x66)` and one validation run used `(0x3415,0x3415,0x66)`.
All four used 2600 iterations, 2000 bytes, GCC 16.2.0/O2 target firmware and
one `-Os` host Verilator model. The release aggregate was declared as the mean
of all three performance scores, with their full range; validation is separate.

| Case | Target mcycle ticks | CPU seconds | Iterations/s | CoreMark/MHz | Final CRC |
| --- | ---: | ---: | ---: | ---: | --- |
| performance_1 | 514,595,220 | 10.395863 | 250.099486 | 5.052514868 | `25b5` |
| performance_2 | 514,595,220 | 10.395863 | 250.099486 | 5.052514868 | `25b5` |
| performance_3 | 514,595,220 | 10.395863 | 250.099486 | 5.052514868 | `25b5` |
| validation_1 | 516,281,520 | 10.429930 | 249.282601 | 5.036012135 | `70a1` |

Performance mean **5.052514868 CoreMark/MHz**; range 5.052514868–5.052514868;
mean 250.099486 iterations/s. Each case passed the strict CRC and
at-least-ten-target-second checks. `summary.json` contains exact values and
`group.json` binds model, RTL, zero memory and firmware hashes. Each case keeps
its raw UART log, manifest, runtime metadata, checker output and parsed result.
`launcher.stdout.log` and `launcher.stderr.log` preserve the bounded launcher's
complete console output, including all four case completions.
The formal ROMs are tracked under `coremark_test_soc/sim/coremark_ima` and
`coremark_test_soc/sim/coremark_validation`; evidence omits duplicate binaries.
The `build.log` line stating a 20M-cycle limit came from model-only preparation;
`group.json` and each `runtime.json` record the actual 800M-cycle case bound.
Absolute paths in raw logs describe this host, not required package inputs.
