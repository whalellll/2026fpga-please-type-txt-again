# 历史 5.03 与当前 4.67 的固件对照

本文冻结于 GCC 13.2 阶段，表内“当前/发布”均指当时输入，不代表最终比赛工具链。后续官方源码比较见 [compiler-comparison](../compiler-comparison/README.md)。

结论只来自 10 次迭代 RTL 短诊断；不是实板成绩，也未满足至少 10 秒计时。

| RTL | 固件 | CPU ticks | iterations × 1e6 / ticks |
|---|---|---:|---:|
| 历史 f71b9162 | 历史 GCC 15.3.0 / RV32IM | 1,987,946 | 5.030317725 |
| 历史 f71b9162 | GCC 13.2.0 / RV32IMA，27 MHz 固件 | 2,137,661 | 4.678010218 |
| 当前 c81a1b96 | 同一历史 GCC 15.3.0 / RV32IM 固件 | 1,987,534 | 5.031360470 |
| 当前 c81a1b96 | 当前 GCC 13.2.0 / RV32IMA，49.5 MHz 固件 | 2,138,457 | 4.676268917 |

同一历史固件跨旧/新 CPU 的差值为 -412 周期（-0.020725%）。同一当前模型切换到发布固件的差值为 +150,923 周期。四组 CRC 均为 e714 / 1fd7 / 8e3a / fcaf。

本次直接复用发布校准已构建的 `Vtb_coremark_soc.exe`，没有重编模型、修改 CPU 或更改生产固件门槛。模型始终为 49.5 MHz；历史固件仍按 27 MHz 打印时间，因此没有把历史固件打印的秒数作为实际模拟时间。此处仅使用 CPU cycle CSR 的原始 ticks 计算归一分数。实际模拟计时为 0.040152202 秒；仿真墙钟 143.908 秒。

旧固件编译标识是 `GCC 15.3.0`、`-O2 -march=rv32im_zicsr -mabi=ilp32`；当前为 `GCC 13.2.0`、`-O2 -march=rv32ima_zicsr_zifencei -mabi=ilp32`。旧宏文件和运行日志保存了编译器/参数证据，没有找到原始 GCC 编译过程日志。本对照没有把编译器、ISA 参数、运行库和代码布局分别控制为单一变量，不能把差异武断归因于 GCC 版本或 A 扩展。

历史输入逐字节匹配提交 `c7167eb1c91709ad0d2391d297ca3c83551e1a5b` 下的 `cpu-v15/soc/sim/coremark_i10/`，SHA256 见 `result.json`。交付只保留历史 manifest、宏、日志和哈希，不再保存旧 BIN/ELF/HEX。需要复验时从该提交取出旧输入，在当前已构建模型的独立工作目录放入 `ram.hex` 和 `scripts/meminit`，直接运行模型 `+max_cycles=20000000`；沿用 Windows Job containment。本次 Job 上限为 1,200 秒，实际退出码为 0。

旧 CPU/旧固件来源为 `../reorg-20260927/run-summary.json`；旧 CPU/IMA 固件来源为 `../isa-comparison/historical-c-frontend-diagnostic.json`；当前发布输入来源为 `../ima-release/summary.json`。本目录的 `run.log` 是新 CPU/旧固件实际复验输出。
