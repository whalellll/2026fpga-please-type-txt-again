# CPU75 recovery payload candidate

Base: `cc54c21` with the tested one-hot ALU allocation change.
The second integrated 75MHz attempt `d8307ce0e77440b0914180a181fb4499`
failed final setup with WNS -0.254ns, TNS -0.371ns, two endpoints. The worst
path ran from ALU1 exSrc0[3] to redirectPcR[31] CE, including a long enable
cascade: 25 levels, 3.259ns logic and 9.744ns routing.

This candidate captures the existing selected redirect PC every cycle.
Redirect validity, cycle, lane arbitration, pending owner, block/flush,
FTQ and taken fields are unchanged. The frontend consumes this PC only when
early_redirect_valid is asserted; inactive PC payload values may change.
No pipeline stage, cache/queue capacity, multiplier latency or ISA change
is introduced. Pikafish accelerator hardware remains an integration invariant.

Tests were written before implementation. A frozen reference compares every
control and owner output, and redirect PC on every valid cycle. Directed
tests cover all 32 ROB head positions, age wraparound, blocking, alignment and
flush; a second test drives 1,200 seeded dual-lane cycles with changing invalid
payloads. Original-vs-original passed 2/2. The first fixture omitted a changed
prediction bit for a deliberate direction miss; its failed expectation was
corrected before implementation and retained separately in SoC build logs.

The optimized full regression passed 100 tests in 34 suites, including the
four ALU allocation equivalence tests. Paired exports and generated binding
passed. Among 64 modules only EarlyBranchRecovery differs from cc54c21;
against the original CPU, only RsAlu and EarlyBranchRecovery differ after
line-ending normalization for comparison. Emitted bytes are unchanged.
CoreTop SHA-256:
`7c79bbece9dd19535b27ac3ed4205942923a2672120681d2c9f0c6befe9c2db7`.
SoC tests, native structural/resource checks, final STA and board acceptance
remain required. No RTL CoreMark is used. This is a candidate, not a release tag.
