# ISA 选择的短校准证据

这是 C 清理前的历史实验记录，当前发布源代码和固件均为 RV32IMA（另含 Zicsr/Zifencei），已删除压缩前端。这里保存结果、原始日志、构建清单和输入哈希，不保存重复固件或旧 CPU 生成物。历史绝对路径仅标识当时输入，不是新电脑依赖。

| 硬件 | 固件 | cycles / 10 iterations | CoreMark/MHz |
|---|---|---:|---:|
| RV32IMAC | IMA | 2,138,066 | 4.677124 |
| RV32IMA（开关关闭 C） | 相同 IMA | 2,138,066 | 4.677124 |
| RV32IMAC | IMAC | 4,300,843 | 2.325126 |

三组使用相同的初期集成 PMA、GCC 13.2.0、-O2、ILP32、10 次迭代及同一 RV32IMA/ILP32 libgcc。该 PMA 尚未包含后来清除旧设备窗口的修复；本目录仅用于同条件 ISA 选择，最终地址规则与复测见 `../ima-release`。两个 march 分别为 rv32ima_zicsr_zifencei 和 rv32imac_zicsr_zifencei。所有 CRC 均正确（list e714 / matrix 1fd7 / state 8e3a / final fcaf）；27 MHz 固件计时区间约 0.079/0.159 秒，全部仅为 CALIBRATION_ONLY。比较根据每 MHz 分数选择 IMA，不能据此声称已测最高 FPGA 主频或正式十秒成绩。

`comparison.json` 包含每组 RTL/BIN/RAM SHA256、CRC、周期、墙钟耗时和长时仿真估算；`*-firmware-manifest.json` 保存完整构建参数、大小和源文件哈希。原始三份 `*.log` 可核对 UART 和结束标记。旧实验的固件未随当前发布保留，完整源码已收敛为 IMA，当前复现入口在 `coremark_test_soc/sw/README.md`，不能直接在当前 CPU 上复跑 IMAC。

`historical-c-frontend-diagnostic.json` 和对应测试台来自更早的旧 PMA 观察实验：IMA 2,137,661 周期，IMAC 4,300,820 周期。C 固件顺序修复/空槽周期大量增加，支持前端吞吐差异的解释；其中 short_groups 观察了超出有效槽位的位段，不代表真正提交的压缩组数。旧 PMA 与新 PMA 的 IMA 差值 405 周期不能归咎于 C 开关；决策使用上表同 PMA 比较。

最终 IMA 清理版的独立复测证据另存 `../ima-release`，其 CRC/周期以最终 RTL 为准。正式至少十秒的板测、最高频率、外设 console/debug 验收仍需接板。
