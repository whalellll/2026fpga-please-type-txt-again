# CPU V3 clean-package PDS check

The recorded preflight ZIP was unpacked under a path containing spaces. Its
`CPU_V3` directory initially had neither `.git` nor `work/`. The package
manifest verified all 525 inputs, including the tracked `.pds`, FDC, generated
CPU, IMA firmware, ROM source, and handoff documentation. From the extracted
tree, `newpc.ps1 -Stage PdsCheck` opened the isolated PDS project and
`newpc.ps1 -Stage PdsSynthesis` completed Compile, ADS, and the mapped-control
audit. [result.json](result.json) records the UTC interval, input hashes,
original local receipt hashes, resources, and audit counts.

This is the `coremark_test_soc` CPU/BRAM/UART test project. It has no board
pinout. Synthesis timing and resource counts do not establish full integrated
SoC routed timing, a maximum clock, board operation, or a CoreMark score.
The final source ZIP is rebuilt after this record and the handoff DOCX are
updated; its CPU, firmware, FDC, and PDS source bytes must still match these
input hashes. `VerifyPackage` and `PdsCheck` run again on that final archive.
