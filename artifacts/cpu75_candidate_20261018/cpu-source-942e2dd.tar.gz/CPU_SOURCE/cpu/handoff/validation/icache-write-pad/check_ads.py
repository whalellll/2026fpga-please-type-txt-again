"""Strict reviewer for the observed standalone Icache ADS shape, not PnR."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def module(text, name):
    found = re.findall(r"(?m)^module " + re.escape(name) + r"\b[\s\S]*?^endmodule\b", text)
    assert len(found) == 1, f"Expected unique module {name}"
    return found[0]


def clean(text):
    return re.sub(r"/\*.*?\*/|//[^\r\n]*", "", text, flags=re.S)


def ports(text):
    values = re.findall(r"\.(\w+)\s*\(([^()]*)\)", text)
    assert len(values) == len(dict(values)), "Duplicate port/parameter"
    return {k: re.sub(r"\s+", "", v) for k, v in values}


def cells(body, kind):
    pattern = (r"(?m)^[ \t]*(?P<attr>\(\*[^\r\n]*\*\)\s*)?" + re.escape(kind) +
               r"\s*(?:#\s*\((?P<params>.*?)\)\s*)?" +
               r"(?P<name>\\\S+|\w+)\s+\((?P<ports>.*?)\);")
    return list(re.finditer(pattern, clean(body), re.S))


def bus(name, width):
    return "{" + ",".join(f"{name}[{i}]" for i in range(width-1, -1, -1)) + "}"


def check(text):
    pad = module(text, "PangoIdentityPad")
    icache = module(text, "Icache")
    primitives = cells(pad, "GTP_LUT6D")
    assert len(primitives) == 64, "Not 64 dual LUT primitives"
    seen = set()
    for cell in primitives:
        name = re.fullmatch(r"\\data_pad\[(\d+)\]\.u_hold_dual_lut", cell["name"])
        assert name, "Unknown pad primitive name"
        i = int(name[1])
        assert 0 <= i < 64 and i not in seen, "Duplicate/out-of-range primitive"
        seen.add(i)
        assert cell["attr"].strip() == "(* PAP_DONT_TOUCH *)", "Missing native preservation attribute"
        assert ports(cell["params"]) == {"INIT": "64'b" + f"{0xCCCCCCCCAAAAAAAA:064b}"}, "Identity INIT differs"
        assert ports(cell["ports"]) == {
            "Z": f"dataOut[{2*i+1}]", "Z5": f"dataOut[{2*i}]",
            "I0": f"dataIn[{2*i}]", "I1": f"dataIn[{2*i+1}]",
            "I2": "1'b0", "I3": "1'b0", "I4": "1'b0", "I5": "1'b1"}, "Identity primitive connections differ"
    for name in ("dataIn", "dataOut"):
        counts = Counter(map(int, re.findall(r"\b" + name + r"\[(\d+)\]", clean(pad))))
        assert counts == Counter({i: 1 for i in range(128)}), "Unknown extra pad driver/load"
    assert len(re.findall(r"\bGTP_\w+\s", clean(pad))) == 64, "Unexpected primitive in pad"
    assert not re.search(r"\bassign\b", clean(pad)), "Unknown pad alias/bypass"

    pad_instances = cells(icache, "PangoIdentityPad")
    assert len(pad_instances) == 1, "Pad is not uniquely instantiated by Icache"
    p = ports(pad_instances[0]["ports"])
    assert p == {"dataOut": bus("refillWriteLine", 128), "dataIn": "refillB0"}, "Actual shared pad bus differs"
    ff_bits = []
    for kind in sorted(set(re.findall(r"\bGTP_DFF\w*", clean(icache)))):
        for cell in cells(icache, kind):
            q = ports(cell["ports"]).get("Q", "")
            m = re.fullmatch(r"refillB0\[(\d+)\]", q)
            if m:
                ff_bits.append(int(m[1]))
    assert Counter(ff_bits) == Counter({i: 1 for i in range(128)}), "Missing/extra actual refill FF drivers"
    assert not re.search(r"\bassign\s+refillB0\b", clean(icache)), "Unexpected refill FF alias driver"

    ways = []
    expected = "{" + bus("nt_io_axiRetData", 128)[1:-1] + "," + bus("refillWriteLine", 128)[1:-1] + "}"
    for index, kind in enumerate(("wayMem_128x256", "wayMem_128x256_unq4")):
        child = cells(icache, kind)
        assert len(child) == 1 and child[0]["name"] == f"wayMem_{index}_ext", "Unexpected actual RAM hierarchy"
        assert ports(child[0]["ports"])["W0_data"] == expected, "Actual RAM write bus bypass/truncation/reordering"
        ram = module(text, kind)
        memory = cells(ram, "GTP_DRM36K_E1")
        assert len(memory) == 4, "Unknown standalone RAM primitive mapping"
        consumed = []
        for cell in memory:
            params, pin = ports(cell["params"]), ports(cell["ports"])
            assert params["DATA_WIDTH_A"] == params["DATA_WIDTH_B"] == "64", "Unknown DRM width"
            for port in ("DIA", "DIB"):
                expr = pin[port]
                assert expr.startswith("{") and expr.endswith("}"), "Unknown DRM data expression"
                for atom in expr[1:-1].split(","):
                    if atom == "1'b0":
                        continue
                    m = re.fullmatch(r"W0_data\[(\d+)\]", atom)
                    assert m, "Unknown RAM write-data driver"
                    consumed.append(int(m[1]))
        assert Counter(consumed) == Counter({i: 1 for i in range(256)}), "RAM DI coverage differs"
        refs = Counter(map(int, re.findall(r"\bW0_data\[(\d+)\]", clean(ram))))
        assert refs == Counter({i: 1 for i in range(256)}), "Extra RAM write-data driver/load"
        ways.append(dict(instance=child[0]["name"], module=kind, drm36k=4,
                         write_bits_checked=256, padded_low_bits=128,
                         module_sha256=hashlib.sha256(ram.encode()).hexdigest()))
    refs = Counter(map(int, re.findall(r"\brefillWriteLine\[(\d+)\]", clean(icache))))
    assert refs == Counter({i: 3 for i in range(128)}), "Pad output must have one driver and both RAM loads only"
    return dict(primitive="GTP_LUT6D", pairs=64, bits=128, init="CCCCCCCC_AAAAAAAA",
                preservation_attribute="PAP_DONT_TOUCH", upstream_ff_bits=128,
                unique_driver_and_two_way_loads=True, bypass=False, ways=ways,
                pad_module_sha256=hashlib.sha256(pad.encode()).hexdigest(),
                icache_module_sha256=hashlib.sha256(icache.encode()).hexdigest())


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--run-dir", required=True, type=Path)
    p.add_argument("--output", required=True, type=Path)
    a = p.parse_args()
    assert not a.output.exists(), "Never overwrite prior review evidence"
    owner_path = a.run_dir / "owner.json"
    owner = json.loads(owner_path.read_text(encoding="utf-8-sig"))
    assert owner["status"] == "ADS_COMPLETED_STRUCTURAL_REVIEW_REQUIRED"
    netlist = a.run_dir / "synthesize/Icache_syn.vm"
    digest = sha(netlist)
    assert owner["outputs"]["synthesize/Icache_syn.vm"] == digest
    result = dict(schema=1, status="FAIL", scope="ISOLATED_ACTUAL_ICACHE_ADS_ONLY",
                  netlist_sha256=digest, source_rtl_sha256=owner["source_rtl_sha256"],
                  owner_sha256=sha(owner_path), checker_sha256=sha(Path(__file__)),
                  native_seconds=None, full_soc_mapping_proven=False,
                  routed_hold_margin_proven=False, simulation_performed=False)
    try:
        result["connectivity"] = check(netlist.read_text())
        assert sha(netlist) == digest and sha(owner_path) == result["owner_sha256"]
        result["status"] = "PASS"
    except Exception as exc:
        result["failure"] = str(exc)
        raise
    finally:
        a.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
