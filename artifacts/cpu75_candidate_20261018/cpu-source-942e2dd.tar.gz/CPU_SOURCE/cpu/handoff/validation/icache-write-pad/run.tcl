add_design "icache-probe.sv"
add_constraint "clock.fdc"
set_arch -family Logos2 -device PG2L100H -speedgrade -6 -package FBG676
compile -top_module Icache -system_verilog
synthesize -ads -selected_syn_tool_opt 2
