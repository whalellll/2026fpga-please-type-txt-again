# 新 CPU 的可移植测试基座 PDS 综合

2026-10-02 在隔离副本中用 PDS 2022.2-SP6.4 打开仓内
`coremark_test_soc/pds/coremark_test_soc.pds`，随后执行 compile/ADS，均 PASS。
综合 CPU `CoreTop.sv` SHA256 为
`b73b680b108df9ee5c3819a4c4399ef4424ab1e112e4cc329ac52e58235c0c70`；
实际使用仓内五份 RTL、FDC、固定 CoreMark RAM 和三个初始化文件，
不依赖旧 `work` 数据库。详情见[打开收据](open.json)、[综合收据](synthesis.json)、
[ADS 控制检查](ads-controls.json)、[资源报告](coremark_soc_top.snr)和压缩的
`synthesis.log.gz`。原始日志 SHA256 为
`2eeba75a59e5f9a62525ffc565f4d98b1d013ba01a932f65c84962309ce0ea33`。

本次测试基座为 19,098 LUT、10,880 FF、90 DRM、0 latch；相比同基座的
[上一次综合](../../pds-synthesis-gcc16/result.json)，LUT 增加 64，FF 不变。
ADS 控制检查通过 42,880 组前端、2,144 个 PMA 地址和 17,152 组地址提示。
此工程只用于 CPU/BRAM/UART 测试，没有真实板级引脚；compile/ADS 通过
不代表完整 SoC 布线、STA、最高主频或上板通过。
