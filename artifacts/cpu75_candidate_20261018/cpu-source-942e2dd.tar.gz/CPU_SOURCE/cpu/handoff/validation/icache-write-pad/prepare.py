"""Extract a fresh emitted Icache without changing module bytes; never run PDS."""
import argparse
import hashlib
import json
import re
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ports(body):
    result = {}
    for name, expr in re.findall(r"\.(\w+)\s*\(([^()]*)\)", body):
        if name in result:
            raise ValueError("duplicate port " + name)
        result[name] = re.sub(r"\s+", "", expr)
    return result


def extract(source):
    names = ("tagMem_128x21", "wayMem_128x256", "PangoIdentityPad", "Icache")
    modules = {}
    for name in names:
        found = re.findall(rb"(?m)^module " + name.encode() + rb"\b[\s\S]*?^endmodule\b[^\r\n]*", source)
        if len(found) != 1:
            raise ValueError(f"Expected exactly one emitted {name}, found {len(found)}")
        modules[name] = found[0]
    icache = modules["Icache"].decode("utf-8")
    clean = re.sub(r"/\*.*?\*/|//[^\r\n]*", "", icache, flags=re.S)
    pads = re.findall(r"(?m)^\s*PangoIdentityPad\s+(\w+)\s*\((.*?)\);", clean, re.S)
    if len(pads) != 1:
        raise ValueError("Expected one shared Icache pad instance")
    pad_ports = ports(pads[0][1])
    if set(pad_ports) != {"dataIn", "dataOut"} or pad_ports["dataIn"] != "refillB0":
        raise ValueError("Unknown Icache pad input or ports")
    if not re.fullmatch(r"\w+", pad_ports["dataOut"]):
        raise ValueError("Unknown pad output expression")
    aliases = dict(re.findall(r"\bwire\s+(?:\[[^]]+\]\s+)?(\w+)\s*=\s*([^;]+);", clean))

    def resolve(expr):
        visited = set()
        expr = re.sub(r"\s+", "", expr)
        while expr in aliases:
            if expr in visited:
                raise ValueError("Alias cycle")
            visited.add(expr)
            expr = re.sub(r"\s+", "", aliases[expr])
        return expr

    expected_write = "{io_axiRetData," + pad_ports["dataOut"] + "}"
    ways = []
    for index in range(2):
        name = f"wayMem_{index}_ext"
        matches = re.findall(r"\bwayMem_128x256\s+" + name + r"\s*\((.*?)\);", clean, re.S)
        if len(matches) != 1:
            raise ValueError("Unknown/missing actual way instance " + name)
        p = ports(matches[0])
        if resolve(p.get("W0_data", "")) != expected_write:
            raise ValueError("Way write bus bypasses/shared pad differs: " + name)
        ways.append(dict(instance=name, write_port=p["W0_data"], resolved=expected_write))
    response_rhs = re.findall(r"\brespLine\s*<=\s*([^;]+);", clean)
    if sum(resolve(rhs) == "{io_axiRetData,refillB0}" for rhs in response_rhs) != 1:
        raise ValueError("Expected one raw refill response assignment")
    if any(pad_ports["dataOut"] in resolve(rhs) for rhs in response_rhs):
        raise ValueError("Pad unexpectedly feeds the response bypass")
    if re.search(r"\bfunction\b", b"\n".join(modules.values()).decode()):
        raise ValueError("Unexpected Verilog function")
    return modules, dict(shared_pad_instance=pads[0][0], pad_ports=pad_ports,
                         ways=ways, response_bypass="{io_axiRetData,refillB0}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--source-rtl", required=True, type=Path)
    p.add_argument("--expected-rtl-sha256", required=True)
    p.add_argument("--output-dir", type=Path)
    a = p.parse_args()
    raw = a.source_rtl.read_bytes()
    if sha(raw) != a.expected_rtl_sha256:
        raise ValueError("Source RTL hash differs from explicitly authorized export")
    modules, proof = extract(raw)
    result = dict(schema=1, status="SOURCE_EXTRACTED_NOT_SYNTHESIZED",
                  source_rtl=str(a.source_rtl.resolve()), source_rtl_sha256=sha(raw),
                  modules={n: sha(v) for n, v in modules.items()}, source_connectivity=proof)
    if a.output_dir:
        a.output_dir.mkdir(parents=True, exist_ok=False)
        files = {
            "icache-probe.sv": b"\n\n".join(modules.values()) + b"\n",
            "clock.fdc": b"create_clock -name sys_clk -period 20.2020202 [get_ports {clock}]\n",
            "run.tcl": (b'add_design "icache-probe.sv"\nadd_constraint "clock.fdc"\n'
                        b'set_arch -family Logos2 -device PG2L100H -speedgrade -6 -package FBG676\n'
                        b'compile -top_module Icache -system_verilog\n'
                        b'synthesize -ads -selected_syn_tool_opt 2\n'),
        }
        for name, data in files.items():
            (a.output_dir / name).write_bytes(data)
        result["files"] = {name: sha(data) for name, data in files.items()}
        result["preparer_sha256"] = sha(Path(__file__).read_bytes())
        (a.output_dir / "prepared-inputs.json").write_text(json.dumps(result, indent=2) + "\n")
    if a.source_rtl.read_bytes() != raw:
        raise ValueError("Source changed during extraction")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
