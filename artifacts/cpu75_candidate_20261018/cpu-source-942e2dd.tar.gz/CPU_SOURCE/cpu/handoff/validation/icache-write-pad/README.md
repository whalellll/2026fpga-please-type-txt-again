# ICache 回填写入口的单模块原生 ADS 检查

本记录使用综合 RTL `b73b680b108df9ee5c3819a4c4399ef4424ab1e112e4cc329ac52e58235c0c70`
中的真实 `Icache`、两路 `wayMem_128x256`、`tagMem_128x21` 和 `PangoIdentityPad`
模块建立独立 PDS 工程；未重写 DUT 连接。2026-10-02 的 bounded native PDS
仅执行 compile/ADS，90.227 秒正常退出。原始[运行收据](owner.json)、
[标准输出](pds.stdout.txt)、[结构结果](structural-review.json)和压缩的
`Icache_syn.vm.gz` 均保存；压缩前网表 SHA256 为
`f051e84f1b8b13db7b2f0fe324ca15e3c6532c2a3f5c309a718f0b1c012e97e0`。

实际 ADS 中保留 64 颗 `GTP_LUT6D` 双输出恒等 LUT，检查了 128 位输入 FF、
各原语 INIT/引脚、每位唯一驱动与两路 RAM 写入口负载，高 128 位和响应旁路保持原连接。
该独立工程每路 ICache RAM 映射为 4 个 DRM；这不代表完整 SoC 的 RAM 映射、
布局布线、保持时间或板上行为已通过。四个连接/属性错误的人工变异均被
[检查器负例](checker-negatives.json)拒绝。

`prepare.py` 从正式生成 RTL 中提取相同模块，`icache-probe.sv` 保存本次真实输入，
`check_ads.py` 复核压缩前网表。`run.ps1`、`impl.tcl`、`run.tcl` 和 `clock.fdc`
记录本机执行配方；其中的机器路径仅作来源记录，新电脑应按自己的 PDS 安装路径
准备临时工程。综合 RTL 的仿真导出与先前版本逐字节相同。

[RTL 回归收据](regression-summary.json)及[32 份原始运行文件](regression-evidence.zip)
记录 Unit 49/49、两路缓存额外 2/2、Functional 8/8。固定 GCC 16.2/O2
性能种子十次 CoreMark 为 1,994,149 周期，与修改前相同，CRC 全部一致；
这是约 0.0403 秒的 RTL 短校准，不是 ≥10 秒实板成绩。ZIP 内文件保持
原 `work/icache-hold-pad-validation-20261002/` 相对路径和字节，摘要记录其 SHA256。
