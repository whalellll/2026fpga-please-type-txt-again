param(
    [Parameter(Mandatory=$true)][string]$PreparedDirectory,
    [string]$PdsShell='D:\LJL\WORK\pango\PDS_2022.2-SP6.4\bin\pds_shell.exe',
    [ValidateRange(1,300)][int]$TimeoutSeconds=300,
    [switch]$Execute
)
$ErrorActionPreference='Stop'
function Hash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
$probeRoot=[IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$prepared=[IO.Path]::GetFullPath($PreparedDirectory).TrimEnd('\')
if(!$prepared.StartsWith($probeRoot+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Prepared inputs must be inside the owned scratch root'}
$manifestPath=Join-Path $prepared 'prepared-inputs.json'
$manifest=Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8|ConvertFrom-Json
function Assert-Inputs {
    if($manifest.status -cne 'SOURCE_EXTRACTED_NOT_SYNTHESIZED'){throw 'Unexpected preparation status'}
    if((Hash $manifest.source_rtl) -cne $manifest.source_rtl_sha256){throw 'Fresh source RTL changed after preparation'}
    if((Hash (Join-Path $probeRoot 'prepare.py')) -cne $manifest.preparer_sha256){throw 'Preparer changed'}
    foreach($entry in $manifest.files.PSObject.Properties){
        if($entry.Name -notin @('icache-probe.sv','clock.fdc','run.tcl')){throw 'Unknown prepared input'}
        if((Hash (Join-Path $prepared $entry.Name)) -cne $entry.Value){throw "Prepared input changed: $($entry.Name)"}
    }
    if(@($manifest.files.PSObject.Properties).Count -ne 3){throw 'Missing prepared inputs'}
}
Assert-Inputs
if(!$Execute){Write-Output 'ICACHE_ADS_PREPARED_ONLY NO_NATIVE_TOOL_STARTED';return}
if(@(Get-CimInstance Win32_Process|Where-Object{$_.Name -match '^(pds_shell|PDS|ads|compile|synthesize|dev_map|pnr|ta)\.exe$'}).Count){throw 'Another native PDS/TA job is active'}
$helper=Join-Path $probeRoot 'bounded_process.cs'
if(!('CpuV3Simulation.BoundedProcess' -as [type])){Add-Type -Path $helper}
$id=[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,8)
$run=Join-Path $probeRoot ('runs/'+$id)
New-Item -ItemType Directory -Path $run|Out-Null
foreach($entry in $manifest.files.PSObject.Properties){
    Copy-Item -LiteralPath (Join-Path $prepared $entry.Name) -Destination (Join-Path $run $entry.Name)
    if((Hash (Join-Path $run $entry.Name)) -cne $entry.Value){throw 'Copied input differs'}
}
$owner=[ordered]@{schema=1;status='RUNNING';scope='Actual emitted Icache standalone ADS; not complete CoreTop/SoC/PnR/STA';owner_pid=$PID;started_utc=[DateTime]::UtcNow.ToString('o');timeout_seconds=$TimeoutSeconds;stop_command="Stop-Process -Id $PID";directory=$run;command='pds_shell.exe -file run.tcl';runner_sha256=Hash $PSCommandPath;prepared_inputs_sha256=Hash $manifestPath;helper_sha256=Hash $helper;pds_shell_sha256=Hash $PdsShell;source_rtl_sha256=$manifest.source_rtl_sha256;containment='Windows kill-on-close Job owns suspended child and descendants'}
$ownerPath=Join-Path $run 'owner.json'
$owner|ConvertTo-Json -Depth 6|Set-Content -LiteralPath $ownerPath -Encoding UTF8
Write-Output "ICACHE_ADS owner_pid=$PID limit=${TimeoutSeconds}s directory=$run"
Write-Output "Stop: Stop-Process -Id $PID closes the owned native Job tree."
try{
    $owner.exit_code=[CpuV3Simulation.BoundedProcess]::Run($PdsShell,'-file run.tcl',$run,(Join-Path $run 'pds.stdout.txt'),(Join-Path $run 'pds.stderr.txt'),$TimeoutSeconds)
    if($owner.exit_code -ne 0){throw "Native ADS exit $($owner.exit_code)"}
    $owner.outputs=[ordered]@{}
    foreach($name in @('synthesize/Icache_syn.vm','synthesize/Icache.snr','compile/run.log','synthesize/run.log')){
        $path=Join-Path $run $name
        if(!(Test-Path -LiteralPath $path -PathType Leaf) -or (Get-Item -LiteralPath $path).LastWriteTimeUtc -lt ([datetime]$owner.started_utc).ToUniversalTime()){throw "Missing/stale native output: $name"}
        $owner.outputs[$name]=Hash $path
    }
    $owner.status='ADS_COMPLETED_STRUCTURAL_REVIEW_REQUIRED'
}catch{$owner.status='FAILED_OR_TIMED_OUT';$owner.failure=$_.Exception.GetBaseException().Message;throw}
finally{
    $guardFailure=$null
    try{
        Assert-Inputs
        foreach($entry in $manifest.files.PSObject.Properties){if((Hash (Join-Path $run $entry.Name)) -cne $entry.Value){throw 'Copied input changed during native run'}}
        $owner.inputs_unchanged=$true
    }catch{$guardFailure=$_.Exception.GetBaseException().Message;$owner.status='FAILED_INPUT_CHANGED';$owner.inputs_unchanged=$false;$owner.end_guard_failure=$guardFailure}
    $owner.ended_utc=[DateTime]::UtcNow.ToString('o')
    $owner|ConvertTo-Json -Depth 6|Set-Content -LiteralPath $ownerPath -Encoding UTF8
    if($guardFailure){throw $guardFailure}
}
Write-Output 'ICACHE_NATIVE_ADS_COMPLETE_NOT_A_STRUCTURAL_OR_TIMING_PASS'
