module tagMem_128x21(
  input  [6:0]  R0_addr,
  input         R0_en,
                R0_clk,
  output [20:0] R0_data,
  input  [6:0]  W0_addr,
  input         W0_en,
                W0_clk,
  input  [20:0] W0_data
);

  reg [20:0] Memory[0:127];
  always @(posedge W0_clk) begin
    if (W0_en & 1'h1)
      Memory[W0_addr] <= W0_data;
  end // always @(posedge)
  assign R0_data = R0_en ? Memory[R0_addr] : 21'bx;
endmodule

module wayMem_128x256(
  input  [6:0]   R0_addr,
  input          R0_en,
                 R0_clk,
  output [255:0] R0_data,
  input  [6:0]   W0_addr,
  input          W0_en,
                 W0_clk,
  input  [255:0] W0_data
);

  reg [255:0] Memory[0:127];
  always @(posedge W0_clk) begin
    if (W0_en & 1'h1)
      Memory[W0_addr] <= W0_data;
  end // always @(posedge)
  assign R0_data = R0_en ? Memory[R0_addr] : 256'bx;
endmodule

module PangoIdentityPad(
  input  [127:0] dataIn,
  output [127:0] dataOut
);
`ifdef SYNTHESIS
  genvar pad_pair;
  generate
    for (pad_pair = 0; pad_pair < 64; pad_pair = pad_pair + 1) begin : data_pad
      (* PAP_DONT_TOUCH *) GTP_LUT6D #(.INIT(64'hCCCCCCCC_AAAAAAAA)) u_hold_dual_lut (
        .I0(dataIn[2*pad_pair]), .I1(dataIn[2*pad_pair+1]),
        .I2(1'b0), .I3(1'b0), .I4(1'b0), .I5(1'b1),
        .Z5(dataOut[2*pad_pair]), .Z(dataOut[2*pad_pair+1])
      );
    end
  endgenerate
`else
  assign dataOut = dataIn;
`endif
endmodule

module Icache(
  input          clock,
                 reset,
                 io_ifuReq,
  input  [31:0]  io_ifuPaddr,
  output         io_ifuAddrOk,
                 io_ifuDataOk,
                 io_ifuError,
  output [255:0] io_ifuRline,
  input          io_invalidate,
  output         io_axiRdReq,
  output [31:0]  io_axiRdAddr,
  input          io_axiRdRdy,
                 io_axiRetError,
                 io_axiRetValid,
                 io_axiRetLast,
  input  [127:0] io_axiRetData
);

  wire [127:0] _refillWriteLow_refillWritePad_dataOut;
  wire [255:0] _wayMem_1_ext_R0_data;
  wire [255:0] _wayMem_0_ext_R0_data;
  wire [20:0]  _tagMem_1_ext_R0_data;
  wire [20:0]  _tagMem_0_ext_R0_data;
  reg  [2:0]   state;
  reg  [20:0]  tagOut_0;
  reg  [20:0]  tagOut_1;
  reg          clearing;
  reg  [6:0]   clearSet;
  reg  [255:0] dataOut_0;
  reg  [255:0] dataOut_1;
  reg  [31:0]  reqPaddr;
  reg          reqUncached;
  reg          invalidatePending;
  wire         fullInvNow = io_invalidate | invalidatePending | clearing;
  reg          refillKilled;
  reg  [1:0]   victimWay;
  reg  [127:0] refillB0;
  reg          responseError;
  reg  [255:0] respLine;
  wire         wayHit_1 = tagOut_1[20] & tagOut_1[19:0] == reqPaddr[31:12];
  wire [1:0]   _hitAny_T = {wayHit_1, tagOut_0[20] & tagOut_0[19:0] == reqPaddr[31:12]};
  reg          replaceWay;
  wire         lookupHit = state == 3'h1 & ~reqUncached & (|_hitAny_T) & ~fullInvNow;
  wire         _reqWindow_T_2 = state == 3'h4;
  wire [255:0] _GEN = wayHit_1 ? dataOut_1 : dataOut_0;
  wire         reqTake =
    (~(|state) | lookupHit | _reqWindow_T_2) & ~fullInvNow & io_ifuReq;
  wire         io_axiRdReq_0 = state == 3'h2;
  wire [255:0] refillWriteLine = {io_axiRetData, _refillWriteLow_refillWritePad_dataOut};
  wire         _refillKilled_T_1 = state == 3'h3;
  wire         refillWr =
    _refillKilled_T_1 & io_axiRetValid & io_axiRetLast & ~io_axiRetError;
  wire [6:0]   ramAddr = refillWr ? reqPaddr[11:5] : io_ifuPaddr[11:5];
  wire         _installTag_T_4 = victimWay == 2'h0;
  wire         _GEN_0 = refillWr & _installTag_T_4;
  wire         _GEN_1 = reqTake | _GEN_0;
  wire         _GEN_2 =
    clearing | refillWr & ~refillKilled & ~fullInvNow & _installTag_T_4;
  wire [6:0]   _GEN_3 = clearing ? clearSet : reqPaddr[11:5];
  wire [20:0]  _GEN_4 = clearing ? 21'h0 : {1'h1, reqPaddr[31:12]};
  wire         _installTag_T_9 = victimWay == 2'h1;
  wire         _GEN_5 = refillWr & _installTag_T_9;
  wire         _GEN_6 = reqTake | _GEN_5;
  wire         _GEN_7 =
    clearing | refillWr & ~refillKilled & ~fullInvNow & _installTag_T_9;
  wire         _GEN_8 = refillKilled | fullInvNow | io_axiRetError;
  wire         _GEN_9 = state == 3'h1;
  wire         _GEN_10 = fullInvNow & ~reqUncached & (|_hitAny_T);
  wire         _GEN_11 = reset | ~(|state);
  wire         _GEN_12 = state == 3'h2;
  wire         _GEN_13 = state == 3'h3;
  wire         _GEN_14 = io_axiRetValid & io_axiRetLast;
  wire         _GEN_15 = _GEN_13 & _GEN_14;
  wire         _GEN_16 = ~(|state) | _GEN_9 | _GEN_12;
  wire         _GEN_17 = reset | _GEN_16;
  wire         _GEN_18 = state == 3'h4;
  wire         _GEN_19 = _GEN_10 | reqUncached | ~((|_hitAny_T) & reqTake);
  wire         _GEN_20 = _GEN_12 | _GEN_13 | ~_GEN_18 | fullInvNow | ~reqTake;
  always @(posedge clock) begin
    if (reset) begin
      state <= 3'h0;
      clearing <= 1'h1;
      clearSet <= 7'h0;
      invalidatePending <= 1'h0;
      refillKilled <= 1'h0;
      responseError <= 1'h0;
      replaceWay <= 1'h0;
    end
    else begin
      if (reset)
        state <= 3'h0;
      else if (|state) begin
        if (_GEN_9) begin
          if (_GEN_10)
            state <= 3'h4;
          else if (reqUncached)
            state <= 3'h5;
          else
            state <= {1'h0, (|_hitAny_T) ? {1'h0, reqTake} : 2'h2};
        end
        else if (_GEN_12) begin
          if (io_axiRdRdy)
            state <= 3'h3;
        end
        else if (_GEN_13) begin
          if (_GEN_14)
            state <= 3'h4;
        end
        else if (_GEN_18) begin
          if (fullInvNow)
            state <= 3'h4;
          else
            state <= {2'h0, reqTake};
        end
      end
      else if (reqTake)
        state <= 3'h1;
      clearing <= io_invalidate | ~(clearing & (&clearSet)) & clearing;
      if (io_invalidate)
        clearSet <= 7'h0;
      else if (~clearing | (&clearSet)) begin
      end
      else
        clearSet <= clearSet + 7'h1;
      invalidatePending <= ~reset & io_invalidate;
      refillKilled <=
        ~reset & (_GEN_16 | ~(_GEN_13 & io_axiRetValid & io_axiRetLast & _GEN_8))
        & (invalidatePending
             ? io_axiRdReq_0 | _refillKilled_T_1 | state == 3'h5 | state == 3'h6
             : refillKilled);
      if (_GEN_17 | ~_GEN_15)
        responseError <= ~reqTake & responseError;
      else
        responseError <= io_axiRetError;
      if (_GEN_17 | ~_GEN_15 | _GEN_8) begin
      end
      else
        replaceWay <= ~(victimWay[0]);
    end
    if (_GEN_2 | ~reqTake) begin
    end
    else
      tagOut_0 <= _tagMem_0_ext_R0_data;
    if (_GEN_7 | ~reqTake) begin
    end
    else
      tagOut_1 <= _tagMem_1_ext_R0_data;
    if (~_GEN_1 | _GEN_0) begin
    end
    else
      dataOut_0 <= _wayMem_0_ext_R0_data;
    if (~_GEN_6 | _GEN_5) begin
    end
    else
      dataOut_1 <= _wayMem_1_ext_R0_data;
    if (reset) begin
    end
    else if (|state) begin
      if (_GEN_9 ? _GEN_19 : _GEN_20) begin
      end
      else
        reqPaddr <= io_ifuPaddr;
      if (_GEN_9)
        reqUncached <= _GEN_19 & reqUncached;
      else
        reqUncached <= _GEN_20 & reqUncached;
    end
    else begin
      if (reqTake)
        reqPaddr <= io_ifuPaddr;
      reqUncached <= ~reqTake & reqUncached;
    end
    if (_GEN_11 | ~_GEN_9 | _GEN_10 | reqUncached | (|_hitAny_T)) begin
    end
    else
      victimWay <= {1'h0, tagOut_0[20] & (~(tagOut_1[20]) | replaceWay)};
    if (_GEN_17 | ~(_GEN_13 & io_axiRetValid) | io_axiRetLast) begin
    end
    else
      refillB0 <= io_axiRetData;
    if (~_GEN_11) begin
      if (_GEN_9) begin
        if (_GEN_10)
          respLine <= _GEN;
      end
      else if (_GEN_12 | ~_GEN_15) begin
      end
      else
        respLine <= {io_axiRetData, refillB0};
    end
  end // always @(posedge)
  tagMem_128x21 tagMem_0_ext (
    .R0_addr (io_ifuPaddr[11:5]),
    .R0_en   (~_GEN_2 & reqTake),
    .R0_clk  (clock),
    .R0_data (_tagMem_0_ext_R0_data),
    .W0_addr (_GEN_3),
    .W0_en   (_GEN_2),
    .W0_clk  (clock),
    .W0_data (_GEN_4)
  );
  tagMem_128x21 tagMem_1_ext (
    .R0_addr (io_ifuPaddr[11:5]),
    .R0_en   (~_GEN_7 & reqTake),
    .R0_clk  (clock),
    .R0_data (_tagMem_1_ext_R0_data),
    .W0_addr (_GEN_3),
    .W0_en   (_GEN_7),
    .W0_clk  (clock),
    .W0_data (_GEN_4)
  );
  wayMem_128x256 wayMem_0_ext (
    .R0_addr (ramAddr),
    .R0_en   (_GEN_1 & ~_GEN_0),
    .R0_clk  (clock),
    .R0_data (_wayMem_0_ext_R0_data),
    .W0_addr (ramAddr),
    .W0_en   (_GEN_1 & _GEN_0),
    .W0_clk  (clock),
    .W0_data (refillWriteLine)
  );
  wayMem_128x256 wayMem_1_ext (
    .R0_addr (ramAddr),
    .R0_en   (_GEN_6 & ~_GEN_5),
    .R0_clk  (clock),
    .R0_data (_wayMem_1_ext_R0_data),
    .W0_addr (ramAddr),
    .W0_en   (_GEN_6 & _GEN_5),
    .W0_clk  (clock),
    .W0_data (refillWriteLine)
  );
  PangoIdentityPad refillWriteLow_refillWritePad (
    .dataIn  (refillB0),
    .dataOut (_refillWriteLow_refillWritePad_dataOut)
  );
  assign io_ifuAddrOk = reqTake;
  assign io_ifuDataOk = (lookupHit | _reqWindow_T_2) & ~fullInvNow;
  assign io_ifuError = _reqWindow_T_2 & responseError;
  assign io_ifuRline = lookupHit ? _GEN : respLine;
  assign io_axiRdReq = io_axiRdReq_0;
  assign io_axiRdAddr = {reqPaddr[31:5], 5'h0};
endmodule
