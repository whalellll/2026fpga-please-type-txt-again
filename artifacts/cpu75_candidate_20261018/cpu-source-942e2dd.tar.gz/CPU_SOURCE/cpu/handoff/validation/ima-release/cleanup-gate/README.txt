This gate uses the same frozen 27 MHz IMA firmware as the new-PMA C-off control.
Both measured 2,138,066 CPU cycles for 10 iterations; CRCs match exactly.
It validates removal of C-only source paths before the later integration fix.
This is CALIBRATION_ONLY, not a >=10-second score or board frequency validation.
Final 49.5 MHz firmware validation belongs in the parent ima-release directory.