# 当前纯 IMA 短校准

本目录对应完整 performance_soc 地址图修复后的纯 IMA RTL，并保留 LSU 地址提示刷新修复。这里只做 10 次迭代 RTL 校准，不是实板成绩，也不满足正式至少 10 秒的计时要求。

| 项目 | 当前结果 |
|---|---:|
| 固件与测试台计时频率 | 49.5 MHz |
| CoreMark cycles | 2,138,457 |
| CoreMark/MHz（短校准） | 4.676268917 |
| 模拟 CPU 计时区间 | 0.043201152 秒 |
| 仿真墙钟耗时 | 260.567 秒 |

四项 CRC 均正确：e714 / 1fd7 / 8e3a / fcaf。编译参数仍为 GCC 13.2.0、O2、`rv32ima_zicsr_zifencei`、ILP32，无压缩指令。当前固件 BIN SHA256：`061e603e653688d841394ee0d5d733c20661fa02069e4d92ca67b8f92b1c8caa`。当前仿真 RTL SHA256：`c81a1b96adbc458a44c9752701bd99055930d4f436c61f5ab0f39ade7e2c6075`。

上版同一固件在 RTL `c5db69ca...` 上为 2,138,457 周期，本次差值为 +0 周期。完整 PMA 地址图修复没有改变该 CoreMark 程序的周期；本程序代码和工作数据地址的属性未变化。 历史结果（含旧 27 MHz 冻结镜像 gate）完整保存在 `historical/pre-current-pma-c5db69ca`，不能把该目录中的 RTL 哈希当成当前交付哈希。

`cleanup-gate` 保留删除 C 源码前后周期不变的门槛证据；`rsmem-ordering` 保留 LSU 顺序修复的先失败后通过证据。LSU 修复此前使冻结程序从 2,138,066 增至 2,138,457 周期（+391，0.01829%），该历史差值与本次 PMA 修改分开记录。

当前目录的 `result.json`、`manifest.json`、`run.log`、`runtime.json`、`rtl-inputs.sha256`、`simulator-version.txt` 对应本轮；`summary.json` 记录输入哈希及同固件前后差值。使用 `scripts/newpc.ps1 -Stage CoreMark`，2 个编译作业、20,000,000 周期上限和 Windows Job 进程管理；未运行长迭代或修改 CPU。

49.5 MHz 仍是工程候选值，不等于已测 FPGA Fmax。主机并发负载会改变构模和仿真墙钟，不改变目标 CPU ticks。正式至少 10 秒的板测和最高稳定频率验收仍待接板。
