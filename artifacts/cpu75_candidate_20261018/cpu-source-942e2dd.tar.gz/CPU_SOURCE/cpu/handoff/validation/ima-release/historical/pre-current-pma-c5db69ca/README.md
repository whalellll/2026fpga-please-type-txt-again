# 最终纯 IMA 短校准

本目录记录最终纯 IMA CPU、performance_soc 地址属性适配及 LSU 地址提示刷新修复后的结果。全部为十次迭代 RTL 校准，CRC 正确；没有运行正式十秒测试，也没有板上最高频率验收。

| 输入 | CPU 计时参数 | CoreMark cycles | CoreMark/MHz | 模拟计时 |
|---|---:|---:|---:|---:|
| 冻结 IMA 镜像 | 27 MHz | 2,138,457 | 4.676269 | 0.079202 秒 |
| 当前发布 IMA 镜像 | 49.5 MHz | 2,138,457 | 4.676269 | 0.043201 秒 |

两组使用相同最终 RTL，SHA256 为 `c5db69ca96fb875e7f3b8b819eed9fee9f6b30db3e524ad0f8b2b1960209f1c0`。编译统一 GCC 13.2.0、O2、`rv32ima_zicsr_zifencei`、ILP32，无压缩指令；当前固件 BIN SHA256 为 `061e603e653688d841394ee0d5d733c20661fa02069e4d92ca67b8f92b1c8caa`。四项 CRC 分别为 e714 / 1fd7 / 8e3a / fcaf。完整参数及每项产物哈希在 manifest 中。

`cleanup-gate` 是删除 C 源码后的独立门槛，冻结镜像为 2,138,066 周期，与仅关闭 C 开关的候选精确一致。此后 LSU 修复禁止在操作数刚就绪、地址提示尚未刷新时让非队首访存旁路，以保证 MMIO 顺序正确；最终两组都比修复前增加 391 周期（0.01829%）。这项小幅变化来自后续 LSU 修复，不来自删除 C 源码或更改计时频率。

`final-gate` 保存冻结镜像的最终复测；本目录下的 result/manifest/run.log/runtime.json 对应当前 49.5 MHz 发布输入。`summary.json` 汇总两组的周期、哈希和差值，`rtl-inputs.sha256` 包含 CPU、测试 SoC、测试台与初始化表的输入哈希。

冻结组仿真墙钟 315.9 秒，发布组 101.9 秒；主机负载变化影响墙钟，不改变目标 CPU ticks。两组构模分别耗时 499.1 秒与 327.6 秒，构模时间不计入 CoreMark。当前 49.5 MHz 是工程候选值，绝不等价于已测 FPGA Fmax。长仿真应按实时 cycle/s 估算，仍不能替代板测。
