# 历史本地移植版本的 RV32IMA 编译器基线

本目录保留切换至官方原样核心源码之前的历史证据。当前官方源码比较见 [compiler-comparison](../compiler-comparison/README.md)。

本目录记录真实目标 `riscv32-unknown-elf` 的 GCC 14.2.0、`-O2 -march=rv32ima_zicsr_zifencei -mabi=ilp32` 短校准。它是工具链选型基线，尚未决定最终版本。

同一最终 CPU 的十次迭代为 **2,138,583 周期，4.6759934031 CoreMark/MHz**，CRC 全部正确；模拟 CPU 时间约 0.043204 秒，不满足比赛至少十秒，不能作为正式成绩。CPU/固件哈希、运行库、完整参数见清单与 summary.json。固件两次独立输出目录重建逐字节一致，见 reproducibility.json。

此前 GCC 13.2.0 同 CPU 为 2,138,457 周期，4.6762689173/MHz，记录保存在 `historical/gcc13_2-final-pma-c81a1b96`。此处只比较固件构建结果；49.5 MHz 仍未通过上板验收。

历史 C 删除及 LSU 修复证据分别保留于 `cleanup-gate` 和 `rsmem-ordering`。旧 PMA 阶段结果在 `historical/pre-current-pma-c5db69ca`，不可当作当前输入的新测试。
