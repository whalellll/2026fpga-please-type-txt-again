# C 删除后的补充回归

2026-10-01，综合 CPU `01747a11…a1a1`、仿真 CPU `d3e15490…735ad`。
本次只补测此前两处覆盖缺口，没有修改 CPU 源码，也没有重跑已有七项整核回归。

- `FrontendPipelineSpec` 六项全部通过，覆盖当前前端的重定向、异常 PC、命中顺序、嵌套调用返回、背压和 flush 后旧回填丢弃。套件实测 707.335 秒，Windows Job 上限 1800 秒；精简原始输出和输入哈希见 `frontend-summary.log`、`frontend-result.json`。
- 新增第八项 IALIGN32 整核回归：GCC 16.2.0，RV32IMA/Zicsr/Zifencei、ILP32，1185 周期、361 条退休指令。精确观察到六次预期异常；检查 taken branch/JAL/JALR 的 mcause、mepc、mtval，未 taken 分支不触发对齐异常，faulting JAL/JALR 不提交链接寄存器，JALR 清除目标 bit 0，C.NOP/C.EBREAK 编码非法，以及 mepc 写入清除低两位和 MRET 返回。

错误目标为源 PC +18，即另一个字地址的 +2。这样，如果错误实现先提交跳转、随后才在目标取指时异常，保存的 mepc 会不同，不能被低两位清零掩盖。非法指令的 mtval 按当前 CPU 返回零检查。

模型使用单个构建作业，只构建一次。最终严格汇编重新编译后，在确认测试台哈希不变的同一模型上运行；仿真实际耗时 0.107 秒、上限 3,000,000 周期。原始日志、软件 oracle、生成的汇编与测试台保留在本目录，所有输入哈希见 `result.json`。这不是 CoreMark 成绩或实板验收。

从 `cpu-v15` 可单独复现新增整核测试：

```powershell
$env:CPU_TEST_JOBS = '1'
.\scripts\newpc.ps1 -Stage Ialign32 -Config .\toolchain.local.json
```

`Functional` 现在包含八项；`Unit` 现在包含 `FrontendPipelineSpec`。只补跑六项前端时使用 sbt 的 `testOnly e91c.FrontendPipelineSpec`。

此前 34 项 C 清理测试摘要已从真实旧日志重新提取，位于 `../ima-release/rsmem-ordering/ima-clean-unit-summary.log`；其来源 SHA256 与提取方法记录在同目录 `result.json`，没有重新运行或改写历史测试结果。
