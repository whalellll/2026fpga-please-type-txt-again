# Integrated SoC CPU75 ALU allocation candidate

Base implementation: `45d24b9e09c44abc10f8b4fb5b69f69ecff48b70`.
This branch changes only the ALU reservation station allocation consumer;
the separate frontend call/return experiment is absent.

The original CPU's integrated 75 MHz run
`9de4163704264cd8af2751b87366ddac` failed final slow setup at -0.393 ns:
DCache `reqRobid[3]` -> RsAlu1 `s1Val_1[21]` CE, 14 logic levels,
2.075 ns logic and 11.110 ns routing (84.262%). Its frozen inputs and formal
report remain in the SoC campaign evidence. It was not programmed onto the board.

The candidate reuses existing `ageAllocGrant` directly for per-slot operand
writes and next-occupancy computation. The encoded `freeIdx` remains for the
descriptor memory's single write address. No new pipeline stage, issue cycle,
cache/queue capacity, multiplier latency, ISA or clock-domain change is introduced.
A simulation assertion checks that accepted one-hot allocation equals the
descriptor address. Both synthesis and simulation exports must be regenerated.

Tests were written before the logic edit. The frozen original reference and
candidate compare canAccept, occupancy, issue validity and speculative control
every cycle, and the complete issued payload whenever valid. Four tests cover
4/8-entry capacity, blocked full stations, full fast-wakeup replacement, flush,
priority and 1,200 seeded mixed-traffic cycles. The corrected original-vs-original
baseline passed all four. The first test fixture incorrectly expected admission
one cycle too early; its failed run is retained in SoC build logs and is not
counted as CPU failure or acceptance evidence.

The optimized full unit regression passed 98 tests in 33 suites, including
the four cycle equivalence tests and the allocation assertion. Paired exports
passed generated-source verification. After CRLF/LF normalization for comparison
only, 63 of 64 modules are unchanged and only RsAlu differs; emitted bytes are
untouched. The candidate CoreTop SHA-256 is
`6cd3a7398d239ff30e4c3eecdf1f19b9abee80cc594e8d1aaa076a9f99ca51e4`.
Integrated peripheral/CPU simulation, native ADS retention/resource gates,
routed multi-corner timing and board CoreMark/model/function acceptance remain
required. Unit and export logs are retained beside this note.
No RTL CoreMark is used for this integration campaign. All performance results
must bind the exact integrated bitstream and firmware. This is not a release tag.
