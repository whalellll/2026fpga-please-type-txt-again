# 官方 CoreMark 源码下的编译器比较

这组历史阶段比较固定 BRAM 属性修复前的 CPU（仿真 RTL `c81a1b96…6075`）、49.5 MHz 测试台、RV32IMA/ILP32、2000 字节静态工作区、计时端口与官方 CoreMark 六份核心源文件，只改变编译器/优化等级。官方 tag `v1.01`、提交 `cfa9ab377835911f23d9b0831c7be302ed1f58de`，程序报告 CoreMark 1.0；核心文件逐字节保持上游原样。

| 编译器 | 优化 | 10 次迭代 ticks | CoreMark/MHz 短校准 |
| --- | --- | ---: | ---: |
| GCC 14.2.0 | O2 | 2,123,909 | 4.7082996494 |
| GCC 14.2.0 | O3 | 2,126,614 | 4.7023108096 |

两组性能种子 CRC 均正确；O2 独立验证种子也通过，ticks 为 2,130,346，seed/list/matrix/state CRC 为 18f2/e3c1/0747/8d84。验证种子结果只作正确性检查，不参与性能分数排序。后续 CPU 已移除错误的 BRAM 不可缓存例外，并完成 [当前 CPU 的 GCC 14.2/16.2 对照](cpu01747/README.md)，选择 16.2/O2。旧记录不作为新 RTL 的验证结果。每组 CPU 计时时间约 0.043 秒，不是比赛要求的至少十秒，也不是 performance_soc 实板分数。

各目录保存原始运行日志、结果、CPU 输入哈希、模拟器版本、当时的构建清单。`rebuilt-manifest.json` 与 `rebuild-comparison.json` 记录补充验证种子宏检查后的重建：五份程序输入与实际已测文件逐字节一致；没有冒充第二次仿真。

较早的 IMA/IMAC、GCC 13.2/14.2/15.3 对比使用当时的本地 CoreMark 移植副本；见 `../ima-release`、`../isa-comparison`、`../compiler-baseline`。它们仍可说明各自固定输入下的差异，但不能与本组混成只改变 GCC 的对照。

原始短运行日志保留官方“Must execute for at least 10 secs”与“Errors detected”提示；校准解析仅允许这一项时长不足，另行严格检查种子、CRC、迭代数和完整 64 位 ticks，不把它标记成官方有效成绩。
