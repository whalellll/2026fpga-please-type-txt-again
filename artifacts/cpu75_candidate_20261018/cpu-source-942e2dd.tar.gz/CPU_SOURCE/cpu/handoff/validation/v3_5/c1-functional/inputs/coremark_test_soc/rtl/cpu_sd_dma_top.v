`timescale 1ns/1ps

// RV32IMA CPU, native SD registers, and write-only SD DMA.
// External AXI is the shared memory port; DMA writes carry AXI ID 4'he.
module cpu_sd_dma_top #(
    parameter [31:0] RESET_VECTOR = 32'h1c00_0000,
    parameter [15:0] SD_RESET_DIV = 16'd124,
    parameter integer SD_DEBOUNCE_CYCLES = 247500
)(
    input wire aclk,
    input wire aresetn,
    input wire [31:0] external_interrupts,
    output wire sd_clk,
    inout wire sd_cmd,
    inout wire sd_data0,
    inout wire sd_data1,
    inout wire sd_data2,
    inout wire sd_data3,
    input wire sd_detect_n,
    output wire [3:0] arid,
    output wire [31:0] araddr,
    output wire [7:0] arlen,
    output wire [2:0] arsize,
    output wire [1:0] arburst,
    output wire [1:0] arlock,
    output wire [3:0] arcache,
    output wire [2:0] arprot,
    output wire arvalid,
    input wire arready,
    input wire [3:0] rid,
    input wire [31:0] rdata,
    input wire [1:0] rresp,
    input wire rlast,
    input wire rvalid,
    output wire rready,
    output wire [3:0] awid,
    output wire [31:0] awaddr,
    output wire [7:0] awlen,
    output wire [2:0] awsize,
    output wire [1:0] awburst,
    output wire [1:0] awlock,
    output wire [3:0] awcache,
    output wire [2:0] awprot,
    output wire awvalid,
    input wire awready,
    output wire [3:0] wid,
    output wire [31:0] wdata,
    output wire [3:0] wstrb,
    output wire wlast,
    output wire wvalid,
    input wire wready,
    input wire [3:0] bid,
    input wire [1:0] bresp,
    input wire bvalid,
    output wire bready
);

    // CPU-side AXI, including metadata used only by CPU transactions.
    wire [3:0] c_arid;
    wire [31:0] c_araddr;
    wire [7:0] c_arlen;
    wire [2:0] c_arsize;
    wire [1:0] c_arburst;
    wire [1:0] c_arlock;
    wire [3:0] c_arcache;
    wire [2:0] c_arprot;
    wire c_arvalid;
    wire c_arready;
    wire [3:0] c_rid;
    wire [31:0] c_rdata;
    wire [1:0] c_rresp;
    wire c_rlast;
    wire c_rvalid;
    wire c_rready;
    wire [3:0] c_awid;
    wire [31:0] c_awaddr;
    wire [7:0] c_awlen;
    wire [2:0] c_awsize;
    wire [1:0] c_awburst;
    wire [1:0] c_awlock;
    wire [3:0] c_awcache;
    wire [2:0] c_awprot;
    wire c_awvalid;
    wire c_awready;
    wire [3:0] c_wid;
    wire [31:0] c_wdata;
    wire [3:0] c_wstrb;
    wire c_wlast;
    wire c_wvalid;
    wire c_wready;
    wire [3:0] c_bid;
    wire [1:0] c_bresp;
    wire c_bvalid;
    wire c_bready;

    cpu_core_top #(.RESET_VECTOR(RESET_VECTOR)) u_cpu (
        .aclk(aclk), .aresetn(aresetn),
        .external_interrupts(external_interrupts),
        .arid(c_arid),
        .araddr(c_araddr),
        .arlen(c_arlen),
        .arsize(c_arsize),
        .arburst(c_arburst),
        .arlock(c_arlock),
        .arcache(c_arcache),
        .arprot(c_arprot),
        .arvalid(c_arvalid),
        .arready(c_arready),
        .rid(c_rid),
        .rdata(c_rdata),
        .rresp(c_rresp),
        .rlast(c_rlast),
        .rvalid(c_rvalid),
        .rready(c_rready),
        .awid(c_awid),
        .awaddr(c_awaddr),
        .awlen(c_awlen),
        .awsize(c_awsize),
        .awburst(c_awburst),
        .awlock(c_awlock),
        .awcache(c_awcache),
        .awprot(c_awprot),
        .awvalid(c_awvalid),
        .awready(c_awready),
        .wid(c_wid),
        .wdata(c_wdata),
        .wstrb(c_wstrb),
        .wlast(c_wlast),
        .wvalid(c_wvalid),
        .wready(c_wready),
        .bid(c_bid),
        .bresp(c_bresp),
        .bvalid(c_bvalid),
        .bready(c_bready)
    );

    // The address splitter sends only the SD register aperture locally.
    wire [3:0] d_arid;
    wire [31:0] d_araddr;
    wire [7:0] d_arlen;
    wire [2:0] d_arsize;
    wire [1:0] d_arburst;
    wire d_arvalid;
    wire d_arready;
    wire [3:0] d_rid;
    wire [31:0] d_rdata;
    wire [1:0] d_rresp;
    wire d_rlast;
    wire d_rvalid;
    wire d_rready;
    wire [3:0] d_awid;
    wire [31:0] d_awaddr;
    wire [7:0] d_awlen;
    wire [2:0] d_awsize;
    wire [1:0] d_awburst;
    wire d_awvalid;
    wire d_awready;
    wire [3:0] d_wid;
    wire [31:0] d_wdata;
    wire [3:0] d_wstrb;
    wire d_wlast;
    wire d_wvalid;
    wire d_wready;
    wire [3:0] d_bid;
    wire [1:0] d_bresp;
    wire d_bvalid;
    wire d_bready;
    wire [3:0] l_arid;
    wire [31:0] l_araddr;
    wire [7:0] l_arlen;
    wire [2:0] l_arsize;
    wire [1:0] l_arburst;
    wire l_arvalid;
    wire l_arready;
    wire [3:0] l_rid;
    wire [31:0] l_rdata;
    wire [1:0] l_rresp;
    wire l_rlast;
    wire l_rvalid;
    wire l_rready;
    wire [3:0] l_awid;
    wire [31:0] l_awaddr;
    wire [7:0] l_awlen;
    wire [2:0] l_awsize;
    wire [1:0] l_awburst;
    wire l_awvalid;
    wire l_awready;
    wire [3:0] l_wid;
    wire [31:0] l_wdata;
    wire [3:0] l_wstrb;
    wire l_wlast;
    wire l_wvalid;
    wire l_wready;
    wire [3:0] l_bid;
    wire [1:0] l_bresp;
    wire l_bvalid;
    wire l_bready;
    axi_1x2_sd u_split (
        .clk(aclk), .resetn(aresetn),
        .s_arid(c_arid),
        .s_araddr(c_araddr),
        .s_arlen(c_arlen),
        .s_arsize(c_arsize),
        .s_arburst(c_arburst),
        .s_arlock(c_arlock),
        .s_arcache(c_arcache),
        .s_arprot(c_arprot),
        .s_arvalid(c_arvalid),
        .s_arready(c_arready),
        .s_rid(c_rid),
        .s_rdata(c_rdata),
        .s_rresp(c_rresp),
        .s_rlast(c_rlast),
        .s_rvalid(c_rvalid),
        .s_rready(c_rready),
        .s_awid(c_awid),
        .s_awaddr(c_awaddr),
        .s_awlen(c_awlen),
        .s_awsize(c_awsize),
        .s_awburst(c_awburst),
        .s_awlock(c_awlock),
        .s_awcache(c_awcache),
        .s_awprot(c_awprot),
        .s_awvalid(c_awvalid),
        .s_awready(c_awready),
        .s_wid(c_wid),
        .s_wdata(c_wdata),
        .s_wstrb(c_wstrb),
        .s_wlast(c_wlast),
        .s_wvalid(c_wvalid),
        .s_wready(c_wready),
        .s_bid(c_bid),
        .s_bresp(c_bresp),
        .s_bvalid(c_bvalid),
        .s_bready(c_bready),
        .m0_arid(d_arid),
        .m0_araddr(d_araddr),
        .m0_arlen(d_arlen),
        .m0_arsize(d_arsize),
        .m0_arburst(d_arburst),
        .m0_arvalid(d_arvalid),
        .m0_arready(d_arready),
        .m0_rid(d_rid),
        .m0_rdata(d_rdata),
        .m0_rresp(d_rresp),
        .m0_rlast(d_rlast),
        .m0_rvalid(d_rvalid),
        .m0_rready(d_rready),
        .m0_awid(d_awid),
        .m0_awaddr(d_awaddr),
        .m0_awlen(d_awlen),
        .m0_awsize(d_awsize),
        .m0_awburst(d_awburst),
        .m0_awvalid(d_awvalid),
        .m0_awready(d_awready),
        .m0_wid(d_wid),
        .m0_wdata(d_wdata),
        .m0_wstrb(d_wstrb),
        .m0_wlast(d_wlast),
        .m0_wvalid(d_wvalid),
        .m0_wready(d_wready),
        .m0_bid(d_bid),
        .m0_bresp(d_bresp),
        .m0_bvalid(d_bvalid),
        .m0_bready(d_bready),
        .m1_arid(l_arid),
        .m1_araddr(l_araddr),
        .m1_arlen(l_arlen),
        .m1_arsize(l_arsize),
        .m1_arburst(l_arburst),
        .m1_arvalid(l_arvalid),
        .m1_arready(l_arready),
        .m1_rid(l_rid),
        .m1_rdata(l_rdata),
        .m1_rresp(l_rresp),
        .m1_rlast(l_rlast),
        .m1_rvalid(l_rvalid),
        .m1_rready(l_rready),
        .m1_awid(l_awid),
        .m1_awaddr(l_awaddr),
        .m1_awlen(l_awlen),
        .m1_awsize(l_awsize),
        .m1_awburst(l_awburst),
        .m1_awvalid(l_awvalid),
        .m1_awready(l_awready),
        .m1_wid(l_wid),
        .m1_wdata(l_wdata),
        .m1_wstrb(l_wstrb),
        .m1_wlast(l_wlast),
        .m1_wvalid(l_wvalid),
        .m1_wready(l_wready),
        .m1_bid(l_bid),
        .m1_bresp(l_bresp),
        .m1_bvalid(l_bvalid),
        .m1_bready(l_bready)
    );

    wire [31:0] sd_addr, sd_wdata, sd_rdata;
    wire [3:0] sd_wstrb;
    wire sd_wr, sd_hit;
    sd_axi_mmio u_registers (
        .clk(aclk), .resetn(aresetn),
        .arid(l_arid),
        .araddr(l_araddr),
        .arlen(l_arlen),
        .arsize(l_arsize),
        .arburst(l_arburst),
        .arvalid(l_arvalid),
        .arready(l_arready),
        .rid(l_rid),
        .rdata(l_rdata),
        .rresp(l_rresp),
        .rlast(l_rlast),
        .rvalid(l_rvalid),
        .rready(l_rready),
        .awid(l_awid),
        .awaddr(l_awaddr),
        .awlen(l_awlen),
        .awsize(l_awsize),
        .awburst(l_awburst),
        .awvalid(l_awvalid),
        .awready(l_awready),
        .wid(l_wid),
        .wdata(l_wdata),
        .wstrb(l_wstrb),
        .wlast(l_wlast),
        .wvalid(l_wvalid),
        .wready(l_wready),
        .bid(l_bid),
        .bresp(l_bresp),
        .bvalid(l_bvalid),
        .bready(l_bready),
        .sd_addr(sd_addr), .sd_wr(sd_wr), .sd_wdata(sd_wdata),
        .sd_wstrb(sd_wstrb), .sd_rdata(sd_rdata), .sd_hit(sd_hit)
    );

    wire [31:0] dma_awaddr, dma_wdata;
    wire [7:0] dma_awlen;
    wire [2:0] dma_awsize;
    wire [1:0] dma_awburst, dma_bresp;
    wire [3:0] dma_wstrb;
    wire dma_awvalid, dma_awready, dma_wlast, dma_wvalid;
    wire dma_wready, dma_bvalid, dma_bready;
    wire sd_cmd_out, sd_cmd_oe;
    wire [3:0] sd_dat_in = {sd_data3, sd_data2, sd_data1, sd_data0};
    assign sd_cmd = sd_cmd_oe ? sd_cmd_out : 1'bz;
    assign sd_data0 = 1'bz;
    assign sd_data1 = 1'bz;
    assign sd_data2 = 1'bz;
    assign sd_data3 = 1'bz;

    sd_native_mmio #(.RESET_DIV(SD_RESET_DIV),
        .DEBOUNCE_CYCLES(SD_DEBOUNCE_CYCLES)) u_sd (
        .clk(aclk), .resetn(aresetn),
        .addr(sd_addr), .wr(sd_wr), .wdata(sd_wdata),
        .wstrb(sd_wstrb), .rdata(sd_rdata), .hit(sd_hit),
        .sd_clk(sd_clk), .sd_cmd_in(sd_cmd),
        .sd_cmd_out(sd_cmd_out), .sd_cmd_oe(sd_cmd_oe),
        .sd_dat_in(sd_dat_in), .sd_detect_n(sd_detect_n),
        .m_axi_awaddr(dma_awaddr),
        .m_axi_awlen(dma_awlen),
        .m_axi_awsize(dma_awsize),
        .m_axi_awburst(dma_awburst),
        .m_axi_awvalid(dma_awvalid),
        .m_axi_awready(dma_awready),
        .m_axi_wdata(dma_wdata),
        .m_axi_wstrb(dma_wstrb),
        .m_axi_wlast(dma_wlast),
        .m_axi_wvalid(dma_wvalid),
        .m_axi_wready(dma_wready),
        .m_axi_bresp(dma_bresp),
        .m_axi_bvalid(dma_bvalid),
        .m_axi_bready(dma_bready)
    );

    axi_2x1_arbiter #(.MASTER1_ID(4'he)) u_dma_arbiter (
        .clk(aclk), .resetn(aresetn),
        .s0_arid(d_arid),
        .s0_araddr(d_araddr),
        .s0_arlen(d_arlen),
        .s0_arsize(d_arsize),
        .s0_arburst(d_arburst),
        .s0_arvalid(d_arvalid),
        .s0_arready(d_arready),
        .s0_rid(d_rid),
        .s0_rdata(d_rdata),
        .s0_rresp(d_rresp),
        .s0_rlast(d_rlast),
        .s0_rvalid(d_rvalid),
        .s0_rready(d_rready),
        .s0_awid(d_awid),
        .s0_awaddr(d_awaddr),
        .s0_awlen(d_awlen),
        .s0_awsize(d_awsize),
        .s0_awburst(d_awburst),
        .s0_awvalid(d_awvalid),
        .s0_awready(d_awready),
        .s0_wid(d_wid),
        .s0_wdata(d_wdata),
        .s0_wstrb(d_wstrb),
        .s0_wlast(d_wlast),
        .s0_wvalid(d_wvalid),
        .s0_wready(d_wready),
        .s0_bid(d_bid),
        .s0_bresp(d_bresp),
        .s0_bvalid(d_bvalid),
        .s0_bready(d_bready),
        .s1_araddr(32'd0), .s1_arlen(8'd0),
        .s1_arsize(3'd2), .s1_arburst(2'b01),
        .s1_arvalid(1'b0), .s1_arready(),
        .s1_rdata(), .s1_rresp(), .s1_rlast(), .s1_rvalid(),
        .s1_rready(1'b0),
        .s1_awaddr(dma_awaddr),
        .s1_awlen(dma_awlen),
        .s1_awsize(dma_awsize),
        .s1_awburst(dma_awburst),
        .s1_awvalid(dma_awvalid),
        .s1_awready(dma_awready),
        .s1_wdata(dma_wdata),
        .s1_wstrb(dma_wstrb),
        .s1_wlast(dma_wlast),
        .s1_wvalid(dma_wvalid),
        .s1_wready(dma_wready),
        .s1_bresp(dma_bresp),
        .s1_bvalid(dma_bvalid),
        .s1_bready(dma_bready),
        .m_arid(arid),
        .m_araddr(araddr),
        .m_arlen(arlen),
        .m_arsize(arsize),
        .m_arburst(arburst),
        .m_arvalid(arvalid),
        .m_arready(arready),
        .m_rid(rid),
        .m_rdata(rdata),
        .m_rresp(rresp),
        .m_rlast(rlast),
        .m_rvalid(rvalid),
        .m_rready(rready),
        .m_awid(awid),
        .m_awaddr(awaddr),
        .m_awlen(awlen),
        .m_awsize(awsize),
        .m_awburst(awburst),
        .m_awvalid(awvalid),
        .m_awready(awready),
        .m_wid(wid),
        .m_wdata(wdata),
        .m_wstrb(wstrb),
        .m_wlast(wlast),
        .m_wvalid(wvalid),
        .m_wready(wready),
        .m_bid(bid),
        .m_bresp(bresp),
        .m_bvalid(bvalid),
        .m_bready(bready)
    );

    assign arlock = c_arlock;
    assign arcache = c_arcache;
    assign arprot = c_arprot;
    assign awlock = (awid == 4'he) ? 2'b00 : c_awlock;
    assign awcache = (awid == 4'he) ? 4'b0000 : c_awcache;
    assign awprot = (awid == 4'he) ? 3'b000 : c_awprot;
endmodule
