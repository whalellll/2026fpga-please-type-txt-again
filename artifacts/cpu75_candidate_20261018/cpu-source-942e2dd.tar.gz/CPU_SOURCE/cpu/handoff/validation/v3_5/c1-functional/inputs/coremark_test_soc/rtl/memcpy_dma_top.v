`timescale 1ns/1ps

// Standalone DDR-to-DDR DMA channel. No arithmetic accelerator is instantiated.
// The AXI adapter limits each burst to eight words; this controller also keeps
// every burst inside one 256-bit DDR bridge line.
module memcpy_dma_top #(
    parameter [31:0] DDR_BASE = 32'h1b00_0000,
    parameter integer DDR_BYTES = 1024 * 1024
)(
    input wire clk, input wire resetn,
    input wire reg_wr_en,
    input wire [7:0] reg_wr_addr,
    input wire [31:0] reg_wr_data,
    input wire [3:0] reg_wr_strb,
    input wire [7:0] reg_rd_addr,
    output reg [31:0] reg_rd_data,
    output wire irq,
    output wire [31:0] m_axi_awaddr,
    output wire [7:0] m_axi_awlen,
    output wire [2:0] m_axi_awsize,
    output wire [1:0] m_axi_awburst,
    output wire m_axi_awvalid,
    input wire m_axi_awready,
    output wire [31:0] m_axi_wdata,
    output wire [3:0] m_axi_wstrb,
    output wire m_axi_wlast,
    output wire m_axi_wvalid,
    input wire m_axi_wready,
    input wire [1:0] m_axi_bresp,
    input wire m_axi_bvalid,
    output wire m_axi_bready,
    output wire [31:0] m_axi_araddr,
    output wire [7:0] m_axi_arlen,
    output wire [2:0] m_axi_arsize,
    output wire [1:0] m_axi_arburst,
    output wire m_axi_arvalid,
    input wire m_axi_arready,
    input wire [31:0] m_axi_rdata,
    input wire [1:0] m_axi_rresp,
    input wire m_axi_rlast,
    input wire m_axi_rvalid,
    output wire m_axi_rready
);
    localparam [2:0] S_IDLE = 3'd0;
    localparam [2:0] S_READ_REQ = 3'd1;
    localparam [2:0] S_READ_DATA = 3'd2;
    localparam [2:0] S_WRITE_REQ = 3'd3;
    localparam [2:0] S_WRITE_DATA = 3'd4;
    localparam [2:0] S_WRITE_RESP = 3'd5;

    reg [2:0] state;
    reg done, error, irq_enable;
    reg [3:0] error_code;
    reg [31:0] cfg_src, cfg_dst, cfg_words;
    reg [31:0] src_cur, dst_cur, remaining, words_done;
    reg [2:0] read_index, write_index;
    reg [31:0] burst_data [0:7];

    wire busy = state != S_IDLE;
    wire control_write = reg_wr_en && reg_wr_addr[7:2] == 6'h02;
    wire start = control_write && reg_wr_strb[0] && reg_wr_data[0];
    wire clear = control_write && reg_wr_strb[0] && reg_wr_data[1];
    wire [34:0] bytes_to_copy = {3'd0, cfg_words} << 2;
    wire [34:0] ddr_limit = {3'd0, DDR_BASE} + DDR_BYTES;
    wire [34:0] src_end = {3'd0, cfg_src} + bytes_to_copy;
    wire [34:0] dst_end = {3'd0, cfg_dst} + bytes_to_copy;
    wire config_valid = cfg_words != 32'd0 &&
                        cfg_src[1:0] == 2'b00 &&
                        cfg_dst[1:0] == 2'b00;
    wire ranges_valid = cfg_src >= DDR_BASE && cfg_dst >= DDR_BASE &&
                        src_end <= ddr_limit && dst_end <= ddr_limit &&
                        !(cfg_dst > cfg_src && {3'd0, cfg_dst} < src_end);

    wire [3:0] src_line_left = 4'd8 - {1'b0, src_cur[4:2]};
    wire [3:0] dst_line_left = 4'd8 - {1'b0, dst_cur[4:2]};
    wire [3:0] line_beats = src_line_left < dst_line_left ?
                            src_line_left : dst_line_left;
    wire [3:0] burst_beats = remaining < {28'd0, line_beats} ?
                             remaining[3:0] : line_beats;
    wire [3:0] burst_last = burst_beats - 4'd1;
    wire [31:0] burst_bytes = {26'd0, burst_beats, 2'b00};

    wire mem_req_valid = state == S_READ_REQ || state == S_WRITE_REQ;
    wire mem_req_ready;
    wire mem_req_write = state == S_WRITE_REQ;
    wire [31:0] mem_req_addr = mem_req_write ? dst_cur : src_cur;
    wire [2:0] mem_req_len = burst_last[2:0];
    wire mem_w_valid = state == S_WRITE_DATA;
    wire mem_w_ready;
    wire [31:0] mem_w_data = burst_data[write_index];
    wire [3:0] mem_w_strb = 4'hf;
    wire mem_w_last = write_index == burst_last[2:0];
    wire mem_rsp_valid, mem_rsp_last, mem_rsp_error;
    wire mem_rsp_ready = state == S_READ_DATA || state == S_WRITE_RESP;
    wire [31:0] mem_rsp_rdata;

    assign irq = irq_enable && done;

    dma_axi_master32 u_axi (
        .clk(clk), .resetn(resetn),
        .mem_req_valid(mem_req_valid), .mem_req_ready(mem_req_ready),
        .mem_req_write(mem_req_write), .mem_req_addr(mem_req_addr),
        .mem_req_len(mem_req_len),
        .mem_w_valid(mem_w_valid), .mem_w_ready(mem_w_ready),
        .mem_w_data(mem_w_data), .mem_w_strb(mem_w_strb),
        .mem_w_last(mem_w_last),
        .mem_rsp_valid(mem_rsp_valid), .mem_rsp_ready(mem_rsp_ready),
        .mem_rsp_rdata(mem_rsp_rdata), .mem_rsp_last(mem_rsp_last),
        .mem_rsp_error(mem_rsp_error),
        .m_axi_awaddr(m_axi_awaddr), .m_axi_awlen(m_axi_awlen),
        .m_axi_awsize(m_axi_awsize), .m_axi_awburst(m_axi_awburst),
        .m_axi_awvalid(m_axi_awvalid), .m_axi_awready(m_axi_awready),
        .m_axi_wdata(m_axi_wdata), .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wlast(m_axi_wlast), .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wready(m_axi_wready), .m_axi_bresp(m_axi_bresp),
        .m_axi_bvalid(m_axi_bvalid), .m_axi_bready(m_axi_bready),
        .m_axi_araddr(m_axi_araddr), .m_axi_arlen(m_axi_arlen),
        .m_axi_arsize(m_axi_arsize), .m_axi_arburst(m_axi_arburst),
        .m_axi_arvalid(m_axi_arvalid), .m_axi_arready(m_axi_arready),
        .m_axi_rdata(m_axi_rdata), .m_axi_rresp(m_axi_rresp),
        .m_axi_rlast(m_axi_rlast), .m_axi_rvalid(m_axi_rvalid),
        .m_axi_rready(m_axi_rready)
    );

    always @(*) begin
        case (reg_rd_addr[7:2])
            6'h00: reg_rd_data = 32'h444d_4139; // DMA9
            6'h01: reg_rd_data = 32'h0001_0000;
            6'h02: reg_rd_data = {23'd0, irq_enable, 8'd0};
            6'h03: reg_rd_data = {24'd0, error_code, 2'd0, error, done};
            6'h04: reg_rd_data = cfg_src;
            6'h05: reg_rd_data = cfg_dst;
            6'h06: reg_rd_data = cfg_words;
            6'h07: reg_rd_data = words_done;
            6'h08: reg_rd_data = {31'd0, busy};
            default: reg_rd_data = 32'd0;
        endcase
    end

    always @(posedge clk) begin
        if (!resetn) begin
            state <= S_IDLE;
            done <= 1'b0;
            error <= 1'b0;
            error_code <= 4'd0;
            irq_enable <= 1'b0;
            cfg_src <= DDR_BASE;
            cfg_dst <= DDR_BASE;
            cfg_words <= 32'd0;
            src_cur <= 32'd0;
            dst_cur <= 32'd0;
            remaining <= 32'd0;
            words_done <= 32'd0;
            read_index <= 3'd0;
            write_index <= 3'd0;
        end else begin
            if (reg_wr_en && !busy) begin
                case (reg_wr_addr[7:2])
                    6'h02: if (reg_wr_strb[1])
                        irq_enable <= reg_wr_data[8];
                    6'h04: begin
                        if (reg_wr_strb[0]) cfg_src[7:0] <= reg_wr_data[7:0];
                        if (reg_wr_strb[1]) cfg_src[15:8] <= reg_wr_data[15:8];
                        if (reg_wr_strb[2]) cfg_src[23:16] <= reg_wr_data[23:16];
                        if (reg_wr_strb[3]) cfg_src[31:24] <= reg_wr_data[31:24];
                    end
                    6'h05: begin
                        if (reg_wr_strb[0]) cfg_dst[7:0] <= reg_wr_data[7:0];
                        if (reg_wr_strb[1]) cfg_dst[15:8] <= reg_wr_data[15:8];
                        if (reg_wr_strb[2]) cfg_dst[23:16] <= reg_wr_data[23:16];
                        if (reg_wr_strb[3]) cfg_dst[31:24] <= reg_wr_data[31:24];
                    end
                    6'h06: begin
                        if (reg_wr_strb[0]) cfg_words[7:0] <= reg_wr_data[7:0];
                        if (reg_wr_strb[1]) cfg_words[15:8] <= reg_wr_data[15:8];
                        if (reg_wr_strb[2]) cfg_words[23:16] <= reg_wr_data[23:16];
                        if (reg_wr_strb[3]) cfg_words[31:24] <= reg_wr_data[31:24];
                    end
                    default: begin end
                endcase
            end
            if (clear && !busy) begin
                done <= 1'b0;
                error <= 1'b0;
                error_code <= 4'd0;
            end
            case (state)
                S_IDLE: if (start) begin
                    done <= 1'b0;
                    error <= 1'b0;
                    error_code <= 4'd0;
                    words_done <= 32'd0;
                    if (!config_valid || !ranges_valid) begin
                        done <= 1'b1;
                        error <= 1'b1;
                        error_code <= 4'd1;
                    end else begin
                        src_cur <= cfg_src;
                        dst_cur <= cfg_dst;
                        remaining <= cfg_words;
                        state <= S_READ_REQ;
                    end
                end
                S_READ_REQ: if (mem_req_valid && mem_req_ready) begin
                    read_index <= 3'd0;
                    state <= S_READ_DATA;
                end
                S_READ_DATA: if (mem_rsp_valid && mem_rsp_ready) begin
                    burst_data[read_index] <= mem_rsp_rdata;
                    if (mem_rsp_error ||
                        (mem_rsp_last != (read_index == burst_last[2:0]))) begin
                        done <= 1'b1;
                        error <= 1'b1;
                        error_code <= 4'd2;
                        state <= S_IDLE;
                    end else if (mem_rsp_last) begin
                        state <= S_WRITE_REQ;
                    end else begin
                        read_index <= read_index + 3'd1;
                    end
                end
                S_WRITE_REQ: if (mem_req_valid && mem_req_ready) begin
                    write_index <= 3'd0;
                    state <= S_WRITE_DATA;
                end
                S_WRITE_DATA: if (mem_w_valid && mem_w_ready) begin
                    if (mem_w_last) state <= S_WRITE_RESP;
                    else write_index <= write_index + 3'd1;
                end
                S_WRITE_RESP: if (mem_rsp_valid && mem_rsp_ready) begin
                    if (mem_rsp_error) begin
                        done <= 1'b1;
                        error <= 1'b1;
                        error_code <= 4'd3;
                        state <= S_IDLE;
                    end else begin
                        src_cur <= src_cur + burst_bytes;
                        dst_cur <= dst_cur + burst_bytes;
                        remaining <= remaining - {28'd0, burst_beats};
                        words_done <= words_done + {28'd0, burst_beats};
                        if (remaining == {28'd0, burst_beats}) begin
                            done <= 1'b1;
                            state <= S_IDLE;
                        end else begin
                            state <= S_READ_REQ;
                        end
                    end
                end
                default: state <= S_IDLE;
            endcase
        end
    end
endmodule
