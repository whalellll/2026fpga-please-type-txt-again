`timescale 1ns/1ps

// CPU test-SoC wrapper: CoreTop speaks RV32IMA and exposes the AXI signals below.
// The integrated SoC owns a separate wrapper with its own clock and CDC contract.
module cpu_core_top #(
    parameter [31:0] RESET_VECTOR = 32'h1c00_0000
)(
    input wire aclk, input wire aresetn,
    input wire [31:0] external_interrupts,
    output wire [3:0] arid, output wire [31:0] araddr,
    output wire [7:0] arlen, output wire [2:0] arsize,
    output wire [1:0] arburst, output wire [1:0] arlock,
    output wire [3:0] arcache, output wire [2:0] arprot,
    output wire arvalid, input wire arready,
    input wire [3:0] rid, input wire [31:0] rdata,
    input wire [1:0] rresp, input wire rlast, input wire rvalid,
    output wire rready,
    output wire [3:0] awid, output wire [31:0] awaddr,
    output wire [7:0] awlen, output wire [2:0] awsize,
    output wire [1:0] awburst, output wire [1:0] awlock,
    output wire [3:0] awcache, output wire [2:0] awprot,
    output wire awvalid, input wire awready,
    output wire [3:0] wid, output wire [31:0] wdata,
    output wire [3:0] wstrb, output wire wlast, output wire wvalid,
    input wire wready, input wire [3:0] bid, input wire [1:0] bresp,
    input wire bvalid, output wire bready
);
    wire [3:0] c_arid, c_awid, c_wid;
    wire [31:0] c_araddr, c_awaddr, c_wdata;
    wire [7:0] c_arlen, c_awlen;
    wire [2:0] c_arsize, c_awsize, c_arprot, c_awprot;
    wire [1:0] c_arburst, c_awburst, c_arlock, c_awlock;
    wire [3:0] c_arcache, c_awcache, c_wstrb;
    wire c_arvalid, c_arready, c_rready, c_awvalid, c_awready;
    wire c_wlast, c_wvalid, c_wready, c_bready;
    wire [3:0] c_rid, c_bid;
    wire [31:0] c_rdata;
    wire [1:0] c_rresp, c_bresp;
    wire c_rlast, c_rvalid, c_bvalid;
    wire fatal_memory_error;

    reg [63:0] mtime, mtimecmp;
    reg msip;
    wire timer_irq = (mtime >= mtimecmp);
    wire software_irq = msip;
    // The current CSR block has one MEIP pending bit, so source identity is
    // retained at the 32 pins but not exposed individually in a CPU CSR.
    wire [7:0] core_interrupts = {timer_irq, 5'b0, software_irq,
                                  (|external_interrupts)};

    CoreTop u_cpu (
        .io_aclk(aclk), .io_aresetn(aresetn),
        .io_resetVector(RESET_VECTOR), .io_intrpt(core_interrupts),
        .io_arid(c_arid), .io_araddr(c_araddr), .io_arlen(c_arlen),
        .io_arsize(c_arsize), .io_arburst(c_arburst),
        .io_arlock(c_arlock), .io_arcache(c_arcache),
        .io_arprot(c_arprot), .io_arvalid(c_arvalid),
        .io_arready(c_arready), .io_rid(c_rid), .io_rdata(c_rdata),
        .io_rresp(c_rresp), .io_rlast(c_rlast), .io_rvalid(c_rvalid),
        .io_rready(c_rready), .io_awid(c_awid), .io_awaddr(c_awaddr),
        .io_awlen(c_awlen), .io_awsize(c_awsize),
        .io_awburst(c_awburst), .io_awlock(c_awlock),
        .io_awcache(c_awcache), .io_awprot(c_awprot),
        .io_awvalid(c_awvalid), .io_awready(c_awready),
        .io_wid(c_wid), .io_wdata(c_wdata), .io_wstrb(c_wstrb),
        .io_wlast(c_wlast), .io_wvalid(c_wvalid), .io_wready(c_wready),
        .io_bid(c_bid), .io_bresp(c_bresp), .io_bvalid(c_bvalid),
        .io_bready(c_bready), .io_fatalMemoryError(fatal_memory_error),
        .io_break_point(1'b0), .io_infor_flag(1'b0),
        .io_reg_num(5'b0), .io_ws_valid(), .io_rf_rdata(),
        .io_debug0_wb_pc(), .io_debug0_wb_rf_wen(),
        .io_debug0_wb_rf_wnum(), .io_debug0_wb_rf_wdata(),
        .io_debug0_wb_inst()
    );

    // The CPU issues one transaction at a time.  Local CLINT accesses are
    // removed from the outward AXI path; all other traffic passes through.
    wire c_ar_clint = (c_araddr[31:16] == 16'h0200);
    reg local_read_active, local_rvalid, local_rlast;
    reg [3:0] local_rid;
    reg [31:0] local_raddr, local_rdata;
    reg [7:0] local_rlen, local_rbeat;
    reg [2:0] local_rsize;
    reg [1:0] local_rburst, local_rresp;
    reg local_read_bad;

    assign arid = c_arid;
    assign araddr = c_araddr;
    assign arlen = c_arlen;
    assign arsize = c_arsize;
    assign arburst = c_arburst;
    assign arlock = c_arlock;
    assign arcache = c_arcache;
    assign arprot = c_arprot;
    assign arvalid = c_arvalid && !c_ar_clint && !local_read_active;
    assign c_arready = c_ar_clint ? !local_read_active :
                       (local_read_active ? 1'b0 : arready);
    assign c_rid = local_read_active ? local_rid : rid;
    assign c_rdata = local_read_active ? local_rdata : rdata;
    assign c_rresp = local_read_active ? local_rresp : rresp;
    assign c_rlast = local_read_active ? local_rlast : rlast;
    assign c_rvalid = local_read_active ? local_rvalid : rvalid;
    assign rready = !local_read_active && c_rready;

    always @(posedge aclk) begin
        if (!aresetn) begin
            local_read_active <= 1'b0;
            local_rvalid <= 1'b0;
            local_rlast <= 1'b0;
            local_rid <= 4'b0;
            local_raddr <= 32'b0;
            local_rlen <= 8'b0;
            local_rbeat <= 8'b0;
            local_rsize <= 3'b0;
            local_rburst <= 2'b0;
            local_rdata <= 32'b0;
            local_rresp <= 2'b0;
            local_read_bad <= 1'b0;
        end else begin
            if (c_arvalid && c_arready && c_ar_clint) begin
                local_read_active <= 1'b1;
                local_rvalid <= 1'b0;
                local_rid <= c_arid;
                local_raddr <= c_araddr;
                local_rlen <= c_arlen;
                local_rbeat <= 8'b0;
                local_rsize <= c_arsize;
                local_rburst <= c_arburst;
                local_read_bad <= (c_arsize > 3'd2) ||
                                  ((c_arburst != 2'b00) && (c_arburst != 2'b01));
            end else if (local_read_active && !local_rvalid) begin
                local_rlast <= (local_rbeat == local_rlen);
                local_rvalid <= 1'b1;
                local_rresp <= local_read_bad ? 2'b10 : 2'b00;
                case (local_raddr & 32'hffff_fffc)
                    32'h0200_0000: local_rdata <= {31'b0, msip};
                    32'h0200_4000: local_rdata <= mtimecmp[31:0];
                    32'h0200_4004: local_rdata <= mtimecmp[63:32];
                    32'h0200_bff8: local_rdata <= mtime[31:0];
                    32'h0200_bffc: local_rdata <= mtime[63:32];
                    default: begin
                        local_rdata <= 32'b0;
                        local_rresp <= 2'b11;
                    end
                endcase
            end else if (local_rvalid && c_rready) begin
                local_rvalid <= 1'b0;
                if (local_rlast) begin
                    local_read_active <= 1'b0;
                end else begin
                    local_rbeat <= local_rbeat + 8'd1;
                    if (local_rburst == 2'b01)
                        local_raddr <= local_raddr + (32'd1 << local_rsize);
                end
            end
        end
    end

    wire c_aw_clint = (c_awaddr[31:16] == 16'h0200);
    reg local_write_active, local_bvalid;
    reg [3:0] local_wid, local_bid;
    reg [31:0] local_waddr;
    reg [7:0] local_wlen, local_wbeat;
    reg [2:0] local_wsize;
    reg [1:0] local_wburst, local_bresp;
    reg local_write_bad;
    wire local_aw_ready = !local_write_active && !local_bvalid;
    wire local_write_beat = local_write_active && c_wvalid && c_wready;
    wire local_expected_last = (local_wbeat == local_wlen);
    wire local_waddr_ok = ((local_waddr & 32'hffff_fffc) == 32'h0200_0000) ||
                          ((local_waddr & 32'hffff_fffc) == 32'h0200_4000) ||
                          ((local_waddr & 32'hffff_fffc) == 32'h0200_4004) ||
                          ((local_waddr & 32'hffff_fffc) == 32'h0200_bff8) ||
                          ((local_waddr & 32'hffff_fffc) == 32'h0200_bffc);
    wire local_write_error = local_write_bad || !local_waddr_ok ||
                             (c_wid != local_wid) ||
                             (c_wlast != local_expected_last);

    assign awid = c_awid;
    assign awaddr = c_awaddr;
    assign awlen = c_awlen;
    assign awsize = c_awsize;
    assign awburst = c_awburst;
    assign awlock = c_awlock;
    assign awcache = c_awcache;
    assign awprot = c_awprot;
    assign awvalid = c_awvalid && !c_aw_clint && !local_write_active && !local_bvalid;
    assign c_awready = c_aw_clint ? local_aw_ready :
                       ((local_write_active || local_bvalid) ? 1'b0 : awready);
    assign wid = c_wid;
    assign wdata = c_wdata;
    assign wstrb = c_wstrb;
    assign wlast = c_wlast;
    assign wvalid = c_wvalid && !local_write_active &&
                    !(c_awvalid && c_aw_clint) && !local_bvalid;
    assign c_wready = local_write_active ? 1'b1 :
                      ((c_awvalid && c_aw_clint) || local_bvalid ? 1'b0 : wready);
    assign c_bid = local_bvalid ? local_bid : bid;
    assign c_bresp = local_bvalid ? local_bresp : bresp;
    assign c_bvalid = local_bvalid ? 1'b1 :
                      (local_write_active ? 1'b0 : bvalid);
    assign bready = !local_write_active && !local_bvalid && c_bready;

    always @(posedge aclk) begin
        if (!aresetn) begin
            local_write_active <= 1'b0;
            local_bvalid <= 1'b0;
            local_wid <= 4'b0;
            local_bid <= 4'b0;
            local_waddr <= 32'b0;
            local_wlen <= 8'b0;
            local_wbeat <= 8'b0;
            local_wsize <= 3'b0;
            local_wburst <= 2'b0;
            local_bresp <= 2'b0;
            local_write_bad <= 1'b0;
        end else begin
            if (c_awvalid && c_awready && c_aw_clint) begin
                local_write_active <= 1'b1;
                local_wid <= c_awid;
                local_bid <= c_awid;
                local_waddr <= c_awaddr;
                local_wlen <= c_awlen;
                local_wbeat <= 8'b0;
                local_wsize <= c_awsize;
                local_wburst <= c_awburst;
                local_write_bad <= (c_awsize > 3'd2) ||
                                   ((c_awburst != 2'b00) && (c_awburst != 2'b01));
            end else if (local_write_beat) begin
                local_write_bad <= local_write_bad || local_write_error;
                if (local_expected_last || c_wlast) begin
                    local_write_active <= 1'b0;
                    local_bvalid <= 1'b1;
                    local_bresp <= local_write_error ? 2'b10 : 2'b00;
                end else begin
                    local_wbeat <= local_wbeat + 8'd1;
                    if (local_wburst == 2'b01)
                        local_waddr <= local_waddr + (32'd1 << local_wsize);
                end
            end else if (local_bvalid && c_bready) begin
                local_bvalid <= 1'b0;
            end
        end
    end

    reg [63:0] mtime_next, mtimecmp_next;
    reg msip_next;
    integer byte_lane;
    always @* begin
        mtime_next = mtime + 64'd1;
        mtimecmp_next = mtimecmp;
        msip_next = msip;
        if (local_write_beat && !local_write_error) begin
            case (local_waddr & 32'hffff_fffc)
                32'h0200_0000: if (c_wstrb[0]) msip_next = c_wdata[0];
                32'h0200_4000: for (byte_lane = 0; byte_lane < 4; byte_lane = byte_lane + 1)
                    if (c_wstrb[byte_lane]) mtimecmp_next[byte_lane*8 +: 8] = c_wdata[byte_lane*8 +: 8];
                32'h0200_4004: for (byte_lane = 0; byte_lane < 4; byte_lane = byte_lane + 1)
                    if (c_wstrb[byte_lane]) mtimecmp_next[32 + byte_lane*8 +: 8] = c_wdata[byte_lane*8 +: 8];
                32'h0200_bff8: for (byte_lane = 0; byte_lane < 4; byte_lane = byte_lane + 1)
                    if (c_wstrb[byte_lane]) mtime_next[byte_lane*8 +: 8] = c_wdata[byte_lane*8 +: 8];
                32'h0200_bffc: for (byte_lane = 0; byte_lane < 4; byte_lane = byte_lane + 1)
                    if (c_wstrb[byte_lane]) mtime_next[32 + byte_lane*8 +: 8] = c_wdata[byte_lane*8 +: 8];
                default: begin end
            endcase
        end
    end
    always @(posedge aclk) begin
        if (!aresetn) begin
            mtime <= 64'b0;
            mtimecmp <= 64'hffff_ffff_ffff_ffff;
            msip <= 1'b0;
        end else begin
            mtime <= mtime_next;
            mtimecmp <= mtimecmp_next;
            msip <= msip_next;
        end
    end
    wire unused_fatal_memory_error = fatal_memory_error;
endmodule

// Exact legacy two-pin interrupt-free wrapper from the supplied interface.
module core_top #(
    parameter [31:0] RESET_VECTOR = 32'h1c00_0000
)(
    input wire aclk, input wire aresetn,
    output wire [3:0] arid, output wire [31:0] araddr,
    output wire [7:0] arlen, output wire [2:0] arsize,
    output wire [1:0] arburst, output wire [1:0] arlock,
    output wire [3:0] arcache, output wire [2:0] arprot,
    output wire arvalid, input wire arready,
    input wire [3:0] rid, input wire [31:0] rdata,
    input wire [1:0] rresp, input wire rlast, input wire rvalid,
    output wire rready,
    output wire [3:0] awid, output wire [31:0] awaddr,
    output wire [7:0] awlen, output wire [2:0] awsize,
    output wire [1:0] awburst, output wire [1:0] awlock,
    output wire [3:0] awcache, output wire [2:0] awprot,
    output wire awvalid, input wire awready,
    output wire [3:0] wid, output wire [31:0] wdata,
    output wire [3:0] wstrb, output wire wlast, output wire wvalid,
    input wire wready, input wire [3:0] bid, input wire [1:0] bresp,
    input wire bvalid, output wire bready
);
    cpu_core_top #(.RESET_VECTOR(RESET_VECTOR)) u_linux_cpu (
        .aclk(aclk), .aresetn(aresetn), .external_interrupts(32'b0),
        .arid(arid), .araddr(araddr), .arlen(arlen), .arsize(arsize),
        .arburst(arburst), .arlock(arlock), .arcache(arcache), .arprot(arprot),
        .arvalid(arvalid), .arready(arready), .rid(rid), .rdata(rdata),
        .rresp(rresp), .rlast(rlast), .rvalid(rvalid), .rready(rready),
        .awid(awid), .awaddr(awaddr), .awlen(awlen), .awsize(awsize),
        .awburst(awburst), .awlock(awlock), .awcache(awcache), .awprot(awprot),
        .awvalid(awvalid), .awready(awready), .wid(wid), .wdata(wdata),
        .wstrb(wstrb), .wlast(wlast), .wvalid(wvalid), .wready(wready),
        .bid(bid), .bresp(bresp), .bvalid(bvalid), .bready(bready)
    );
endmodule
