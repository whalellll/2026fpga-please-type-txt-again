`timescale 1ns / 1ps

module tb_coremark_soc #(
    parameter integer CPU_HZ = 49500000
);
    localparam real HALF_PERIOD_NS = 500000000.0 / CPU_HZ;
    // Fast UART is outside CoreMark start_time/stop_time; CPU timing is unchanged.
    localparam integer BAUD_DIV = 2;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg uart_rx = 1'b1;
    wire uart_tx;
    reg [7:0] rx_byte;
    reg [8*13-1:0] marker_shift = 0;
    reg [8*13-1:0] marker_next;
    integer bit_no;
    integer cycle_count = 0;
    integer commit_count = 0;
    integer uart_log;
    integer read_decerr_beats = 0;
    reg saw_first_fetch = 0;
    integer max_cycles = 900000000;
    // Diagnostic counters cover the whole short run, including startup/UART.
    // They do not replace PORT_TICKS64 or change official CoreMark scoring.
    integer profile_ib_empty = 0;
    integer profile_rename_blocked = 0;
    integer profile_dispatch_blocked = 0;
    integer profile_rob_full = 0;
    integer profile_pd_repair = 0;
    integer profile_returns = 0;
    integer profile_return_empty = 0;
    integer profile_return_repair = 0;
    integer profile_early_redirect = 0;
    integer profile_cmt_branches = 0;
    integer profile_cmt_mispred = 0;
    integer profile_cmt_return_mispred = 0;


    // Memory reads may run speculatively before an older branch resolves.
    // Check architectural memory effects at all four actual commit slots.
    task automatic check_committed_address;
        input [31:0] addr;
        input integer slot;
        begin
            if (!((addr >= 32'h1c00_0000 && addr < 32'h1c02_0000) ||
                  (addr >= 32'h1fe0_01e0 && addr <= 32'h1fe0_01e7) ||
                  (addr >= 32'h1fe0_0000 && addr <= 32'h1fe0_000b)))
                $fatal(1,"Unmapped committed memory access slot=%0d addr=%h",slot,addr);
        end
    endtask

    initial begin
        if (CPU_HZ <= 0) $fatal(1, "CPU_HZ must be positive");
        $display("TB_COREMARK_SOC_START cpu_hz=%0d", CPU_HZ);
        uart_log = $fopen("uart.log", "w");
        if (!uart_log) $fatal(1, "Cannot open UART log");
        $fflush();
    end

    always #(HALF_PERIOD_NS) clk = ~clk;

    coremark_soc_top #(
        .UART_BAUD_DIV(BAUD_DIV)
    ) dut (
        .clk(clk), .rst_n(rst_n), .uart_rx(uart_rx), .uart_tx(uart_tx),
        .interrupts(8'b0), .gpio_in(32'h12345678), .gpio_out(), .gpio_oe()
    );

    initial begin
        repeat (20) @(posedge clk);
        rst_n = 1'b1;
    end

    // Keep long Icarus runs observable and prove that execution really starts
    // from the linked reset vector.  The first few commits are useful when a
    // firmware/AXI integration regression stalls before UART output.
    always @(posedge clk) begin
        if (dut.sys_resetn) begin
            cycle_count <= cycle_count + 1;
            if (!dut.u_cpu.core.backend.io_ib_pop0_valid) profile_ib_empty <= profile_ib_empty + 1;
            if (dut.u_cpu.core.backend.io_ib_pop0_valid && !dut.u_cpu.core.backend.io_ib_pop0_ready)
                profile_rename_blocked <= profile_rename_blocked + 1;
            if (!dut.u_cpu.core.backend._u_dispatch_io_dispatchReady)
                profile_dispatch_blocked <= profile_dispatch_blocked + 1;
            if (dut.u_cpu.core.backend._u_rob_io_robFull) profile_rob_full <= profile_rob_full + 1;
            if (dut.u_cpu.core.frontend.pdRepair) profile_pd_repair <= profile_pd_repair + 1;
            if (dut.u_cpu.core.frontend.pdAccept && dut.u_cpu.core.frontend.isReturn) begin
                profile_returns <= profile_returns + 1;
                if (dut.u_cpu.core.frontend._ras_io_empty) profile_return_empty <= profile_return_empty + 1;
                if (dut.u_cpu.core.frontend.pdRepair) profile_return_repair <= profile_return_repair + 1;
            end
            if (dut.u_cpu.core.backend.io_early_redirect_valid) profile_early_redirect <= profile_early_redirect + 1;
            if (dut.u_cpu.core.backend.io_cmt_ftq_valid && dut.u_cpu.core.backend.io_cmt_ftq_is_branch) begin
                profile_cmt_branches <= profile_cmt_branches + 1;
                if (dut.u_cpu.core.backend.io_cmt_ftq_mispred) begin
                    profile_cmt_mispred <= profile_cmt_mispred + 1;
                    if (dut.u_cpu.core.backend.io_cmt_ftq_br_type == 2'd3)
                        profile_cmt_return_mispred <= profile_cmt_return_mispred + 1;
                end
            end
            if (dut.arvalid && dut.arready && !saw_first_fetch) begin
                if (dut.araddr !== 32'h1c00_0000) $fatal(1,"Unexpected reset fetch %h",dut.araddr);
                saw_first_fetch <= 1;
            end
            if (dut.rvalid && dut.rready && dut.rresp != 0) begin
                if (dut.u_mem_uart.rd_bad_request) $fatal(1,"Unsupported CPU AXI read burst");
                read_decerr_beats <= read_decerr_beats + 1;
            end
            if (dut.u_cpu.core.backend.cmt_csr_ex)
                $fatal(1,"Unexpected architectural trap in CoreMark pc=%h",dut.u_cpu.core.backend.cmt_csr_pc);
            if (dut.u_cpu.core.backend.cmt_retire0_valid &&
                (dut.u_cpu.core.backend.rob_cmt0_is_load || dut.u_cpu.core.backend.rob_cmt0_is_store))
                check_committed_address(dut.u_cpu.core.backend.cmt0_paddr_eff,0);
            if (dut.u_cpu.core.backend.cmt_retire1_valid &&
                (dut.u_cpu.core.backend.rob_cmt1_is_load || dut.u_cpu.core.backend.rob_cmt1_is_store))
                check_committed_address(dut.u_cpu.core.backend.cmt1_paddr_eff,1);
            if (dut.u_cpu.core.backend.cmt_quad_retire && dut.u_cpu.core.backend.rob_cmt2_is_load)
                check_committed_address(dut.u_cpu.core.backend.rob_cmt2_paddr,2);
            if (dut.u_cpu.core.backend.cmt_quad_retire && dut.u_cpu.core.backend.rob_cmt3_is_load)
                check_committed_address(dut.u_cpu.core.backend.rob_cmt3_paddr,3);
            if (dut.bvalid && dut.bready && dut.bresp != 0) $fatal(1,"AXI write error");
            if (dut.u_cpu.core.backend.cmt_retire0_valid || dut.u_cpu.core.backend.cmt_retire1_valid) begin
                if (commit_count < 16)
                    $display("COMMIT[%0d] cycle=%0d pc0=%08x pc1=%08x",
                             commit_count, cycle_count,
                             dut.u_cpu.core.backend.cmt_retire0_pc, dut.u_cpu.core.backend.cmt_retire1_pc);
                commit_count <= commit_count + dut.u_cpu.core.backend.cmt_csr_retire_count;
            end

        end
    end

    initial begin
        forever begin
            @(negedge uart_tx);
            repeat (BAUD_DIV/2) @(posedge clk);
            if (uart_tx !== 1'b0)
                $fatal(1, "UART false start");
            for (bit_no = 0; bit_no < 8; bit_no = bit_no + 1) begin
                repeat (BAUD_DIV) @(posedge clk);
                rx_byte[bit_no] = uart_tx;
            end
            repeat (BAUD_DIV) @(posedge clk);
            if (uart_tx !== 1'b1)
                $fatal(1, "UART stop-bit error");
            $write("%c", rx_byte);
            $fwrite(uart_log,"%c",rx_byte);
            $fflush();
            marker_next = {marker_shift[8*12-1:0], rx_byte};
            marker_shift = marker_next;
            if (marker_next == "COREMARK_DONE") begin
                $fclose(uart_log);
                if (!saw_first_fetch || commit_count == 0) $fatal(1,"No CPU execution observed");
                $display("\nTB_COREMARK_SOC_PASS cycles=%0d retired=%0d speculative_decerr_beats=%0d",cycle_count,commit_count,read_decerr_beats);
                $display("COREMARK_PROFILE scope=whole_run ib_empty=%0d rename_blocked=%0d dispatch_blocked=%0d rob_full=%0d pd_repair=%0d returns=%0d return_empty=%0d return_repair=%0d early_redirect=%0d committed_branches=%0d committed_mispred=%0d committed_return_mispred=%0d",
                    profile_ib_empty,profile_rename_blocked,profile_dispatch_blocked,profile_rob_full,
                    profile_pd_repair,profile_returns,profile_return_empty,profile_return_repair,
                    profile_early_redirect,profile_cmt_branches,profile_cmt_mispred,profile_cmt_return_mispred);
                $finish;
            end
        end
    end

    initial begin
        if ($value$plusargs("max_cycles=%d", max_cycles)) begin end
        repeat (max_cycles) @(posedge clk);
        $fatal(1, "TB_COREMARK_SOC_TIMEOUT");
    end
endmodule
