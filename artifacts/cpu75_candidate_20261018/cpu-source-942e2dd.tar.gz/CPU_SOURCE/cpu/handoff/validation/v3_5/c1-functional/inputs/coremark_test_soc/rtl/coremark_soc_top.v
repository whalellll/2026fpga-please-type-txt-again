`timescale 1ns / 1ps

module coremark_soc_top #(
    parameter integer UART_BAUD_DIV = 430
) (
    input  wire clk,
    input  wire rst_n,
    input  wire uart_rx,
    input wire [7:0] interrupts,
    output wire uart_tx,
    input wire [31:0] gpio_in,
    output wire [31:0] gpio_out,
    output wire [31:0] gpio_oe
);

    reg [1:0] reset_pipe;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            reset_pipe <= 2'b00;
        else
            reset_pipe <= {reset_pipe[0], 1'b1};
    end
    wire sys_resetn = reset_pipe[1];

    wire [3:0]  arid;
    wire [31:0] araddr;
    wire [7:0]  arlen;
    wire [2:0]  arsize;
    wire [1:0]  arburst;
    wire [1:0]  arlock;
    wire [3:0]  arcache;
    wire [2:0]  arprot;
    wire        arvalid;
    wire        arready;
    wire [3:0]  rid;
    wire [31:0] rdata;
    wire [1:0]  rresp;
    wire        rlast;
    wire        rvalid;
    wire        rready;

    wire [3:0]  awid;
    wire [31:0] awaddr;
    wire [7:0]  awlen;
    wire [2:0]  awsize;
    wire [1:0]  awburst;
    wire [1:0]  awlock;
    wire [3:0]  awcache;
    wire [2:0]  awprot;
    wire        awvalid;
    wire        awready;
    wire [3:0]  wid;
    wire [31:0] wdata;
    wire [3:0]  wstrb;
    wire        wlast;
    wire        wvalid;
    wire        wready;
    wire [3:0]  bid;
    wire [1:0]  bresp;
    wire        bvalid;
    wire        bready;

    wire        ws_valid;
    wire [31:0] rf_rdata;
    wire [31:0] debug0_wb_pc;
    wire [3:0]  debug0_wb_rf_wen;
    wire [4:0]  debug0_wb_rf_wnum;
    wire [31:0] debug0_wb_rf_wdata;
    wire [31:0] debug0_wb_inst;

    CoreTop u_cpu (
        .io_aclk               (clk),
        .io_aresetn            (sys_resetn),
        .io_resetVector        (32'h1c00_0000),
        .io_intrpt             (interrupts),
        .io_arid               (arid),
        .io_araddr             (araddr),
        .io_arlen              (arlen),
        .io_arsize             (arsize),
        .io_arburst            (arburst),
        .io_arlock             (arlock),
        .io_arcache            (arcache),
        .io_arprot             (arprot),
        .io_arvalid            (arvalid),
        .io_arready            (arready),
        .io_rid                (rid),
        .io_rdata              (rdata),
        .io_rresp              (rresp),
        .io_rlast              (rlast),
        .io_rvalid             (rvalid),
        .io_rready             (rready),
        .io_awid               (awid),
        .io_awaddr             (awaddr),
        .io_awlen              (awlen),
        .io_awsize             (awsize),
        .io_awburst            (awburst),
        .io_awlock             (awlock),
        .io_awcache            (awcache),
        .io_awprot             (awprot),
        .io_awvalid            (awvalid),
        .io_awready            (awready),
        .io_wid                (wid),
        .io_wdata              (wdata),
        .io_wstrb              (wstrb),
        .io_wlast              (wlast),
        .io_wvalid             (wvalid),
        .io_wready             (wready),
        .io_bid                (bid),
        .io_bresp              (bresp),
        .io_bvalid             (bvalid),
        .io_bready             (bready),
        .io_break_point        (1'b0),
        .io_infor_flag         (1'b0),
        .io_reg_num            (5'b0),
        .io_ws_valid           (ws_valid),
        .io_rf_rdata           (rf_rdata),
        .io_debug0_wb_pc       (debug0_wb_pc),
        .io_debug0_wb_rf_wen   (debug0_wb_rf_wen),
        .io_debug0_wb_rf_wnum  (debug0_wb_rf_wnum),
        .io_debug0_wb_rf_wdata (debug0_wb_rf_wdata),
        .io_debug0_wb_inst     (debug0_wb_inst)
    );

    axi_bram_uart #(
        .BRAM_BASE (32'h1c00_0000),
        .BRAM_BYTES(128 * 1024),
        .UART_BASE (32'h1fe0_01e0),
        .INIT_FILE ("ram.hex"),
        .UART_BAUD_DIV(UART_BAUD_DIV)
    ) u_mem_uart (
        .clk     (clk),
        .resetn  (sys_resetn),
        .arid    (arid),
        .araddr  (araddr),
        .arlen   (arlen),
        .arsize  (arsize),
        .arburst (arburst),
        .arvalid (arvalid),
        .arready (arready),
        .rid     (rid),
        .rdata   (rdata),
        .rresp   (rresp),
        .rlast   (rlast),
        .rvalid  (rvalid),
        .rready  (rready),
        .awid    (awid),
        .awaddr  (awaddr),
        .awlen   (awlen),
        .awsize  (awsize),
        .awburst (awburst),
        .awvalid (awvalid),
        .awready (awready),
        .wid     (wid),
        .wdata   (wdata),
        .wstrb   (wstrb),
        .wlast   (wlast),
        .wvalid  (wvalid),
        .wready  (wready),
        .bid     (bid),
        .bresp   (bresp),
        .bvalid  (bvalid),
        .bready  (bready),
        .uart_rx (uart_rx),
        .uart_tx (uart_tx),
        .gpio_in (gpio_in),
        .gpio_out(gpio_out),
        .gpio_oe (gpio_oe)
    );

    wire unused_axi_attrs = &{1'b0, arlock, arcache, arprot,
                              awlock, awcache, awprot, ws_valid, rf_rdata,
                              debug0_wb_pc, debug0_wb_rf_wen,
                              debug0_wb_rf_wnum, debug0_wb_rf_wdata,
                              debug0_wb_inst};

endmodule
