`timescale 1ns/1ps

// Single-clock AXI register slave for the copy-DMA, video, and camera apertures.
// Read and write requests are serialized because they share one address port.
module dma_axi_mmio(
    input wire clk, input wire resetn,
    input wire [3:0] arid, input wire [31:0] araddr,
    input wire [7:0] arlen, input wire [2:0] arsize,
    input wire [1:0] arburst, input wire arvalid, output wire arready,
    output reg [3:0] rid, output reg [31:0] rdata,
    output reg [1:0] rresp, output reg rlast,
    output reg rvalid, input wire rready,
    input wire [3:0] awid, input wire [31:0] awaddr,
    input wire [7:0] awlen, input wire [2:0] awsize,
    input wire [1:0] awburst, input wire awvalid, output wire awready,
    input wire [3:0] wid, input wire [31:0] wdata,
    input wire [3:0] wstrb, input wire wlast,
    input wire wvalid, output wire wready,
    output reg [3:0] bid, output reg [1:0] bresp,
    output reg bvalid, input wire bready,
    output wire [31:0] mmio_addr, output wire mmio_wr,
    output wire [31:0] mmio_wdata, output wire [3:0] mmio_wstrb,
    input wire [31:0] mmio_rdata, input wire mmio_hit
);
    reg wr_active;
    reg [3:0] wr_id;
    reg [31:0] wr_addr;
    reg wr_bad;
    wire read_good = mmio_hit && arlen == 8'd0 && arsize <= 3'd2 &&
                     (arburst == 2'b00 || arburst == 2'b01);
    wire write_good = mmio_hit && !wr_bad && (wid == wr_id) && wlast;

    assign awready = !wr_active && !bvalid && !rvalid;
    assign arready = !wr_active && !bvalid && !rvalid && !awvalid;
    assign wready = wr_active && !bvalid;
    assign mmio_addr = wr_active ? wr_addr : araddr;
    assign mmio_wr = wr_active && wvalid && wready && write_good;
    assign mmio_wdata = wdata;
    assign mmio_wstrb = wstrb;

    always @(posedge clk) begin
        if (!resetn) begin
            rid <= 4'd0; rdata <= 32'd0; rresp <= 2'd0;
            rlast <= 1'b0; rvalid <= 1'b0;
            bid <= 4'd0; bresp <= 2'd0; bvalid <= 1'b0;
            wr_active <= 1'b0; wr_id <= 4'd0;
            wr_addr <= 32'd0; wr_bad <= 1'b0;
        end else begin
            if (arvalid && arready) begin
                rid <= arid;
                rdata <= read_good ? mmio_rdata : 32'd0;
                rresp <= read_good ? 2'b00 : 2'b11;
                rlast <= 1'b1;
                rvalid <= 1'b1;
            end else if (rvalid && rready) begin
                rvalid <= 1'b0;
            end
            if (awvalid && awready) begin
                wr_active <= 1'b1;
                wr_id <= awid;
                wr_addr <= awaddr;
                wr_bad <= awlen != 8'd0 || awsize > 3'd2 ||
                          (awburst != 2'b00 && awburst != 2'b01);
            end
            if (wvalid && wready) begin
                wr_active <= 1'b0;
                bid <= wr_id;
                bresp <= write_good ? 2'b00 : 2'b11;
                bvalid <= 1'b1;
            end else if (bvalid && bready) begin
                bvalid <= 1'b0;
            end
        end
    end
endmodule
