`timescale 1ns/1ps

// Byte-oriented SPI mode-0 controller for the on-board Micro SD socket.
//
// Register map (all registers are 32-bit and only byte lane zero is writable):
//   BASE + 0x00  ID       read-only, 0x53445331 ("SDS1")
//   BASE + 0x04  CTRL     bit 0: chip-select output, active low
//   BASE + 0x08  STATUS   bit 0: busy
//                         bit 1: received byte valid (write one to clear)
//                         bit 2: debounced card present
//                         bit 3: synchronized raw card present
//   BASE + 0x0c  DATA     write low byte to start a transfer; read RX byte
//   BASE + 0x10  DIV      low 16 bits: SPI half-period minus one
//   BASE + 0x14  PINS     bits 4:0: detect_n, miso, mosi, clk, cs_n
//   BASE + 0x18  DMA_DST  aligned physical DDR destination
//   BASE + 0x1c  DMA_CTRL bit 0: start 512-byte payload, bit 1: clear status
//   BASE + 0x20  DMA_STAT bits 0: busy, 1: done, 2: error,
//                         3: address error, 4: CRC error, 5: AXI error
//   BASE + 0x24  DMA_CRC  received CRC16 in [31:16], calculated CRC16 in [15:0]
//   BASE + 0x28  DMA_COUNT number of payload bytes received
//   BASE + 0x2c  DMA_CAP  version 1, 512-byte transfers
//
// DIV=63 gives 49.5 MHz / (2 * 64) = 386.7 kHz for card setup.
// Software may select DIV=1 for 12.375 MHz after card initialization.
module sd_spi_mmio #(
    parameter [31:0] BASE = 32'h1fe1_3000,
    parameter [15:0] RESET_DIV = 16'd63,
    parameter integer DEBOUNCE_CYCLES = 247500
)(
    input  wire        clk,
    input  wire        resetn,
    input  wire [31:0] addr,
    input  wire        wr,
    input  wire [31:0] wdata,
    input  wire [3:0]  wstrb,
    output reg  [31:0] rdata,
    output wire        hit,

    output reg         sd_clk,
    output wire        sd_mosi,
    input  wire        sd_miso,
    output reg         sd_cs_n,
    input  wire        sd_detect_n,

    output wire [31:0] m_axi_awaddr,
    output wire [7:0]  m_axi_awlen,
    output wire [2:0]  m_axi_awsize,
    output wire [1:0]  m_axi_awburst,
    output wire        m_axi_awvalid,
    input  wire        m_axi_awready,
    output wire [31:0] m_axi_wdata,
    output wire [3:0]  m_axi_wstrb,
    output wire        m_axi_wlast,
    output wire        m_axi_wvalid,
    input  wire        m_axi_wready,
    input  wire [1:0]  m_axi_bresp,
    input  wire        m_axi_bvalid,
    output wire        m_axi_bready
);
    reg [7:0]  tx_shift;
    reg [7:0]  rx_shift;
    reg [7:0]  rx_data;
    reg [2:0]  bit_count;
    reg [15:0] divider;
    reg [15:0] divider_count;
    reg        busy;
    reg        rx_valid;
    reg        byte_dma;

    reg [31:0] dma_destination;
    reg [31:0] dma_word_address;
    reg [31:0] dma_word;
    reg [10:0] dma_bytes_done;
    reg [1:0]  dma_word_bytes;
    reg [1:0]  dma_phase;
    reg [15:0] dma_crc;
    reg [15:0] dma_received_crc;
    reg        dma_busy;
    reg        dma_done;
    reg        dma_error;
    reg        dma_address_error;
    reg        dma_crc_error;
    reg        dma_axi_error;
    reg        dma_word_full;
    reg        dma_aw_sent;
    reg        dma_w_sent;
    reg        dma_wait_b;
    reg [15:0] dma_crc_next;
    integer    dma_crc_bit;

    reg        detect_meta_n;
    reg        detect_sync_n;
    reg        detect_debounced_n;
    reg [31:0] detect_count;

    wire raw_present;
    wire card_present;

    assign hit = (addr >= BASE) && (addr < (BASE + 32'h30));
    assign sd_mosi = tx_shift[7];
    assign raw_present = ~detect_sync_n;
    assign card_present = ~detect_debounced_n;

    assign m_axi_awaddr  = dma_word_address;
    assign m_axi_awlen   = 8'd0;
    assign m_axi_awsize  = 3'd2;
    assign m_axi_awburst = 2'b01;
    assign m_axi_awvalid = dma_word_full && !dma_aw_sent;
    assign m_axi_wdata   = dma_word;
    assign m_axi_wstrb   = 4'hf;
    assign m_axi_wlast   = 1'b1;
    assign m_axi_wvalid  = dma_word_full && !dma_w_sent;
    assign m_axi_bready  = dma_word_full && dma_wait_b;

    always @* begin
        dma_crc_next = dma_crc ^ {rx_shift, 8'h00};
        for (dma_crc_bit = 0; dma_crc_bit < 8; dma_crc_bit = dma_crc_bit + 1)
            dma_crc_next = dma_crc_next[15]
                ? ((dma_crc_next << 1) ^ 16'h1021)
                : (dma_crc_next << 1);
    end

    always @* begin
        rdata = 32'd0;
        if (hit) begin
            case (addr[5:2])
                4'd0: rdata = 32'h5344_5331;
                4'd1: rdata = {31'd0, sd_cs_n};
                4'd2: rdata = {22'd0, dma_axi_error, dma_crc_error,
                                dma_address_error, dma_error, dma_done,
                                dma_busy, raw_present, card_present,
                                rx_valid, busy};
                4'd3: rdata = {24'd0, rx_data};
                4'd4: rdata = {16'd0, divider};
                4'd5: rdata = {27'd0, sd_detect_n, sd_miso, sd_mosi,
                                sd_clk, sd_cs_n};
                4'd6: rdata = dma_destination;
                4'd7: rdata = 32'd0;
                4'd8: rdata = {26'd0, dma_axi_error, dma_crc_error,
                                dma_address_error, dma_error, dma_done,
                                dma_busy};
                4'd9: rdata = {dma_received_crc, dma_crc};
                4'd10: rdata = {21'd0, dma_bytes_done};
                4'd11: rdata = 32'h0001_0200;
                default: rdata = 32'd0;
            endcase
        end
    end

    always @(posedge clk) begin
        if (!resetn) begin
            detect_meta_n      <= 1'b1;
            detect_sync_n      <= 1'b1;
            detect_debounced_n <= 1'b1;
            detect_count       <= 32'd0;
        end else begin
            detect_meta_n <= sd_detect_n;
            detect_sync_n <= detect_meta_n;

            if (detect_sync_n == detect_debounced_n) begin
                detect_count <= 32'd0;
            end else if (DEBOUNCE_CYCLES <= 1) begin
                detect_debounced_n <= detect_sync_n;
                detect_count <= 32'd0;
            end else if (detect_count >= (DEBOUNCE_CYCLES - 1)) begin
                detect_debounced_n <= detect_sync_n;
                detect_count <= 32'd0;
            end else begin
                detect_count <= detect_count + 1'b1;
            end
        end
    end

    always @(posedge clk) begin
        if (!resetn) begin
            sd_clk        <= 1'b0;
            sd_cs_n       <= 1'b1;
            tx_shift      <= 8'hff;
            rx_shift      <= 8'h00;
            rx_data       <= 8'h00;
            bit_count     <= 3'd0;
            divider       <= RESET_DIV;
            divider_count <= 16'd0;
            busy          <= 1'b0;
            rx_valid      <= 1'b0;
            byte_dma      <= 1'b0;
            dma_destination <= 32'd0;
            dma_word_address <= 32'd0;
            dma_word      <= 32'd0;
            dma_bytes_done <= 11'd0;
            dma_word_bytes <= 2'd0;
            dma_phase     <= 2'd0;
            dma_crc       <= 16'd0;
            dma_received_crc <= 16'd0;
            dma_busy      <= 1'b0;
            dma_done      <= 1'b0;
            dma_error     <= 1'b0;
            dma_address_error <= 1'b0;
            dma_crc_error <= 1'b0;
            dma_axi_error <= 1'b0;
            dma_word_full <= 1'b0;
            dma_aw_sent   <= 1'b0;
            dma_w_sent    <= 1'b0;
            dma_wait_b    <= 1'b0;
        end else begin
            if (wr && hit && (addr[5:2] == 4'd1) && wstrb[0] &&
                !busy && !dma_busy)
                sd_cs_n <= wdata[0];

            if (wr && hit && (addr[5:2] == 4'd4) && wstrb[0] &&
                !busy && !dma_busy)
                divider <= wdata[15:0];

            if (wr && hit && (addr[5:2] == 4'd2) && wstrb[0] && wdata[1])
                rx_valid <= 1'b0;

            if (wr && hit && (addr[5:2] == 4'd6) && wstrb[0] && !dma_busy)
                dma_destination <= wdata;

            if (wr && hit && (addr[5:2] == 4'd7) && wstrb[0] &&
                wdata[1] && !dma_busy) begin
                dma_done          <= 1'b0;
                dma_error         <= 1'b0;
                dma_address_error <= 1'b0;
                dma_crc_error     <= 1'b0;
                dma_axi_error     <= 1'b0;
                dma_bytes_done    <= 11'd0;
                dma_received_crc  <= 16'd0;
            end

            if (wr && hit && (addr[5:2] == 4'd7) && wstrb[0] &&
                wdata[0] && !dma_busy && !busy) begin
                dma_done          <= 1'b0;
                dma_error         <= 1'b0;
                dma_address_error <= 1'b0;
                dma_crc_error     <= 1'b0;
                dma_axi_error     <= 1'b0;
                dma_bytes_done    <= 11'd0;
                dma_word_bytes    <= 2'd0;
                dma_phase         <= 2'd0;
                dma_crc           <= 16'd0;
                dma_received_crc  <= 16'd0;
                dma_word_full     <= 1'b0;
                dma_aw_sent       <= 1'b0;
                dma_w_sent        <= 1'b0;
                dma_wait_b        <= 1'b0;
                if ((dma_destination[1:0] != 2'b00) ||
                    (dma_destination > 32'h1bff_fe00)) begin
                    dma_done          <= 1'b1;
                    dma_error         <= 1'b1;
                    dma_address_error <= 1'b1;
                end else begin
                    dma_busy <= 1'b1;
                end
            end

            if (wr && hit && (addr[5:2] == 4'd3) && wstrb[0] &&
                !busy && !dma_busy) begin
                sd_clk        <= 1'b0;
                tx_shift      <= wdata[7:0];
                rx_shift      <= 8'h00;
                bit_count     <= 3'd0;
                divider_count <= 16'd0;
                busy          <= 1'b1;
                byte_dma      <= 1'b0;
                rx_valid      <= 1'b0;
            end else if (!busy && dma_busy && !dma_word_full) begin
                sd_clk        <= 1'b0;
                tx_shift      <= 8'hff;
                rx_shift      <= 8'h00;
                bit_count     <= 3'd0;
                divider_count <= 16'd0;
                busy          <= 1'b1;
                byte_dma      <= 1'b1;
            end else if (busy) begin
                if (divider_count >= divider) begin
                    divider_count <= 16'd0;
                    if (!sd_clk) begin
                        // SPI mode 0 samples input on the rising edge.
                        sd_clk   <= 1'b1;
                        rx_shift <= {rx_shift[6:0], sd_miso};
                    end else begin
                        // Advance output on the falling edge.  The final
                        // falling edge restores the required idle-low clock.
                        sd_clk <= 1'b0;
                        if (bit_count == 3'd7) begin
                            busy <= 1'b0;
                            if (byte_dma) begin
                                if (dma_phase == 2'd0) begin
                                    dma_crc <= dma_crc_next;
                                    case (dma_word_bytes)
                                        2'd0: dma_word[7:0]   <= rx_shift;
                                        2'd1: dma_word[15:8]  <= rx_shift;
                                        2'd2: dma_word[23:16] <= rx_shift;
                                        2'd3: begin
                                            dma_word[31:24] <= rx_shift;
                                            dma_word_address <= dma_destination +
                                                {dma_bytes_done[10:2], 2'b00};
                                            dma_word_full <= 1'b1;
                                            dma_aw_sent   <= 1'b0;
                                            dma_w_sent    <= 1'b0;
                                            dma_wait_b    <= 1'b0;
                                        end
                                    endcase
                                    dma_word_bytes <= dma_word_bytes + 1'b1;
                                    dma_bytes_done <= dma_bytes_done + 1'b1;
                                    if (dma_bytes_done == 11'd511)
                                        dma_phase <= 2'd1;
                                end else if (dma_phase == 2'd1) begin
                                    dma_received_crc[15:8] <= rx_shift;
                                    dma_phase <= 2'd2;
                                end else begin
                                    dma_received_crc[7:0] <= rx_shift;
                                    dma_busy <= 1'b0;
                                    dma_done <= 1'b1;
                                    if ({dma_received_crc[15:8], rx_shift} != dma_crc) begin
                                        dma_error     <= 1'b1;
                                        dma_crc_error <= 1'b1;
                                    end
                                    dma_phase <= 2'd3;
                                end
                            end else begin
                                rx_data  <= rx_shift;
                                rx_valid <= 1'b1;
                            end
                            byte_dma <= 1'b0;
                        end else begin
                            bit_count <= bit_count + 1'b1;
                            tx_shift  <= {tx_shift[6:0], 1'b1};
                        end
                    end
                end else begin
                    divider_count <= divider_count + 1'b1;
                end
            end

            if (dma_word_full) begin
                if (!dma_aw_sent && m_axi_awready)
                    dma_aw_sent <= 1'b1;
                if (!dma_w_sent && m_axi_wready)
                    dma_w_sent <= 1'b1;
                if ((dma_aw_sent || m_axi_awready) &&
                    (dma_w_sent || m_axi_wready))
                    dma_wait_b <= 1'b1;
                if (dma_wait_b && m_axi_bvalid) begin
                    dma_word_full <= 1'b0;
                    dma_aw_sent   <= 1'b0;
                    dma_w_sent    <= 1'b0;
                    dma_wait_b    <= 1'b0;
                    if (m_axi_bresp != 2'b00) begin
                        dma_busy      <= 1'b0;
                        dma_done      <= 1'b1;
                        dma_error     <= 1'b1;
                        dma_axi_error <= 1'b1;
                    end
                end
            end

            if (dma_busy && !card_present) begin
                dma_busy  <= 1'b0;
                dma_done  <= 1'b1;
                dma_error <= 1'b1;
            end
        end
    end
endmodule
