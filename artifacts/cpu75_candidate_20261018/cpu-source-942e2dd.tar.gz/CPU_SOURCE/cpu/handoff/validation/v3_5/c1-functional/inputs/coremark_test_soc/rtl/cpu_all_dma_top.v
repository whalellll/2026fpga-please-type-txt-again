`timescale 1ns/1ps

// RV32IMA CPU with native SD, memory-copy, video-read, and camera-write DMA.
// The output is the Pango 256-bit native DDR protocol; connect it to the
// board DDR controller. The pixel, DDR and CPU clocks may be independent.
module cpu_all_dma_top #(
    parameter [31:0] RESET_VECTOR = 32'h1c00_0000,
    parameter [15:0] SD_RESET_DIV = 16'd124,
    parameter integer SD_DEBOUNCE_CYCLES = 247500
)(
    input wire aclk, input wire aresetn,
    input wire [31:0] external_interrupts,
    input wire ddr_clk, input wire ddr_resetn, input wire ddr_init_done,
    input wire pix_clk, input wire pix_resetn,
    input wire camera_pixel_clk, input wire camera_pixel_resetn,
    input wire camera_pixel_vsync, input wire camera_pixel_line_active,
    input wire camera_pixel_valid, input wire [15:0] camera_pixel_rgb565,
    input wire cmos1_init_done, input wire cmos2_init_done,
    input wire sccb_nack,
    output wire camera_sensor_enable,
    output wire dma_irq,
    output wire sd_clk, inout wire sd_cmd,
    inout wire sd_data0, inout wire sd_data1,
    inout wire sd_data2, inout wire sd_data3,
    input wire sd_detect_n,
    output wire vs_out, output wire hs_out, output wire de_out,
    output wire [7:0] r_out, output wire [7:0] g_out, output wire [7:0] b_out,
    output wire [27:0] ddr_awaddr, output wire ddr_awuser_ap,
    output wire [3:0] ddr_awid, output wire [3:0] ddr_awlen,
    output wire ddr_awvalid, input wire ddr_awready,
    output wire [255:0] ddr_wdata, output wire [31:0] ddr_wstrb,
    input wire ddr_wready, input wire [3:0] ddr_wusero_id,
    input wire ddr_wusero_last,
    output wire [27:0] ddr_araddr, output wire ddr_aruser_ap,
    output wire [3:0] ddr_arid, output wire [3:0] ddr_arlen,
    output wire ddr_arvalid, input wire ddr_arready,
    input wire [255:0] ddr_rdata, input wire [3:0] ddr_rid,
    input wire ddr_rlast, input wire ddr_rvalid
);
    wire [31:0] cpu_external_interrupts =
        external_interrupts | {31'd0, dma_irq};

    wire [3:0] x_arid;
    wire [31:0] x_araddr;
    wire [7:0] x_arlen;
    wire [2:0] x_arsize;
    wire [1:0] x_arburst;
    wire [1:0] x_arlock;
    wire [3:0] x_arcache;
    wire [2:0] x_arprot;
    wire x_arvalid;
    wire x_arready;
    wire [3:0] x_rid;
    wire [31:0] x_rdata;
    wire [1:0] x_rresp;
    wire x_rlast;
    wire x_rvalid;
    wire x_rready;
    wire [3:0] x_awid;
    wire [31:0] x_awaddr;
    wire [7:0] x_awlen;
    wire [2:0] x_awsize;
    wire [1:0] x_awburst;
    wire [1:0] x_awlock;
    wire [3:0] x_awcache;
    wire [2:0] x_awprot;
    wire x_awvalid;
    wire x_awready;
    wire [3:0] x_wid;
    wire [31:0] x_wdata;
    wire [3:0] x_wstrb;
    wire x_wlast;
    wire x_wvalid;
    wire x_wready;
    wire [3:0] x_bid;
    wire [1:0] x_bresp;
    wire x_bvalid;
    wire x_bready;
    wire [3:0] d_arid;
    wire [31:0] d_araddr;
    wire [7:0] d_arlen;
    wire [2:0] d_arsize;
    wire [1:0] d_arburst;
    wire d_arvalid;
    wire d_arready;
    wire [3:0] d_rid;
    wire [31:0] d_rdata;
    wire [1:0] d_rresp;
    wire d_rlast;
    wire d_rvalid;
    wire d_rready;
    wire [3:0] d_awid;
    wire [31:0] d_awaddr;
    wire [7:0] d_awlen;
    wire [2:0] d_awsize;
    wire [1:0] d_awburst;
    wire d_awvalid;
    wire d_awready;
    wire [3:0] d_wid;
    wire [31:0] d_wdata;
    wire [3:0] d_wstrb;
    wire d_wlast;
    wire d_wvalid;
    wire d_wready;
    wire [3:0] d_bid;
    wire [1:0] d_bresp;
    wire d_bvalid;
    wire d_bready;
    wire [3:0] l_arid;
    wire [31:0] l_araddr;
    wire [7:0] l_arlen;
    wire [2:0] l_arsize;
    wire [1:0] l_arburst;
    wire l_arvalid;
    wire l_arready;
    wire [3:0] l_rid;
    wire [31:0] l_rdata;
    wire [1:0] l_rresp;
    wire l_rlast;
    wire l_rvalid;
    wire l_rready;
    wire [3:0] l_awid;
    wire [31:0] l_awaddr;
    wire [7:0] l_awlen;
    wire [2:0] l_awsize;
    wire [1:0] l_awburst;
    wire l_awvalid;
    wire l_awready;
    wire [3:0] l_wid;
    wire [31:0] l_wdata;
    wire [3:0] l_wstrb;
    wire l_wlast;
    wire l_wvalid;
    wire l_wready;
    wire [3:0] l_bid;
    wire [1:0] l_bresp;
    wire l_bvalid;
    wire l_bready;
    wire [3:0] a_arid;
    wire [31:0] a_araddr;
    wire [7:0] a_arlen;
    wire [2:0] a_arsize;
    wire [1:0] a_arburst;
    wire a_arvalid;
    wire a_arready;
    wire [3:0] a_rid;
    wire [31:0] a_rdata;
    wire [1:0] a_rresp;
    wire a_rlast;
    wire a_rvalid;
    wire a_rready;
    wire [3:0] a_awid;
    wire [31:0] a_awaddr;
    wire [7:0] a_awlen;
    wire [2:0] a_awsize;
    wire [1:0] a_awburst;
    wire a_awvalid;
    wire a_awready;
    wire [3:0] a_wid;
    wire [31:0] a_wdata;
    wire [3:0] a_wstrb;
    wire a_wlast;
    wire a_wvalid;
    wire a_wready;
    wire [3:0] a_bid;
    wire [1:0] a_bresp;
    wire a_bvalid;
    wire a_bready;

    cpu_sd_dma_top #(.RESET_VECTOR(RESET_VECTOR),
        .SD_RESET_DIV(SD_RESET_DIV),
        .SD_DEBOUNCE_CYCLES(SD_DEBOUNCE_CYCLES)) u_cpu_sd (
        .aclk(aclk), .aresetn(aresetn),
        .external_interrupts(cpu_external_interrupts),
        .sd_clk(sd_clk), .sd_cmd(sd_cmd),
        .sd_data0(sd_data0), .sd_data1(sd_data1),
        .sd_data2(sd_data2), .sd_data3(sd_data3),
        .sd_detect_n(sd_detect_n),
        .arid(x_arid),
        .araddr(x_araddr),
        .arlen(x_arlen),
        .arsize(x_arsize),
        .arburst(x_arburst),
        .arlock(x_arlock),
        .arcache(x_arcache),
        .arprot(x_arprot),
        .arvalid(x_arvalid),
        .arready(x_arready),
        .rid(x_rid),
        .rdata(x_rdata),
        .rresp(x_rresp),
        .rlast(x_rlast),
        .rvalid(x_rvalid),
        .rready(x_rready),
        .awid(x_awid),
        .awaddr(x_awaddr),
        .awlen(x_awlen),
        .awsize(x_awsize),
        .awburst(x_awburst),
        .awlock(x_awlock),
        .awcache(x_awcache),
        .awprot(x_awprot),
        .awvalid(x_awvalid),
        .awready(x_awready),
        .wid(x_wid),
        .wdata(x_wdata),
        .wstrb(x_wstrb),
        .wlast(x_wlast),
        .wvalid(x_wvalid),
        .wready(x_wready),
        .bid(x_bid),
        .bresp(x_bresp),
        .bvalid(x_bvalid),
        .bready(x_bready)
    );

    axi_1x2_dma u_dma_split (
        .clk(aclk), .resetn(aresetn),
        .s_arid(x_arid),
        .s_araddr(x_araddr),
        .s_arlen(x_arlen),
        .s_arsize(x_arsize),
        .s_arburst(x_arburst),
        .s_arlock(x_arlock),
        .s_arcache(x_arcache),
        .s_arprot(x_arprot),
        .s_arvalid(x_arvalid),
        .s_arready(x_arready),
        .s_rid(x_rid),
        .s_rdata(x_rdata),
        .s_rresp(x_rresp),
        .s_rlast(x_rlast),
        .s_rvalid(x_rvalid),
        .s_rready(x_rready),
        .s_awid(x_awid),
        .s_awaddr(x_awaddr),
        .s_awlen(x_awlen),
        .s_awsize(x_awsize),
        .s_awburst(x_awburst),
        .s_awlock(x_awlock),
        .s_awcache(x_awcache),
        .s_awprot(x_awprot),
        .s_awvalid(x_awvalid),
        .s_awready(x_awready),
        .s_wid(x_wid),
        .s_wdata(x_wdata),
        .s_wstrb(x_wstrb),
        .s_wlast(x_wlast),
        .s_wvalid(x_wvalid),
        .s_wready(x_wready),
        .s_bid(x_bid),
        .s_bresp(x_bresp),
        .s_bvalid(x_bvalid),
        .s_bready(x_bready),
        .m0_arid(d_arid),
        .m0_araddr(d_araddr),
        .m0_arlen(d_arlen),
        .m0_arsize(d_arsize),
        .m0_arburst(d_arburst),
        .m0_arvalid(d_arvalid),
        .m0_arready(d_arready),
        .m0_rid(d_rid),
        .m0_rdata(d_rdata),
        .m0_rresp(d_rresp),
        .m0_rlast(d_rlast),
        .m0_rvalid(d_rvalid),
        .m0_rready(d_rready),
        .m0_awid(d_awid),
        .m0_awaddr(d_awaddr),
        .m0_awlen(d_awlen),
        .m0_awsize(d_awsize),
        .m0_awburst(d_awburst),
        .m0_awvalid(d_awvalid),
        .m0_awready(d_awready),
        .m0_wid(d_wid),
        .m0_wdata(d_wdata),
        .m0_wstrb(d_wstrb),
        .m0_wlast(d_wlast),
        .m0_wvalid(d_wvalid),
        .m0_wready(d_wready),
        .m0_bid(d_bid),
        .m0_bresp(d_bresp),
        .m0_bvalid(d_bvalid),
        .m0_bready(d_bready),
        .m1_arid(l_arid),
        .m1_araddr(l_araddr),
        .m1_arlen(l_arlen),
        .m1_arsize(l_arsize),
        .m1_arburst(l_arburst),
        .m1_arvalid(l_arvalid),
        .m1_arready(l_arready),
        .m1_rid(l_rid),
        .m1_rdata(l_rdata),
        .m1_rresp(l_rresp),
        .m1_rlast(l_rlast),
        .m1_rvalid(l_rvalid),
        .m1_rready(l_rready),
        .m1_awid(l_awid),
        .m1_awaddr(l_awaddr),
        .m1_awlen(l_awlen),
        .m1_awsize(l_awsize),
        .m1_awburst(l_awburst),
        .m1_awvalid(l_awvalid),
        .m1_awready(l_awready),
        .m1_wid(l_wid),
        .m1_wdata(l_wdata),
        .m1_wstrb(l_wstrb),
        .m1_wlast(l_wlast),
        .m1_wvalid(l_wvalid),
        .m1_wready(l_wready),
        .m1_bid(l_bid),
        .m1_bresp(l_bresp),
        .m1_bvalid(l_bvalid),
        .m1_bready(l_bready)
    );

    wire [31:0] mmio_addr, mmio_wdata, mmio_rdata;
    wire [3:0] mmio_wstrb;
    wire mmio_wr, mmio_hit;
    dma_axi_mmio u_dma_regs (
        .clk(aclk), .resetn(aresetn),
        .arid(l_arid),
        .araddr(l_araddr),
        .arlen(l_arlen),
        .arsize(l_arsize),
        .arburst(l_arburst),
        .arvalid(l_arvalid),
        .arready(l_arready),
        .rid(l_rid),
        .rdata(l_rdata),
        .rresp(l_rresp),
        .rlast(l_rlast),
        .rvalid(l_rvalid),
        .rready(l_rready),
        .awid(l_awid),
        .awaddr(l_awaddr),
        .awlen(l_awlen),
        .awsize(l_awsize),
        .awburst(l_awburst),
        .awvalid(l_awvalid),
        .awready(l_awready),
        .wid(l_wid),
        .wdata(l_wdata),
        .wstrb(l_wstrb),
        .wlast(l_wlast),
        .wvalid(l_wvalid),
        .wready(l_wready),
        .bid(l_bid),
        .bresp(l_bresp),
        .bvalid(l_bvalid),
        .bready(l_bready),
        .mmio_addr(mmio_addr), .mmio_wr(mmio_wr),
        .mmio_wdata(mmio_wdata), .mmio_wstrb(mmio_wstrb),
        .mmio_rdata(mmio_rdata), .mmio_hit(mmio_hit)
    );

    wire copy_hit = mmio_addr >= 32'h1fe1_0000 &&
                   mmio_addr < 32'h1fe1_0100;
    wire [31:0] copy_reg_rdata, fb_reg_rdata, camera_reg_rdata;
    wire fb_hit, camera_hit;
    assign mmio_hit = copy_hit || fb_hit || camera_hit;
    assign mmio_rdata = copy_hit ? copy_reg_rdata :
                        fb_hit ? fb_reg_rdata : camera_reg_rdata;

    wire [31:0] copy_araddr, copy_awaddr, copy_wdata, copy_rdata;
    wire [7:0] copy_arlen, copy_awlen;
    wire [2:0] copy_arsize, copy_awsize;
    wire [1:0] copy_arburst, copy_awburst, copy_rresp, copy_bresp;
    wire [3:0] copy_wstrb;
    wire copy_arvalid, copy_arready, copy_rvalid, copy_rready, copy_rlast;
    wire copy_awvalid, copy_awready, copy_wvalid, copy_wready, copy_wlast;
    wire copy_bvalid, copy_bready;
    memcpy_dma_top #(
        .DDR_BASE(32'h1b00_0000), .DDR_BYTES(1024*1024)
    ) u_copy_dma (
        .clk(aclk), .resetn(aresetn),
        .reg_wr_en(mmio_wr && copy_hit),
        .reg_wr_addr(mmio_addr[7:0]), .reg_wr_data(mmio_wdata),
        .reg_wr_strb(mmio_wstrb), .reg_rd_addr(mmio_addr[7:0]),
        .reg_rd_data(copy_reg_rdata), .irq(dma_irq),
        .m_axi_araddr(copy_araddr),
        .m_axi_arlen(copy_arlen),
        .m_axi_arsize(copy_arsize),
        .m_axi_arburst(copy_arburst),
        .m_axi_arvalid(copy_arvalid),
        .m_axi_arready(copy_arready),
        .m_axi_rdata(copy_rdata),
        .m_axi_rresp(copy_rresp),
        .m_axi_rlast(copy_rlast),
        .m_axi_rvalid(copy_rvalid),
        .m_axi_rready(copy_rready),
        .m_axi_awaddr(copy_awaddr),
        .m_axi_awlen(copy_awlen),
        .m_axi_awsize(copy_awsize),
        .m_axi_awburst(copy_awburst),
        .m_axi_awvalid(copy_awvalid),
        .m_axi_awready(copy_awready),
        .m_axi_wdata(copy_wdata),
        .m_axi_wstrb(copy_wstrb),
        .m_axi_wlast(copy_wlast),
        .m_axi_wvalid(copy_wvalid),
        .m_axi_wready(copy_wready),
        .m_axi_bresp(copy_bresp),
        .m_axi_bvalid(copy_bvalid),
        .m_axi_bready(copy_bready)
    );

    axi_2x1_arbiter #(.MASTER1_ID(4'hf)) u_copy_arbiter (
        .clk(aclk), .resetn(aresetn),
        .s0_arid(d_arid),
        .s0_araddr(d_araddr),
        .s0_arlen(d_arlen),
        .s0_arsize(d_arsize),
        .s0_arburst(d_arburst),
        .s0_arvalid(d_arvalid),
        .s0_arready(d_arready),
        .s0_rid(d_rid),
        .s0_rdata(d_rdata),
        .s0_rresp(d_rresp),
        .s0_rlast(d_rlast),
        .s0_rvalid(d_rvalid),
        .s0_rready(d_rready),
        .s0_awid(d_awid),
        .s0_awaddr(d_awaddr),
        .s0_awlen(d_awlen),
        .s0_awsize(d_awsize),
        .s0_awburst(d_awburst),
        .s0_awvalid(d_awvalid),
        .s0_awready(d_awready),
        .s0_wid(d_wid),
        .s0_wdata(d_wdata),
        .s0_wstrb(d_wstrb),
        .s0_wlast(d_wlast),
        .s0_wvalid(d_wvalid),
        .s0_wready(d_wready),
        .s0_bid(d_bid),
        .s0_bresp(d_bresp),
        .s0_bvalid(d_bvalid),
        .s0_bready(d_bready),
        .s1_araddr(copy_araddr),
        .s1_arlen(copy_arlen),
        .s1_arsize(copy_arsize),
        .s1_arburst(copy_arburst),
        .s1_arvalid(copy_arvalid),
        .s1_arready(copy_arready),
        .s1_rdata(copy_rdata),
        .s1_rresp(copy_rresp),
        .s1_rlast(copy_rlast),
        .s1_rvalid(copy_rvalid),
        .s1_rready(copy_rready),
        .s1_awaddr(copy_awaddr),
        .s1_awlen(copy_awlen),
        .s1_awsize(copy_awsize),
        .s1_awburst(copy_awburst),
        .s1_awvalid(copy_awvalid),
        .s1_awready(copy_awready),
        .s1_wdata(copy_wdata),
        .s1_wstrb(copy_wstrb),
        .s1_wlast(copy_wlast),
        .s1_wvalid(copy_wvalid),
        .s1_wready(copy_wready),
        .s1_bresp(copy_bresp),
        .s1_bvalid(copy_bvalid),
        .s1_bready(copy_bready),
        .m_arid(a_arid),
        .m_araddr(a_araddr),
        .m_arlen(a_arlen),
        .m_arsize(a_arsize),
        .m_arburst(a_arburst),
        .m_arvalid(a_arvalid),
        .m_arready(a_arready),
        .m_rid(a_rid),
        .m_rdata(a_rdata),
        .m_rresp(a_rresp),
        .m_rlast(a_rlast),
        .m_rvalid(a_rvalid),
        .m_rready(a_rready),
        .m_awid(a_awid),
        .m_awaddr(a_awaddr),
        .m_awlen(a_awlen),
        .m_awsize(a_awsize),
        .m_awburst(a_awburst),
        .m_awvalid(a_awvalid),
        .m_awready(a_awready),
        .m_wid(a_wid),
        .m_wdata(a_wdata),
        .m_wstrb(a_wstrb),
        .m_wlast(a_wlast),
        .m_wvalid(a_wvalid),
        .m_wready(a_wready),
        .m_bid(a_bid),
        .m_bresp(a_bresp),
        .m_bvalid(a_bvalid),
        .m_bready(a_bready)
    );

    wire [27:0] bridge_araddr;
    wire bridge_aruser_ap;
    wire [3:0] bridge_arid;
    wire [3:0] bridge_arlen;
    wire bridge_arvalid;
    wire bridge_arready;
    wire [255:0] bridge_rdata;
    wire [3:0] bridge_rid;
    wire bridge_rlast;
    wire bridge_rvalid;
    wire [27:0] bridge_awaddr;
    wire bridge_awuser_ap;
    wire [3:0] bridge_awid;
    wire [3:0] bridge_awlen;
    wire bridge_awvalid;
    wire bridge_awready;
    wire [255:0] bridge_wdata;
    wire [31:0] bridge_wstrb;
    wire bridge_wready;
    wire [3:0] bridge_wusero_id;
    wire bridge_wusero_last;

    axi_ddr_cdc u_bridge (
        .cpu_clk(aclk), .cpu_resetn(aresetn),
        .s_arid(a_arid),
        .s_araddr(a_araddr),
        .s_arlen(a_arlen),
        .s_arsize(a_arsize),
        .s_arburst(a_arburst),
        .s_arvalid(a_arvalid),
        .s_arready(a_arready),
        .s_rid(a_rid),
        .s_rdata(a_rdata),
        .s_rresp(a_rresp),
        .s_rlast(a_rlast),
        .s_rvalid(a_rvalid),
        .s_rready(a_rready),
        .s_awid(a_awid),
        .s_awaddr(a_awaddr),
        .s_awlen(a_awlen),
        .s_awsize(a_awsize),
        .s_awburst(a_awburst),
        .s_awvalid(a_awvalid),
        .s_awready(a_awready),
        .s_wid(a_wid),
        .s_wdata(a_wdata),
        .s_wstrb(a_wstrb),
        .s_wlast(a_wlast),
        .s_wvalid(a_wvalid),
        .s_wready(a_wready),
        .s_bid(a_bid),
        .s_bresp(a_bresp),
        .s_bvalid(a_bvalid),
        .s_bready(a_bready),
        .ddr_clk(ddr_clk), .ddr_resetn(ddr_resetn),
        .ddr_init_done(ddr_init_done),
        .m_araddr(bridge_araddr),
        .m_aruser_ap(bridge_aruser_ap),
        .m_aruser_id(bridge_arid),
        .m_arlen(bridge_arlen),
        .m_arvalid(bridge_arvalid),
        .m_arready(bridge_arready),
        .m_rdata(bridge_rdata),
        .m_rid(bridge_rid),
        .m_rlast(bridge_rlast),
        .m_rvalid(bridge_rvalid),
        .m_awaddr(bridge_awaddr),
        .m_awuser_ap(bridge_awuser_ap),
        .m_awuser_id(bridge_awid),
        .m_awlen(bridge_awlen),
        .m_awvalid(bridge_awvalid),
        .m_awready(bridge_awready),
        .m_wdata(bridge_wdata),
        .m_wstrb(bridge_wstrb),
        .m_wready(bridge_wready),
        .m_wusero_id(bridge_wusero_id),
        .m_wusero_last(bridge_wusero_last)
    );

    // CPU-visible controls. The source design's camera and video DDR engines
    // keep their separate clock domains and communicate through stable
    // mailbox payloads inside the imported modules.
    wire fb_enable_sys, fb_requested_buffer_sys;
    wire fb_clear_underflow_toggle_sys;
    wire fb_active_enable_pix, fb_active_buffer_pix, fb_underflow_pix;
    wire [31:0] fb_frame_count_pix, fb_underflow_count_pix;
    wire fb_dma_busy_ddr, fb_dma_error_ddr;
    wire camera_enable_cpu, camera_stop_cpu;
    wire camera_frame_valid_ddr, camera_published_buffer_ddr;
    wire camera_buffer_idle_ddr, camera_stopping_ddr;
    wire camera_frame_accept_ddr, camera_write_buffer_ddr;
    wire camera_writer_started_ddr, camera_writer_complete_ddr;
    wire camera_writer_completed_buffer_ddr, camera_writer_busy_ddr;
    wire camera_writer_idle_ddr, camera_writer_ddr_error_ddr;
    wire [31:0] camera_frame_count_ddr, camera_dropped_count_ddr;
    wire [31:0] camera_bad_line_count_ddr;
    wire camera_frame_error_ddr =
        (camera_bad_line_count_ddr != 32'd0) ||
        (camera_dropped_count_ddr != 32'd0);
    reg [1:0] camera_enable_sync, camera_stop_sync;
    reg [1:0] display_enable_sync, display_buffer_sync;
    always @(posedge ddr_clk or negedge ddr_resetn) begin
        if (!ddr_resetn) begin
            camera_enable_sync <= 2'b00;
            camera_stop_sync <= 2'b00;
            display_enable_sync <= 2'b00;
            display_buffer_sync <= 2'b00;
        end else begin
            camera_enable_sync <= {camera_enable_sync[0], camera_enable_cpu};
            camera_stop_sync <= {camera_stop_sync[0], camera_stop_cpu};
            display_enable_sync <= {display_enable_sync[0], fb_active_enable_pix};
            display_buffer_sync <= {display_buffer_sync[0], fb_active_buffer_pix};
        end
    end
    camera_buffer_control u_camera_buffers (
        .clk(ddr_clk), .resetn(ddr_resetn),
        .control_enable(camera_enable_sync[1]),
        .stop_request(camera_stop_sync[1]),
        .writer_started(camera_writer_started_ddr),
        .writer_complete(camera_writer_complete_ddr),
        .writer_completed_buffer(camera_writer_completed_buffer_ddr),
        .writer_idle(camera_writer_idle_ddr),
        .display_enable(display_enable_sync[1]),
        .display_buffer(display_buffer_sync[1]),
        .sensor_enable(camera_sensor_enable),
        .frame_accept_enable(camera_frame_accept_ddr),
        .write_buffer(camera_write_buffer_ddr),
        .frame_valid(camera_frame_valid_ddr),
        .published_buffer(camera_published_buffer_ddr),
        .idle(camera_buffer_idle_ddr),
        .stopping(camera_stopping_ddr),
        .frame_count(camera_frame_count_ddr)
    );

    // Synchronize the DDR-domain status before software reads it.
    wire [6:0] camera_status_ddr = {
        camera_writer_ddr_error_ddr, camera_frame_error_ddr,
        camera_published_buffer_ddr, camera_stopping_ddr,
        camera_buffer_idle_ddr, camera_writer_busy_ddr,
        camera_frame_valid_ddr
    };
    reg [6:0] camera_status_c1, camera_status_cpu;
    reg [31:0] camera_frame_count_c1, camera_frame_count_cpu;
    reg [31:0] camera_dropped_count_c1, camera_dropped_count_cpu;
    reg [31:0] camera_bad_line_count_c1, camera_bad_line_count_cpu;
    reg [1:0] cmos1_init_sync, cmos2_init_sync, sccb_nack_sync;
    always @(posedge aclk or negedge aresetn) begin
        if (!aresetn) begin
            camera_status_c1 <= 7'd0;
            camera_status_cpu <= 7'd0;
            camera_frame_count_c1 <= 32'd0;
            camera_frame_count_cpu <= 32'd0;
            camera_dropped_count_c1 <= 32'd0;
            camera_dropped_count_cpu <= 32'd0;
            camera_bad_line_count_c1 <= 32'd0;
            camera_bad_line_count_cpu <= 32'd0;
            cmos1_init_sync <= 2'b00;
            cmos2_init_sync <= 2'b00;
            sccb_nack_sync <= 2'b00;
        end else begin
            camera_status_c1 <= camera_status_ddr;
            camera_status_cpu <= camera_status_c1;
            camera_frame_count_c1 <= camera_frame_count_ddr;
            camera_frame_count_cpu <= camera_frame_count_c1;
            camera_dropped_count_c1 <= camera_dropped_count_ddr;
            camera_dropped_count_cpu <= camera_dropped_count_c1;
            camera_bad_line_count_c1 <= camera_bad_line_count_ddr;
            camera_bad_line_count_cpu <= camera_bad_line_count_c1;
            cmos1_init_sync <= {cmos1_init_sync[0], cmos1_init_done};
            cmos2_init_sync <= {cmos2_init_sync[0], cmos2_init_done};
            sccb_nack_sync <= {sccb_nack_sync[0], sccb_nack};
        end
    end
    camera_mmio u_camera_regs (
        .clk(aclk), .resetn(aresetn),
        .addr(mmio_addr), .wr(mmio_wr),
        .wdata(mmio_wdata), .wstrb(mmio_wstrb),
        .rdata(camera_reg_rdata), .hit(camera_hit),
        .enable(camera_enable_cpu), .stop_request(camera_stop_cpu),
        .cmos1_init_done(cmos1_init_sync[1]),
        .cmos2_init_done(cmos2_init_sync[1]),
        .frame_valid(camera_status_cpu[0]),
        .writer_busy(camera_status_cpu[1]),
        .idle(camera_status_cpu[2]),
        .stopping(camera_status_cpu[3]),
        .completed_buffer(camera_status_cpu[4]),
        .sccb_nack(sccb_nack_sync[1]),
        .frame_error(camera_status_cpu[5]),
        .ddr_error(camera_status_cpu[6]),
        .frame_count(camera_frame_count_cpu),
        .dropped_count(camera_dropped_count_cpu),
        .bad_line_count(camera_bad_line_count_cpu)
    );

    // Camera publication takes priority over a software-requested FB page.
    wire camera_scanout_enable_sys =
        camera_enable_cpu && camera_status_cpu[0];
    wire fb_dma_enable_sys =
        camera_scanout_enable_sys ? 1'b1 : fb_enable_sys;
    wire fb_dma_requested_buffer_sys =
        camera_scanout_enable_sys ? camera_status_cpu[4] :
                                    fb_requested_buffer_sys;
    video_fb_mmio u_fb_regs (
        .clk(aclk), .resetn(aresetn),
        .addr(mmio_addr), .wr(mmio_wr),
        .wdata(mmio_wdata), .wstrb(mmio_wstrb),
        .rdata(fb_reg_rdata), .hit(fb_hit),
        .enable(fb_enable_sys),
        .requested_buffer(fb_requested_buffer_sys),
        .clear_underflow_toggle(fb_clear_underflow_toggle_sys),
        .active_enable_pix(fb_active_enable_pix),
        .active_buffer_pix(fb_active_buffer_pix),
        .underflow_pix(fb_underflow_pix),
        .frame_count_pix(fb_frame_count_pix),
        .underflow_count_pix(fb_underflow_count_pix),
        .dma_busy_ddr(fb_dma_busy_ddr),
        .dma_error_ddr(fb_dma_error_ddr)
    );

    wire [27:0] fb_araddr;
    wire [3:0] fb_arid, fb_arlen, fb_rid;
    wire fb_arvalid, fb_urgent, fb_arready;
    wire [255:0] fb_rdata;
    wire fb_rlast, fb_rvalid;
    video_fb_dma u_video_dma (
        .sys_enable(fb_dma_enable_sys),
        .sys_requested_buffer(fb_dma_requested_buffer_sys),
        .sys_clear_underflow_toggle(fb_clear_underflow_toggle_sys),
        .ddr_clk(ddr_clk), .ddr_resetn(ddr_resetn),
        .ddr_init_done(ddr_init_done),
        .fb_araddr(fb_araddr), .fb_arid(fb_arid),
        .fb_arlen(fb_arlen), .fb_arvalid(fb_arvalid),
        .fb_urgent(fb_urgent), .fb_arready(fb_arready),
        .fb_rdata(fb_rdata), .fb_rid(fb_rid),
        .fb_rlast(fb_rlast), .fb_rvalid(fb_rvalid),
        .dma_busy_ddr(fb_dma_busy_ddr),
        .dma_error_ddr(fb_dma_error_ddr),
        .pix_clk(pix_clk), .pix_resetn(pix_resetn),
        .active_enable_pix(fb_active_enable_pix),
        .active_buffer_pix(fb_active_buffer_pix),
        .underflow_pix(fb_underflow_pix),
        .frame_count_pix(fb_frame_count_pix),
        .underflow_count_pix(fb_underflow_count_pix),
        .vs_out(vs_out), .hs_out(hs_out), .de_out(de_out),
        .r_out(r_out), .g_out(g_out), .b_out(b_out)
    );

    wire [27:0] cam_awaddr;
    wire [3:0] cam_awid, cam_awlen, cam_wid;
    wire cam_awvalid, cam_awready, cam_wready, cam_wlast;
    wire cam_urgent;
    wire [255:0] cam_wdata;
    wire [31:0] cam_wstrb;
    camera_frame_writer u_camera_dma (
        .pixel_clk(camera_pixel_clk),
        .pixel_resetn(camera_pixel_resetn),
        .pixel_vsync(camera_pixel_vsync),
        .pixel_line_active(camera_pixel_line_active),
        .pixel_valid(camera_pixel_valid),
        .pixel_rgb565(camera_pixel_rgb565),
        .ddr_clk(ddr_clk), .ddr_resetn(ddr_resetn),
        .enable(camera_sensor_enable),
        .frame_accept_enable(camera_frame_accept_ddr),
        .write_buffer(camera_write_buffer_ddr),
        .stop_request(camera_stop_sync[1]),
        .cam_awaddr(cam_awaddr), .cam_awid(cam_awid),
        .cam_awlen(cam_awlen), .cam_awvalid(cam_awvalid),
        .cam_awready(cam_awready), .cam_wdata(cam_wdata),
        .cam_wstrb(cam_wstrb), .cam_wready(cam_wready),
        .cam_wid(cam_wid), .cam_wlast(cam_wlast),
        .cam_urgent(cam_urgent),
        .frame_started(camera_writer_started_ddr),
        .frame_complete(camera_writer_complete_ddr),
        .completed_buffer(camera_writer_completed_buffer_ddr),
        .busy(camera_writer_busy_ddr),
        .idle(camera_writer_idle_ddr),
        .bad_line_count(camera_bad_line_count_ddr),
        .drop_frame_count(camera_dropped_count_ddr),
        .ddr_error(camera_writer_ddr_error_ddr)
    );

    ddr_native_read_arbiter u_native_reads (
        .clk(ddr_clk), .resetn(ddr_resetn),
        .s0_araddr(bridge_araddr),
        .s0_aruser_ap(bridge_aruser_ap),
        .s0_arid(bridge_arid), .s0_arlen(bridge_arlen),
        .s0_arvalid(bridge_arvalid), .s0_arready(bridge_arready),
        .s0_rdata(bridge_rdata), .s0_rid(bridge_rid),
        .s0_rlast(bridge_rlast), .s0_rvalid(bridge_rvalid),
        .s1_araddr(fb_araddr), .s1_arid(fb_arid),
        .s1_arlen(fb_arlen), .s1_arvalid(fb_arvalid),
        .s1_urgent(fb_urgent), .s1_arready(fb_arready),
        .s1_rdata(fb_rdata), .s1_rid(fb_rid),
        .s1_rlast(fb_rlast), .s1_rvalid(fb_rvalid),
        .m_araddr(ddr_araddr), .m_aruser_ap(ddr_aruser_ap),
        .m_arid(ddr_arid), .m_arlen(ddr_arlen),
        .m_arvalid(ddr_arvalid), .m_arready(ddr_arready),
        .m_rdata(ddr_rdata), .m_rid(ddr_rid),
        .m_rlast(ddr_rlast), .m_rvalid(ddr_rvalid)
    );

    ddr_native_write_arbiter u_native_writes (
        .clk(ddr_clk), .resetn(ddr_resetn),
        .s0_awaddr(bridge_awaddr),
        .s0_awuser_ap(bridge_awuser_ap),
        .s0_awid(bridge_awid), .s0_awlen(bridge_awlen),
        .s0_awvalid(bridge_awvalid), .s0_awready(bridge_awready),
        .s0_wdata(bridge_wdata), .s0_wstrb(bridge_wstrb),
        .s0_wready(bridge_wready),
        .s0_wusero_id(bridge_wusero_id),
        .s0_wusero_last(bridge_wusero_last),
        .s1_awaddr(cam_awaddr), .s1_awid(cam_awid),
        .s1_awlen(cam_awlen), .s1_awvalid(cam_awvalid),
        .s1_urgent(cam_urgent), .s1_awready(cam_awready),
        .s1_wdata(cam_wdata), .s1_wstrb(cam_wstrb),
        .s1_wready(cam_wready),
        .s1_wusero_id(cam_wid), .s1_wusero_last(cam_wlast),
        .m_awaddr(ddr_awaddr), .m_awuser_ap(ddr_awuser_ap),
        .m_awid(ddr_awid), .m_awlen(ddr_awlen),
        .m_awvalid(ddr_awvalid), .m_awready(ddr_awready),
        .m_wdata(ddr_wdata), .m_wstrb(ddr_wstrb),
        .m_wready(ddr_wready),
        .m_wusero_id(ddr_wusero_id),
        .m_wusero_last(ddr_wusero_last),
        .busy(), .owner_camera()
    );
endmodule

