#define ITERATIONS 10
#define PERFORMANCE_RUN 1
#define VALIDATION_RUN 0
#define PROFILE_RUN 0
#define CORE_CLOCKS_PER_SEC 49500000ULL
#define COMPILER_VERSION "GCC 16.2.0 (riscv32-unknown-elf)"
#define COMPILER_FLAGS "-O2 -march=rv32ima_zicsr_zifencei -mabi=ilp32 -mcmodel=medany -mno-relax -msmall-data-limit=0 -mstrict-align -ffreestanding -fno-builtin -fno-common -ffunction-sections -fdata-sections"
