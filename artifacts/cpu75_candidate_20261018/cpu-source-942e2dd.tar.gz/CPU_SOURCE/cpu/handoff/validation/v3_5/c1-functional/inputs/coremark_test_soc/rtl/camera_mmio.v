`timescale 1ns/1ps

// Bootloader-facing camera control/status block.
// Base address: 0x1fe1_2000.  All counters and status inputs are synchronized
// into clk by the integrating top level before they reach this module.
module camera_mmio (
    input  wire        clk,
    input  wire        resetn,
    input  wire [31:0] addr,
    input  wire        wr,
    input  wire [31:0] wdata,
    input  wire [3:0]  wstrb,
    output reg  [31:0] rdata,
    output wire        hit,

    output reg         enable,
    output reg         stop_request,

    input  wire        cmos1_init_done,
    input  wire        cmos2_init_done,
    input  wire        frame_valid,
    input  wire        writer_busy,
    input  wire        idle,
    input  wire        stopping,
    input  wire        completed_buffer,
    input  wire        sccb_nack,
    input  wire        frame_error,
    input  wire        ddr_error,
    input  wire [31:0] frame_count,
    input  wire [31:0] dropped_count,
    input  wire [31:0] bad_line_count
);
    assign hit = (addr >= 32'h1fe1_2000) && (addr < 32'h1fe1_2020);

    always @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            enable       <= 1'b0;
            stop_request <= 1'b0;
        end else if (hit && wr && (addr[4:2] == 3'd2) && wstrb[0]) begin
            enable       <= wdata[0];
            stop_request <= wdata[1];
        end
    end

    always @* begin
        rdata = 32'd0;
        if (hit) begin
            case (addr[4:2])
                3'd0: rdata = 32'h4341_4d33; // "CAM3"
                3'd1: rdata = 32'h0001_0000;
                3'd2: rdata = {30'd0, stop_request, enable};
                3'd3: rdata = {
                    21'd0,
                    ddr_error,
                    frame_error,
                    sccb_nack,
                    completed_buffer,
                    stopping,
                    idle,
                    writer_busy,
                    frame_valid,
                    cmos2_init_done,
                    cmos1_init_done,
                    enable
                };
                3'd4: rdata = frame_count;
                3'd5: rdata = dropped_count;
                3'd6: rdata = bad_line_count;
                default: rdata = 32'd0;
            endcase
        end
    end
endmodule
