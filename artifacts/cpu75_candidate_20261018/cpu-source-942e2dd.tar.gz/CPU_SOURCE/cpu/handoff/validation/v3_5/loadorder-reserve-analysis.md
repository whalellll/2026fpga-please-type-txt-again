# LoadOrder 备用分析：尚未实现

本记录是 2026-10-08 C1 源码冻结后的只读分析，不属于 C1 改动，也不是时序改善证据。
当前 C1 完整单元回归为 32 suite / 93 tests PASS；没有为此分析修改 Scala 或生成 RTL。

## 证据

根任务读取的基线 div15 完整布局布线报告显示，slow CPU 最大路径为
`memory/u_lsu/loadOrder/barrierTag_0[2]` 到 `loadOrder/poisonTag[0..2]/CE`：
logic 2.932 ns、route 11.648 ns（79.890%）、WNS +1.665 ns。
这是已知基线关键路径；C1 新布局布线结果仍未产生。

`src/main/scala/e91c/mem/LoadOrderQueue.scala:124–148` 的 `CompactLoadOrderQueue`
先做四个 barrier tag 比较、签名/byte-mask 冲突判定，再由 Scala 展开的四项循环维护
`selectedTag`、`selectedDistance` 和 `selectedValid`。每一项的选择依赖上一项 mux 后的距离。
最后对 mux 后的 `selectedTag` 计算相对 ROB head 的年龄，并与已登记 poison 年龄比较。
生成 `CoreTop.sv:3973–4012` 对应串联的 `take_1`、`take_2`、最后一级 tag mux 和 `_GEN_10`。
Scala 循环已展开为常量索引逻辑；本问题不是 Verilog procedural integer 索引。

## 无新增周期的候选重组

保留四项存储、所有 reserve/resolve/store/flush 优先级、poison 注册时刻和 replay 接口。
对每项独立计算：

* `d_i = (ordinal(loadTag_i) - ordinal(storeTag)) mod 32`。
* `a_i = (ordinal(loadTag_i) - ordinal(headTag)) mod 32`。
* 六个两两距离比较，得到每一项的固定索引胜出条件。

第 i 项胜出条件为它冲突，且对所有更低索引的冲突项 `d_i < d_j`，
对所有更高索引的冲突项 `d_i <= d_j`。这保留现有严格小于更新所规定的低索引平局优先。
四个胜出项应恰好 one-hot 或全零。以固定宽度掩码和 OR 生成 selectedTag；
poison 写使能直接归约 `winner_i && (!poisonValid || a_i < poisonAge)`，
不用在最后 mux 后再做一次减法。`io.storeValid`、reset/flush 优先级保持原样。

这将 barrierMatch 到 CE 的依赖从串行距离选择、tag mux、减法、比较，
改为冲突屏蔽与已并行计算的年龄比较归约。不能把“当前 live 项通常只有一个”或
“head 与 store 的相对位置”作为等价前提；对任意 5-bit tag、冲突掩码和平局均应保持原行为。
必须使用常量索引表达式，不能引入 procedural integer 索引优先器。

## 代价和风险

没有额外流水级或预计周期收益。静态比较器由三项串行比较增至六个两两比较，
head-relative 年龄减法从 selectedTag/poison 两个增至四项/poison 五个；没有新增队列容量或 DRM。
精确 LUT/布线代价需 ADS 决定，额外 head/store 扇出和交叉连线可能抵消逻辑深度收益。
原路径近 80% 是布线，不能依据组合层级直接预言频率上升。
现有四项测试中的倒序分配、wrap、mask、清空和精确 replay 必须继续通过。

## 实施条件和验证

只在本轮 C1 PnR 显示该路径仍限制目标频率，并且预算保留最终构建与 59.4 MHz 对照后考虑。
实现前补充旧算法参考模型的定向/随机等价测试：四项全部冲突、每种子集、最低索引平局、
所有 head/store 边界、旧 poison 更老/更年轻、连续 store 使 poison 更换、flush 优先、
同拍 reserve/resolve/store 的现有更新优先级。

若实施，执行 LoadOrder/Commit/LSU 定向、完整现有回归及相同固件短 CoreMark，
要求 ticks 与未改选择器的 C1 完全相同；重新生成和同步，ADS 检查所有四项冲突、年龄、
poison valid/tag 控制均保留，再进行实际 PnR 双 corner/资源/CDC 检查及受影响板测。
只有实际时间改善且周期完全不变、资源门槛不变时，才接受此替代。
