`timescale 1ns / 1ps

// AXI3/AXI4-compatible single-port slave used by the E80 core.  It accepts
// one read and one write transaction at a time.  SOC_USE serializes requests
// in axi_line_bridge, while this slave still implements all 8 beats of a
// 32-byte cache-line transfer and preserves IDs and WSTRB.
module axi_bram_uart #(
    parameter [31:0] BRAM_BASE = 32'h1c00_0000,
    parameter integer BRAM_BYTES = 128 * 1024,
    parameter [31:0] UART_BASE = 32'h1fe0_01e0,
    parameter [31:0] GPIO_BASE = 32'h1fe0_0000,
    parameter INIT_FILE = "ram.hex",
    parameter integer UART_BAUD_DIV = 234
)(
    input  wire        clk,
    input  wire        resetn,

    input  wire [3:0]  arid,
    input  wire [31:0] araddr,
    input  wire [7:0]  arlen,
    input  wire [2:0]  arsize,
    input  wire [1:0]  arburst,
    input  wire        arvalid,
    output wire        arready,
    output reg  [3:0]  rid,
    output reg  [31:0] rdata,
    output reg  [1:0]  rresp,
    output reg         rlast,
    output reg         rvalid,
    input  wire        rready,

    input  wire [3:0]  awid,
    input  wire [31:0] awaddr,
    input  wire [7:0]  awlen,
    input  wire [2:0]  awsize,
    input  wire [1:0]  awburst,
    input  wire        awvalid,
    output wire        awready,
    input  wire [3:0]  wid,
    input  wire [31:0] wdata,
    input  wire [3:0]  wstrb,
    input  wire        wlast,
    input  wire        wvalid,
    output wire        wready,
    output reg  [3:0]  bid,
    output reg  [1:0]  bresp,
    output reg         bvalid,
    input  wire        bready,

    input  wire        uart_rx,
    output wire        uart_tx,
    input  wire [31:0] gpio_in,
    output reg  [31:0] gpio_out,
    output reg  [31:0] gpio_oe
);

    localparam integer BRAM_WORDS = BRAM_BYTES / 4;
    localparam [1:0] AXI_OKAY   = 2'b00;
    localparam [1:0] AXI_DECERR = 2'b11;

    reg [31:0] memory [0:BRAM_WORDS-1] /* synthesis syn_ramstyle = "block_ram" */;
    initial $readmemh(INIT_FILE, memory);

    reg [31:0] gpio_meta, gpio_sync;
    always @(posedge clk) begin
        if (!resetn) begin gpio_meta <= 0; gpio_sync <= 0; end
        else begin gpio_meta <= gpio_in; gpio_sync <= gpio_meta; end
    end

    reg        rd_active;
    reg [31:0] rd_addr;
    reg [7:0]  rd_len;
    reg [7:0]  rd_beat;
    reg [2:0]  rd_size;
    reg [1:0]  rd_burst;
    reg        rd_bad_request;
    reg        rd_rbr_pop_pending;

    wire [31:0] uart_lsr_word =
        {16'b0, 1'b0, uart_idle, uart_empty, 4'b0, !uart_rx_empty, 8'b0};

    wire [7:0] uart_rx_data;
    wire uart_rx_full;
    wire uart_rx_empty;
    // Pop only when an RBR response which actually captured a byte is
    // accepted.  rdata and the FIFO front therefore remain stable for an
    // arbitrarily long R-channel stall.
    wire uart_rx_pop = rvalid && rready && rd_rbr_pop_pending;

    assign arready = !rd_active && !rvalid;

    always @(posedge clk) begin
        if (!resetn) begin
            rd_active      <= 1'b0;
            rd_addr        <= 32'b0;
            rd_len         <= 8'b0;
            rd_beat        <= 8'b0;
            rd_size        <= 3'b0;
            rd_burst       <= 2'b0;
            rd_bad_request <= 1'b0;
            rid            <= 4'b0;
            rdata          <= 32'b0;
            rresp          <= AXI_OKAY;
            rlast          <= 1'b0;
            rvalid         <= 1'b0;
            rd_rbr_pop_pending <= 1'b0;
        end else begin
            if (arvalid && arready) begin
                rd_active      <= 1'b1;
                rd_addr        <= araddr;
                rd_len         <= arlen;
                rd_beat        <= 8'b0;
                rd_size        <= arsize;
                rd_burst       <= arburst;
                rd_bad_request <= (arlen > 8'd7) || (arsize > 3'd2) ||
                                  ((arburst != 2'b00) && (arburst != 2'b01));
                rid            <= arid;
            end

            if (rd_active && !rvalid) begin
                rlast <= (rd_beat == rd_len);
                rd_rbr_pop_pending <= 1'b0;
                if (!rd_bad_request && (rd_addr >= BRAM_BASE) && (rd_addr < BRAM_BASE + BRAM_BYTES)) begin
                    rdata <= memory[(rd_addr - BRAM_BASE) >> 2];
                    rresp <= AXI_OKAY;
                end else if (!rd_bad_request && ((rd_addr & 32'hffff_fffc) == UART_BASE)) begin
                    rdata <= {24'b0, uart_rx_data};
                    rresp <= AXI_OKAY;
                    rd_rbr_pop_pending <= !uart_rx_empty;
                end else if (!rd_bad_request && ((rd_addr & 32'hffff_fffc) == (UART_BASE + 32'd4))) begin
                    rdata <= uart_lsr_word;
                    rresp <= AXI_OKAY;
                end else if (!rd_bad_request && ((rd_addr & 32'hffff_fffc) == GPIO_BASE)) begin
                    rdata <= gpio_sync; rresp <= AXI_OKAY;
                end else if (!rd_bad_request && ((rd_addr & 32'hffff_fffc) == GPIO_BASE + 32'd4)) begin
                    rdata <= gpio_out; rresp <= AXI_OKAY;
                end else if (!rd_bad_request && ((rd_addr & 32'hffff_fffc) == GPIO_BASE + 32'd8)) begin
                    rdata <= gpio_oe; rresp <= AXI_OKAY;
                end else begin
                    rdata <= 32'b0;
                    rresp <= AXI_DECERR;
                end
                rvalid <= 1'b1;
            end else if (rvalid && rready) begin
                rvalid <= 1'b0;
                rd_rbr_pop_pending <= 1'b0;
                if (rlast) begin
                    rd_active <= 1'b0;
                end else begin
                    rd_beat <= rd_beat + 8'd1;
                    rd_addr <= (rd_burst == 2'b01) ? rd_addr + (32'd1 << rd_size) : rd_addr;
                end
            end
        end
    end

    reg        wr_active;
    reg [31:0] wr_addr;
    reg [7:0]  wr_len;
    reg [7:0]  wr_beat;
    reg [2:0]  wr_size;
    reg [1:0]  wr_burst;
    reg [3:0]  wr_id;
    reg        wr_error;

    wire wr_to_bram = (wr_addr >= BRAM_BASE) && (wr_addr < BRAM_BASE + BRAM_BYTES);
    wire wr_to_uart = ((wr_addr & 32'hffff_fffc) == UART_BASE);
    wire wr_gpio_out = ((wr_addr & 32'hffff_fffc) == GPIO_BASE + 32'd4);
    wire wr_gpio_oe = ((wr_addr & 32'hffff_fffc) == GPIO_BASE + 32'd8);
    wire wr_target_ok = wr_to_bram || wr_to_uart || wr_gpio_out || wr_gpio_oe;
    wire wr_expected_last = (wr_beat == wr_len);
    wire write_beat_valid = !wr_error && wr_target_ok && (wid == wr_id)
                          && (wlast == wr_expected_last);
    wire uart_push = wr_active && wvalid && wready && wr_to_uart
                   && write_beat_valid && (|wstrb);
    wire [7:0] uart_push_data = wstrb[0] ? wdata[7:0] :
                                wstrb[1] ? wdata[15:8] :
                                wstrb[2] ? wdata[23:16] : wdata[31:24];
    wire uart_full;
    wire uart_empty;
    wire uart_idle;

    assign awready = !wr_active && !bvalid;
    assign wready  = wr_active && (wr_to_bram || !wr_to_uart || !uart_full);

    uart_tx_fifo #(
        .BAUD_DIV(UART_BAUD_DIV),
        .FIFO_DEPTH(16),
        .PTR_W(4)
    ) u_uart_tx (
        .clk       (clk),
        .resetn    (resetn),
        .push      (uart_push),
        .push_data (uart_push_data),
        .full      (uart_full),
        .empty     (uart_empty),
        .idle      (uart_idle),
        .tx        (uart_tx)
    );

    uart_rx_fifo #(
        .BAUD_DIV (UART_BAUD_DIV),
        .FIFO_DEPTH(16),
        .PTR_W     (4)
    ) u_uart_rx (
        .clk   (clk),
        .resetn(resetn),
        .rx    (uart_rx),
        .pop   (uart_rx_pop),
        .data  (uart_rx_data),
        .full  (uart_rx_full),
        .empty (uart_rx_empty)
    );

    always @(posedge clk) begin : write_channel
        integer word_index;
        integer byte_index;
        if (!resetn) begin
            gpio_out <= 0;
            gpio_oe <= 0;
            wr_active <= 1'b0;
            wr_addr   <= 32'b0;
            wr_len    <= 8'b0;
            wr_beat   <= 8'b0;
            wr_size   <= 3'b0;
            wr_burst  <= 2'b0;
            wr_id     <= 4'b0;
            wr_error  <= 1'b0;
            bid       <= 4'b0;
            bresp     <= AXI_OKAY;
            bvalid    <= 1'b0;
        end else begin
            if (awvalid && awready) begin
                wr_active <= 1'b1;
                wr_addr   <= awaddr;
                wr_len    <= awlen;
                wr_beat   <= 8'b0;
                wr_size   <= awsize;
                wr_burst  <= awburst;
                wr_id     <= awid;
                wr_error  <= (awlen > 8'd7) || (awsize > 3'd2) ||
                             ((awburst != 2'b00) && (awburst != 2'b01));
            end

            if (wr_active && wvalid && wready) begin
                for (byte_index = 0; byte_index < 4; byte_index = byte_index + 1) begin
                    if (write_beat_valid && wstrb[byte_index]) begin
                        if (wr_gpio_out) gpio_out[byte_index*8 +: 8] <= wdata[byte_index*8 +: 8];
                        if (wr_gpio_oe) gpio_oe[byte_index*8 +: 8] <= wdata[byte_index*8 +: 8];
                    end
                end
                if (wr_to_bram && write_beat_valid) begin
                    word_index = (wr_addr - BRAM_BASE) >> 2;
                    if (wstrb[0]) memory[word_index][7:0]   <= wdata[7:0];
                    if (wstrb[1]) memory[word_index][15:8]  <= wdata[15:8];
                    if (wstrb[2]) memory[word_index][23:16] <= wdata[23:16];
                    if (wstrb[3]) memory[word_index][31:24] <= wdata[31:24];
                end

                if (!wr_target_ok || (wid != wr_id) || (wlast != wr_expected_last))
                    wr_error <= 1'b1;

                if (wlast || wr_expected_last) begin
                    wr_active <= 1'b0;
                    bid       <= wr_id;
                    bresp     <= (wr_error || !wr_target_ok ||
                                  (wid != wr_id) || (wlast != wr_expected_last))
                                 ? AXI_DECERR : AXI_OKAY;
                    bvalid    <= 1'b1;
                end else begin
                    wr_beat <= wr_beat + 8'd1;
                    wr_addr <= (wr_burst == 2'b01) ? wr_addr + (32'd1 << wr_size) : wr_addr;
                end
            end

            if (bvalid && bready)
                bvalid <= 1'b0;
        end
    end

endmodule
