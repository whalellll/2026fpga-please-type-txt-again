# Current performance_soc physical address map

Validation date: 2026-10-01. These are directed Chisel tests, before the unified RTL export and SoC integration regression.

The CPU now classifies only `0x02000000–0x0200ffff` (CLINT) and `0x1fe00000–0x1fefffff` (SoC MMIO) as devices and rejects instruction fetches there. Former standalone PLIC, UART and peripheral windows are ordinary low DDR. The uncached data alias `0x80000000–0xbfffffff` and data-only DMA BRAM carveout `0x1c018000–0x1c01bfff` are preserved. Broad RAM access permissions remain unchanged; unmapped transactions are handled by the AXI fabric.

## Reproduction

Run from `cpu-v15` with the JDK 17 / sbt 1.10.1 environment described by the repository setup guide:

```text
sbt "testOnly e91c.PhysicalMemoryAttributesSpec e91c.PmaMmuSpec e91c.IntegrationAddressMapSpec e91c.MachineCsrSpec"
```

- `red.log`: before the map fix, `testOnly e91c.IntegrationAddressMapSpec -- -z former` ran the two newly added PLIC/UART cases. Both failed because instruction fault `64` was returned instead of `0`. Total sbt time: 95 s.
- `green.log`: after the fix, all 13 tests across the four suites passed. Test execution: 47.565 s; total sbt time: 128 s.
- `result.json`: commands, outcomes and source hashes for this validation.

Coverage includes both sides of the CLINT and former peripheral boundaries, every 64 KiB subwindow in the full 1 MiB SoC MMIO aperture, the former PLIC/UART ranges, low/high DDR aliases, the DMA data carveout, and attributes after Sv32 translation. Existing one-entry Sv32 dynamic-index elaboration warnings remain in the logs; there were no failed or aborted suites in the green run.
