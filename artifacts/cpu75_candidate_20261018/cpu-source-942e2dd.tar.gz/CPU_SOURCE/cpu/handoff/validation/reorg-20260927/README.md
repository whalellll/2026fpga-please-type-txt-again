# V15 整理目录的本机复现证据（2026-09-27）

这是 D:\LJL\WORK\GitHub\src 独立仓库的实际运行，原始提交 ab617dccfff52e252fc37a433cf6d77722b3dde9，整理分支 cpu-v15-reorg-20260927。只改变布局、忽略规则、清单与文档，不改变处理器逻辑。

- run-summary.json：真实阶段结果、固定 RTL 哈希、CoreMark 结果与本机综合基线。
- protected-before.json：整理前 120 个受保护文件的逐文件 SHA256 与长度；整理后及提交索引逐项比对。
- moved-file-hashes.json：13 个移动文件的原/新路径与不变 SHA256。
- references-before.txt：移动/删除之前的引用清单。这里保留旧路径作为审计历史，不是当前入口。
- doctor.log、emit.log、unit-stage.log、functional-stage.log、rvc-stage.log、coremark-stage.log、synthesis-stage.log：实际入口输出，保留原始编码。
- unit/、functional/、rvc/：本次测试 XML、运行日志及输入哈希。
- coremark-run.log、coremark-inputs.sha256：本次 CoreMark 的原始串口结果与输入哈希。相同的历史结果 JSON 统一使用 ../coremark-result.json；run-summary.json 也记录本次解析出的结果。
- identical-run-evidence.json：本次与历史内容完全相同的 oracle 对照，保留历史文件，不重复跟踪副本。
- synthesis/：本次 PDS 完整日志、报告、输入哈希与 staging 路径。原始 evidence/v15/ 不被覆盖。

固定固件为 rv32im_zicsr，10 次 RTL 校准；总 ticks 1,987,946，5.030317724928142/MHz，CRC e714/1fd7/8e3a/fcaf。日志中不足十秒的提示仍保留，不能作为正式 CoreMark 或带 C 固件成绩。

PDS 2022.2-SP6.4 build 146967 实际复现完整顶层 24,138 LUT、CPU 核 19,654 LUT、cpu_clk WNS −0.180 ns @9.0909 ns。只有综合，没有布局布线签核，没有正时序声明。

自动审批以 blocked by policy 拒绝删除已搬空的旧验证目录，以及 Emit 重建的 null/ 缓存。旧目录没有文件；约 9.8 MB firtool 缓存被忽略，不进入 Git。这是本地清理的剩余限制，不影响文件清单或复现验收。
