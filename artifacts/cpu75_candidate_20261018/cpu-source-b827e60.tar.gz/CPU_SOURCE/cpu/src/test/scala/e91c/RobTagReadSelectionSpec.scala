package e91c

import chisel3._
import chiseltest._
import e91c.reg.RobTagRegisterFile
import org.scalatest.flatspec.AnyFlatSpec

class RobTagReadSelectionSpec extends AnyFlatSpec with ChiselScalatestTester {
  behavior of "ROB result read selection"

  it should "match all banks, collision priorities and tag lifetimes at every read port" in {
    test(new RobTagRegisterFile(8)) { d =>
      val values = Array.fill[BigInt](32)(0)
      val valid = Array.fill(32)(false)
      val live = Array.fill(32)(false)
      val random = new scala.util.Random(750019L)
      def idle(): Unit = {
        d.io.flush.poke(false.B)
        for (i <- 0 until 2) {
          d.io.clear(i).poke(false.B); d.io.allocate(i).poke(false.B)
          d.io.allocateTag(i).poke(0.U); d.io.retire(i).poke(false.B)
          d.io.retireRd(i).poke(0.U); d.io.retireTag(i).poke(0.U)
          d.io.retireData(i).poke(0.U)
        }
        for (i <- 0 until 5) {
          d.io.write(i).poke(false.B); d.io.writeTag(i).poke(0.U)
          d.io.writeData(i).poke(0.U)
        }
        for (i <- 0 until 4) d.io.archRead(i).poke(0.U)
      }
      def check(offset: Int): Unit = {
        // Set all independent read addresses before evaluating the outputs.
        // Rotate the offset so every tag appears at every read port.
        val tags = (0 until 8).map(port => (offset + port * 4) % 32)
        for (port <- 0 until 8) d.io.tagRead(port).poke(tags(port).U)
        for (port <- 0 until 8) {
          val tag = tags(port)
          d.io.tagData(port).expect((if (valid(tag)) values(tag) else BigInt(0)).U)
        }
      }
      idle(); d.clock.step()
      for (tag <- 0 until 32 by 2) {
        idle()
        for (lane <- 0 until 2) {
          d.io.clear(lane).poke(true.B); d.io.allocate(lane).poke(true.B)
          d.io.allocateTag(lane).poke((tag + lane).U); live(tag + lane) = true
        }
        d.clock.step()
      }
      // All 32 write masks on each tag, including simultaneous producers.
      for (tag <- 0 until 32; mask <- 0 until 32) {
        idle()
        for (port <- 0 until 5) {
          val data = BigInt(32, random)
          d.io.write(port).poke(((mask & (1 << port)) != 0).B)
          d.io.writeTag(port).poke(tag.U); d.io.writeData(port).poke(data.U)
          if ((mask & (1 << port)) != 0) { values(tag) = data; valid(tag) = true }
        }
        d.clock.step(); check(tag)
      }
      // Concurrent independent writes, flush, stale writers and clear winning
      // over a same-cycle write. Reads retain their original zero-cycle latency.
      for (cycle <- 0 until 1536) {
        idle()
        val flush = cycle % 113 == 0
        d.io.flush.poke(flush.B)
        for (port <- 0 until 5) {
          val tag = random.nextInt(32); val enable = random.nextBoolean()
          val data = BigInt(32, random)
          d.io.write(port).poke(enable.B); d.io.writeTag(port).poke(tag.U)
          d.io.writeData(port).poke(data.U)
          if (enable && live(tag) && !flush) { values(tag) = data; valid(tag) = true }
        }
        if (flush) java.util.Arrays.fill(live, false)
        else {
          val free = live.indices.filterNot(live(_)).take(2)
          for ((tag, lane) <- free.zipWithIndex) {
            d.io.allocate(lane).poke(true.B); d.io.clear(lane).poke(true.B)
            d.io.allocateTag(lane).poke(tag.U); live(tag) = true; valid(tag) = false
          }
          if (free.isEmpty && cycle % 17 == 0) {
            val tag = random.nextInt(32)
            d.io.clear(0).poke(true.B); d.io.allocateTag(0).poke(tag.U)
            valid(tag) = false
          }
        }
        d.clock.step(); check(cycle % 32)
      }
    }
  }
}
