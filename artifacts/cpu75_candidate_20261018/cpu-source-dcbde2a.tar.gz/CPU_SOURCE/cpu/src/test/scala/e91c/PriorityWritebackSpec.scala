package e91c

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import e91c.util.PriorityWriteback

class PriorityWritebackHarness extends Module {
  val io = IO(new Bundle {
    val matches = Input(Vec(5, Bool()))
    val data = Input(Vec(5, UInt(32.W)))
    val result = Output(UInt(32.W))
  })
  io.result := PriorityWriteback(io.matches.toSeq, io.data.toSeq)
}

class PriorityWritebackSpec extends AnyFlatSpec with ChiselScalatestTester {
  "writeback selection" should "preserve all 32 masks including collisions and the no-hit payload" in {
    test(new PriorityWritebackHarness) { d =>
      val rng = new scala.util.Random(750018)
      for (mask <- 0 until 32; trial <- 0 until 128) {
        val values = (0 until 5).map { port =>
          if (trial < 32) BigInt(1) << ((trial + port * 7) % 32)
          else if (trial == 32) BigInt("ffffffff", 16)
          else BigInt(32, rng)
        }
        for (port <- 0 until 5) {
          d.io.matches(port).poke(((mask & (1 << port)) != 0).B)
          d.io.data(port).poke(values(port).U)
        }
        val winner = (0 until 5).find(p => (mask & (1 << p)) != 0).getOrElse(0)
        d.io.result.expect(values(winner).U)
        d.clock.step()
      }
    }
  }
}
