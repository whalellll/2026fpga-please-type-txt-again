package e91c.util

import chisel3._
import chisel3.util.Mux1H

/** Lowest numbered matching port wins; no match returns port zero. */
object PriorityWriteback {
  def apply(matches: Seq[Bool], data: Seq[UInt]): UInt = {
    require(matches.size == 5 && data.size == 5)
    val mask = VecInit(matches).asUInt
    // Resolve collisions once in the narrow control path. Each data bit sees
    // the same exclusive grants instead of a binary encoder and wide mux.
    val grants = matches.indices.map { i =>
      if (i == 0) matches.head || !mask.orR
      else matches(i) && !VecInit(matches.take(i)).asUInt.orR
    }
    Mux1H(grants, data)
  }
}
